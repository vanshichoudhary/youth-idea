import React from 'react';
import Link from 'next/link';
import { FiCalendar, FiMapPin, FiClock, FiArrowLeft } from 'react-icons/fi';

// Mock data for events
const events = [
  {
    id: 1,
    title: 'Youth Leadership Summit 2025',
    image: 'https://ext.same-assets.com/2636907205/3475345170.webp',
    date: 'May 15, 2025',
    location: 'Delhi, India',
    time: '9:00 AM - 5:00 PM',
    description: 'Join us for the largest youth leadership summit in India. Featuring keynote speakers from various industries and interactive workshops designed to enhance your leadership skills.',
    fullDescription: `
      <p>The Youth Leadership Summit 2025 is a premier event designed to bring together young leaders from across India to network, learn, and grow. This full-day event will feature keynote speeches, panel discussions, interactive workshops, and networking opportunities.</p>

      <h3>What to Expect</h3>
      <ul>
        <li>Inspiring keynote speeches from industry leaders</li>
        <li>Interactive workshops on leadership, communication, and problem-solving</li>
        <li>Networking opportunities with like-minded individuals</li>
        <li>Career guidance sessions with professional mentors</li>
        <li>Certificate of participation</li>
      </ul>

      <h3>Speakers</h3>
      <p>We have an exciting lineup of speakers from various industries, including business, technology, social impact, and arts. Our confirmed speakers include CEOs, entrepreneurs, and thought leaders who will share their experiences and insights.</p>

      <h3>Registration</h3>
      <p>Registration is required to attend this event. Early bird registration is available until April 15, 2025. The registration fee includes access to all sessions, lunch, refreshments, and materials.</p>
    `
  },
  {
    id: 2,
    title: 'Workshop on AI and Machine Learning for Beginners',
    image: 'https://ext.same-assets.com/2636907205/4196539442.webp',
    date: 'April 20, 2025',
    location: 'Online',
    time: '2:00 PM - 4:00 PM',
    description: 'A beginner-friendly workshop covering the basics of AI and machine learning. Learn how to get started with programming and implementing simple AI models.',
    fullDescription: `
      <p>This online workshop is designed for beginners who want to learn about Artificial Intelligence and Machine Learning. No prior experience in programming or AI is required.</p>

      <h3>Workshop Content</h3>
      <ul>
        <li>Introduction to AI and Machine Learning concepts</li>
        <li>Overview of programming languages used in AI</li>
        <li>Hands-on exercises with simple AI models</li>
        <li>Resources for further learning</li>
      </ul>

      <h3>What You Need</h3>
      <p>Participants should have a computer with internet connection. All tools and software will be provided during the workshop.</p>

      <h3>Registration</h3>
      <p>This workshop is free to attend, but registration is required as spaces are limited. Registered participants will receive the workshop link and materials via email.</p>
    `
  },
  {
    id: 3,
    title: 'Entrepreneurship Bootcamp - From Idea to Business',
    image: 'https://ext.same-assets.com/2636907205/3843830320.webp',
    date: 'June 5-7, 2025',
    location: 'Mumbai, India',
    time: '10:00 AM - 4:00 PM',
    description: 'A three-day intensive bootcamp designed to help you transform your ideas into viable business ventures. Includes mentorship from successful entrepreneurs and hands-on sessions on business development.',
    fullDescription: `
      <p>The Entrepreneurship Bootcamp is an intensive three-day program designed to help aspiring entrepreneurs transform their ideas into viable business ventures. The bootcamp will cover all aspects of starting and running a business, from ideation to execution.</p>

      <h3>Bootcamp Schedule</h3>
      <p><strong>Day 1:</strong> Idea Validation and Market Research</p>
      <p><strong>Day 2:</strong> Business Model Development and Financial Planning</p>
      <p><strong>Day 3:</strong> Pitching, Marketing, and Growth Strategies</p>

      <h3>Mentors</h3>
      <p>The bootcamp will feature mentorship from successful entrepreneurs and industry experts who will share their experiences and provide guidance on business development.</p>

      <h3>Who Should Attend</h3>
      <p>This bootcamp is ideal for:</p>
      <ul>
        <li>Aspiring entrepreneurs with business ideas</li>
        <li>Early-stage startup founders</li>
        <li>Students interested in entrepreneurship</li>
        <li>Professionals looking to transition to entrepreneurship</li>
      </ul>

      <h3>Registration</h3>
      <p>Registration fee includes access to all sessions, mentorship, meals, and materials. Early bird registration is available until May 15, 2025.</p>
    `
  },
  {
    id: 4,
    title: 'Digital Marketing Masterclass',
    image: 'https://ext.same-assets.com/2636907205/1175443342.webp',
    date: 'May 25, 2025',
    location: 'Bangalore, India',
    time: '11:00 AM - 3:00 PM',
    description: 'Learn the most effective digital marketing strategies from industry experts. This masterclass covers social media marketing, SEO, content marketing, and analytics.',
    fullDescription: `
      <p>The Digital Marketing Masterclass is a comprehensive session covering the latest strategies and techniques in digital marketing. This masterclass is designed for beginners as well as those with some experience in marketing who want to enhance their digital skills.</p>

      <h3>Topics Covered</h3>
      <ul>
        <li>Social Media Marketing: Strategies for major platforms</li>
        <li>Search Engine Optimization: Getting your content found</li>
        <li>Content Marketing: Creating valuable and engaging content</li>
        <li>Email Marketing: Building and nurturing your audience</li>
        <li>Analytics: Measuring and improving your results</li>
      </ul>

      <h3>What You'll Learn</h3>
      <p>By the end of this masterclass, you will have a solid understanding of digital marketing principles and practical skills that you can apply immediately. You will also receive a digital marketing toolkit with templates and resources.</p>

      <h3>Registration</h3>
      <p>Registration includes access to the masterclass, lunch, and digital marketing toolkit. Group discounts are available for organizations sending multiple participants.</p>
    `
  }
];

export function generateStaticParams() {
  return events.map((event) => ({
    id: event.id.toString(),
  }));
}

export default function EventPage({ params }: { params: { id: string } }) {
  // Find the event by ID
  const event = events.find((e) => e.id.toString() === params.id);

  if (!event) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Event Not Found</h1>
        <p className="mb-6">The event you're looking for doesn't exist or has been removed.</p>
        <Link
          href="/events"
          className="inline-flex items-center text-primary hover:underline"
        >
          <FiArrowLeft className="mr-2" /> Back to Events
        </Link>
      </div>
    );
  }

  return (
    <div className="pb-16">
      <div className="relative">
        <div className="w-full h-80">
          <img
            src={event.image}
            alt={event.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40" />
          <div className="absolute bottom-0 left-0 w-full p-6">
            <div className="container mx-auto">
              <Link
                href="/events"
                className="inline-flex items-center text-white mb-4 hover:underline"
              >
                <FiArrowLeft className="mr-2" /> Back to Events
              </Link>
              <h1 className="text-3xl font-bold text-white">{event.title}</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <div className="prose prose-slate max-w-none" dangerouslySetInnerHTML={{ __html: event.fullDescription }} />
          </div>

          <div>
            <div className="bg-white rounded-lg shadow-sm p-6 sticky top-20">
              <h3 className="text-xl font-bold mb-4">Event Details</h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <FiCalendar className="mt-1 mr-3 text-primary" size={18} />
                  <div>
                    <div className="font-medium">Date</div>
                    <div className="text-muted-foreground">{event.date}</div>
                  </div>
                </div>
                <div className="flex items-start">
                  <FiClock className="mt-1 mr-3 text-primary" size={18} />
                  <div>
                    <div className="font-medium">Time</div>
                    <div className="text-muted-foreground">{event.time}</div>
                  </div>
                </div>
                <div className="flex items-start">
                  <FiMapPin className="mt-1 mr-3 text-primary" size={18} />
                  <div>
                    <div className="font-medium">Location</div>
                    <div className="text-muted-foreground">{event.location}</div>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <button className="w-full bg-primary text-white py-3 rounded-md font-medium hover:bg-primary/90">
                  Register Now
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
