'use client';

import React from 'react';
import Link from 'next/link';
import { FiCalendar, FiMapPin, FiClock } from 'react-icons/fi';

// Mock data for events
const events = [
  {
    id: 1,
    title: 'Youth Leadership Summit 2025',
    image: 'https://ext.same-assets.com/2636907205/3475345170.webp',
    date: 'May 15, 2025',
    location: 'Delhi, India',
    time: '9:00 AM - 5:00 PM',
    description: 'Join us for the largest youth leadership summit in India. Featuring keynote speakers from various industries and interactive workshops designed to enhance your leadership skills.'
  },
  {
    id: 2,
    title: 'Workshop on AI and Machine Learning for Beginners',
    image: 'https://ext.same-assets.com/2636907205/4196539442.webp',
    date: 'April 20, 2025',
    location: 'Online',
    time: '2:00 PM - 4:00 PM',
    description: 'A beginner-friendly workshop covering the basics of AI and machine learning. Learn how to get started with programming and implementing simple AI models.'
  },
  {
    id: 3,
    title: 'Entrepreneurship Bootcamp - From Idea to Business',
    image: 'https://ext.same-assets.com/2636907205/3843830320.webp',
    date: 'June 5-7, 2025',
    location: 'Mumbai, India',
    time: '10:00 AM - 4:00 PM',
    description: 'A three-day intensive bootcamp designed to help you transform your ideas into viable business ventures. Includes mentorship from successful entrepreneurs and hands-on sessions on business development.'
  },
  {
    id: 4,
    title: 'Digital Marketing Masterclass',
    image: 'https://ext.same-assets.com/2636907205/1175443342.webp',
    date: 'May 25, 2025',
    location: 'Bangalore, India',
    time: '11:00 AM - 3:00 PM',
    description: 'Learn the most effective digital marketing strategies from industry experts. This masterclass covers social media marketing, SEO, content marketing, and analytics.'
  }
];

export default function EventsPage() {
  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">Upcoming Events</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {events.map((event) => (
            <div key={event.id} className="bg-white rounded-lg overflow-hidden shadow-sm">
              <div className="h-48 overflow-hidden">
                <img
                  src={event.image}
                  alt={event.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{event.title}</h3>
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <FiCalendar className="mr-2" size={16} />
                    <span>{event.date}</span>
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <FiMapPin className="mr-2" size={16} />
                    <span>{event.location}</span>
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <FiClock className="mr-2" size={16} />
                    <span>{event.time}</span>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-4">{event.description}</p>
                <div className="flex justify-end">
                  <Link
                    href={`/event/${event.id}`}
                    className="bg-primary text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-primary/90"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
