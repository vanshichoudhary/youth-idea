import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "YouthStory - India's leading platform for young achievers",
  description: "India's leading platform where young achievers share inspiring success stories, access exclusive opportunities, scholarships, mentorship programs, skill development resources, and networking events.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Header />
        <main className="pb-20">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}
