'use client';

import React, { useState } from 'react';
import Link from 'next/link';

// Mock data for opportunities
const opportunities = [
  {
    id: 1,
    title: 'JOB POST: Software Developer – Analyst at Deloitte, Bangalore [Full Time, On-Site]: Apply Now',
    image: 'https://ext.same-assets.com/2636907205/206773026.webp',
    deadline: 'April 18, 2025',
    type: 'opportunity'
  },
  {
    id: 2,
    title: 'Essay Contest on International Day of Yoga 2025 by The Ministry of AYUSH in collaboration with MyGov [Cash Prizes of Rs. 32k]',
    image: 'https://ext.same-assets.com/2636907205/206773026.webp',
    deadline: 'April 30, 2025',
    type: 'opportunity'
  },
  {
    id: 3,
    title: 'Rajiv Gandhi Entrepreneurship Program [Karnataka Residents only, Grant of Rs.3L, 12 Month]',
    image: 'https://ext.same-assets.com/2636907205/134880545.webp',
    deadline: 'April 28, 2025',
    type: 'opportunity'
  },
  {
    id: 4,
    title: 'Youth Leadership Summit 2025 - Apply Now',
    image: 'https://ext.same-assets.com/2636907205/3475345170.webp',
    date: 'May 15, 2025',
    type: 'event'
  },
  {
    id: 5,
    title: 'Free Workshop on AI and Machine Learning for Beginners',
    image: 'https://ext.same-assets.com/2636907205/4196539442.webp',
    date: 'April 20, 2025',
    type: 'event'
  },
  {
    id: 6,
    title: 'Entrepreneurship Bootcamp - From Idea to Business',
    image: 'https://ext.same-assets.com/2636907205/3843830320.webp',
    date: 'June 5-7, 2025',
    type: 'event'
  },
  {
    id: 7,
    title: 'Free Ebook: Guide to Competitive Exams Preparation',
    image: 'https://ext.same-assets.com/2636907205/1175443342.webp',
    type: 'resource'
  },
  {
    id: 8,
    title: 'Free Video Course: Essential Soft Skills for Young Professionals',
    image: 'https://ext.same-assets.com/2636907205/212981899.webp',
    type: 'resource'
  }
];

export default function OpportunitiesPage() {
  const [activeTab, setActiveTab] = useState('opportunity'); // opportunity, event, resource

  const filteredItems = opportunities.filter((item) => item.type === activeTab);

  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">Opportunities</h1>

        <div className="flex flex-col md:flex-row items-center justify-center gap-4 mb-8">
          <button
            className={`px-6 py-2 font-medium ${activeTab === 'event' ? 'border-b-2 border-primary' : ''}`}
            onClick={() => setActiveTab('event')}
          >
            Events
          </button>
          <button
            className={`px-6 py-2 font-medium ${activeTab === 'opportunity' ? 'text-primary bg-primary/10 rounded-md' : ''}`}
            onClick={() => setActiveTab('opportunity')}
          >
            Opportunity
          </button>
          <button
            className={`px-6 py-2 font-medium ${activeTab === 'resource' ? 'border-b-2 border-primary' : ''}`}
            onClick={() => setActiveTab('resource')}
          >
            Resources
          </button>
        </div>

        <div className="space-y-4">
          {filteredItems.map((item) => (
            <div key={item.id} className="bg-background rounded-lg p-4 flex items-center">
              <div className="flex-shrink-0 mr-4">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-16 h-16 rounded-full object-cover"
                />
              </div>
              <div>
                <h3 className="font-bold">{item.title}</h3>
                {item.deadline && (
                  <p className="text-sm text-muted-foreground">Deadline: {item.deadline}</p>
                )}
                {item.date && (
                  <p className="text-sm text-muted-foreground">Date: {item.date}</p>
                )}
              </div>
            </div>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No items found in this category.</p>
          </div>
        )}
      </div>
    </div>
  );
}
