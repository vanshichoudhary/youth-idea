'use client';

import React from 'react';
import Link from 'next/link';
import StoryCard from '@/components/StoryCard';
import CategoryBadge from '@/components/CategoryBadge';
import { FiArrowRight } from 'react-icons/fi';

// Mock data for stories
const featuredStories = [
  {
    id: 72,
    title: 'Bridging Dreams and Realities Through Virtual Trust',
    category: 'Social Impact',
    author: 'Prakriti Tripathi',
    readTime: 14,
    imageSrc: 'https://ext.same-assets.com/3508645956/1955214707.webp'
  },
  {
    id: 71,
    title: 'From Gamer to Green Hero: A Teenager\'s Inspiring Story',
    category: 'Social Impact',
    author: 'Aditi Shree',
    readTime: 15,
    imageSrc: 'https://ext.same-assets.com/3508645956/646717528.webp'
  },
  {
    id: 70,
    title: 'Graphiedit: The Rising Powerhouse of 3D, VFX, & Motion Graphics',
    category: 'Innovation',
    author: 'Ishita Gangwar',
    readTime: 13,
    imageSrc: 'https://ext.same-assets.com/3508645956/449932634.webp'
  }
];

const topStories = [
  {
    id: 48,
    title: 'Neha Byadwal Quit Social Media to Become IAS at 24',
    category: 'Education',
    author: 'Shreeti Sinha',
    readTime: 15,
    imageSrc: 'https://ext.same-assets.com/2636907205/3393313470.webp'
  },
  {
    id: 6,
    title: 'From Struggles to Strength: Her Journey to Mental Health Advocacy',
    category: 'Social Impact',
    author: 'Sakshi Shewale',
    readTime: 12,
    imageSrc: 'https://ext.same-assets.com/2636907205/1635107063.webp'
  },
  {
    id: 20,
    title: 'From Classroom to Global Impact: Sayandeep Dutta\'s Innovation Tale',
    category: 'Entrepreneurship',
    author: 'Sakshi Shewale',
    readTime: 11,
    imageSrc: 'https://ext.same-assets.com/2636907205/3843830320.webp'
  }
];

const trendings = [
  {
    id: 48,
    title: 'Neha Byadwal Quit Social Media to Become IAS at 24',
    category: 'Education',
    author: 'Shreeti Sinha',
    readTime: 15,
    imageSrc: 'https://ext.same-assets.com/2636907205/3843830320.webp'
  },
  {
    id: 6,
    title: 'From Struggles to Strength: Her Journey to Mental Health Advocacy',
    category: 'Social Impact',
    author: 'Sakshi Shewale',
    readTime: 12,
    imageSrc: 'https://ext.same-assets.com/2636907205/1175443342.webp'
  },
  {
    id: 15,
    title: 'From Startup Success to Inner Peace: A Leader\'s Inspiring Journey',
    category: 'Business Pedia',
    author: 'Sakshi',
    readTime: 13,
    imageSrc: 'https://ext.same-assets.com/2636907205/1299044089.webp'
  }
];

const editorialChoice = {
  id: 15,
  title: 'From Startup Success to Inner Peace: A Leader\'s Inspiring Journey',
  category: 'Business Pedia',
  author: 'Sakshi',
  readTime: 13,
  imageSrc: 'https://ext.same-assets.com/2636907205/345180853.png'
};

const latestUpdates = [
  {
    id: 72,
    title: 'Bridging Dreams and Realities Through Virtual Trust',
    category: 'Social Impact',
    author: 'Prakriti Tripathi',
    readTime: 14,
    imageSrc: 'https://ext.same-assets.com/3508645956/1955214707.webp'
  },
  {
    id: 71,
    title: 'From Gamer to Green Hero: A Teenager\'s Inspiring Story',
    category: 'Social Impact',
    author: 'Aditi Shree',
    readTime: 15,
    imageSrc: 'https://ext.same-assets.com/2636907205/1175443342.webp'
  },
  {
    id: 59,
    title: 'Shaping Change and Innovation: A Journey of Growth and Impact',
    category: 'Social Impact',
    author: 'Sakshi Shewale',
    readTime: 13,
    imageSrc: 'https://ext.same-assets.com/2636907205/926474149.webp'
  }
];

const popularTags = [
  'Entrepreneurship',
  'Social Impact',
  'Business Pedia',
  'Sports',
  'Innovation',
  'Diversity',
  'Research',
  'Education',
  'Travel & Exploration'
];

export default function Home() {
  return (
    <div>
      {/* Top Stories Section */}
      <section className="py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">Top Stories</h2>
            <div className="text-sm text-muted-foreground">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long' })}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="md:col-span-2 lg:col-span-3">
              <StoryCard
                {...featuredStories[0]}
                featured
              />
            </div>

            {topStories.map((story) => (
              <StoryCard key={story.id} {...story} />
            ))}
          </div>
        </div>
      </section>

      {/* The Top 2023 Section */}
      <section className="the-top-2023 my-8 relative">
        <div className="container mx-auto px-4 relative z-10">
          <h2 className="section-title text-center mb-6">THE TOP 2023</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredStories.map((story) => (
              <StoryCard key={story.id} {...story} />
            ))}
          </div>
        </div>
      </section>

      {/* Trending Section */}
      <section className="py-6">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">Trending</h2>
            <Link href="/trending" className="view-all-btn">
              View All
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              {trendings.map((story) => (
                <StoryCard key={story.id} {...story} compact />
              ))}
            </div>

            <div className="bg-white rounded-lg p-4 shadow-sm">
              <h3 className="text-lg font-bold mb-4">Popular Tags</h3>
              <div className="tags-container flex flex-wrap">
                {popularTags.map((tag) => (
                  <Link
                    key={tag}
                    href={`/tag/${tag.toLowerCase().replace(/\s+/g, '-')}`}
                    className="tag bg-secondary text-secondary-foreground"
                  >
                    #{tag}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Editorial Choice */}
      <section className="py-6 editorial-choice">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center mb-6">
            <div className="flex items-center">
              <img
                src="https://ext.same-assets.com/2636907205/345180853.png"
                alt="Editorial Choice"
                className="w-8 h-8 mr-2"
              />
              <h2 className="section-title text-white mb-0">Editorial Choice</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <img
                src={editorialChoice.imageSrc}
                alt={editorialChoice.title}
                className="w-full h-auto rounded-lg"
              />
            </div>
            <div>
              <CategoryBadge
                category={editorialChoice.category}
                className="mb-3"
              />
              <h3 className="text-2xl font-bold text-white mb-3">
                {editorialChoice.title}
              </h3>
              <div className="flex items-center text-white/70 mb-4">
                <span className="mr-3">Sakshi</span>
                <span>14 August, 2024</span>
              </div>
              <Link
                href={`/story/${editorialChoice.id}`}
                className="inline-flex items-center text-white border border-white/30 px-4 py-2 rounded-full hover:bg-white/10"
              >
                Read More <FiArrowRight className="ml-2" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Latest Updates */}
      <section className="py-6">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">Latest Updates</h2>
            <Link href="/latest" className="view-all-btn">
              View All
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {latestUpdates.map((story) => (
              <StoryCard key={story.id} {...story} />
            ))}
          </div>
        </div>
      </section>

      {/* Opportunities Section */}
      <section className="py-6 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 mb-8">
            <button className="px-6 py-2 border-b-2 border-primary font-medium">Events</button>
            <button className="px-6 py-2 font-medium text-primary bg-primary/10 rounded-md">Opportunity</button>
            <button className="px-6 py-2 font-medium">Resources</button>
          </div>

          <div className="space-y-4">
            <div className="bg-background rounded-lg p-4 flex items-center">
              <div className="flex-shrink-0 mr-4">
                <img
                  src="https://ext.same-assets.com/2636907205/206773026.webp"
                  alt="Deloitte"
                  className="w-16 h-16 rounded-full object-cover"
                />
              </div>
              <div>
                <h3 className="font-bold">JOB POST: Software Developer – Analyst at Deloitte, Bangalore [Full Time, On-Site]: Apply Now</h3>
                <p className="text-sm text-muted-foreground">Deadline: April 18, 2025</p>
              </div>
            </div>

            <div className="bg-background rounded-lg p-4 flex items-center">
              <div className="flex-shrink-0 mr-4">
                <img
                  src="https://ext.same-assets.com/2636907205/206773026.webp"
                  alt="Essay Contest"
                  className="w-16 h-16 rounded-full object-cover"
                />
              </div>
              <div>
                <h3 className="font-bold">Essay Contest on International Day of Yoga 2025 by The Ministry of AYUSH in collaboration with MyGov [Cash Prizes of Rs. 32k]</h3>
                <p className="text-sm text-muted-foreground">Deadline: April 30, 2025</p>
              </div>
            </div>

            <div className="bg-background rounded-lg p-4 flex items-center">
              <div className="flex-shrink-0 mr-4">
                <img
                  src="https://ext.same-assets.com/2636907205/134880545.webp"
                  alt="Rajiv Gandhi"
                  className="w-16 h-16 rounded-full object-cover"
                />
              </div>
              <div>
                <h3 className="font-bold">Rajiv Gandhi Entrepreneurship Program [Karnataka Residents only, Grant of Rs.3L, 12 Month]</h3>
                <p className="text-sm text-muted-foreground">Deadline: April 28, 2025</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
