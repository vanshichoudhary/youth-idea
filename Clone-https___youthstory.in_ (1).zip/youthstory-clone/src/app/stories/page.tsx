'use client';

import React from 'react';
import Link from 'next/link';
import StoryCard from '@/components/StoryCard';

// Import mock data
const allStories = [
  {
    id: 72,
    title: 'Bridging Dreams and Realities Through Virtual Trust',
    category: 'Social Impact',
    author: 'Prakriti Tripathi',
    readTime: 14,
    imageSrc: 'https://ext.same-assets.com/3508645956/1955214707.webp'
  },
  {
    id: 71,
    title: 'From Gamer to Green Hero: A Teenager\'s Inspiring Story',
    category: 'Social Impact',
    author: 'Aditi Shree',
    readTime: 15,
    imageSrc: 'https://ext.same-assets.com/3508645956/646717528.webp'
  },
  {
    id: 70,
    title: 'Graphiedit: The Rising Powerhouse of 3D, VFX, & Motion Graphics',
    category: 'Innovation',
    author: 'Ishita Gangwar',
    readTime: 13,
    imageSrc: 'https://ext.same-assets.com/3508645956/449932634.webp'
  },
  {
    id: 48,
    title: 'Neha Byadwal Quit Social Media to Become IAS at 24',
    category: 'Education',
    author: 'Shreeti Sinha',
    readTime: 15,
    imageSrc: 'https://ext.same-assets.com/2636907205/3393313470.webp'
  },
  {
    id: 6,
    title: 'From Struggles to Strength: Her Journey to Mental Health Advocacy',
    category: 'Social Impact',
    author: 'Sakshi Shewale',
    readTime: 12,
    imageSrc: 'https://ext.same-assets.com/2636907205/1635107063.webp'
  },
  {
    id: 20,
    title: 'From Classroom to Global Impact: Sayandeep Dutta\'s Innovation Tale',
    category: 'Entrepreneurship',
    author: 'Sakshi Shewale',
    readTime: 11,
    imageSrc: 'https://ext.same-assets.com/2636907205/3843830320.webp'
  },
  {
    id: 15,
    title: 'From Startup Success to Inner Peace: A Leader\'s Inspiring Journey',
    category: 'Business Pedia',
    author: 'Sakshi',
    readTime: 13,
    imageSrc: 'https://ext.same-assets.com/2636907205/1299044089.webp'
  },
  {
    id: 59,
    title: 'Shaping Change and Innovation: A Journey of Growth and Impact',
    category: 'Social Impact',
    author: 'Sakshi Shewale',
    readTime: 13,
    imageSrc: 'https://ext.same-assets.com/2636907205/926474149.webp'
  }
];

const categories = [
  'All',
  'Social Impact',
  'Entrepreneurship',
  'Startup',
  'Innovation',
  'Leadership',
  'Business Pedia',
  'Education',
  'Programming'
];

export default function StoriesPage() {
  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">All Stories</h1>

        <div className="mb-8 overflow-x-auto">
          <div className="flex space-x-2">
            {categories.map((category) => (
              <button
                key={category}
                className={`px-4 py-2 rounded-full whitespace-nowrap ${
                  category === 'All'
                    ? 'bg-primary text-white'
                    : 'bg-secondary hover:bg-secondary/80'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {allStories.map((story) => (
            <StoryCard key={story.id} {...story} />
          ))}
        </div>
      </div>
    </div>
  );
}
