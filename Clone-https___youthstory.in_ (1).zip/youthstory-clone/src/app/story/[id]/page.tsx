import React from 'react';
import Link from 'next/link';
import { FiClock, FiShare2, FiHeart, FiCalendar } from 'react-icons/fi';
import CategoryBadge from '@/components/CategoryBadge';
import StoryCard from '@/components/StoryCard';

// Mock data for a single story
const storyData = {
  id: 72,
  title: 'Bridging Dreams and Realities Through Virtual Trust',
  category: 'Social Impact',
  author: 'Prakriti Tripathi',
  date: '2025-03-25',
  readTime: 14,
  content: `<p>An exciting story started in the beautiful but difficult landscape of Arunachal Pradesh, where consistent water, power, and internet are uncommon luxury. An ambitious engineering student named Vishal Dutta overcame the limitations of his surroundings to forge a remarkable career. Pratha (www.prathaindic.in), an organization that has <strong>improved the lives of over 135,000 people throughout India</strong>, was founded as a result of his tour.</p>
  <p><strong>A Spark of Vision</strong><br>
  At the esteemed <strong>National Youth Parliament Festival (NYPF),</strong> which took place at Vigyan Bhawan in New Delhi in 2019, Vishal's story was sparked. Prime Minister Narendra Modi's instruction, <strong><em>"Once this event is over, don't return to your normal lives,"</em></strong> hit a profound connection with Vishal, a young visionary who is enthusiastic about social change. Join forces to effect change at the local level.
  <br>
  These remarks served as the foundation for Vishal's desire to change things. Vishal recognized a chance to take action in 2020 as the globe faced the COVID-19 pandemic's huge challenges. Using relationships with NYPF members, the majority of whom he had never met in person, he started the process of creating a network of changemakers.</p>

  <p><strong>Pratha's Birth</strong><br>
  Vishal established Pratha with the strong assistance of his sister and founding member, Divyanshi Srivastava, who was also a member of the NYPF. He had an idea for an organization that would empower communities to effect change while filling up educational and skill gaps.<br>

  Pratha's foundation, which is based on trust and collaboration between people who never met in person but were connected to digital means, is what makes it special. This energetic team of more than 100 people has organized more than 400 significant events over the course of five years, forming partnerships with well-known companies like TATA and Jio and working with more than 15 Indian colleges and 45 NGOs.</p>

  <p>Three main pillars serve as the focal points of Pratha's impact:
  <br>
  <strong>Volunteering in the Social Sector</strong><br>
  Pratha has led successful initiatives centered on community donations, climate representation, disaster aid, and illness awareness. Their activities include international discussions, fund-raising, and interaction with representatives from around the world.<br>

  <strong>Supporting Critical Discussions</strong><br>
  Distinguished speakers, including Padma winners, NASA scientists, United Nations members, and well-known social activists, have participated in the organization's talks on important national and international problems.<br>

  <strong>Development of Skills</strong><br>
  Pratha provides free workshops on engineering, public speaking, law, and professional skills to bridge the gap between academic curricula and industrial expectations. Many pupils, especially those in rural areas, have benefited from these programs by becoming prepared for the workforce.</p>

  <p><strong>Recognition and Worldwide Presence</strong><br>
  One of its most significant accomplishments was when<br>
  Vishal, the Founder Chairman and Sheenam Dhingra, the Vice President of Community Engagement and associated founding member, &nbsp;represented India at the UN Youth Conference during COP29 in Azerbaijan. An important turning point in Pratha's international involvement was reached when their involvement in LCOY helped create India's National Youth Statement for the Global Youth Statement that was presented to all the global heads at United&nbsp;Nations&nbsp;COP.
  <br>
  The organization's standing on global stages has also been strengthened by Vishal's representation of Pratha as a <strong>Facilitator at the UN FCCC LCOY</strong> India, where he was given the <strong>Climate Resilience Award</strong>.</p>

  <p><strong>Collaboration and Leadership</strong><br>
  Pratha's success can be attributed to the teamwork of its committed leaders. In addition to Vishal and Divyanshi, trustees Aditya Trivedi, Sheenam Dhingra, and Divya Negi provide their knowledge of government involvement, skill development, and legal consulting. This unified leadership group is a prime example of Pratha's dedication to effective and well-organized governance.<br>

  The foundation of the organization is the collaboration between Divyanshi and Vishal. Divyanshi has been crucial to Pratha's path; she and Vishal have a sibling-like attachment. Together with Sheenam Dhingra, a significant founding member, they have established an organization based on constant allegiance and shared principles.</p>

  <p>This is far from the end of the road for Vishal, Divyanshi, and the Pratha crew. Their narrative serves as an example of what is possible when perseverance, foresight, and teamwork come together. They continue to empower people, close societal divides, and redefine what is possible via their tireless efforts, demonstrating that even the most trying situations may serve as an umbrella for revolutionary change.</p>`,
  images: [
    'https://ext.same-assets.com/3508645956/1955214707.webp',
    'https://ext.same-assets.com/3508645956/646717528.webp',
    'https://ext.same-assets.com/3508645956/1268506862.webp'
  ]
};

// Mock data for related stories
const relatedStories = [
  {
    id: 71,
    title: 'From Gamer to Green Hero: A Teenager\'s Inspiring Story',
    category: 'Social Impact',
    author: 'Aditi Shree',
    readTime: 15,
    imageSrc: 'https://ext.same-assets.com/3508645956/646717528.webp'
  },
  {
    id: 59,
    title: 'Shaping Change and Innovation: A Journey of Growth and Impact',
    category: 'Social Impact',
    author: 'Sakshi Shewale',
    readTime: 13,
    imageSrc: 'https://ext.same-assets.com/2636907205/926474149.webp'
  }
];

// All story IDs for static generation
const allStoryIds = [6, 15, 20, 48, 59, 70, 71, 72];

export function generateStaticParams() {
  return allStoryIds.map((id) => ({
    id: id.toString(),
  }));
}

export default function StoryPage({ params }: { params: { id: string } }) {
  const formattedDate = new Date(storyData.date).toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });

  // Sanitize content for safety (this is a simplistic approach, more robust solutions like dompurify should be used in production)
  const renderStoryContent = () => {
    return (
      <div className="max-w-3xl mx-auto prose prose-slate">
        <div dangerouslySetInnerHTML={{ __html: storyData.content }} />
      </div>
    );
  };

  return (
    <div className="pb-16">
      {/* Story Hero */}
      <div className="relative">
        <div className="w-full h-96">
          <img
            src={storyData.images[0]}
            alt={storyData.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-black/70 to-transparent" />
        </div>

        <button className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm text-white p-2 rounded-full">
          <FiShare2 size={20} />
        </button>
      </div>

      {/* Story Info */}
      <div className="single-blog-info border-b pb-4">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-center py-4">
            <div className="flex items-center md:pr-6">
              <button className="post-love flex flex-col items-center mr-6">
                <FiHeart size={24} className="mb-1" />
                <span className="text-xs">Like</span>
              </button>
              <button className="post-share flex flex-col items-center">
                <FiShare2 size={24} className="mb-1" />
                <span className="text-xs">Share</span>
              </button>
            </div>

            <div className="mt-4 md:mt-0 md:border-l md:pl-6">
              <CategoryBadge category={storyData.category} href={`/category/${storyData.category.toLowerCase().replace(/\s+/g, '-')}`} className="mb-2" />
              <h1 className="text-2xl md:text-3xl font-bold mb-2">{storyData.title}</h1>
              <div className="flex items-center text-sm text-muted-foreground">
                <div className="flex items-center mr-4">
                  <FiCalendar className="mr-1" size={14} />
                  <span>{formattedDate}</span>
                </div>
                <div className="flex items-center">
                  <FiClock className="mr-1" size={14} />
                  <span>{storyData.readTime} min read</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Story Content */}
      <div className="blog-description py-6">
        <div className="container mx-auto px-4">
          {renderStoryContent()}

          <div className="my-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {storyData.images.slice(1).map((image, i) => (
                <div key={`story-image-${image}`} className="overflow-hidden rounded-lg">
                  <img
                    src={image}
                    alt={`Story image ${i + 1}`}
                    className="w-full h-48 object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Related Stories */}
      <div className="related-post-wrapper py-6 bg-slate-50">
        <div className="container mx-auto px-4">
          <h6 className="section-title mb-4">Related Stories</h6>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {relatedStories.map((story) => (
              <StoryCard key={story.id} {...story} compact />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
