"use client";

import StoryCard from "@/components/StoryCard";
import Link from "next/link";
import React from "react";

// Mock data for trending stories
const trendingStories = [
  {
    id: 48,
    title: "Neha Byadwal Quit Social Media to Become IAS at 24",
    category: "Education",
    author: "Shreeti Sinha",
    readTime: 15,
    imageSrc: "https://ext.same-assets.com/2636907205/3393313470.webp",
  },
  {
    id: 6,
    title: "From Struggles to Strength: Her Journey to Mental Health Advocacy",
    category: "Social Impact",
    author: "Sakshi Shewale",
    readTime: 12,
    imageSrc: "https://ext.same-assets.com/2636907205/1635107063.webp",
  },
  {
    id: 15,
    title: "From Startup Success to Inner Peace: A Leader's Inspiring Journey",
    category: "Business Pedia",
    author: "Sakshi",
    readTime: 13,
    imageSrc: "https://ext.same-assets.com/2636907205/1299044089.webp",
  },
  {
    id: 72,
    title: "Bridging Dreams and Realities Through Virtual Trust",
    category: "Social Impact",
    author: "Prakriti Tripathi",
    readTime: 14,
    imageSrc: "https://ext.same-assets.com/3508645956/1955214707.webp",
  },
  {
    id: 71,
    title: "From Gamer to Green Hero: A Teenager's Inspiring Story",
    category: "Social Impact",
    author: "Aditi Shree",
    readTime: 15,
    imageSrc: "https://ext.same-assets.com/3508645956/646717528.webp",
  },
  {
    id: 70,
    title: "Graphiedit: The Rising Powerhouse of 3D, VFX, & Motion Graphics",
    category: "Innovation",
    author: "Ishita Gangwar",
    readTime: 13,
    imageSrc: "https://ext.same-assets.com/3508645956/449932634.webp",
  },
];

const popularTags = [
  "Entrepreneurship",
  "Social Impact",
  "Business Pedia",
  "Sports",
  "Innovation",
  "Diversity",
  "Research",
  "Education",
  "Travel & Exploration",
];

export default function TrendingPage() {
  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-8">Trending Stories</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <div className="grid grid-cols-1 gap-6">
              {trendingStories.map((story) => (
                <StoryCard key={story.id} {...story} compact />
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="text-lg font-bold mb-4">Popular Tags</h3>
              <div className="tags-container flex flex-wrap">
                {popularTags.map((tag) => (
                  <Link
                    key={tag}
                    href={`/tag/${tag.toLowerCase().replace(/\s+/g, "-")}`}
                    className="tag bg-secondary text-secondary-foreground"
                  >
                    #{tag}
                  </Link>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="text-lg font-bold mb-4">Top Authors</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-slate-200 mr-3" />
                  <div>
                    <div className="font-medium">Sakshi Shewale</div>
                    <div className="text-xs text-muted-foreground">
                      24 Stories
                    </div>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-slate-200 mr-3" />
                  <div>
                    <div className="font-medium">Aditi Shree</div>
                    <div className="text-xs text-muted-foreground">
                      18 Stories
                    </div>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-slate-200 mr-3" />
                  <div>
                    <div className="font-medium">Prakriti Tripathi</div>
                    <div className="text-xs text-muted-foreground">
                      15 Stories
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
