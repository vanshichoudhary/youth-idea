import React from 'react';
import Link from 'next/link';

type CategoryBadgeProps = {
  category: string;
  className?: string;
  href?: string;
};

export default function CategoryBadge({ category, className = '', href }: CategoryBadgeProps) {
  // Convert category to lowercase and remove spaces
  const categorySlug = category.toLowerCase().replace(/\s+/g, '-');

  // Determine background color based on category
  let categoryClass = '';

  switch (categorySlug) {
    case 'social-impact':
      categoryClass = 'social-impact';
      break;
    case 'entrepreneurship':
      categoryClass = 'entrepreneurship';
      break;
    case 'startup':
      categoryClass = 'startup';
      break;
    case 'leadership':
      categoryClass = 'leadership';
      break;
    case 'innovation':
      categoryClass = 'innovation';
      break;
    case 'business-pedia':
      categoryClass = 'entrepreneurship';
      break;
    case 'programming':
      categoryClass = 'innovation';
      break;
    default:
      categoryClass = 'social-impact';
  }

  const Badge = () => (
    <span className={`category-badge ${categoryClass} ${className}`}>
      {category}
    </span>
  );

  if (href) {
    return (
      <Link href={href}>
        <Badge />
      </Link>
    );
  }

  return <Badge />;
}
