'use client';

import React from 'react';
import Link from 'next/link';
import { FiHome, FiGrid, FiTrendingUp, FiBriefcase, FiCalendar, FiBookmark } from 'react-icons/fi';

export default function Footer() {
  return (
    <div className="footer-nav-area fixed bottom-0 left-0 right-0 z-40">
      <div className="h-14 w-full bg-white border-t border-gray-200">
        <div className="h-full flex items-center justify-between px-4 max-w-md mx-auto">
          <Link href="/" className="h-full flex flex-col items-center justify-center px-3">
            <FiHome size={20} className="mb-1" />
            <span className="text-xs font-medium">Home</span>
          </Link>

          <Link href="/stories" className="h-full flex flex-col items-center justify-center px-3">
            <FiGrid size={20} className="mb-1" />
            <span className="text-xs font-medium">Stories</span>
          </Link>

          <Link href="/trending" className="h-full flex flex-col items-center justify-center px-3">
            <FiTrendingUp size={20} className="mb-1" />
            <span className="text-xs font-medium">Trending</span>
          </Link>

          <Link href="/opportunities" className="h-full flex flex-col items-center justify-center px-3">
            <FiBriefcase size={20} className="mb-1" />
            <span className="text-xs font-medium">Opportunities</span>
          </Link>

          <Link href="/events" className="h-full flex flex-col items-center justify-center px-3">
            <FiCalendar size={20} className="mb-1" />
            <span className="text-xs font-medium">Events</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
