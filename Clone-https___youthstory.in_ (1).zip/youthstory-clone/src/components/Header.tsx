'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { FiSearch, FiMenu } from 'react-icons/fi';
import { HiOutlineX } from 'react-icons/hi';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="header-area sticky top-0 z-50">
      <div className="container mx-auto h-16 flex items-center justify-between px-4">
        <div className="flex items-center">
          <button
            className="mr-4 lg:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <HiOutlineX size={24} /> : <FiMenu size={24} />}
          </button>
          <Link href="/">
            <div className="flex items-center">
              <img
                src="https://ext.same-assets.com/3508645956/1299044089.webp"
                alt="Youth Story Logo"
                className="h-9"
              />
            </div>
          </Link>
        </div>

        <div className="hidden lg:flex items-center space-x-6">
          <Link href="/" className="text-sm font-medium hover:text-primary">Home</Link>
          <Link href="/stories" className="text-sm font-medium hover:text-primary">Stories</Link>
          <Link href="/trending" className="text-sm font-medium hover:text-primary">Trending</Link>
          <Link href="/opportunities" className="text-sm font-medium hover:text-primary">Opportunities</Link>
          <Link href="/events" className="text-sm font-medium hover:text-primary">Events</Link>
        </div>

        <div className="flex items-center">
          <button className="p-2">
            <FiSearch size={20} />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 bg-white z-40 pt-16">
          <div className="container mx-auto px-4 py-8">
            <div className="flex flex-col space-y-4">
              <Link
                href="/"
                className="text-lg font-medium p-2 hover:bg-muted rounded-md"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                href="/stories"
                className="text-lg font-medium p-2 hover:bg-muted rounded-md"
                onClick={() => setIsMenuOpen(false)}
              >
                Stories
              </Link>
              <Link
                href="/trending"
                className="text-lg font-medium p-2 hover:bg-muted rounded-md"
                onClick={() => setIsMenuOpen(false)}
              >
                Trending
              </Link>
              <Link
                href="/opportunities"
                className="text-lg font-medium p-2 hover:bg-muted rounded-md"
                onClick={() => setIsMenuOpen(false)}
              >
                Opportunities
              </Link>
              <Link
                href="/events"
                className="text-lg font-medium p-2 hover:bg-muted rounded-md"
                onClick={() => setIsMenuOpen(false)}
              >
                Events
              </Link>
            </div>

            <div className="mt-8 border-t pt-4">
              <div className="flex flex-col space-y-4">
                <Link
                  href="/profile"
                  className="text-base font-medium p-2 hover:bg-muted rounded-md"
                  onClick={() => setIsMenuOpen(false)}
                >
                  My Profile
                </Link>
                <Link
                  href="/categories"
                  className="text-base font-medium p-2 hover:bg-muted rounded-md"
                  onClick={() => setIsMenuOpen(false)}
                >
                  All Categories 24+
                </Link>
                <Link
                  href="/settings"
                  className="text-base font-medium p-2 hover:bg-muted rounded-md"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Settings
                </Link>
                <Link
                  href="/contact"
                  className="text-base font-medium p-2 hover:bg-muted rounded-md"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Contact Us
                </Link>
                <Link
                  href="/privacy-policy"
                  className="text-base font-medium p-2 hover:bg-muted rounded-md"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Privacy Policy
                </Link>
                <Link
                  href="/terms"
                  className="text-base font-medium p-2 hover:bg-muted rounded-md"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Terms & Conditions
                </Link>
                <Link
                  href="https://feature.youthstory.in"
                  className="text-base font-medium p-2 hover:bg-muted rounded-md"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Share Your Story
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
