'use client';

import React, { useState, useRef, useEffect } from 'react';
import { FiSearch, FiX } from 'react-icons/fi';
import Link from 'next/link';

type SearchResult = {
  id: number;
  title: string;
  category: string;
  imageSrc?: string;
};

type SearchBarProps = {
  placeholder?: string;
  className?: string;
  allStories: SearchResult[];
};

export default function SearchBar({
  placeholder = 'Search stories...',
  className = '',
  allStories
}: SearchBarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);

  // Filter stories based on search query
  useEffect(() => {
    if (searchQuery.trim().length < 2) {
      setResults([]);
      return;
    }

    const filteredResults = allStories.filter(story =>
      story.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      story.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setResults(filteredResults.slice(0, 5)); // Limit to 5 results for better UX
  }, [searchQuery, allStories]);

  // Close search when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className={`relative ${className}`} ref={searchRef}>
      <div className="flex items-center">
        <div className={`flex items-center w-full transition-all duration-300 ${isOpen ? 'bg-white shadow-md' : ''}`}>
          <button
            className="p-2 text-gray-500 hover:text-gray-700"
            onClick={() => setIsOpen(!isOpen)}
          >
            <FiSearch size={20} />
          </button>
          {isOpen && (
            <>
              <input
                type="text"
                placeholder={placeholder}
                className="w-full py-2 px-3 outline-none bg-transparent"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                autoFocus
              />
              {searchQuery && (
                <button
                  className="p-2 text-gray-500 hover:text-gray-700"
                  onClick={() => setSearchQuery('')}
                >
                  <FiX size={20} />
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Search Results Dropdown */}
      {isOpen && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white shadow-lg rounded-md overflow-hidden z-50">
          <div className="py-2">
            {results.map((result) => (
              <Link
                key={result.id}
                href={`/story/${result.id}`}
                className="flex items-center px-4 py-2 hover:bg-gray-100"
                onClick={() => {
                  setIsOpen(false);
                  setSearchQuery('');
                }}
              >
                {result.imageSrc && (
                  <div className="flex-shrink-0 w-10 h-10 mr-3">
                    <img
                      src={result.imageSrc}
                      alt={result.title}
                      className="w-full h-full object-cover rounded"
                    />
                  </div>
                )}
                <div>
                  <div className="text-sm font-medium">{result.title}</div>
                  <div className="text-xs text-gray-500">{result.category}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* No Results Message */}
      {isOpen && searchQuery.trim().length >= 2 && results.length === 0 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white shadow-lg rounded-md overflow-hidden z-50">
          <div className="py-4 px-4 text-center text-gray-500">
            No stories found matching "{searchQuery}"
          </div>
        </div>
      )}
    </div>
  );
}
