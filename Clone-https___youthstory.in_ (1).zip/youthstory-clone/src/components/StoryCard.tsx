import Link from "next/link";
import React from "react";
import { FiClock } from "react-icons/fi";
import CategoryBadge from "./CategoryBadge";

type StoryCardProps = {
  id: number;
  title: string;
  category: string;
  author?: string;
  readTime?: number;
  imageSrc?: string;
  className?: string;
  compact?: boolean;
  featured?: boolean;
};

export default function StoryCard({
  id,
  title,
  category,
  author,
  readTime = 10,
  imageSrc,
  className = "",
  compact = false,
  featured = false,
}: StoryCardProps) {
  if (compact) {
    return (
      <div className={`single-trending-post flex mb-3 ${className}`}>
        {imageSrc && (
          <div className="post-thumbnail flex-shrink-0 mr-3">
            <Link href={`/story/${id}`}>
              <img
                src={imageSrc}
                alt={title}
                className="w-16 h-16 object-cover rounded-md"
              />
            </Link>
          </div>
        )}
        <div className="post-content">
          <Link
            href={`/story/${id}`}
            className="post-title text-base font-medium line-clamp-2 mb-1 hover:text-primary"
          >
            {title}
          </Link>
          <div className="post-meta flex text-xs text-muted-foreground items-center">
            <CategoryBadge
              category={category}
              href={`/category/${category.toLowerCase().replace(/\s+/g, "-")}`}
            />
            {author && <span className="ml-2">{author}</span>}
          </div>
        </div>
      </div>
    );
  }

  if (featured) {
    return (
      <div
        className={`featured-story-card relative overflow-hidden rounded-lg ${className}`}
      >
        <div className="relative h-80 w-full">
          <img
            src={
              imageSrc ||
              "https://ext.same-assets.com/3508645956/1955214707.webp"
            }
            alt={title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
          <div className="absolute bottom-0 left-0 p-4 text-white">
            <CategoryBadge
              category={category}
              href={`/category/${category.toLowerCase().replace(/\s+/g, "-")}`}
              className="mb-2"
            />
            <h3 className="text-xl font-bold mb-2">{title}</h3>
            <div className="flex items-center text-sm text-white/80">
              {author && <span className="mr-3">{author}</span>}
              <div className="flex items-center">
                <FiClock className="mr-1" size={14} />
                <span>{readTime} min read</span>
              </div>
            </div>
            <Link href={`/story/${id}`} className="absolute inset-0">
              <span className="sr-only">Read more about {title}</span>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`story-card overflow-hidden rounded-lg ${className}`}>
      <div className="relative">
        <div className="mb-3">
          <img
            src={
              imageSrc ||
              "https://ext.same-assets.com/3508645956/1955214707.webp"
            }
            alt={title}
            className="w-full h-48 object-cover rounded-lg"
          />
        </div>
        <div className="p-1">
          <CategoryBadge
            category={category}
            href={`/category/${category.toLowerCase().replace(/\s+/g, "-")}`}
            className="mb-2"
          />
          <h3 className="text-lg font-bold mb-2 line-clamp-2">{title}</h3>
          <div className="flex items-center text-sm text-muted-foreground">
            {author && <span className="mr-3">{author}</span>}
            <div className="flex items-center">
              <FiClock className="mr-1" size={14} />
              <span>{readTime} min read</span>
            </div>
          </div>
        </div>
        <Link href={`/story/${id}`} className="absolute inset-0">
          <span className="sr-only">Read more about {title}</span>
        </Link>
      </div>
    </div>
  );
}
