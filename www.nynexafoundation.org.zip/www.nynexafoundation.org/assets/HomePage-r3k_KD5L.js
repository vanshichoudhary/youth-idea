import {
    a as e,
    s as t,
    u as a,
    b as i,
    c as s,
    j as r,
    m as n,
    A as l,
    d as o,
    L as c,
    G as d,
    e as h,
    f as m,
    C as x,
    M as u,
    I as g,
    B as p,
    g as v,
    h as b,
    i as f,
    S as y
} from "./index-AQVjGcvK.js";
import {
    b as j,
    L as w
} from "./vendor-CDsBVsyF.js";
import {
    E as N
} from "./external-link-DoMSGJsZ.js";
import {
    C as k,
    a as E,
    b as I,
    c as S,
    d as U,
    e as M
} from "./card-C3HleBDS.js";
import {
    T
} from "./trending-up-cHYr1Zor.js";
import {
    U as C
} from "./users-CvcoJy48.js";
import {
    Z as O
} from "./zap-DEHoMbld.js";
import {
    N as V
} from "./NewsCard-DFD8dy5j.js";
import "./calendar-yjCJPMYD.js";

function R(e, a) {
    [...a].reverse().forEach((i => {
        const s = e.getVariant(i);
        s && t(e, s), e.variantChildren && e.variantChildren.forEach((e => {
            R(e, a)
        }))
    }))
}

function A() {
    const a = new Set,
        i = {
            subscribe: e => (a.add(e), () => {
                a.delete(e)
            }),
            start(t, i) {
                const s = [];
                return a.forEach((a => {
                    s.push(e(a, t, {
                        transitionOverride: i
                    }))
                })), Promise.all(s)
            },
            set: e => a.forEach((a => {
                ! function(e, a) {
                    Array.isArray(a) ? R(e, a) : "string" == typeof a ? R(e, [a]) : t(e, a)
                }(a, e)
            })),
            stop() {
                a.forEach((e => {
                    ! function(e) {
                        e.values.forEach((e => e.stop()))
                    }(e)
                }))
            },
            mount: () => () => {
                i.stop()
            }
        };
    return i
}
const F = function() {
        const e = a(A);
        return i(e.mount, []), e
    },
    q = s("ArrowUpRight", [
        ["path", {
            d: "M7 7h10v10",
            key: "1tivn9"
        }],
        ["path", {
            d: "M7 17 17 7",
            key: "1vkiza"
        }]
    ]),
    H = s("Handshake", [
        ["path", {
            d: "m11 17 2 2a1 1 0 1 0 3-3",
            key: "efffak"
        }],
        ["path", {
            d: "m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4",
            key: "9pr0kb"
        }],
        ["path", {
            d: "m21 3 1 11h-2",
            key: "1tisrp"
        }],
        ["path", {
            d: "M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3",
            key: "1uvwmv"
        }],
        ["path", {
            d: "M3 4h8",
            key: "1ep09j"
        }]
    ]),
    L = s("HeartHandshake", [
        ["path", {
            d: "M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",
            key: "c3ymky"
        }],
        ["path", {
            d: "M12 5 9.04 7.96a2.17 2.17 0 0 0 0 3.08c.82.82 2.13.85 3 .07l2.07-1.9a2.82 2.82 0 0 1 3.79 0l2.96 2.66",
            key: "4oyue0"
        }],
        ["path", {
            d: "m18 15-2-2",
            key: "60u0ii"
        }],
        ["path", {
            d: "m15 18-2-2",
            key: "6p76be"
        }]
    ]);
/**
 * @license lucide-react v0.394.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
var P = new Map,
    z = new WeakMap,
    B = 0;

function $(e) {
    return Object.keys(e).sort().filter((t => void 0 !== e[t])).map((t => {
        return `${t}_${"root"===t?(a=e.root,a?(z.has(a)||(B+=1,z.set(a,B.toString())),z.get(a)):"0"):e[t]}`;
        var a
    })).toString()
}

function _(e, t, a = {}, i = undefined) {
    if (void 0 === window.IntersectionObserver && void 0 !== i) {
        const s = e.getBoundingClientRect();
        return t(i, {
            isIntersecting: i,
            target: e,
            intersectionRatio: "number" == typeof a.threshold ? a.threshold : 0,
            time: 0,
            boundingClientRect: s,
            intersectionRect: s,
            rootBounds: s
        }), () => {}
    }
    const {
        id: s,
        observer: r,
        elements: n
    } = function(e) {
        const t = $(e);
        let a = P.get(t);
        if (!a) {
            const i = new Map;
            let s;
            const r = new IntersectionObserver((t => {
                t.forEach((t => {
                    var a;
                    const r = t.isIntersecting && s.some((e => t.intersectionRatio >= e));
                    e.trackVisibility && void 0 === t.isVisible && (t.isVisible = r), null == (a = i.get(t.target)) || a.forEach((e => {
                        e(r, t)
                    }))
                }))
            }), e);
            s = r.thresholds || (Array.isArray(e.threshold) ? e.threshold : [e.threshold || 0]), a = {
                id: t,
                observer: r,
                elements: i
            }, P.set(t, a)
        }
        return a
    }(a), l = n.get(e) || [];
    return n.has(e) || n.set(e, l), l.push(t), r.observe(e),
        function() {
            l.splice(l.indexOf(t), 1), 0 === l.length && (n.delete(e), r.unobserve(e)), 0 === n.size && (r.disconnect(), P.delete(s))
        }
}

function W({
    threshold: e,
    delay: t,
    trackVisibility: a,
    rootMargin: i,
    root: s,
    triggerOnce: r,
    skip: n,
    initialInView: l,
    fallbackInView: o,
    onChange: c
} = {}) {
    var d;
    const [h, m] = j.useState(null), x = j.useRef(c), [u, g] = j.useState({
        inView: !!l,
        entry: void 0
    });
    x.current = c, j.useEffect((() => {
        if (n || !h) return;
        let l;
        return l = _(h, ((e, t) => {
            g({
                inView: e,
                entry: t
            }), x.current && x.current(e, t), t.isIntersecting && r && l && (l(), l = void 0)
        }), {
            root: s,
            rootMargin: i,
            threshold: e,
            trackVisibility: a,
            delay: t
        }, o), () => {
            l && l()
        }
    }), [Array.isArray(e) ? e.toString() : e, h, s, i, r, n, a, o, t]);
    const p = null == (d = u.entry) ? void 0 : d.target,
        v = j.useRef(void 0);
    h || !p || r || n || v.current === p || (v.current = p, g({
        inView: !!l,
        entry: void 0
    }));
    const b = [m, u.inView, u.entry];
    return b.ref = b[0], b.inView = b[1], b.entry = b[2], b
}
const D = () => {
        const [e, t] = j.useState(!1), a = {
            hidden: {
                opacity: 0,
                y: 20
            },
            visible: {
                opacity: 1,
                y: 0
            }
        };
        return r.jsxs("section", {
            className: "relative h-screen max-h-[800px] overflow-hidden",
            children: [r.jsxs("div", {
                className: "absolute inset-0 w-full h-full bg-[#000000]",
                children: [r.jsxs("video", {
                    autoPlay: !0,
                    loop: !0,
                    muted: !0,
                    playsInline: !0,
                    className: "w-full h-full object-cover opacity-30 mix-blend-screen",
                    children: [r.jsx("source", {
                        src: "https://www.fordfoundation.org/wp-content/uploads/2025/01/website_cover_video_update_2025_final-_720.mp4",
                        type: "video/mp4"
                    }), "Your browser does not support the video tag."]
                }), r.jsx("div", {
                    className: "absolute inset-0 z-30 flex items-center",
                    children: r.jsx("div", {
                        className: "container mx-auto px-6 md:px-8",
                        children: r.jsxs(n.div, {
                            className: "max-w-3xl ml-0 text-left",
                            variants: {
                                hidden: {
                                    opacity: 0,
                                    y: 20
                                },
                                visible: {
                                    opacity: 1,
                                    y: 0,
                                    transition: {
                                        duration: .6,
                                        staggerChildren: .2
                                    }
                                }
                            },
                            initial: "hidden",
                            animate: "visible",
                            children: [r.jsx(n.h1, {
                                className: "text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 md:mb-6 leading-tight drop-shadow-lg",
                                variants: a,
                                children: "Advancing Humanity Through Innovation"
                            }), r.jsx(n.p, {
                                className: "text-lg md:text-xl text-white mb-6 md:mb-8 max-w-2xl drop-shadow-lg",
                                variants: a,
                                children: "We're on a mission to solve humanity's greatest challenges through groundbreaking research, strategic investments, and educational initiatives."
                            }), r.jsxs(n.div, {
                                className: "flex flex-col sm:flex-row items-start space-y-4 sm:space-y-0 sm:space-x-4",
                                variants: a,
                                children: [r.jsx(w, {
                                    to: "/work/research-development",
                                    children: r.jsxs("a", {
                                        className: "hero-button hero-button-primary",
                                        children: ["Explore Our Work", r.jsx(l, {
                                            className: "ml-2 h-4 w-4"
                                        })]
                                    })
                                }), r.jsx(w, {
                                    to: "/about",
                                    children: r.jsxs("a", {
                                        className: "hero-button hero-button-outline",
                                        children: [r.jsx(N, {
                                            className: "mr-2 h-4 w-4"
                                        }), " Learn About Us"]
                                    })
                                })]
                            })]
                        })
                    })
                })]
            }), r.jsx("div", {
                className: "block md:hidden",
                children: r.jsx("div", {
                    className: "opacity-0 h-0 overflow-hidden",
                    children: r.jsxs("div", {
                        className: "flex flex-col",
                        children: [r.jsx("h1", {
                            children: "Nynexa Foundation"
                        }), r.jsx("p", {
                            children: "Ensuring mobile compatibility"
                        })]
                    })
                })
            })]
        })
    },
    G = () => {
        const e = F(),
            [t, a] = W({
                triggerOnce: !0,
                threshold: .2
            });
        j.useEffect((() => {
            a && e.start("visible")
        }), [e, a]);
        const i = {
            hidden: {
                opacity: 0,
                y: 30
            },
            visible: {
                opacity: 1,
                y: 0,
                transition: {
                    duration: .8,
                    ease: [.22, 1, .36, 1]
                }
            }
        };
        return r.jsx("section", {
            className: "py-24 bg-gradient-to-b from-white to-gray-50",
            children: r.jsx("div", {
                className: "container mx-auto px-4",
                children: r.jsxs(n.div, {
                    ref: t,
                    animate: e,
                    initial: "hidden",
                    variants: {
                        hidden: {
                            opacity: 0
                        },
                        visible: {
                            opacity: 1,
                            transition: {
                                staggerChildren: .2
                            }
                        }
                    },
                    className: "max-w-5xl mx-auto",
                    children: [r.jsx(n.h2, {
                        variants: i,
                        className: "text-4xl md:text-5xl font-bold text-black-800 mb-12 leading-tight max-w-3xl",
                        children: "Shaping the Future of Humanity"
                    }), r.jsx(n.p, {
                        variants: i,
                        className: "text-xl md:text-2xl text-gray-700 mb-16 leading-relaxed max-w-3xl",
                        children: "The Nynexa Foundation was established with a singular vision: to accelerate human progress through strategic investments in science, technology, and education."
                    }), r.jsxs(n.div, {
                        variants: i,
                        className: "grid grid-cols-1 md:grid-cols-3 gap-8 mt-20",
                        children: [r.jsxs("div", {
                            className: "bg-white rounded-xl p-8 shadow-md border border-gray-200 transition-transform duration-300 hover:-translate-y-2",
                            children: [r.jsx("div", {
                                className: "bg-black-100 w-16 h-16 rounded-full flex items-center justify-center mb-6",
                                children: r.jsx("span", {
                                    className: "text-xl font-bold text-black-800",
                                    children: "01"
                                })
                            }), r.jsx("h3", {
                                className: "text-2xl font-bold text-black-800 mb-4",
                                children: "Identify"
                            }), r.jsx("p", {
                                className: "text-gray-700",
                                children: "We identify critical global challenges where innovation can drive transformative change and create strategic opportunities for impact."
                            })]
                        }), r.jsxs("div", {
                            className: "bg-white rounded-xl p-8 shadow-md border border-gray-200 transition-transform duration-300 hover:-translate-y-2",
                            children: [r.jsx("div", {
                                className: "bg-black-100 w-16 h-16 rounded-full flex items-center justify-center mb-6",
                                children: r.jsx("span", {
                                    className: "text-xl font-bold text-black-800",
                                    children: "02"
                                })
                            }), r.jsx("h3", {
                                className: "text-2xl font-bold text-black-800 mb-4",
                                children: "Invest"
                            }), r.jsx("p", {
                                className: "text-gray-700",
                                children: "We strategically invest resources in research, education, and collaborative initiatives to accelerate meaningful solutions."
                            })]
                        }), r.jsxs("div", {
                            className: "bg-white rounded-xl p-8 shadow-md border border-gray-200 transition-transform duration-300 hover:-translate-y-2",
                            children: [r.jsx("div", {
                                className: "bg-black-100 w-16 h-16 rounded-full flex items-center justify-center mb-6",
                                children: r.jsx("span", {
                                    className: "text-xl font-bold text-black-800",
                                    children: "03"
                                })
                            }), r.jsx("h3", {
                                className: "text-2xl font-bold text-black-800 mb-4",
                                children: "Impact"
                            }), r.jsx("p", {
                                className: "text-gray-700",
                                children: "We measure and amplify our impact through scaling successful solutions globally and fostering sustainable change."
                            })]
                        })]
                    }), r.jsx(n.div, {
                        variants: i,
                        className: "mt-24 bg-black-900 text-white p-10 rounded-xl",
                        children: r.jsxs("blockquote", {
                            className: "text-3xl md:text-4xl font-light leading-tight max-w-4xl",
                            children: ['"Our mission is to be the catalyst that transforms human potential into reality."', r.jsx("footer", {
                                className: "mt-8 text-base font-normal text-gray-300",
                                children: "— Rajnish Mani Tiwari, Founder of the Nynexa Foundation"
                            })]
                        })
                    })]
                })
            })
        })
    },
    J = ({
        title: e = "Innovative R&D",
        description: t = "Pioneering research and development in longevity, artificial super intelligence, and sustainable technologies.",
        icon: a = "research",
        imageUrl: i,
        linkUrl: s = "#",
        linkText: m = "Learn More",
        className: x
    }) => r.jsx(n.div, {
        whileHover: {
            y: -5
        },
        transition: {
            duration: .3
        },
        className: o("h-full", x),
        children: r.jsxs(k, {
            className: "h-full flex flex-col overflow-hidden border-purple-100 bg-white",
            children: [i && r.jsx("div", {
                className: "relative h-48 w-full overflow-hidden",
                children: r.jsx("img", {
                    src: i,
                    alt: e,
                    className: "h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                })
            }), r.jsxs(E, {
                className: "pb-0",
                children: [r.jsx("div", {
                    className: "mb-4",
                    children: (() => {
                        switch (a) {
                            case "research":
                            default:
                                return r.jsx(c, {
                                    className: "h-10 w-10 text-purple-600"
                                });
                            case "fund":
                                return r.jsx(h, {
                                    className: "h-10 w-10 text-purple-600"
                                });
                            case "education":
                                return r.jsx(d, {
                                    className: "h-10 w-10 text-purple-600"
                                })
                        }
                    })()
                }), r.jsx(I, {
                    className: "text-2xl font-bold text-purple-900",
                    children: e
                })]
            }), r.jsx(S, {
                className: "flex-grow",
                children: r.jsx(U, {
                    className: "text-base text-gray-600",
                    children: t
                })
            }), r.jsx(M, {
                children: r.jsxs("a", {
                    href: s,
                    className: "group inline-flex items-center text-purple-700 hover:text-purple-900 font-medium",
                    children: [m, r.jsx(l, {
                        className: "ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                    })]
                })
            })]
        })
    }),
    Y = () => {
        const e = F(),
            [t, a] = W({
                triggerOnce: !0,
                threshold: .1
            });
        j.useEffect((() => {
            a && e.start("visible")
        }), [e, a]);
        const i = {
                hidden: {
                    opacity: 0
                },
                visible: {
                    opacity: 1,
                    transition: {
                        staggerChildren: .2
                    }
                }
            },
            s = {
                hidden: {
                    opacity: 0,
                    y: 30
                },
                visible: {
                    opacity: 1,
                    y: 0,
                    transition: {
                        duration: .8,
                        ease: [.22, 1, .36, 1]
                    }
                }
            };
        return r.jsx("section", {
            className: "py-20 bg-gray-50",
            children: r.jsx("div", {
                className: "container mx-auto px-4",
                children: r.jsxs(n.div, {
                    ref: t,
                    animate: e,
                    initial: "hidden",
                    variants: i,
                    children: [r.jsxs(n.div, {
                        variants: s,
                        className: "text-center mb-16",
                        children: [r.jsx("h2", {
                            className: "text-3xl md:text-4xl font-bold text-gray-900 mb-4",
                            children: "Our Core Pillars"
                        }), r.jsx("p", {
                            className: "text-xl text-gray-700 max-w-3xl mx-auto",
                            children: "Through these three strategic pillars, we're working to create a more equitable, sustainable, and innovative future for all of humanity."
                        })]
                    }), r.jsx(n.div, {
                        variants: i,
                        className: "grid grid-cols-1 md:grid-cols-3 gap-8",
                        children: [{
                            title: "Research & Development",
                            description: "Pioneering breakthrough technologies and scientific advancements that address humanity's greatest challenges.",
                            icon: "research",
                            imageUrl: "https://images.unsplash.com/photo-1507413245164-6160d8298b31?w=800&q=80",
                            linkUrl: "/work/research-development",
                            linkText: "Explore Research"
                        }, {
                            title: "Billionaire Fund",
                            description: "Strategic investments in transformative global initiatives led by visionary philanthropists and innovators.",
                            icon: "fund",
                            imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80",
                            linkUrl: "/work/billionaire-fund",
                            linkText: "Learn About the Fund"
                        }, {
                            title: "Education & STEM",
                            description: "Empowering the next generation through educational initiatives focused on science, technology, engineering, and mathematics.",
                            icon: "education",
                            imageUrl: "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800&q=80",
                            linkUrl: "/work/education-stem",
                            linkText: "Discover Programs"
                        }].map(((e, t) => r.jsx(n.div, {
                            variants: s,
                            whileHover: {
                                y: -10
                            },
                            transition: {
                                duration: .3
                            },
                            children: r.jsx(J, {
                                title: e.title,
                                description: e.description,
                                icon: e.icon,
                                imageUrl: e.imageUrl,
                                linkUrl: e.linkUrl,
                                linkText: e.linkText
                            })
                        }, t)))
                    }), r.jsx(n.div, {
                        variants: s,
                        className: "mt-16 text-center",
                        children: r.jsxs(w, {
                            to: "/about/vision-mission",
                            className: "inline-flex items-center text-black font-semibold hover:text-black-900 transition-colors",
                            children: ["Learn more about our vision and mission", r.jsx(l, {
                                className: "ml-2 h-4 w-4"
                            })]
                        })
                    })]
                })
            })
        })
    },
    Z = ({
        title: e = "Lives Impacted",
        value: t,
        description: a = "People directly benefiting from our education initiatives worldwide",
        trend: i,
        icon: s = r.jsx(T, {
            size: 20
        }),
        color: l = "default",
        onClick: c,
        imageUrl: d,
        link: h
    }) => {
        const m = {
            default: "bg-white hover:bg-gray-50",
            purple: "bg-purple-50 hover:bg-purple-100 border-purple-200",
            teal: "bg-teal-50 hover:bg-teal-100 border-teal-200",
            gold: "bg-amber-50 hover:bg-amber-100 border-amber-200"
        };
        return d ? r.jsx(n.div, {
            whileHover: {
                y: -5,
                transition: {
                    duration: .2
                }
            },
            className: "h-full",
            children: r.jsxs(k, {
                className: o("h-full cursor-pointer transition-all duration-200 border overflow-hidden", m[l]),
                onClick: c,
                children: [r.jsx("div", {
                    className: "relative h-48 overflow-hidden",
                    children: r.jsx("img", {
                        src: d,
                        alt: e,
                        className: "w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                    })
                }), r.jsx(E, {
                    children: r.jsx(I, {
                        className: "text-xl font-bold text-gray-900",
                        children: e
                    })
                }), r.jsx(S, {
                    children: r.jsx(U, {
                        className: "text-gray-600",
                        children: a
                    })
                }), r.jsx(M, {
                    children: r.jsxs("a", {
                        href: h,
                        className: "flex items-center text-sm font-medium text-purple-600 hover:text-purple-800 transition-colors",
                        children: ["Learn more", r.jsx(q, {
                            size: 16,
                            className: "ml-1"
                        })]
                    })
                })]
            })
        }) : r.jsx(n.div, {
            whileHover: {
                y: -5,
                transition: {
                    duration: .2
                }
            },
            className: "h-full",
            children: r.jsxs(k, {
                className: o("h-full cursor-pointer transition-all duration-200 border-2", m[l]),
                onClick: c,
                children: [r.jsxs(E, {
                    className: "flex flex-row items-start justify-between",
                    children: [r.jsxs("div", {
                        children: [r.jsx(I, {
                            className: o("text-lg font-bold mb-1", {
                                default: "text-gray-600",
                                purple: "text-purple-700",
                                teal: "text-teal-700",
                                gold: "text-amber-700"
                            }[l]),
                            children: e
                        }), r.jsx(U, {
                            className: "text-gray-500",
                            children: a
                        })]
                    }), r.jsx("div", {
                        className: o("p-2 rounded-full", {
                            default: "bg-gray-100 text-gray-700",
                            purple: "bg-purple-100 text-purple-700",
                            teal: "bg-teal-100 text-teal-700",
                            gold: "bg-amber-100 text-amber-700"
                        }[l]),
                        children: s
                    })]
                }), r.jsxs(S, {
                    children: [t && r.jsx("div", {
                        className: o("text-4xl font-bold", {
                            default: "text-gray-900",
                            purple: "text-purple-900",
                            teal: "text-teal-900",
                            gold: "text-amber-900"
                        }[l]),
                        children: t
                    }), i && r.jsxs("div", {
                        className: "flex items-center mt-2 text-sm",
                        children: [r.jsxs("span", {
                            className: i > 0 ? "text-green-600" : "text-red-600",
                            children: [i > 0 ? "+" : "", i, "%"]
                        }), r.jsx("span", {
                            className: "ml-1 text-gray-500",
                            children: "from previous year"
                        })]
                    })]
                }), r.jsx(M, {
                    children: r.jsxs("div", {
                        className: "flex items-center text-sm font-medium text-purple-600 hover:text-purple-800 transition-colors",
                        children: ["View details", r.jsx(q, {
                            size: 16,
                            className: "ml-1"
                        })]
                    })
                })]
            })
        })
    },
    Q = () => {
        const e = F(),
            [t, a] = W({
                triggerOnce: !0,
                threshold: .1
            });
        j.useEffect((() => {
            a && e.start("visible")
        }), [e, a]);
        const i = {
                hidden: {
                    opacity: 0
                },
                visible: {
                    opacity: 1,
                    transition: {
                        staggerChildren: .2
                    }
                }
            },
            s = {
                hidden: {
                    opacity: 0,
                    y: 30
                },
                visible: {
                    opacity: 1,
                    y: 0,
                    transition: {
                        duration: .8,
                        ease: [.22, 1, .36, 1]
                    }
                }
            },
            o = [{
                value: "$250M+",
                label: "Research Funding",
                icon: r.jsx(T, {
                    className: "h-6 w-6"
                }),
                color: "purple"
            }, {
                value: "120+",
                label: "Global Partners",
                icon: r.jsx(C, {
                    className: "h-6 w-6"
                }),
                color: "teal"
            }, {
                value: "35+",
                label: "Breakthrough Innovations",
                icon: r.jsx(O, {
                    className: "h-6 w-6"
                }),
                color: "gold"
            }];
        return r.jsx("section", {
            className: "py-20 bg-white",
            children: r.jsx("div", {
                className: "container mx-auto px-4",
                children: r.jsxs(n.div, {
                    ref: t,
                    animate: e,
                    initial: "hidden",
                    variants: i,
                    children: [r.jsxs(n.div, {
                        variants: s,
                        className: "text-center mb-16",
                        children: [r.jsx("h2", {
                            className: "text-3xl md:text-4xl font-bold text-gray-900 mb-4",
                            children: "Our Impact"
                        }), r.jsx("p", {
                            className: "text-xl text-gray-700 max-w-3xl mx-auto",
                            children: "Discover how our initiatives are transforming lives and advancing human progress across the globe."
                        })]
                    }), r.jsx(n.div, {
                        variants: i,
                        className: "grid grid-cols-1 md:grid-cols-3 gap-8 mb-16",
                        children: o.map(((e, t) => r.jsx(n.div, {
                            variants: s,
                            whileHover: {
                                y: -10
                            },
                            transition: {
                                duration: .3
                            },
                            children: r.jsx(Z, {
                                title: e.label,
                                value: e.value,
                                icon: e.icon,
                                color: e.color
                            })
                        }, t)))
                    }), r.jsx(n.div, {
                        variants: i,
                        className: "grid grid-cols-1 md:grid-cols-3 gap-8",
                        children: [{
                            title: "Breakthrough in Cellular Reprogramming",
                            description: "Our funded research has led to a revolutionary technique that can reverse cellular aging, with profound implications for treating age-related diseases.",
                            imageUrl: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=800&q=80",
                            category: "Research",
                            link: "/impact/stories/cellular-reprogramming-breakthrough"
                        }, {
                            title: "AI Safety Framework Adoption",
                            description: "Our AI alignment framework has been adopted by leading tech companies, ensuring safer development of advanced artificial intelligence systems.",
                            imageUrl: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&q=80",
                            category: "Technology",
                            link: "/impact/stories/ai-alignment-framework"
                        }, {
                            title: "Global Scholars Program Expansion",
                            description: "Our STEM education initiative has expanded to 25 new countries, providing opportunities for talented students from underserved communities.",
                            imageUrl: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80",
                            category: "Education",
                            link: "/impact/stories/global-scholars-expansion"
                        }].map(((e, t) => r.jsx(n.div, {
                            variants: s,
                            whileHover: {
                                y: -10
                            },
                            transition: {
                                duration: .3
                            },
                            children: r.jsx(Z, {
                                title: e.title,
                                description: e.description,
                                imageUrl: e.imageUrl,
                                link: e.link,
                                color: "default"
                            })
                        }, t)))
                    }), r.jsx(n.div, {
                        variants: s,
                        className: "mt-16 text-center",
                        children: r.jsxs(w, {
                            to: "/impact/stories",
                            className: "inline-flex items-center text-black font-semibold hover:text-black-900 transition-colors",
                            children: ["View all impact stories", r.jsx(l, {
                                className: "ml-2 h-4 w-4"
                            })]
                        })
                    })]
                })
            })
        })
    },
    K = () => {
        const [e, t] = j.useState(""), [a, i] = j.useState(!1), [s, o] = j.useState(!1), {
            toast: c
        } = m(), d = F(), [h, f] = W({
            triggerOnce: !0,
            threshold: .1
        });
        j.useEffect((() => {
            f && d.start("visible")
        }), [d, f]);
        const y = {
                hidden: {
                    opacity: 0
                },
                visible: {
                    opacity: 1,
                    transition: {
                        staggerChildren: .2
                    }
                }
            },
            N = {
                hidden: {
                    opacity: 0,
                    y: 30
                },
                visible: {
                    opacity: 1,
                    y: 0,
                    transition: {
                        duration: .8,
                        ease: [.22, 1, .36, 1]
                    }
                }
            };
        return r.jsx("section", {
            className: "py-20 bg-gray-50",
            children: r.jsx("div", {
                className: "container mx-auto px-4",
                children: r.jsxs(n.div, {
                    ref: h,
                    animate: d,
                    initial: "hidden",
                    variants: y,
                    children: [r.jsxs(n.div, {
                        variants: N,
                        className: "flex flex-col md:flex-row md:items-center md:justify-between mb-12",
                        children: [r.jsxs("div", {
                            children: [r.jsx("h2", {
                                className: "text-3xl md:text-4xl font-bold text-gray-900 mb-2",
                                children: "Latest News"
                            }), r.jsx("p", {
                                className: "text-xl text-gray-700",
                                children: "Stay updated with the latest developments and announcements"
                            })]
                        }), r.jsxs(w, {
                            to: "/news",
                            className: "inline-flex items-center text-black-700 font-semibold hover:text-black-900 transition-colors mt-4 md:mt-0",
                            children: ["View all news", r.jsx(l, {
                                className: "ml-2 h-4 w-4"
                            })]
                        })]
                    }), r.jsx(n.div, {
                        variants: y,
                        className: "grid grid-cols-1 md:grid-cols-3 gap-8",
                        children: [{
                            title: "Nynexa Foundation Launches New STEM Education Initiative",
                            date: "June 15, 2023",
                            excerpt: "The Nynexa Foundation has announced a groundbreaking new program aimed at advancing STEM education across underserved communities worldwide.",
                            imageUrl: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80",
                            category: "Education",
                            link: "/news/stem-education-initiative"
                        }, {
                            title: "Breakthrough in Quantum Computing Research",
                            date: "May 28, 2023",
                            excerpt: "Researchers funded by the Nynexa Foundation have achieved a significant breakthrough in quantum computing that could revolutionize the field.",
                            imageUrl: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&q=80",
                            category: "Research",
                            link: "/news/quantum-computing-breakthrough"
                        }, {
                            title: "Global Climate Initiative Receives $500M Funding",
                            date: "April 22, 2023",
                            excerpt: "The Billionaire Fund has committed $500 million to a new global initiative aimed at developing innovative solutions to combat climate change.",
                            imageUrl: "https://images.unsplash.com/photo-1534274988757-a28bf1a57c17?w=800&q=80",
                            category: "Funding",
                            link: "/news/climate-initiative-funding"
                        }].map(((e, t) => r.jsx(n.div, {
                            variants: N,
                            whileHover: {
                                y: -10
                            },
                            transition: {
                                duration: .3
                            },
                            children: r.jsx(V, {
                                title: e.title,
                                date: e.date,
                                excerpt: e.excerpt,
                                imageUrl: e.imageUrl,
                                category: e.category,
                                link: e.link
                            })
                        }, t)))
                    }), r.jsxs(n.div, {
                        variants: N,
                        className: "mt-16 p-8 bg-gray-50 rounded-xl flex flex-col md:flex-row md:items-center md:justify-between border border-gray-200 shadow-sm",
                        children: [r.jsxs("div", {
                            className: "mb-6 md:mb-0 md:mr-8",
                            children: [r.jsx("h3", {
                                className: "text-2xl font-bold text-gray-900 mb-2",
                                children: "Subscribe to Our Newsletter"
                            }), r.jsx("p", {
                                className: "text-gray-700",
                                children: "Get the latest updates on our work, events, and opportunities delivered to your inbox."
                            })]
                        }), s ? r.jsxs("div", {
                            className: "flex items-center space-x-2 text-black p-4 bg-green-50 rounded-lg",
                            children: [r.jsx(x, {
                                className: "h-6 w-6 text-green-500"
                            }), r.jsx("p", {
                                className: "font-medium",
                                children: "Thank you for subscribing!"
                            })]
                        }) : r.jsxs("div", {
                            className: "flex flex-col w-full md:w-auto",
                            children: [r.jsxs("form", {
                                onSubmit: async a => {
                                    if (a.preventDefault(), e) {
                                        i(!0);
                                        try {
                                            const a = await b(e);
                                            if (!a.success) throw new Error(a.message);
                                            o(!0), c({
                                                title: "Subscription successful!",
                                                description: a.message
                                            }), t("")
                                        } catch (s) {
                                            c({
                                                title: "Subscription failed",
                                                description: s.message || "There was an error subscribing to the newsletter.",
                                                variant: "destructive"
                                            })
                                        } finally {
                                            i(!1)
                                        }
                                    }
                                },
                                className: "flex",
                                children: [r.jsxs("div", {
                                    className: "relative flex-grow",
                                    children: [r.jsx(u, {
                                        className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                                    }), r.jsx(g, {
                                        type: "email",
                                        placeholder: "Your email address",
                                        className: "pl-10 bg-white border-gray-200 w-full",
                                        value: e,
                                        onChange: e => t(e.target.value),
                                        required: !0
                                    }), r.jsx("input", {
                                        type: "text",
                                        tabIndex: -1,
                                        name: "b_1487cc549a49109c00fe60a80_93cd7be172",
                                        style: {
                                            position: "absolute",
                                            left: "-5000px"
                                        },
                                        "aria-hidden": "true"
                                    })]
                                }), r.jsx(p, {
                                    type: "submit",
                                    size: "lg",
                                    variant: "default",
                                    className: "ml-2 bg-black-700 hover:bg-black-800",
                                    disabled: a,
                                    children: a ? r.jsxs(r.Fragment, {
                                        children: [r.jsx(v, {
                                            className: "mr-2 h-4 w-4 animate-spin"
                                        }), "Subscribing..."]
                                    }) : "Subscribe"
                                })]
                            }), r.jsx("p", {
                                className: "text-xs text-gray-500 mt-2",
                                children: "We respect your privacy. Unsubscribe at any time."
                            })]
                        })]
                    })]
                })
            })
        })
    },
    X = ({
        title: e = "Join Our Mission",
        description: t = "Together, we can drive innovation and create positive change for generations to come.",
        actions: a = [{
            label: "Make a Donation",
            href: "/get-involved/donate",
            icon: r.jsx(L, {
                className: "mr-2 h-4 w-4"
            }),
            variant: "default"
        }, {
            label: "Become a Partner",
            href: "/get-involved/partners",
            icon: r.jsx(H, {
                className: "mr-2 h-4 w-4"
            }),
            variant: "outline"
        }, {
            label: "Explore Initiatives",
            href: "/work",
            icon: r.jsx(N, {
                className: "mr-2 h-4 w-4"
            }),
            variant: "outline"
        }],
        backgroundColor: i = "bg-black-900"
    }) => r.jsx("section", {
        className: `${i} text-white py-16 px-4 md:py-20 md:px-8 lg:px-16 w-full`,
        children: r.jsx("div", {
            className: "max-w-7xl mx-auto",
            children: r.jsxs(n.div, {
                initial: {
                    opacity: 0
                },
                whileInView: {
                    opacity: 1
                },
                viewport: {
                    once: !0
                },
                transition: {
                    duration: .5
                },
                className: "grid grid-cols-1 lg:grid-cols-2 gap-8 items-center",
                children: [r.jsxs("div", {
                    children: [r.jsx(n.h2, {
                        initial: {
                            opacity: 0,
                            y: 20
                        },
                        whileInView: {
                            opacity: 1,
                            y: 0
                        },
                        viewport: {
                            once: !0
                        },
                        transition: {
                            duration: .5
                        },
                        className: "text-3xl md:text-4xl font-bold mb-4",
                        children: e
                    }), r.jsx(n.p, {
                        initial: {
                            opacity: 0,
                            y: 20
                        },
                        whileInView: {
                            opacity: 1,
                            y: 0
                        },
                        viewport: {
                            once: !0
                        },
                        transition: {
                            duration: .5,
                            delay: .1
                        },
                        className: "text-lg md:text-xl text-gray-300 mb-6 max-w-2xl",
                        children: t
                    })]
                }), r.jsx("div", {
                    className: "flex flex-col sm:flex-row flex-wrap gap-4 justify-start lg:justify-end",
                    children: a.map(((e, t) => r.jsx(n.div, {
                        initial: {
                            opacity: 0,
                            y: 20
                        },
                        whileInView: {
                            opacity: 1,
                            y: 0
                        },
                        viewport: {
                            once: !0
                        },
                        transition: {
                            duration: .5,
                            delay: .1 + .1 * t
                        },
                        className: "mission-button-container",
                        children: r.jsxs("a", {
                            href: e.href,
                            className: `\n                    inline-flex items-center px-6 py-3 rounded-lg font-medium shadow-lg transition-all duration-200\n                    ${"default"===e.variant?"bg-white text-black hover:bg-gray-200":""}\n                    ${"secondary"===e.variant?"bg-black-600 text-white hover:bg-black-500":""}\n                    ${"outline"===e.variant?"border-2 border-white text-white bg-transparent hover:bg-white hover:text-black":""}\n                  `,
                            children: [e.icon, e.label, r.jsx(l, {
                                className: "ml-2 h-4 w-4"
                            })]
                        })
                    }, t)))
                })]
            })
        })
    }),
    ee = () => {
        const e = F(),
            [t, a] = W({
                triggerOnce: !0,
                threshold: .1
            });
        return j.useEffect((() => {
            a && e.start("visible")
        }), [e, a]), r.jsxs(f, {
            children: [r.jsx(y, {
                title: "Advancing Humanity Through Innovation",
                description: "The Nynexa Foundation is dedicated to advancing humanity through groundbreaking research, strategic investments, and educational initiatives.",
                keywords: "innovation, research, education, philanthropy, technology, science, STEM"
            }), r.jsx(D, {}), r.jsxs(n.div, {
                ref: t,
                animate: e,
                initial: "hidden",
                variants: {
                    visible: {
                        opacity: 1,
                        y: 0,
                        transition: {
                            duration: .5,
                            staggerChildren: .3
                        }
                    },
                    hidden: {
                        opacity: 0,
                        y: 50
                    }
                },
                children: [r.jsx(G, {}), r.jsx(Y, {}), r.jsx(Q, {}), r.jsx(K, {}), r.jsx(X, {})]
            })]
        })
    };
export {
    ee as
    default
};
//# sourceMappingURL=HomePage-r3k_KD5L.js.map