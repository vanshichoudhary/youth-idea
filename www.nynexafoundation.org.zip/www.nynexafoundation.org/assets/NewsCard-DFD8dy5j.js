import {
    j as e,
    m as a,
    d as s,
    A as l
} from "./index-AQVjGcvK.js";
import {
    C as t,
    a as r,
    b as i,
    c as n,
    d as o,
    e as c
} from "./card-C3HleBDS.js";
import {
    C as d
} from "./calendar-yjCJPMYD.js";
const m = ({
    title: m = "Nynexa Foundation Launches New STEM Education Initiative",
    date: x = "June 15, 2023",
    excerpt: h = "The Nynexa Foundation has announced a groundbreaking new program aimed at advancing STEM education across underserved communities worldwide.",
    imageUrl: u = "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80",
    category: p = "Education",
    link: j = "#",
    className: f
}) => e.jsx(a.div, {
    whileHover: {
        y: -5
    },
    transition: {
        duration: .3
    },
    className: s("h-full", f),
    children: e.jsxs(t, {
        className: "overflow-hidden h-full flex flex-col bg-white",
        children: [e.jsxs("div", {
            className: "relative h-48 overflow-hidden",
            children: [e.jsx("img", {
                src: u,
                alt: m,
                className: "w-full h-full object-cover transition-transform duration-500 hover:scale-105"
            }), e.jsx("div", {
                className: "absolute top-4 left-4 bg-purple-700 text-white text-xs font-semibold py-1 px-2 rounded",
                children: p
            })]
        }), e.jsxs(r, {
            children: [e.jsxs("div", {
                className: "flex items-center text-sm text-gray-500 mb-2",
                children: [e.jsx(d, {
                    className: "h-4 w-4 mr-1"
                }), e.jsx("span", {
                    children: x
                })]
            }), e.jsx(i, {
                className: "text-xl font-bold text-gray-800 line-clamp-2 hover:text-purple-700 transition-colors",
                children: m
            })]
        }), e.jsx(n, {
            className: "flex-grow",
            children: e.jsx(o, {
                className: "text-gray-600 line-clamp-3",
                children: h
            })
        }), e.jsx(c, {
            className: "pt-2",
            children: e.jsxs("a", {
                href: j,
                className: "inline-flex items-center text-purple-700 font-medium hover:text-purple-900 transition-colors",
                children: ["Read more", e.jsx(l, {
                    className: "ml-2 h-4 w-4"
                })]
            })
        })]
    })
});
export {
    m as N
};
//# sourceMappingURL=NewsCard-DFD8dy5j.js.map