import {
    j as e,
    i as a,
    S as t,
    P as s,
    k as r,
    m as i,
    l as n,
    I as l,
    B as o
} from "./index-AQVjGcvK.js";
import {
    b as c
} from "./vendor-CDsBVsyF.js";
import {
    N as d
} from "./NewsCard-DFD8dy5j.js";
import {
    F as p
} from "./filter-DqTBH87M.js";
import {
    C as h
} from "./calendar-yjCJPMYD.js";
import "./card-C3HleBDS.js";
const m = () => {
    const [m, u] = c.useState(""), [x, g] = c.useState("All"), y = [{
        id: "1",
        title: "Nynexa Foundation Launches New Research Initiative",
        date: "April 15, 2023",
        excerpt: "The Nynexa Foundation announces a groundbreaking research initiative focused on sustainable technologies and their global implementation.",
        imageUrl: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80",
        category: "Research & Development",
        link: "/news/research-initiative"
    }, {
        id: "2",
        title: "Annual Billionaire Summit Addresses Global Challenges",
        date: "March 28, 2023",
        excerpt: "Leading philanthropists and innovators gathered at the exclusive Nynexa Billionaire Summit to discuss collaborative approaches to solving humanity's most pressing issues.",
        imageUrl: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&q=80",
        category: "Billionaire Fund",
        link: "/news/billionaire-summit"
    }, {
        id: "3",
        title: "Nynexa Academy Opens Applications for Fall Semester",
        date: "March 10, 2023",
        excerpt: "The prestigious Nynexa Academy is now accepting applications for its innovative STEM programs designed to nurture the next generation of visionary leaders.",
        imageUrl: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=800&q=80",
        category: "Education & STEM",
        link: "/news/academy-applications"
    }, {
        id: "4",
        title: "Breakthrough in Longevity Research Funded by Nynexa",
        date: "February 22, 2023",
        excerpt: "Scientists supported by the Nynexa Foundation have identified a key cellular pathway that could significantly extend human healthspan.",
        imageUrl: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=800&q=80",
        category: "Research & Development",
        link: "/news/longevity-breakthrough"
    }, {
        id: "5",
        title: "Nynexa Foundation Partners with Global Universities",
        date: "February 15, 2023",
        excerpt: "New academic partnerships will accelerate research and create opportunities for talented students worldwide.",
        imageUrl: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800&q=80",
        category: "Partnerships",
        link: "/news/university-partnerships"
    }, {
        id: "6",
        title: "AI for Climate Solutions Initiative Launches",
        date: "January 30, 2023",
        excerpt: "The Nynexa Foundation announces a new program leveraging artificial intelligence to address climate change challenges.",
        imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80",
        category: "Research & Development",
        link: "/news/ai-climate-initiative"
    }, {
        id: "7",
        title: "Nynexa Foundation Releases Annual Impact Report",
        date: "January 15, 2023",
        excerpt: "The report highlights significant progress across all three pillars of the Foundation's work during the past year.",
        imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80",
        category: "Foundation Updates",
        link: "/news/annual-report-2022"
    }, {
        id: "8",
        title: "Global STEM Education Initiative Reaches 100,000 Students",
        date: "December 12, 2022",
        excerpt: "The Nynexa Foundation's flagship education program has now impacted students across 25 countries.",
        imageUrl: "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800&q=80",
        category: "Education & STEM",
        link: "/news/stem-initiative-milestone"
    }, {
        id: "9",
        title: "Nynexa Foundation Welcomes New Board Members",
        date: "November 28, 2022",
        excerpt: "Three distinguished leaders in science, technology, and philanthropy join the Foundation's Board of Directors.",
        imageUrl: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=800&q=80",
        category: "Foundation Updates",
        link: "/news/new-board-members"
    }], b = ["All", ...new Set(y.map((e => e.category)))], v = y.filter((e => {
        const a = e.title.toLowerCase().includes(m.toLowerCase()) || e.excerpt.toLowerCase().includes(m.toLowerCase()),
            t = "All" === x || e.category === x;
        return a && t
    }));
    return e.jsxs(a, {
        children: [e.jsx(t, {
            title: "News & Insights",
            description: "Stay informed about the latest news, events, and insights from the Nynexa Foundation.",
            keywords: "Nynexa Foundation news, updates, press releases, events, insights, announcements"
        }), e.jsx(s, {
            title: "News & Insights",
            subtitle: "Stay informed about our latest initiatives, breakthroughs, and events",
            backgroundImage: "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=1920&q=80"
        }), e.jsxs("div", {
            className: "container mx-auto px-4 py-12",
            children: [e.jsx(r, {
                overrides: {
                    news: "News & Insights"
                }
            }), e.jsxs("div", {
                className: "max-w-7xl mx-auto",
                children: [e.jsxs(i.section, {
                    initial: {
                        opacity: 0,
                        y: 20
                    },
                    whileInView: {
                        opacity: 1,
                        y: 0
                    },
                    viewport: {
                        once: !0
                    },
                    transition: {
                        duration: .5
                    },
                    children: [e.jsxs("div", {
                        className: "flex flex-col md:flex-row gap-4 mb-8",
                        children: [e.jsxs("div", {
                            className: "relative flex-grow",
                            children: [e.jsx(n, {
                                className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5"
                            }), e.jsx(l, {
                                type: "text",
                                placeholder: "Search news...",
                                className: "pl-10 py-6 border-gray-300",
                                value: m,
                                onChange: e => u(e.target.value)
                            })]
                        }), e.jsxs("div", {
                            className: "relative",
                            children: [e.jsx(p, {
                                className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5"
                            }), e.jsx("select", {
                                className: "pl-10 py-2 pr-8 border border-gray-300 rounded-md bg-white h-12 w-full md:w-64 appearance-none focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent",
                                value: x,
                                onChange: e => g(e.target.value),
                                children: b.map((a => e.jsx("option", {
                                    value: a,
                                    children: a
                                }, a)))
                            }), e.jsx("div", {
                                className: "absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none",
                                children: e.jsx("svg", {
                                    className: "w-5 h-5 text-gray-400",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: e.jsx("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "2",
                                        d: "M19 9l-7 7-7-7"
                                    })
                                })
                            })]
                        })]
                    }), v.length > 0 ? e.jsx("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12",
                        children: v.map(((a, t) => e.jsx(i.div, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            whileInView: {
                                opacity: 1,
                                y: 0
                            },
                            viewport: {
                                once: !0
                            },
                            transition: {
                                duration: .5,
                                delay: .1 * t
                            },
                            children: e.jsx(d, {
                                title: a.title,
                                date: a.date,
                                excerpt: a.excerpt,
                                imageUrl: a.imageUrl,
                                category: a.category,
                                link: a.link
                            })
                        }, a.id)))
                    }) : e.jsxs("div", {
                        className: "text-center py-12 bg-gray-50 rounded-lg",
                        children: [e.jsx("p", {
                            className: "text-gray-600 mb-4",
                            children: "No news articles matching your criteria."
                        }), e.jsx(o, {
                            variant: "outline",
                            className: "border-purple-700 text-purple-700 hover:bg-purple-50",
                            onClick: () => {
                                u(""), g("All")
                            },
                            children: "Clear Filters"
                        })]
                    }), e.jsx("div", {
                        className: "flex justify-center",
                        children: e.jsxs("div", {
                            className: "flex items-center space-x-2",
                            children: [e.jsx(o, {
                                variant: "outline",
                                className: "border-gray-300 text-gray-600",
                                disabled: !0,
                                children: "Previous"
                            }), e.jsx(o, {
                                variant: "outline",
                                className: "border-purple-700 bg-purple-700 text-white hover:bg-purple-800",
                                children: "1"
                            }), e.jsx(o, {
                                variant: "outline",
                                className: "border-gray-300 text-gray-600 hover:border-purple-700 hover:text-purple-700",
                                children: "2"
                            }), e.jsx(o, {
                                variant: "outline",
                                className: "border-gray-300 text-gray-600 hover:border-purple-700 hover:text-purple-700",
                                children: "3"
                            }), e.jsx(o, {
                                variant: "outline",
                                className: "border-gray-300 text-gray-600 hover:border-purple-700 hover:text-purple-700",
                                children: "Next"
                            })]
                        })
                    })]
                }), e.jsxs(i.section, {
                    initial: {
                        opacity: 0,
                        y: 20
                    },
                    whileInView: {
                        opacity: 1,
                        y: 0
                    },
                    viewport: {
                        once: !0
                    },
                    transition: {
                        duration: .5,
                        delay: .2
                    },
                    className: "mt-16",
                    children: [e.jsx("h2", {
                        className: "text-2xl font-bold text-purple-900 mb-6",
                        children: "Upcoming Events"
                    }), e.jsxs("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
                        children: [e.jsxs("div", {
                            className: "bg-white rounded-lg shadow-sm border border-gray-100 p-6",
                            children: [e.jsxs("div", {
                                className: "flex items-center text-purple-700 mb-3",
                                children: [e.jsx(h, {
                                    className: "h-5 w-5 mr-2"
                                }), e.jsx("span", {
                                    className: "text-sm font-medium",
                                    children: "May 15-17, 2023"
                                })]
                            }), e.jsx("h3", {
                                className: "text-lg font-bold text-gray-900 mb-2",
                                children: "Nynexa Global Innovation Summit"
                            }), e.jsx("p", {
                                className: "text-gray-600 text-sm mb-4",
                                children: "New York, NY & Virtual"
                            }), e.jsx("p", {
                                className: "text-gray-600 mb-4",
                                children: "Join leaders from science, technology, business, and policy to explore solutions to humanity's greatest challenges."
                            }), e.jsx(o, {
                                variant: "outline",
                                className: "w-full border-purple-700 text-purple-700 hover:bg-purple-50",
                                asChild: !0,
                                children: e.jsx("a", {
                                    href: "/events/innovation-summit",
                                    children: "Learn More"
                                })
                            })]
                        }), e.jsxs("div", {
                            className: "bg-white rounded-lg shadow-sm border border-gray-100 p-6",
                            children: [e.jsxs("div", {
                                className: "flex items-center text-purple-700 mb-3",
                                children: [e.jsx(h, {
                                    className: "h-5 w-5 mr-2"
                                }), e.jsx("span", {
                                    className: "text-sm font-medium",
                                    children: "June 8, 2023"
                                })]
                            }), e.jsx("h3", {
                                className: "text-lg font-bold text-gray-900 mb-2",
                                children: "AI Safety Symposium"
                            }), e.jsx("p", {
                                className: "text-gray-600 text-sm mb-4",
                                children: "Virtual Event"
                            }), e.jsx("p", {
                                className: "text-gray-600 mb-4",
                                children: "A virtual symposium exploring the latest research and approaches to ensuring beneficial and safe artificial intelligence."
                            }), e.jsx(o, {
                                variant: "outline",
                                className: "w-full border-purple-700 text-purple-700 hover:bg-purple-50",
                                asChild: !0,
                                children: e.jsx("a", {
                                    href: "/events/ai-safety-symposium",
                                    children: "Learn More"
                                })
                            })]
                        }), e.jsxs("div", {
                            className: "bg-white rounded-lg shadow-sm border border-gray-100 p-6",
                            children: [e.jsxs("div", {
                                className: "flex items-center text-purple-700 mb-3",
                                children: [e.jsx(h, {
                                    className: "h-5 w-5 mr-2"
                                }), e.jsx("span", {
                                    className: "text-sm font-medium",
                                    children: "July 22-24, 2023"
                                })]
                            }), e.jsx("h3", {
                                className: "text-lg font-bold text-gray-900 mb-2",
                                children: "STEM Education Conference"
                            }), e.jsx("p", {
                                className: "text-gray-600 text-sm mb-4",
                                children: "Singapore & Virtual"
                            }), e.jsx("p", {
                                className: "text-gray-600 mb-4",
                                children: "Educators, researchers, and innovators gather to share best practices in STEM education for the 21st century."
                            }), e.jsx(o, {
                                variant: "outline",
                                className: "w-full border-purple-700 text-purple-700 hover:bg-purple-50",
                                asChild: !0,
                                children: e.jsx("a", {
                                    href: "/events/stem-education-conference",
                                    children: "Learn More"
                                })
                            })]
                        })]
                    })]
                })]
            })]
        })]
    })
};
export {
    m as
    default
};
//# sourceMappingURL=NewsPage-DW-E3f0q.js.map