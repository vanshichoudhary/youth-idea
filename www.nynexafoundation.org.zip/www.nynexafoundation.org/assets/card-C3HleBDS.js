import {
    j as a,
    d as s
} from "./index-AQVjGcvK.js";
import {
    b as e
} from "./vendor-CDsBVsyF.js";
const r = e.forwardRef((({
    className: e,
    ...r
}, d) => a.jsx("div", {
    ref: d,
    className: s("rounded-xl border bg-card text-card-foreground shadow", e),
    ...r
})));
r.displayName = "Card";
const d = e.forwardRef((({
    className: e,
    ...r
}, d) => a.jsx("div", {
    ref: d,
    className: s("flex flex-col space-y-1.5 p-6", e),
    ...r
})));
d.displayName = "CardHeader";
const o = e.forwardRef((({
    className: e,
    ...r
}, d) => a.jsx("h3", {
    ref: d,
    className: s("font-semibold leading-none tracking-tight", e),
    ...r
})));
o.displayName = "CardTitle";
const t = e.forwardRef((({
    className: e,
    ...r
}, d) => a.jsx("p", {
    ref: d,
    className: s("text-sm text-muted-foreground", e),
    ...r
})));
t.displayName = "CardDescription";
const c = e.forwardRef((({
    className: e,
    ...r
}, d) => a.jsx("div", {
    ref: d,
    className: s("p-6 pt-0", e),
    ...r
})));
c.displayName = "CardContent";
const f = e.forwardRef((({
    className: e,
    ...r
}, d) => a.jsx("div", {
    ref: d,
    className: s("flex items-center p-6 pt-0", e),
    ...r
})));
f.displayName = "CardFooter";
export {
    r as C, d as a, o as b, c, t as d, f as e
};
//# sourceMappingURL=card-C3HleBDS.js.map