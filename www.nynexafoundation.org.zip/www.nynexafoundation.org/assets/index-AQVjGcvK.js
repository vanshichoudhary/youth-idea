const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/browser-Cix0Qkrg.js", "assets/vendor-CDsBVsyF.js", "assets/HomePage-r3k_KD5L.js", "assets/external-link-DoMSGJsZ.js", "assets/card-C3HleBDS.js", "assets/trending-up-cHYr1Zor.js", "assets/users-CvcoJy48.js", "assets/zap-DEHoMbld.js", "assets/NewsCard-DFD8dy5j.js", "assets/calendar-yjCJPMYD.js", "assets/NewsPage-DW-E3f0q.js", "assets/filter-DqTBH87M.js", "assets/ContactPage-Br1cbQZq.js", "assets/map-pin-BmN4V0va.js", "assets/NotFound-C03kZNmN.js", "assets/GovernanceLeadershipPage-8XYRwW08.js", "assets/shield-DgEEsH5E.js", "assets/scale-DPorXkmO.js", "assets/file-text-BkixgwiT.js", "assets/VisionMissionPage-CeCR5xjZ.js", "assets/StoriesPage-CONwsZ32.js", "assets/ReportsPage-ZPyHQw6c.js", "assets/DonatePage-pkAiZeYW.js", "assets/PartnersPage-fqi53bUE.js", "assets/CareersPage-KuRYqTpt.js", "assets/ResearchDevelopmentPage-BXWeFgbV.js", "assets/brain-BpzxKpoJ.js", "assets/sparkles-Dkop4sr-.js", "assets/globe-DQab3m7f.js", "assets/EducationStemPage-DaNNpYpM.js", "assets/BillionaireFundPage-BqFKLyDf.js"]))) => i.map(i => d[i]);
var e, t, r = Object.defineProperty,
    n = (e, t, n) => ((e, t, n) => t in e ? r(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : e[t] = n)(e, "symbol" != typeof t ? t + "" : t, n);
import {
    r as s,
    a as i,
    b as o,
    g as a,
    c as l,
    L as c,
    R as u,
    d,
    e as h,
    f as p,
    u as f,
    h as m,
    i as g,
    j as y,
    N as v,
    B as b
} from "./vendor-CDsBVsyF.js";
! function() {
    const e = document.createElement("link").relList;
    if (!(e && e.supports && e.supports("modulepreload"))) {
        for (const e of document.querySelectorAll('link[rel="modulepreload"]')) t(e);
        new MutationObserver((e => {
            for (const r of e)
                if ("childList" === r.type)
                    for (const e of r.addedNodes) "LINK" === e.tagName && "modulepreload" === e.rel && t(e)
        })).observe(document, {
            childList: !0,
            subtree: !0
        })
    }

    function t(e) {
        if (e.ep) return;
        e.ep = !0;
        const t = function(e) {
            const t = {};
            return e.integrity && (t.integrity = e.integrity), e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy), "use-credentials" === e.crossOrigin ? t.credentials = "include" : "anonymous" === e.crossOrigin ? t.credentials = "omit" : t.credentials = "same-origin", t
        }(e);
        fetch(e.href, t)
    }
}();
var x, w, k = {
        exports: {}
    },
    j = {};
var S, T = (w || (w = 1, k.exports = function() {
        if (x) return j;
        x = 1;
        var e = s(),
            t = Symbol.for("react.element"),
            r = Symbol.for("react.fragment"),
            n = Object.prototype.hasOwnProperty,
            i = e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
            o = {
                key: !0,
                ref: !0,
                __self: !0,
                __source: !0
            };

        function a(e, r, s) {
            var a, l = {},
                c = null,
                u = null;
            for (a in void 0 !== s && (c = "" + s), void 0 !== r.key && (c = "" + r.key), void 0 !== r.ref && (u = r.ref), r) n.call(r, a) && !o.hasOwnProperty(a) && (l[a] = r[a]);
            if (e && e.defaultProps)
                for (a in r = e.defaultProps) void 0 === l[a] && (l[a] = r[a]);
            return {
                $$typeof: t,
                type: e,
                key: c,
                ref: u,
                props: l,
                _owner: i.current
            }
        }
        return j.Fragment = r, j.jsx = a, j.jsxs = a, j
    }()), k.exports),
    _ = {};
var E = function() {
    if (S) return _;
    S = 1;
    var e = i();
    return _.createRoot = e.createRoot, _.hydrateRoot = e.hydrateRoot, _
}();
const P = {},
    C = function(e, t, r) {
        let n = Promise.resolve();
        if (t && t.length > 0) {
            document.getElementsByTagName("link");
            const e = document.querySelector("meta[property=csp-nonce]"),
                r = (null == e ? void 0 : e.nonce) || (null == e ? void 0 : e.getAttribute("nonce"));
            n = Promise.allSettled(t.map((e => {
                if ((e = function(e) {
                        return "/" + e
                    }(e)) in P) return;
                P[e] = !0;
                const t = e.endsWith(".css"),
                    n = t ? '[rel="stylesheet"]' : "";
                if (document.querySelector(`link[href="${e}"]${n}`)) return;
                const s = document.createElement("link");
                return s.rel = t ? "stylesheet" : "modulepreload", t || (s.as = "script"), s.crossOrigin = "", s.href = e, r && s.setAttribute("nonce", r), document.head.appendChild(s), t ? new Promise(((t, r) => {
                    s.addEventListener("load", t), s.addEventListener("error", (() => r(new Error(`Unable to preload CSS for ${e}`))))
                })) : void 0
            })))
        }

        function s(e) {
            const t = new Event("vite:preloadError", {
                cancelable: !0
            });
            if (t.payload = e, window.dispatchEvent(t), !t.defaultPrevented) throw e
        }
        return n.then((t => {
            for (const e of t || []) "rejected" === e.status && s(e.reason);
            return e().catch(s)
        }))
    },
    O = o.createContext({});

function A(e) {
    const t = o.useRef(null);
    return null === t.current && (t.current = e()), t.current
}
const N = o.createContext(null),
    R = o.createContext({
        transformPagePoint: e => e,
        isStatic: !1,
        reducedMotion: "never"
    });
class I extends o.Component {
    getSnapshotBeforeUpdate(e) {
        const t = this.props.childRef.current;
        if (t && e.isPresent && !this.props.isPresent) {
            const e = this.props.sizeRef.current;
            e.height = t.offsetHeight || 0, e.width = t.offsetWidth || 0, e.top = t.offsetTop, e.left = t.offsetLeft
        }
        return null
    }
    componentDidUpdate() {}
    render() {
        return this.props.children
    }
}

function L({
    children: e,
    isPresent: t
}) {
    const r = o.useId(),
        n = o.useRef(null),
        s = o.useRef({
            width: 0,
            height: 0,
            top: 0,
            left: 0
        }),
        {
            nonce: i
        } = o.useContext(R);
    return o.useInsertionEffect((() => {
        const {
            width: e,
            height: o,
            top: a,
            left: l
        } = s.current;
        if (t || !n.current || !e || !o) return;
        n.current.dataset.motionPopId = r;
        const c = document.createElement("style");
        return i && (c.nonce = i), document.head.appendChild(c), c.sheet && c.sheet.insertRule(`\n          [data-motion-pop-id="${r}"] {\n            position: absolute !important;\n            width: ${e}px !important;\n            height: ${o}px !important;\n            top: ${a}px !important;\n            left: ${l}px !important;\n          }\n        `), () => {
            document.head.removeChild(c)
        }
    }), [t]), T.jsx(I, {
        isPresent: t,
        childRef: n,
        sizeRef: s,
        children: o.cloneElement(e, {
            ref: n
        })
    })
}
const M = ({
    children: e,
    initial: t,
    isPresent: r,
    onExitComplete: n,
    custom: s,
    presenceAffectsLayout: i,
    mode: a
}) => {
    const l = A(U),
        c = o.useId(),
        u = o.useCallback((e => {
            l.set(e, !0);
            for (const t of l.values())
                if (!t) return;
            n && n()
        }), [l, n]),
        d = o.useMemo((() => ({
            id: c,
            initial: t,
            isPresent: r,
            custom: s,
            onExitComplete: u,
            register: e => (l.set(e, !1), () => l.delete(e))
        })), i ? [Math.random(), u] : [r, u]);
    return o.useMemo((() => {
        l.forEach(((e, t) => l.set(t, !1)))
    }), [r]), o.useEffect((() => {
        !r && !l.size && n && n()
    }), [r]), "popLayout" === a && (e = T.jsx(L, {
        isPresent: r,
        children: e
    })), T.jsx(N.Provider, {
        value: d,
        children: e
    })
};

function U() {
    return new Map
}

function D(e = !0) {
    const t = o.useContext(N);
    if (null === t) return [!0, null];
    const {
        isPresent: r,
        onExitComplete: n,
        register: s
    } = t, i = o.useId();
    o.useEffect((() => {
        e && s(i)
    }), [e]);
    const a = o.useCallback((() => e && n && n(i)), [i, n, e]);
    return !r && n ? [!1, a] : [!0]
}
const $ = e => e.key || "";

function F(e) {
    const t = [];
    return o.Children.forEach(e, (e => {
        o.isValidElement(e) && t.push(e)
    })), t
}
const V = "undefined" != typeof window,
    B = V ? o.useLayoutEffect : o.useEffect,
    z = ({
        children: e,
        custom: t,
        initial: r = !0,
        onExitComplete: n,
        presenceAffectsLayout: s = !0,
        mode: i = "sync",
        propagate: a = !1
    }) => {
        const [l, c] = D(a), u = o.useMemo((() => F(e)), [e]), d = a && !l ? [] : u.map($), h = o.useRef(!0), p = o.useRef(u), f = A((() => new Map)), [m, g] = o.useState(u), [y, v] = o.useState(u);
        B((() => {
            h.current = !1, p.current = u;
            for (let e = 0; e < y.length; e++) {
                const t = $(y[e]);
                d.includes(t) ? f.delete(t) : !0 !== f.get(t) && f.set(t, !1)
            }
        }), [y, d.length, d.join("-")]);
        const b = [];
        if (u !== m) {
            let e = [...u];
            for (let t = 0; t < y.length; t++) {
                const r = y[t],
                    n = $(r);
                d.includes(n) || (e.splice(t, 0, r), b.push(r))
            }
            return "wait" === i && b.length && (e = b), v(F(e)), void g(u)
        }
        const {
            forceRender: x
        } = o.useContext(O);
        return T.jsx(T.Fragment, {
            children: y.map((e => {
                const o = $(e),
                    m = !(a && !l) && (u === y || d.includes(o));
                return T.jsx(M, {
                    isPresent: m,
                    initial: !(h.current && !r) && void 0,
                    custom: m ? void 0 : t,
                    presenceAffectsLayout: s,
                    mode: i,
                    onExitComplete: m ? void 0 : () => {
                        if (!f.has(o)) return;
                        f.set(o, !0);
                        let e = !0;
                        f.forEach((t => {
                            t || (e = !1)
                        })), e && (null == x || x(), v(p.current), a && (null == c || c()), n && n())
                    },
                    children: e
                }, o)
            }))
        })
    },
    W = e => e;
let H = W;

function q(e) {
    let t;
    return () => (void 0 === t && (t = e()), t)
}
const K = (e, t, r) => {
        const n = t - e;
        return 0 === n ? 1 : (r - e) / n
    },
    G = e => 1e3 * e,
    Y = e => e / 1e3,
    J = !1;
const X = ["read", "resolveKeyframes", "update", "preRender", "render", "postRender"];

function Z(e, t) {
    let r = !1,
        n = !0;
    const s = {
            delta: 0,
            timestamp: 0,
            isProcessing: !1
        },
        i = () => r = !0,
        o = X.reduce(((e, t) => (e[t] = function(e) {
            let t = new Set,
                r = new Set,
                n = !1,
                s = !1;
            const i = new WeakSet;
            let o = {
                delta: 0,
                timestamp: 0,
                isProcessing: !1
            };

            function a(t) {
                i.has(t) && (l.schedule(t), e()), t(o)
            }
            const l = {
                schedule: (e, s = !1, o = !1) => {
                    const a = o && n ? t : r;
                    return s && i.add(e), a.has(e) || a.add(e), e
                },
                cancel: e => {
                    r.delete(e), i.delete(e)
                },
                process: e => {
                    o = e, n ? s = !0 : (n = !0, [t, r] = [r, t], t.forEach(a), t.clear(), n = !1, s && (s = !1, l.process(e)))
                }
            };
            return l
        }(i), e)), {}),
        {
            read: a,
            resolveKeyframes: l,
            update: c,
            preRender: u,
            render: d,
            postRender: h
        } = o,
        p = () => {
            const i = performance.now();
            r = !1, s.delta = n ? 1e3 / 60 : Math.max(Math.min(i - s.timestamp, 40), 1), s.timestamp = i, s.isProcessing = !0, a.process(s), l.process(s), c.process(s), u.process(s), d.process(s), h.process(s), s.isProcessing = !1, r && t && (n = !1, e(p))
        };
    return {
        schedule: X.reduce(((t, i) => {
            const a = o[i];
            return t[i] = (t, i = !1, o = !1) => (r || (r = !0, n = !0, s.isProcessing || e(p)), a.schedule(t, i, o)), t
        }), {}),
        cancel: e => {
            for (let t = 0; t < X.length; t++) o[X[t]].cancel(e)
        },
        state: s,
        steps: o
    }
}
const {
    schedule: Q,
    cancel: ee,
    state: te,
    steps: re
} = Z("undefined" != typeof requestAnimationFrame ? requestAnimationFrame : W, !0), ne = o.createContext({
    strict: !1
}), se = {
    animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
    exit: ["exit"],
    drag: ["drag", "dragControls"],
    focus: ["whileFocus"],
    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
    layout: ["layout", "layoutId"]
}, ie = {};
for (const Mw in se) ie[Mw] = {
    isEnabled: e => se[Mw].some((t => !!e[t]))
};
const oe = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "ignoreStrict", "viewport"]);

function ae(e) {
    return e.startsWith("while") || e.startsWith("drag") && "draggable" !== e || e.startsWith("layout") || e.startsWith("onTap") || e.startsWith("onPan") || e.startsWith("onLayout") || oe.has(e)
}
let le = e => !ae(e);
try {
    (ce = require("@emotion/is-prop-valid").default) && (le = e => e.startsWith("on") ? !ae(e) : ce(e))
} catch (Rw) {}
var ce;

function ue(e) {
    if ("undefined" == typeof Proxy) return e;
    const t = new Map;
    return new Proxy(((...t) => e(...t)), {
        get: (r, n) => "create" === n ? e : (t.has(n) || t.set(n, e(n)), t.get(n))
    })
}
const de = o.createContext({});

function he(e) {
    return "string" == typeof e || Array.isArray(e)
}

function pe(e) {
    return null !== e && "object" == typeof e && "function" == typeof e.start
}
const fe = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
    me = ["initial", ...fe];

function ge(e) {
    return pe(e.animate) || me.some((t => he(e[t])))
}

function ye(e) {
    return Boolean(ge(e) || e.variants)
}

function ve(e) {
    const {
        initial: t,
        animate: r
    } = function(e, t) {
        if (ge(e)) {
            const {
                initial: t,
                animate: r
            } = e;
            return {
                initial: !1 === t || he(t) ? t : void 0,
                animate: he(r) ? r : void 0
            }
        }
        return !1 !== e.inherit ? t : {}
    }(e, o.useContext(de));
    return o.useMemo((() => ({
        initial: t,
        animate: r
    })), [be(t), be(r)])
}

function be(e) {
    return Array.isArray(e) ? e.join(" ") : e
}
const xe = Symbol.for("motionComponentSymbol");

function we(e) {
    return e && "object" == typeof e && Object.prototype.hasOwnProperty.call(e, "current")
}

function ke(e, t, r) {
    return o.useCallback((n => {
        n && e.onMount && e.onMount(n), t && (n ? t.mount(n) : t.unmount()), r && ("function" == typeof r ? r(n) : we(r) && (r.current = n))
    }), [t])
}
const je = e => e.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase(),
    Se = "data-" + je("framerAppearId"),
    {
        schedule: Te
    } = Z(queueMicrotask, !1),
    _e = o.createContext({});

function Ee(e, t, r, n, s) {
    var i, a;
    const {
        visualElement: l
    } = o.useContext(de), c = o.useContext(ne), u = o.useContext(N), d = o.useContext(R).reducedMotion, h = o.useRef(null);
    n = n || c.renderer, !h.current && n && (h.current = n(e, {
        visualState: t,
        parent: l,
        props: r,
        presenceContext: u,
        blockInitialAnimation: !!u && !1 === u.initial,
        reducedMotionConfig: d
    }));
    const p = h.current,
        f = o.useContext(_e);
    !p || p.projection || !s || "html" !== p.type && "svg" !== p.type || function(e, t, r, n) {
        const {
            layoutId: s,
            layout: i,
            drag: o,
            dragConstraints: a,
            layoutScroll: l,
            layoutRoot: c
        } = t;
        e.projection = new r(e.latestValues, t["data-framer-portal-id"] ? void 0 : Pe(e.parent)), e.projection.setOptions({
            layoutId: s,
            layout: i,
            alwaysMeasureLayout: Boolean(o) || a && we(a),
            visualElement: e,
            animationType: "string" == typeof i ? i : "both",
            initialPromotionConfig: n,
            layoutScroll: l,
            layoutRoot: c
        })
    }(h.current, r, s, f);
    const m = o.useRef(!1);
    o.useInsertionEffect((() => {
        p && m.current && p.update(r, u)
    }));
    const g = r[Se],
        y = o.useRef(Boolean(g) && !(null === (i = window.MotionHandoffIsComplete) || void 0 === i ? void 0 : i.call(window, g)) && (null === (a = window.MotionHasOptimisedAnimation) || void 0 === a ? void 0 : a.call(window, g)));
    return B((() => {
        p && (m.current = !0, window.MotionIsMounted = !0, p.updateFeatures(), Te.render(p.render), y.current && p.animationState && p.animationState.animateChanges())
    })), o.useEffect((() => {
        p && (!y.current && p.animationState && p.animationState.animateChanges(), y.current && (queueMicrotask((() => {
            var e;
            null === (e = window.MotionHandoffMarkAsComplete) || void 0 === e || e.call(window, g)
        })), y.current = !1))
    })), p
}

function Pe(e) {
    if (e) return !1 !== e.options.allowProjection ? e.projection : Pe(e.parent)
}

function Ce({
    preloadedFeatures: e,
    createVisualElement: t,
    useRender: r,
    useVisualState: n,
    Component: s
}) {
    var i, a;

    function l(e, i) {
        let a;
        const l = { ...o.useContext(R),
                ...e,
                layoutId: Oe(e)
            },
            {
                isStatic: c
            } = l,
            u = ve(e),
            d = n(e, c);
        if (!c && V) {
            o.useContext(ne).strict;
            const e = function(e) {
                const {
                    drag: t,
                    layout: r
                } = ie;
                if (!t && !r) return {};
                const n = { ...t,
                    ...r
                };
                return {
                    MeasureLayout: (null == t ? void 0 : t.isEnabled(e)) || (null == r ? void 0 : r.isEnabled(e)) ? n.MeasureLayout : void 0,
                    ProjectionNode: n.ProjectionNode
                }
            }(l);
            a = e.MeasureLayout, u.visualElement = Ee(s, d, l, t, e.ProjectionNode)
        }
        return T.jsxs(de.Provider, {
            value: u,
            children: [a && u.visualElement ? T.jsx(a, {
                visualElement: u.visualElement,
                ...l
            }) : null, r(s, e, ke(d, u.visualElement, i), d, c, u.visualElement)]
        })
    }
    e && function(e) {
        for (const t in e) ie[t] = { ...ie[t],
            ...e[t]
        }
    }(e), l.displayName = `motion.${"string"==typeof s?s:`create(${null!==(a=null!==(i=s.displayName)&&void 0!==i?i:s.name)&&void 0!==a?a:""})`}`;
    const c = o.forwardRef(l);
    return c[xe] = s, c
}

function Oe({
    layoutId: e
}) {
    const t = o.useContext(O).id;
    return t && void 0 !== e ? t + "-" + e : e
}
const Ae = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

function Ne(e) {
    return "string" == typeof e && !e.includes("-") && !!(Ae.indexOf(e) > -1 || /[A-Z]/u.test(e))
}

function Re(e) {
    const t = [{}, {}];
    return null == e || e.values.forEach(((e, r) => {
        t[0][r] = e.get(), t[1][r] = e.getVelocity()
    })), t
}

function Ie(e, t, r, n) {
    if ("function" == typeof t) {
        const [s, i] = Re(n);
        t = t(void 0 !== r ? r : e.custom, s, i)
    }
    if ("string" == typeof t && (t = e.variants && e.variants[t]), "function" == typeof t) {
        const [s, i] = Re(n);
        t = t(void 0 !== r ? r : e.custom, s, i)
    }
    return t
}
const Le = e => Array.isArray(e),
    Me = e => Boolean(e && e.getVelocity);

function Ue(e) {
    const t = Me(e) ? e.get() : e;
    return r = t, Boolean(r && "object" == typeof r && r.mix && r.toValue) ? t.toValue() : t;
    var r
}
const De = e => (t, r) => {
    const n = o.useContext(de),
        s = o.useContext(N),
        i = () => function({
            scrapeMotionValuesFromProps: e,
            createRenderState: t,
            onUpdate: r
        }, n, s, i) {
            const o = {
                latestValues: $e(n, s, i, e),
                renderState: t()
            };
            return r && (o.onMount = e => r({
                props: n,
                current: e,
                ...o
            }), o.onUpdate = e => r(e)), o
        }(e, t, n, s);
    return r ? i() : A(i)
};

function $e(e, t, r, n) {
    const s = {},
        i = n(e, {});
    for (const h in i) s[h] = Ue(i[h]);
    let {
        initial: o,
        animate: a
    } = e;
    const l = ge(e),
        c = ye(e);
    t && c && !l && !1 !== e.inherit && (void 0 === o && (o = t.initial), void 0 === a && (a = t.animate));
    let u = !!r && !1 === r.initial;
    u = u || !1 === o;
    const d = u ? a : o;
    if (d && "boolean" != typeof d && !pe(d)) {
        const t = Array.isArray(d) ? d : [d];
        for (let r = 0; r < t.length; r++) {
            const n = Ie(e, t[r]);
            if (n) {
                const {
                    transitionEnd: e,
                    transition: t,
                    ...r
                } = n;
                for (const n in r) {
                    let e = r[n];
                    if (Array.isArray(e)) {
                        e = e[u ? e.length - 1 : 0]
                    }
                    null !== e && (s[n] = e)
                }
                for (const n in e) s[n] = e[n]
            }
        }
    }
    return s
}
const Fe = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
    Ve = new Set(Fe),
    Be = e => t => "string" == typeof t && t.startsWith(e),
    ze = Be("--"),
    We = Be("var(--"),
    He = e => !!We(e) && qe.test(e.split("/*")[0].trim()),
    qe = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,
    Ke = (e, t) => t && "number" == typeof e ? t.transform(e) : e,
    Ge = (e, t, r) => r > t ? t : r < e ? e : r,
    Ye = {
        test: e => "number" == typeof e,
        parse: parseFloat,
        transform: e => e
    },
    Je = { ...Ye,
        transform: e => Ge(0, 1, e)
    },
    Xe = { ...Ye,
        default: 1
    },
    Ze = e => ({
        test: t => "string" == typeof t && t.endsWith(e) && 1 === t.split(" ").length,
        parse: parseFloat,
        transform: t => `${t}${e}`
    }),
    Qe = Ze("deg"),
    et = Ze("%"),
    tt = Ze("px"),
    rt = Ze("vh"),
    nt = Ze("vw"),
    st = { ...et,
        parse: e => et.parse(e) / 100,
        transform: e => et.transform(100 * e)
    },
    it = {
        borderWidth: tt,
        borderTopWidth: tt,
        borderRightWidth: tt,
        borderBottomWidth: tt,
        borderLeftWidth: tt,
        borderRadius: tt,
        radius: tt,
        borderTopLeftRadius: tt,
        borderTopRightRadius: tt,
        borderBottomRightRadius: tt,
        borderBottomLeftRadius: tt,
        width: tt,
        maxWidth: tt,
        height: tt,
        maxHeight: tt,
        top: tt,
        right: tt,
        bottom: tt,
        left: tt,
        padding: tt,
        paddingTop: tt,
        paddingRight: tt,
        paddingBottom: tt,
        paddingLeft: tt,
        margin: tt,
        marginTop: tt,
        marginRight: tt,
        marginBottom: tt,
        marginLeft: tt,
        backgroundPositionX: tt,
        backgroundPositionY: tt
    },
    ot = {
        rotate: Qe,
        rotateX: Qe,
        rotateY: Qe,
        rotateZ: Qe,
        scale: Xe,
        scaleX: Xe,
        scaleY: Xe,
        scaleZ: Xe,
        skew: Qe,
        skewX: Qe,
        skewY: Qe,
        distance: tt,
        translateX: tt,
        translateY: tt,
        translateZ: tt,
        x: tt,
        y: tt,
        z: tt,
        perspective: tt,
        transformPerspective: tt,
        opacity: Je,
        originX: st,
        originY: st,
        originZ: tt
    },
    at = { ...Ye,
        transform: Math.round
    },
    lt = { ...it,
        ...ot,
        zIndex: at,
        size: tt,
        fillOpacity: Je,
        strokeOpacity: Je,
        numOctaves: at
    },
    ct = {
        x: "translateX",
        y: "translateY",
        z: "translateZ",
        transformPerspective: "perspective"
    },
    ut = Fe.length;

function dt(e, t, r) {
    const {
        style: n,
        vars: s,
        transformOrigin: i
    } = e;
    let o = !1,
        a = !1;
    for (const l in t) {
        const e = t[l];
        if (Ve.has(l)) o = !0;
        else if (ze(l)) s[l] = e;
        else {
            const t = Ke(e, lt[l]);
            l.startsWith("origin") ? (a = !0, i[l] = t) : n[l] = t
        }
    }
    if (t.transform || (o || r ? n.transform = function(e, t, r) {
            let n = "",
                s = !0;
            for (let i = 0; i < ut; i++) {
                const o = Fe[i],
                    a = e[o];
                if (void 0 === a) continue;
                let l = !0;
                if (l = "number" == typeof a ? a === (o.startsWith("scale") ? 1 : 0) : 0 === parseFloat(a), !l || r) {
                    const e = Ke(a, lt[o]);
                    l || (s = !1, n += `${ct[o]||o}(${e}) `), r && (t[o] = e)
                }
            }
            return n = n.trim(), r ? n = r(t, s ? "" : n) : s && (n = "none"), n
        }(t, e.transform, r) : n.transform && (n.transform = "none")), a) {
        const {
            originX: e = "50%",
            originY: t = "50%",
            originZ: r = 0
        } = i;
        n.transformOrigin = `${e} ${t} ${r}`
    }
}
const ht = {
        offset: "stroke-dashoffset",
        array: "stroke-dasharray"
    },
    pt = {
        offset: "strokeDashoffset",
        array: "strokeDasharray"
    };

function ft(e, t, r) {
    return "string" == typeof e ? e : tt.transform(t + r * e)
}

function mt(e, {
    attrX: t,
    attrY: r,
    attrScale: n,
    originX: s,
    originY: i,
    pathLength: o,
    pathSpacing: a = 1,
    pathOffset: l = 0,
    ...c
}, u, d) {
    if (dt(e, c, d), u) return void(e.style.viewBox && (e.attrs.viewBox = e.style.viewBox));
    e.attrs = e.style, e.style = {};
    const {
        attrs: h,
        style: p,
        dimensions: f
    } = e;
    h.transform && (f && (p.transform = h.transform), delete h.transform), f && (void 0 !== s || void 0 !== i || p.transform) && (p.transformOrigin = function(e, t, r) {
        return `${ft(t,e.x,e.width)} ${ft(r,e.y,e.height)}`
    }(f, void 0 !== s ? s : .5, void 0 !== i ? i : .5)), void 0 !== t && (h.x = t), void 0 !== r && (h.y = r), void 0 !== n && (h.scale = n), void 0 !== o && function(e, t, r = 1, n = 0, s = !0) {
        e.pathLength = 1;
        const i = s ? ht : pt;
        e[i.offset] = tt.transform(-n);
        const o = tt.transform(t),
            a = tt.transform(r);
        e[i.array] = `${o} ${a}`
    }(h, o, a, l, !1)
}
const gt = () => ({
        style: {},
        transform: {},
        transformOrigin: {},
        vars: {}
    }),
    yt = () => ({
        style: {},
        transform: {},
        transformOrigin: {},
        vars: {},
        attrs: {}
    }),
    vt = e => "string" == typeof e && "svg" === e.toLowerCase();

function bt(e, {
    style: t,
    vars: r
}, n, s) {
    Object.assign(e.style, t, s && s.getProjectionStyles(n));
    for (const i in r) e.style.setProperty(i, r[i])
}
const xt = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]);

function wt(e, t, r, n) {
    bt(e, t, void 0, n);
    for (const s in t.attrs) e.setAttribute(xt.has(s) ? s : je(s), t.attrs[s])
}
const kt = {};

function jt(e, {
    layout: t,
    layoutId: r
}) {
    return Ve.has(e) || e.startsWith("origin") || (t || void 0 !== r) && (!!kt[e] || "opacity" === e)
}

function St(e, t, r) {
    var n;
    const {
        style: s
    } = e, i = {};
    for (const o in s)(Me(s[o]) || t.style && Me(t.style[o]) || jt(o, e) || void 0 !== (null === (n = null == r ? void 0 : r.getValue(o)) || void 0 === n ? void 0 : n.liveStyle)) && (i[o] = s[o]);
    return i
}

function Tt(e, t, r) {
    const n = St(e, t, r);
    for (const s in e)
        if (Me(e[s]) || Me(t[s])) {
            n[-1 !== Fe.indexOf(s) ? "attr" + s.charAt(0).toUpperCase() + s.substring(1) : s] = e[s]
        }
    return n
}
const _t = ["x", "y", "width", "height", "cx", "cy", "r"],
    Et = {
        useVisualState: De({
            scrapeMotionValuesFromProps: Tt,
            createRenderState: yt,
            onUpdate: ({
                props: e,
                prevProps: t,
                current: r,
                renderState: n,
                latestValues: s
            }) => {
                if (!r) return;
                let i = !!e.drag;
                if (!i)
                    for (const a in s)
                        if (Ve.has(a)) {
                            i = !0;
                            break
                        }
                if (!i) return;
                let o = !t;
                if (t)
                    for (let a = 0; a < _t.length; a++) {
                        const r = _t[a];
                        e[r] !== t[r] && (o = !0)
                    }
                o && Q.read((() => {
                    ! function(e, t) {
                        try {
                            t.dimensions = "function" == typeof e.getBBox ? e.getBBox() : e.getBoundingClientRect()
                        } catch (r) {
                            t.dimensions = {
                                x: 0,
                                y: 0,
                                width: 0,
                                height: 0
                            }
                        }
                    }(r, n), Q.render((() => {
                        mt(n, s, vt(r.tagName), e.transformTemplate), wt(r, n)
                    }))
                }))
            }
        })
    },
    Pt = {
        useVisualState: De({
            scrapeMotionValuesFromProps: St,
            createRenderState: gt
        })
    };

function Ct(e, t, r) {
    for (const n in t) Me(t[n]) || jt(n, r) || (e[n] = t[n])
}

function Ot(e, t) {
    const r = {};
    return Ct(r, e.style || {}, e), Object.assign(r, function({
        transformTemplate: e
    }, t) {
        return o.useMemo((() => {
            const r = {
                style: {},
                transform: {},
                transformOrigin: {},
                vars: {}
            };
            return dt(r, t, e), Object.assign({}, r.vars, r.style)
        }), [t])
    }(e, t)), r
}

function At(e, t) {
    const r = {},
        n = Ot(e, t);
    return e.drag && !1 !== e.dragListener && (r.draggable = !1, n.userSelect = n.WebkitUserSelect = n.WebkitTouchCallout = "none", n.touchAction = !0 === e.drag ? "none" : "pan-" + ("x" === e.drag ? "y" : "x")), void 0 === e.tabIndex && (e.onTap || e.onTapStart || e.whileTap) && (r.tabIndex = 0), r.style = n, r
}

function Nt(e, t, r, n) {
    const s = o.useMemo((() => {
        const r = {
            style: {},
            transform: {},
            transformOrigin: {},
            vars: {},
            attrs: {}
        };
        return mt(r, t, vt(n), e.transformTemplate), { ...r.attrs,
            style: { ...r.style
            }
        }
    }), [t]);
    if (e.style) {
        const t = {};
        Ct(t, e.style, e), s.style = { ...t,
            ...s.style
        }
    }
    return s
}

function Rt(e = !1) {
    return (t, r, n, {
        latestValues: s
    }, i) => {
        const a = (Ne(t) ? Nt : At)(r, s, i, t),
            l = function(e, t, r) {
                const n = {};
                for (const s in e) "values" === s && "object" == typeof e.values || (le(s) || !0 === r && ae(s) || !t && !ae(s) || e.draggable && s.startsWith("onDrag")) && (n[s] = e[s]);
                return n
            }(r, "string" == typeof t, e),
            c = t !== o.Fragment ? { ...l,
                ...a,
                ref: n
            } : {},
            {
                children: u
            } = r,
            d = o.useMemo((() => Me(u) ? u.get() : u), [u]);
        return o.createElement(t, { ...c,
            children: d
        })
    }
}

function It(e, t) {
    return function(r, {
        forwardMotionProps: n
    } = {
        forwardMotionProps: !1
    }) {
        return Ce({ ...Ne(r) ? Et : Pt,
            preloadedFeatures: e,
            useRender: Rt(n),
            createVisualElement: t,
            Component: r
        })
    }
}

function Lt(e, t) {
    if (!Array.isArray(t)) return !1;
    const r = t.length;
    if (r !== e.length) return !1;
    for (let n = 0; n < r; n++)
        if (t[n] !== e[n]) return !1;
    return !0
}

function Mt(e, t, r) {
    const n = e.getProps();
    return Ie(n, t, void 0 !== r ? r : n.custom, e)
}
const Ut = q((() => void 0 !== window.ScrollTimeline));
class Dt {
    constructor(e) {
        this.stop = () => this.runAll("stop"), this.animations = e.filter(Boolean)
    }
    get finished() {
        return Promise.all(this.animations.map((e => "finished" in e ? e.finished : e)))
    }
    getAll(e) {
        return this.animations[0][e]
    }
    setAll(e, t) {
        for (let r = 0; r < this.animations.length; r++) this.animations[r][e] = t
    }
    attachTimeline(e, t) {
        const r = this.animations.map((r => Ut() && r.attachTimeline ? r.attachTimeline(e) : "function" == typeof t ? t(r) : void 0));
        return () => {
            r.forEach(((e, t) => {
                e && e(), this.animations[t].stop()
            }))
        }
    }
    get time() {
        return this.getAll("time")
    }
    set time(e) {
        this.setAll("time", e)
    }
    get speed() {
        return this.getAll("speed")
    }
    set speed(e) {
        this.setAll("speed", e)
    }
    get startTime() {
        return this.getAll("startTime")
    }
    get duration() {
        let e = 0;
        for (let t = 0; t < this.animations.length; t++) e = Math.max(e, this.animations[t].duration);
        return e
    }
    runAll(e) {
        this.animations.forEach((t => t[e]()))
    }
    flatten() {
        this.runAll("flatten")
    }
    play() {
        this.runAll("play")
    }
    pause() {
        this.runAll("pause")
    }
    cancel() {
        this.runAll("cancel")
    }
    complete() {
        this.runAll("complete")
    }
}
class $t extends Dt {
    then(e, t) {
        return Promise.all(this.animations).then(e).catch(t)
    }
}

function Ft(e, t) {
    return e ? e[t] || e.default || e : void 0
}
const Vt = 2e4;

function Bt(e) {
    let t = 0;
    let r = e.next(t);
    for (; !r.done && t < Vt;) t += 50, r = e.next(t);
    return t >= Vt ? 1 / 0 : t
}

function zt(e) {
    return "function" == typeof e
}

function Wt(e, t) {
    e.timeline = t, e.onfinish = null
}
const Ht = e => Array.isArray(e) && "number" == typeof e[0],
    qt = {
        linearEasing: void 0
    };

function Kt(e, t) {
    const r = q(e);
    return () => {
        var e;
        return null !== (e = qt[t]) && void 0 !== e ? e : r()
    }
}
const Gt = Kt((() => {
        try {
            document.createElement("div").animate({
                opacity: 0
            }, {
                easing: "linear(0, 1)"
            })
        } catch (e) {
            return !1
        }
        return !0
    }), "linearEasing"),
    Yt = (e, t, r = 10) => {
        let n = "";
        const s = Math.max(Math.round(t / r), 2);
        for (let i = 0; i < s; i++) n += e(K(0, s - 1, i)) + ", ";
        return `linear(${n.substring(0,n.length-2)})`
    };

function Jt(e) {
    return Boolean("function" == typeof e && Gt() || !e || "string" == typeof e && (e in Zt || Gt()) || Ht(e) || Array.isArray(e) && e.every(Jt))
}
const Xt = ([e, t, r, n]) => `cubic-bezier(${e}, ${t}, ${r}, ${n})`,
    Zt = {
        linear: "linear",
        ease: "ease",
        easeIn: "ease-in",
        easeOut: "ease-out",
        easeInOut: "ease-in-out",
        circIn: Xt([0, .65, .55, 1]),
        circOut: Xt([.55, 0, 1, .45]),
        backIn: Xt([.31, .01, .66, -.59]),
        backOut: Xt([.33, 1.53, .69, .99])
    };

function Qt(e, t) {
    return e ? "function" == typeof e && Gt() ? Yt(e, t) : Ht(e) ? Xt(e) : Array.isArray(e) ? e.map((e => Qt(e, t) || Zt.easeOut)) : Zt[e] : void 0
}
const er = {
    x: !1,
    y: !1
};

function tr() {
    return er.x || er.y
}

function rr(e, t) {
    const r = function(e) {
            if (e instanceof Element) return [e];
            if ("string" == typeof e) {
                const t = document.querySelectorAll(e);
                return t ? Array.from(t) : []
            }
            return Array.from(e)
        }(e),
        n = new AbortController;
    return [r, {
        passive: !0,
        ...t,
        signal: n.signal
    }, () => n.abort()]
}

function nr(e) {
    return t => {
        "touch" === t.pointerType || tr() || e(t)
    }
}
const sr = (e, t) => !!t && (e === t || sr(e, t.parentElement)),
    ir = e => "mouse" === e.pointerType ? "number" != typeof e.button || e.button <= 0 : !1 !== e.isPrimary,
    or = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]);
const ar = new WeakSet;

function lr(e) {
    return t => {
        "Enter" === t.key && e(t)
    }
}

function cr(e, t) {
    e.dispatchEvent(new PointerEvent("pointer" + t, {
        isPrimary: !0,
        bubbles: !0
    }))
}

function ur(e) {
    return ir(e) && !tr()
}

function dr(e, t, r = {}) {
    const [n, s, i] = rr(e, r), o = e => {
        const n = e.currentTarget;
        if (!ur(e) || ar.has(n)) return;
        ar.add(n);
        const i = t(e),
            o = (e, t) => {
                window.removeEventListener("pointerup", a), window.removeEventListener("pointercancel", l), ur(e) && ar.has(n) && (ar.delete(n), "function" == typeof i && i(e, {
                    success: t
                }))
            },
            a = e => {
                o(e, r.useGlobalTarget || sr(n, e.target))
            },
            l = e => {
                o(e, !1)
            };
        window.addEventListener("pointerup", a, s), window.addEventListener("pointercancel", l, s)
    };
    return n.forEach((e => {
        (function(e) {
            return or.has(e.tagName) || -1 !== e.tabIndex
        })(e) || null !== e.getAttribute("tabindex") || (e.tabIndex = 0);
        (r.useGlobalTarget ? window : e).addEventListener("pointerdown", o, s), e.addEventListener("focus", (e => ((e, t) => {
            const r = e.currentTarget;
            if (!r) return;
            const n = lr((() => {
                if (ar.has(r)) return;
                cr(r, "down");
                const e = lr((() => {
                    cr(r, "up")
                }));
                r.addEventListener("keyup", e, t), r.addEventListener("blur", (() => cr(r, "cancel")), t)
            }));
            r.addEventListener("keydown", n, t), r.addEventListener("blur", (() => r.removeEventListener("keydown", n)), t)
        })(e, s)), s)
    })), i
}
const hr = new Set(["width", "height", "top", "left", "right", "bottom", ...Fe]);
let pr;

function fr() {
    pr = void 0
}
const mr = {
    now: () => (void 0 === pr && mr.set(te.isProcessing || J ? te.timestamp : performance.now()), pr),
    set: e => {
        pr = e, queueMicrotask(fr)
    }
};

function gr(e, t) {
    -1 === e.indexOf(t) && e.push(t)
}

function yr(e, t) {
    const r = e.indexOf(t);
    r > -1 && e.splice(r, 1)
}
class vr {
    constructor() {
        this.subscriptions = []
    }
    add(e) {
        return gr(this.subscriptions, e), () => yr(this.subscriptions, e)
    }
    notify(e, t, r) {
        const n = this.subscriptions.length;
        if (n)
            if (1 === n) this.subscriptions[0](e, t, r);
            else
                for (let s = 0; s < n; s++) {
                    const n = this.subscriptions[s];
                    n && n(e, t, r)
                }
    }
    getSize() {
        return this.subscriptions.length
    }
    clear() {
        this.subscriptions.length = 0
    }
}

function br(e, t) {
    return t ? e * (1e3 / t) : 0
}
class xr {
    constructor(e, t = {}) {
        this.version = "11.18.2", this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (e, t = !0) => {
            const r = mr.now();
            this.updatedAt !== r && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(e), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), t && this.events.renderRequest && this.events.renderRequest.notify(this.current)
        }, this.hasAnimated = !1, this.setCurrent(e), this.owner = t.owner
    }
    setCurrent(e) {
        var t;
        this.current = e, this.updatedAt = mr.now(), null === this.canTrackVelocity && void 0 !== e && (this.canTrackVelocity = (t = this.current, !isNaN(parseFloat(t))))
    }
    setPrevFrameValue(e = this.current) {
        this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt
    }
    onChange(e) {
        return this.on("change", e)
    }
    on(e, t) {
        this.events[e] || (this.events[e] = new vr);
        const r = this.events[e].add(t);
        return "change" === e ? () => {
            r(), Q.read((() => {
                this.events.change.getSize() || this.stop()
            }))
        } : r
    }
    clearListeners() {
        for (const e in this.events) this.events[e].clear()
    }
    attach(e, t) {
        this.passiveEffect = e, this.stopPassiveEffect = t
    }
    set(e, t = !0) {
        t && this.passiveEffect ? this.passiveEffect(e, this.updateAndNotify) : this.updateAndNotify(e, t)
    }
    setWithVelocity(e, t, r) {
        this.set(t), this.prev = void 0, this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt - r
    }
    jump(e, t = !0) {
        this.updateAndNotify(e), this.prev = e, this.prevUpdatedAt = this.prevFrameValue = void 0, t && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
    }
    get() {
        return this.current
    }
    getPrevious() {
        return this.prev
    }
    getVelocity() {
        const e = mr.now();
        if (!this.canTrackVelocity || void 0 === this.prevFrameValue || e - this.updatedAt > 30) return 0;
        const t = Math.min(this.updatedAt - this.prevUpdatedAt, 30);
        return br(parseFloat(this.current) - parseFloat(this.prevFrameValue), t)
    }
    start(e) {
        return this.stop(), new Promise((t => {
            this.hasAnimated = !0, this.animation = e(t), this.events.animationStart && this.events.animationStart.notify()
        })).then((() => {
            this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
        }))
    }
    stop() {
        this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
    }
    isAnimating() {
        return !!this.animation
    }
    clearAnimation() {
        delete this.animation
    }
    destroy() {
        this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
    }
}

function wr(e, t) {
    return new xr(e, t)
}

function kr(e, t, r) {
    e.hasValue(t) ? e.getValue(t).set(r) : e.addValue(t, wr(r))
}

function jr(e, t) {
    const r = Mt(e, t);
    let {
        transitionEnd: n = {},
        transition: s = {},
        ...i
    } = r || {};
    i = { ...i,
        ...n
    };
    for (const a in i) {
        kr(e, a, (o = i[a], Le(o) ? o[o.length - 1] || 0 : o))
    }
    var o
}

function Sr(e, t) {
    const r = e.getValue("willChange");
    if (n = r, Boolean(Me(n) && n.add)) return r.add(t);
    var n
}

function Tr(e) {
    return e.props[Se]
}
const _r = (e, t, r) => (((1 - 3 * r + 3 * t) * e + (3 * r - 6 * t)) * e + 3 * t) * e;

function Er(e, t, r, n) {
    if (e === t && r === n) return W;
    const s = t => function(e, t, r, n, s) {
        let i, o, a = 0;
        do {
            o = t + (r - t) / 2, i = _r(o, n, s) - e, i > 0 ? r = o : t = o
        } while (Math.abs(i) > 1e-7 && ++a < 12);
        return o
    }(t, 0, 1, e, r);
    return e => 0 === e || 1 === e ? e : _r(s(e), t, n)
}
const Pr = e => t => t <= .5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2,
    Cr = e => t => 1 - e(1 - t),
    Or = Er(.33, 1.53, .69, .99),
    Ar = Cr(Or),
    Nr = Pr(Ar),
    Rr = e => (e *= 2) < 1 ? .5 * Ar(e) : .5 * (2 - Math.pow(2, -10 * (e - 1))),
    Ir = e => 1 - Math.sin(Math.acos(e)),
    Lr = Cr(Ir),
    Mr = Pr(Ir),
    Ur = e => /^0[^.\s]+$/u.test(e);
const Dr = e => Math.round(1e5 * e) / 1e5,
    $r = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
const Fr = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
    Vr = (e, t) => r => Boolean("string" == typeof r && Fr.test(r) && r.startsWith(e) || t && ! function(e) {
        return null == e
    }(r) && Object.prototype.hasOwnProperty.call(r, t)),
    Br = (e, t, r) => n => {
        if ("string" != typeof n) return n;
        const [s, i, o, a] = n.match($r);
        return {
            [e]: parseFloat(s),
            [t]: parseFloat(i),
            [r]: parseFloat(o),
            alpha: void 0 !== a ? parseFloat(a) : 1
        }
    },
    zr = { ...Ye,
        transform: e => Math.round((e => Ge(0, 255, e))(e))
    },
    Wr = {
        test: Vr("rgb", "red"),
        parse: Br("red", "green", "blue"),
        transform: ({
            red: e,
            green: t,
            blue: r,
            alpha: n = 1
        }) => "rgba(" + zr.transform(e) + ", " + zr.transform(t) + ", " + zr.transform(r) + ", " + Dr(Je.transform(n)) + ")"
    };
const Hr = {
        test: Vr("#"),
        parse: function(e) {
            let t = "",
                r = "",
                n = "",
                s = "";
            return e.length > 5 ? (t = e.substring(1, 3), r = e.substring(3, 5), n = e.substring(5, 7), s = e.substring(7, 9)) : (t = e.substring(1, 2), r = e.substring(2, 3), n = e.substring(3, 4), s = e.substring(4, 5), t += t, r += r, n += n, s += s), {
                red: parseInt(t, 16),
                green: parseInt(r, 16),
                blue: parseInt(n, 16),
                alpha: s ? parseInt(s, 16) / 255 : 1
            }
        },
        transform: Wr.transform
    },
    qr = {
        test: Vr("hsl", "hue"),
        parse: Br("hue", "saturation", "lightness"),
        transform: ({
            hue: e,
            saturation: t,
            lightness: r,
            alpha: n = 1
        }) => "hsla(" + Math.round(e) + ", " + et.transform(Dr(t)) + ", " + et.transform(Dr(r)) + ", " + Dr(Je.transform(n)) + ")"
    },
    Kr = {
        test: e => Wr.test(e) || Hr.test(e) || qr.test(e),
        parse: e => Wr.test(e) ? Wr.parse(e) : qr.test(e) ? qr.parse(e) : Hr.parse(e),
        transform: e => "string" == typeof e ? e : e.hasOwnProperty("red") ? Wr.transform(e) : qr.transform(e)
    },
    Gr = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
const Yr = "number",
    Jr = "color",
    Xr = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

function Zr(e) {
    const t = e.toString(),
        r = [],
        n = {
            color: [],
            number: [],
            var: []
        },
        s = [];
    let i = 0;
    const o = t.replace(Xr, (e => (Kr.test(e) ? (n.color.push(i), s.push(Jr), r.push(Kr.parse(e))) : e.startsWith("var(") ? (n.var.push(i), s.push("var"), r.push(e)) : (n.number.push(i), s.push(Yr), r.push(parseFloat(e))), ++i, "${}"))).split("${}");
    return {
        values: r,
        split: o,
        indexes: n,
        types: s
    }
}

function Qr(e) {
    return Zr(e).values
}

function en(e) {
    const {
        split: t,
        types: r
    } = Zr(e), n = t.length;
    return e => {
        let s = "";
        for (let i = 0; i < n; i++)
            if (s += t[i], void 0 !== e[i]) {
                const t = r[i];
                s += t === Yr ? Dr(e[i]) : t === Jr ? Kr.transform(e[i]) : e[i]
            }
        return s
    }
}
const tn = e => "number" == typeof e ? 0 : e;
const rn = {
        test: function(e) {
            var t, r;
            return isNaN(e) && "string" == typeof e && ((null === (t = e.match($r)) || void 0 === t ? void 0 : t.length) || 0) + ((null === (r = e.match(Gr)) || void 0 === r ? void 0 : r.length) || 0) > 0
        },
        parse: Qr,
        createTransformer: en,
        getAnimatableNone: function(e) {
            const t = Qr(e);
            return en(e)(t.map(tn))
        }
    },
    nn = new Set(["brightness", "contrast", "saturate", "opacity"]);

function sn(e) {
    const [t, r] = e.slice(0, -1).split("(");
    if ("drop-shadow" === t) return e;
    const [n] = r.match($r) || [];
    if (!n) return e;
    const s = r.replace(n, "");
    let i = nn.has(t) ? 1 : 0;
    return n !== r && (i *= 100), t + "(" + i + s + ")"
}
const on = /\b([a-z-]*)\(.*?\)/gu,
    an = { ...rn,
        getAnimatableNone: e => {
            const t = e.match(on);
            return t ? t.map(sn).join(" ") : e
        }
    },
    ln = { ...lt,
        color: Kr,
        backgroundColor: Kr,
        outlineColor: Kr,
        fill: Kr,
        stroke: Kr,
        borderColor: Kr,
        borderTopColor: Kr,
        borderRightColor: Kr,
        borderBottomColor: Kr,
        borderLeftColor: Kr,
        filter: an,
        WebkitFilter: an
    },
    cn = e => ln[e];

function un(e, t) {
    let r = cn(e);
    return r !== an && (r = rn), r.getAnimatableNone ? r.getAnimatableNone(t) : void 0
}
const dn = new Set(["auto", "none", "0"]);
const hn = e => e === Ye || e === tt,
    pn = (e, t) => parseFloat(e.split(", ")[t]),
    fn = (e, t) => (r, {
        transform: n
    }) => {
        if ("none" === n || !n) return 0;
        const s = n.match(/^matrix3d\((.+)\)$/u);
        if (s) return pn(s[1], t); {
            const t = n.match(/^matrix\((.+)\)$/u);
            return t ? pn(t[1], e) : 0
        }
    },
    mn = new Set(["x", "y", "z"]),
    gn = Fe.filter((e => !mn.has(e)));
const yn = {
    width: ({
        x: e
    }, {
        paddingLeft: t = "0",
        paddingRight: r = "0"
    }) => e.max - e.min - parseFloat(t) - parseFloat(r),
    height: ({
        y: e
    }, {
        paddingTop: t = "0",
        paddingBottom: r = "0"
    }) => e.max - e.min - parseFloat(t) - parseFloat(r),
    top: (e, {
        top: t
    }) => parseFloat(t),
    left: (e, {
        left: t
    }) => parseFloat(t),
    bottom: ({
        y: e
    }, {
        top: t
    }) => parseFloat(t) + (e.max - e.min),
    right: ({
        x: e
    }, {
        left: t
    }) => parseFloat(t) + (e.max - e.min),
    x: fn(4, 13),
    y: fn(5, 14)
};
yn.translateX = yn.x, yn.translateY = yn.y;
const vn = new Set;
let bn = !1,
    xn = !1;

function wn() {
    if (xn) {
        const e = Array.from(vn).filter((e => e.needsMeasurement)),
            t = new Set(e.map((e => e.element))),
            r = new Map;
        t.forEach((e => {
            const t = function(e) {
                const t = [];
                return gn.forEach((r => {
                    const n = e.getValue(r);
                    void 0 !== n && (t.push([r, n.get()]), n.set(r.startsWith("scale") ? 1 : 0))
                })), t
            }(e);
            t.length && (r.set(e, t), e.render())
        })), e.forEach((e => e.measureInitialState())), t.forEach((e => {
            e.render();
            const t = r.get(e);
            t && t.forEach((([t, r]) => {
                var n;
                null === (n = e.getValue(t)) || void 0 === n || n.set(r)
            }))
        })), e.forEach((e => e.measureEndState())), e.forEach((e => {
            void 0 !== e.suspendedScrollY && window.scrollTo(0, e.suspendedScrollY)
        }))
    }
    xn = !1, bn = !1, vn.forEach((e => e.complete())), vn.clear()
}

function kn() {
    vn.forEach((e => {
        e.readKeyframes(), e.needsMeasurement && (xn = !0)
    }))
}
class jn {
    constructor(e, t, r, n, s, i = !1) {
        this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [...e], this.onComplete = t, this.name = r, this.motionValue = n, this.element = s, this.isAsync = i
    }
    scheduleResolve() {
        this.isScheduled = !0, this.isAsync ? (vn.add(this), bn || (bn = !0, Q.read(kn), Q.resolveKeyframes(wn))) : (this.readKeyframes(), this.complete())
    }
    readKeyframes() {
        const {
            unresolvedKeyframes: e,
            name: t,
            element: r,
            motionValue: n
        } = this;
        for (let s = 0; s < e.length; s++)
            if (null === e[s])
                if (0 === s) {
                    const s = null == n ? void 0 : n.get(),
                        i = e[e.length - 1];
                    if (void 0 !== s) e[0] = s;
                    else if (r && t) {
                        const n = r.readValue(t, i);
                        null != n && (e[0] = n)
                    }
                    void 0 === e[0] && (e[0] = i), n && void 0 === s && n.set(e[0])
                } else e[s] = e[s - 1]
    }
    setFinalKeyframe() {}
    measureInitialState() {}
    renderEndStyles() {}
    measureEndState() {}
    complete() {
        this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), vn.delete(this)
    }
    cancel() {
        this.isComplete || (this.isScheduled = !1, vn.delete(this))
    }
    resume() {
        this.isComplete || this.scheduleResolve()
    }
}
const Sn = e => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e),
    Tn = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;

function _n(e, t, r = 1) {
    const [n, s] = function(e) {
        const t = Tn.exec(e);
        if (!t) return [, ];
        const [, r, n, s] = t;
        return [`--${null!=r?r:n}`, s]
    }(e);
    if (!n) return;
    const i = window.getComputedStyle(t).getPropertyValue(n);
    if (i) {
        const e = i.trim();
        return Sn(e) ? parseFloat(e) : e
    }
    return He(s) ? _n(s, t, r + 1) : s
}
const En = e => t => t.test(e),
    Pn = [Ye, tt, et, Qe, nt, rt, {
        test: e => "auto" === e,
        parse: e => e
    }],
    Cn = e => Pn.find(En(e));
class On extends jn {
    constructor(e, t, r, n, s) {
        super(e, t, r, n, s, !0)
    }
    readKeyframes() {
        const {
            unresolvedKeyframes: e,
            element: t,
            name: r
        } = this;
        if (!t || !t.current) return;
        super.readKeyframes();
        for (let a = 0; a < e.length; a++) {
            let r = e[a];
            if ("string" == typeof r && (r = r.trim(), He(r))) {
                const n = _n(r, t.current);
                void 0 !== n && (e[a] = n), a === e.length - 1 && (this.finalKeyframe = r)
            }
        }
        if (this.resolveNoneKeyframes(), !hr.has(r) || 2 !== e.length) return;
        const [n, s] = e, i = Cn(n), o = Cn(s);
        if (i !== o)
            if (hn(i) && hn(o))
                for (let a = 0; a < e.length; a++) {
                    const t = e[a];
                    "string" == typeof t && (e[a] = parseFloat(t))
                } else this.needsMeasurement = !0
    }
    resolveNoneKeyframes() {
        const {
            unresolvedKeyframes: e,
            name: t
        } = this, r = [];
        for (let s = 0; s < e.length; s++)("number" == typeof(n = e[s]) ? 0 === n : null === n || "none" === n || "0" === n || Ur(n)) && r.push(s);
        var n;
        r.length && function(e, t, r) {
            let n, s = 0;
            for (; s < e.length && !n;) {
                const t = e[s];
                "string" == typeof t && !dn.has(t) && Zr(t).values.length && (n = e[s]), s++
            }
            if (n && r)
                for (const i of t) e[i] = un(r, n)
        }(e, r, t)
    }
    measureInitialState() {
        const {
            element: e,
            unresolvedKeyframes: t,
            name: r
        } = this;
        if (!e || !e.current) return;
        "height" === r && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = yn[r](e.measureViewportBox(), window.getComputedStyle(e.current)), t[0] = this.measuredOrigin;
        const n = t[t.length - 1];
        void 0 !== n && e.getValue(r, n).jump(n, !1)
    }
    measureEndState() {
        var e;
        const {
            element: t,
            name: r,
            unresolvedKeyframes: n
        } = this;
        if (!t || !t.current) return;
        const s = t.getValue(r);
        s && s.jump(this.measuredOrigin, !1);
        const i = n.length - 1,
            o = n[i];
        n[i] = yn[r](t.measureViewportBox(), window.getComputedStyle(t.current)), null !== o && void 0 === this.finalKeyframe && (this.finalKeyframe = o), (null === (e = this.removedTransforms) || void 0 === e ? void 0 : e.length) && this.removedTransforms.forEach((([e, r]) => {
            t.getValue(e).set(r)
        })), this.resolveNoneKeyframes()
    }
}
const An = (e, t) => "zIndex" !== t && (!("number" != typeof e && !Array.isArray(e)) || !("string" != typeof e || !rn.test(e) && "0" !== e || e.startsWith("url(")));
const Nn = e => null !== e;

function Rn(e, {
    repeat: t,
    repeatType: r = "loop"
}, n) {
    const s = e.filter(Nn),
        i = t && "loop" !== r && t % 2 == 1 ? 0 : s.length - 1;
    return i && void 0 !== n ? n : s[i]
}
class In {
    constructor({
        autoplay: e = !0,
        delay: t = 0,
        type: r = "keyframes",
        repeat: n = 0,
        repeatDelay: s = 0,
        repeatType: i = "loop",
        ...o
    }) {
        this.isStopped = !1, this.hasAttemptedResolve = !1, this.createdAt = mr.now(), this.options = {
            autoplay: e,
            delay: t,
            type: r,
            repeat: n,
            repeatDelay: s,
            repeatType: i,
            ...o
        }, this.updateFinishedPromise()
    }
    calcStartTime() {
        return this.resolvedAt && this.resolvedAt - this.createdAt > 40 ? this.resolvedAt : this.createdAt
    }
    get resolved() {
        return this._resolved || this.hasAttemptedResolve || (kn(), wn()), this._resolved
    }
    onKeyframesResolved(e, t) {
        this.resolvedAt = mr.now(), this.hasAttemptedResolve = !0;
        const {
            name: r,
            type: n,
            velocity: s,
            delay: i,
            onComplete: o,
            onUpdate: a,
            isGenerator: l
        } = this.options;
        if (!l && ! function(e, t, r, n) {
                const s = e[0];
                if (null === s) return !1;
                if ("display" === t || "visibility" === t) return !0;
                const i = e[e.length - 1],
                    o = An(s, t),
                    a = An(i, t);
                return !(!o || !a) && (function(e) {
                    const t = e[0];
                    if (1 === e.length) return !0;
                    for (let r = 0; r < e.length; r++)
                        if (e[r] !== t) return !0
                }(e) || ("spring" === r || zt(r)) && n)
            }(e, r, n, s)) {
            if (!i) return a && a(Rn(e, this.options, t)), o && o(), void this.resolveFinishedPromise();
            this.options.duration = 0
        }
        const c = this.initPlayback(e, t);
        !1 !== c && (this._resolved = {
            keyframes: e,
            finalKeyframe: t,
            ...c
        }, this.onPostResolved())
    }
    onPostResolved() {}
    then(e, t) {
        return this.currentFinishedPromise.then(e, t)
    }
    flatten() {
        this.options.type = "keyframes", this.options.ease = "linear"
    }
    updateFinishedPromise() {
        this.currentFinishedPromise = new Promise((e => {
            this.resolveFinishedPromise = e
        }))
    }
}
const Ln = (e, t, r) => e + (t - e) * r;

function Mn(e, t, r) {
    return r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? e + 6 * (t - e) * r : r < .5 ? t : r < 2 / 3 ? e + (t - e) * (2 / 3 - r) * 6 : e
}

function Un(e, t) {
    return r => r > 0 ? t : e
}
const Dn = (e, t, r) => {
        const n = e * e,
            s = r * (t * t - n) + n;
        return s < 0 ? 0 : Math.sqrt(s)
    },
    $n = [Hr, Wr, qr];

function Fn(e) {
    const t = (r = e, $n.find((e => e.test(r))));
    var r;
    if (!Boolean(t)) return !1;
    let n = t.parse(e);
    return t === qr && (n = function({
        hue: e,
        saturation: t,
        lightness: r,
        alpha: n
    }) {
        e /= 360, r /= 100;
        let s = 0,
            i = 0,
            o = 0;
        if (t /= 100) {
            const n = r < .5 ? r * (1 + t) : r + t - r * t,
                a = 2 * r - n;
            s = Mn(a, n, e + 1 / 3), i = Mn(a, n, e), o = Mn(a, n, e - 1 / 3)
        } else s = i = o = r;
        return {
            red: Math.round(255 * s),
            green: Math.round(255 * i),
            blue: Math.round(255 * o),
            alpha: n
        }
    }(n)), n
}
const Vn = (e, t) => {
        const r = Fn(e),
            n = Fn(t);
        if (!r || !n) return Un(e, t);
        const s = { ...r
        };
        return e => (s.red = Dn(r.red, n.red, e), s.green = Dn(r.green, n.green, e), s.blue = Dn(r.blue, n.blue, e), s.alpha = Ln(r.alpha, n.alpha, e), Wr.transform(s))
    },
    Bn = (e, t) => r => t(e(r)),
    zn = (...e) => e.reduce(Bn),
    Wn = new Set(["none", "hidden"]);

function Hn(e, t) {
    return r => Ln(e, t, r)
}

function qn(e) {
    return "number" == typeof e ? Hn : "string" == typeof e ? He(e) ? Un : Kr.test(e) ? Vn : Yn : Array.isArray(e) ? Kn : "object" == typeof e ? Kr.test(e) ? Vn : Gn : Un
}

function Kn(e, t) {
    const r = [...e],
        n = r.length,
        s = e.map(((e, r) => qn(e)(e, t[r])));
    return e => {
        for (let t = 0; t < n; t++) r[t] = s[t](e);
        return r
    }
}

function Gn(e, t) {
    const r = { ...e,
            ...t
        },
        n = {};
    for (const s in r) void 0 !== e[s] && void 0 !== t[s] && (n[s] = qn(e[s])(e[s], t[s]));
    return e => {
        for (const t in n) r[t] = n[t](e);
        return r
    }
}
const Yn = (e, t) => {
    const r = rn.createTransformer(t),
        n = Zr(e),
        s = Zr(t);
    return n.indexes.var.length === s.indexes.var.length && n.indexes.color.length === s.indexes.color.length && n.indexes.number.length >= s.indexes.number.length ? Wn.has(e) && !s.values.length || Wn.has(t) && !n.values.length ? function(e, t) {
        return Wn.has(e) ? r => r <= 0 ? e : t : r => r >= 1 ? t : e
    }(e, t) : zn(Kn(function(e, t) {
        var r;
        const n = [],
            s = {
                color: 0,
                var: 0,
                number: 0
            };
        for (let i = 0; i < t.values.length; i++) {
            const o = t.types[i],
                a = e.indexes[o][s[o]],
                l = null !== (r = e.values[a]) && void 0 !== r ? r : 0;
            n[i] = l, s[o]++
        }
        return n
    }(n, s), s.values), r) : Un(e, t)
};

function Jn(e, t, r) {
    if ("number" == typeof e && "number" == typeof t && "number" == typeof r) return Ln(e, t, r);
    return qn(e)(e, t)
}

function Xn(e, t, r) {
    const n = Math.max(t - 5, 0);
    return br(r - e(n), t - n)
}
const Zn = 100,
    Qn = 10,
    es = 1,
    ts = 0,
    rs = 800,
    ns = .3,
    ss = .3,
    is = {
        granular: .01,
        default: 2
    },
    os = {
        granular: .005,
        default: .5
    },
    as = .01,
    ls = 10,
    cs = .05,
    us = 1;

function ds({
    duration: e = rs,
    bounce: t = ns,
    velocity: r = ts,
    mass: n = es
}) {
    let s, i, o = 1 - t;
    o = Ge(cs, us, o), e = Ge(as, ls, Y(e)), o < 1 ? (s = t => {
        const n = t * o,
            s = n * e;
        return .001 - (n - r) / ps(t, o) * Math.exp(-s)
    }, i = t => {
        const n = t * o * e,
            i = n * r + r,
            a = Math.pow(o, 2) * Math.pow(t, 2) * e,
            l = Math.exp(-n),
            c = ps(Math.pow(t, 2), o);
        return (.001 - s(t) > 0 ? -1 : 1) * ((i - a) * l) / c
    }) : (s = t => Math.exp(-t * e) * ((t - r) * e + 1) - .001, i = t => Math.exp(-t * e) * (e * e * (r - t)));
    const a = function(e, t, r) {
        let n = r;
        for (let s = 1; s < hs; s++) n -= e(n) / t(n);
        return n
    }(s, i, 5 / e);
    if (e = G(e), isNaN(a)) return {
        stiffness: Zn,
        damping: Qn,
        duration: e
    }; {
        const t = Math.pow(a, 2) * n;
        return {
            stiffness: t,
            damping: 2 * o * Math.sqrt(n * t),
            duration: e
        }
    }
}
const hs = 12;

function ps(e, t) {
    return e * Math.sqrt(1 - t * t)
}
const fs = ["duration", "bounce"],
    ms = ["stiffness", "damping", "mass"];

function gs(e, t) {
    return t.some((t => void 0 !== e[t]))
}

function ys(e = ss, t = ns) {
    const r = "object" != typeof e ? {
        visualDuration: e,
        keyframes: [0, 1],
        bounce: t
    } : e;
    let {
        restSpeed: n,
        restDelta: s
    } = r;
    const i = r.keyframes[0],
        o = r.keyframes[r.keyframes.length - 1],
        a = {
            done: !1,
            value: i
        },
        {
            stiffness: l,
            damping: c,
            mass: u,
            duration: d,
            velocity: h,
            isResolvedFromDuration: p
        } = function(e) {
            let t = {
                velocity: ts,
                stiffness: Zn,
                damping: Qn,
                mass: es,
                isResolvedFromDuration: !1,
                ...e
            };
            if (!gs(e, ms) && gs(e, fs))
                if (e.visualDuration) {
                    const r = e.visualDuration,
                        n = 2 * Math.PI / (1.2 * r),
                        s = n * n,
                        i = 2 * Ge(.05, 1, 1 - (e.bounce || 0)) * Math.sqrt(s);
                    t = { ...t,
                        mass: es,
                        stiffness: s,
                        damping: i
                    }
                } else {
                    const r = ds(e);
                    t = { ...t,
                        ...r,
                        mass: es
                    }, t.isResolvedFromDuration = !0
                }
            return t
        }({ ...r,
            velocity: -Y(r.velocity || 0)
        }),
        f = h || 0,
        m = c / (2 * Math.sqrt(l * u)),
        g = o - i,
        y = Y(Math.sqrt(l / u)),
        v = Math.abs(g) < 5;
    let b;
    if (n || (n = v ? is.granular : is.default), s || (s = v ? os.granular : os.default), m < 1) {
        const e = ps(y, m);
        b = t => {
            const r = Math.exp(-m * y * t);
            return o - r * ((f + m * y * g) / e * Math.sin(e * t) + g * Math.cos(e * t))
        }
    } else if (1 === m) b = e => o - Math.exp(-y * e) * (g + (f + y * g) * e);
    else {
        const e = y * Math.sqrt(m * m - 1);
        b = t => {
            const r = Math.exp(-m * y * t),
                n = Math.min(e * t, 300);
            return o - r * ((f + m * y * g) * Math.sinh(n) + e * g * Math.cosh(n)) / e
        }
    }
    const x = {
        calculatedDuration: p && d || null,
        next: e => {
            const t = b(e);
            if (p) a.done = e >= d;
            else {
                let r = 0;
                m < 1 && (r = 0 === e ? G(f) : Xn(b, e, t));
                const i = Math.abs(r) <= n,
                    l = Math.abs(o - t) <= s;
                a.done = i && l
            }
            return a.value = a.done ? o : t, a
        },
        toString: () => {
            const e = Math.min(Bt(x), Vt),
                t = Yt((t => x.next(e * t).value), e, 30);
            return e + "ms " + t
        }
    };
    return x
}

function vs({
    keyframes: e,
    velocity: t = 0,
    power: r = .8,
    timeConstant: n = 325,
    bounceDamping: s = 10,
    bounceStiffness: i = 500,
    modifyTarget: o,
    min: a,
    max: l,
    restDelta: c = .5,
    restSpeed: u
}) {
    const d = e[0],
        h = {
            done: !1,
            value: d
        },
        p = e => void 0 === a ? l : void 0 === l || Math.abs(a - e) < Math.abs(l - e) ? a : l;
    let f = r * t;
    const m = d + f,
        g = void 0 === o ? m : o(m);
    g !== m && (f = g - d);
    const y = e => -f * Math.exp(-e / n),
        v = e => g + y(e),
        b = e => {
            const t = y(e),
                r = v(e);
            h.done = Math.abs(t) <= c, h.value = h.done ? g : r
        };
    let x, w;
    const k = e => {
        var t;
        (t = h.value, void 0 !== a && t < a || void 0 !== l && t > l) && (x = e, w = ys({
            keyframes: [h.value, p(h.value)],
            velocity: Xn(v, e, h.value),
            damping: s,
            stiffness: i,
            restDelta: c,
            restSpeed: u
        }))
    };
    return k(0), {
        calculatedDuration: null,
        next: e => {
            let t = !1;
            return w || void 0 !== x || (t = !0, b(e), k(e)), void 0 !== x && e >= x ? w.next(e - x) : (!t && b(e), h)
        }
    }
}
const bs = Er(.42, 0, 1, 1),
    xs = Er(0, 0, .58, 1),
    ws = Er(.42, 0, .58, 1),
    ks = {
        linear: W,
        easeIn: bs,
        easeInOut: ws,
        easeOut: xs,
        circIn: Ir,
        circInOut: Mr,
        circOut: Lr,
        backIn: Ar,
        backInOut: Nr,
        backOut: Or,
        anticipate: Rr
    },
    js = e => {
        if (Ht(e)) {
            H(4 === e.length);
            const [t, r, n, s] = e;
            return Er(t, r, n, s)
        }
        return "string" == typeof e ? ks[e] : e
    };

function Ss(e, t, {
    clamp: r = !0,
    ease: n,
    mixer: s
} = {}) {
    const i = e.length;
    if (H(i === t.length), 1 === i) return () => t[0];
    if (2 === i && t[0] === t[1]) return () => t[1];
    const o = e[0] === e[1];
    e[0] > e[i - 1] && (e = [...e].reverse(), t = [...t].reverse());
    const a = function(e, t, r) {
            const n = [],
                s = r || Jn,
                i = e.length - 1;
            for (let o = 0; o < i; o++) {
                let r = s(e[o], e[o + 1]);
                if (t) {
                    const e = Array.isArray(t) ? t[o] || W : t;
                    r = zn(e, r)
                }
                n.push(r)
            }
            return n
        }(t, n, s),
        l = a.length,
        c = r => {
            if (o && r < e[0]) return t[0];
            let n = 0;
            if (l > 1)
                for (; n < e.length - 2 && !(r < e[n + 1]); n++);
            const s = K(e[n], e[n + 1], r);
            return a[n](s)
        };
    return r ? t => c(Ge(e[0], e[i - 1], t)) : c
}

function Ts(e) {
    const t = [0];
    return function(e, t) {
        const r = e[e.length - 1];
        for (let n = 1; n <= t; n++) {
            const s = K(0, t, n);
            e.push(Ln(r, 1, s))
        }
    }(t, e.length - 1), t
}

function _s({
    duration: e = 300,
    keyframes: t,
    times: r,
    ease: n = "easeInOut"
}) {
    const s = (e => Array.isArray(e) && "number" != typeof e[0])(n) ? n.map(js) : js(n),
        i = {
            done: !1,
            value: t[0]
        },
        o = function(e, t) {
            return e.map((e => e * t))
        }(r && r.length === t.length ? r : Ts(t), e),
        a = Ss(o, t, {
            ease: Array.isArray(s) ? s : (l = t, c = s, l.map((() => c || ws)).splice(0, l.length - 1))
        });
    var l, c;
    return {
        calculatedDuration: e,
        next: t => (i.value = a(t), i.done = t >= e, i)
    }
}
const Es = e => {
        const t = ({
            timestamp: t
        }) => e(t);
        return {
            start: () => Q.update(t, !0),
            stop: () => ee(t),
            now: () => te.isProcessing ? te.timestamp : mr.now()
        }
    },
    Ps = {
        decay: vs,
        inertia: vs,
        tween: _s,
        keyframes: _s,
        spring: ys
    },
    Cs = e => e / 100;
class Os extends In {
    constructor(e) {
        super(e), this.holdTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.startTime = null, this.state = "idle", this.stop = () => {
            if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
            this.teardown();
            const {
                onStop: e
            } = this.options;
            e && e()
        };
        const {
            name: t,
            motionValue: r,
            element: n,
            keyframes: s
        } = this.options, i = (null == n ? void 0 : n.KeyframeResolver) || jn;
        this.resolver = new i(s, ((e, t) => this.onKeyframesResolved(e, t)), t, r, n), this.resolver.scheduleResolve()
    }
    flatten() {
        super.flatten(), this._resolved && Object.assign(this._resolved, this.initPlayback(this._resolved.keyframes))
    }
    initPlayback(e) {
        const {
            type: t = "keyframes",
            repeat: r = 0,
            repeatDelay: n = 0,
            repeatType: s,
            velocity: i = 0
        } = this.options, o = zt(t) ? t : Ps[t] || _s;
        let a, l;
        o !== _s && "number" != typeof e[0] && (a = zn(Cs, Jn(e[0], e[1])), e = [0, 100]);
        const c = o({ ...this.options,
            keyframes: e
        });
        "mirror" === s && (l = o({ ...this.options,
            keyframes: [...e].reverse(),
            velocity: -i
        })), null === c.calculatedDuration && (c.calculatedDuration = Bt(c));
        const {
            calculatedDuration: u
        } = c, d = u + n;
        return {
            generator: c,
            mirroredGenerator: l,
            mapPercentToKeyframes: a,
            calculatedDuration: u,
            resolvedDuration: d,
            totalDuration: d * (r + 1) - n
        }
    }
    onPostResolved() {
        const {
            autoplay: e = !0
        } = this.options;
        this.play(), "paused" !== this.pendingPlayState && e ? this.state = this.pendingPlayState : this.pause()
    }
    tick(e, t = !1) {
        const {
            resolved: r
        } = this;
        if (!r) {
            const {
                keyframes: e
            } = this.options;
            return {
                done: !0,
                value: e[e.length - 1]
            }
        }
        const {
            finalKeyframe: n,
            generator: s,
            mirroredGenerator: i,
            mapPercentToKeyframes: o,
            keyframes: a,
            calculatedDuration: l,
            totalDuration: c,
            resolvedDuration: u
        } = r;
        if (null === this.startTime) return s.next(0);
        const {
            delay: d,
            repeat: h,
            repeatType: p,
            repeatDelay: f,
            onUpdate: m
        } = this.options;
        this.speed > 0 ? this.startTime = Math.min(this.startTime, e) : this.speed < 0 && (this.startTime = Math.min(e - c / this.speed, this.startTime)), t ? this.currentTime = e : null !== this.holdTime ? this.currentTime = this.holdTime : this.currentTime = Math.round(e - this.startTime) * this.speed;
        const g = this.currentTime - d * (this.speed >= 0 ? 1 : -1),
            y = this.speed >= 0 ? g < 0 : g > c;
        this.currentTime = Math.max(g, 0), "finished" === this.state && null === this.holdTime && (this.currentTime = c);
        let v = this.currentTime,
            b = s;
        if (h) {
            const e = Math.min(this.currentTime, c) / u;
            let t = Math.floor(e),
                r = e % 1;
            !r && e >= 1 && (r = 1), 1 === r && t--, t = Math.min(t, h + 1);
            Boolean(t % 2) && ("reverse" === p ? (r = 1 - r, f && (r -= f / u)) : "mirror" === p && (b = i)), v = Ge(0, 1, r) * u
        }
        const x = y ? {
            done: !1,
            value: a[0]
        } : b.next(v);
        o && (x.value = o(x.value));
        let {
            done: w
        } = x;
        y || null === l || (w = this.speed >= 0 ? this.currentTime >= c : this.currentTime <= 0);
        const k = null === this.holdTime && ("finished" === this.state || "running" === this.state && w);
        return k && void 0 !== n && (x.value = Rn(a, this.options, n)), m && m(x.value), k && this.finish(), x
    }
    get duration() {
        const {
            resolved: e
        } = this;
        return e ? Y(e.calculatedDuration) : 0
    }
    get time() {
        return Y(this.currentTime)
    }
    set time(e) {
        e = G(e), this.currentTime = e, null !== this.holdTime || 0 === this.speed ? this.holdTime = e : this.driver && (this.startTime = this.driver.now() - e / this.speed)
    }
    get speed() {
        return this.playbackSpeed
    }
    set speed(e) {
        const t = this.playbackSpeed !== e;
        this.playbackSpeed = e, t && (this.time = Y(this.currentTime))
    }
    play() {
        if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) return void(this.pendingPlayState = "running");
        if (this.isStopped) return;
        const {
            driver: e = Es,
            onPlay: t,
            startTime: r
        } = this.options;
        this.driver || (this.driver = e((e => this.tick(e)))), t && t();
        const n = this.driver.now();
        null !== this.holdTime ? this.startTime = n - this.holdTime : this.startTime ? "finished" === this.state && (this.startTime = n) : this.startTime = null != r ? r : this.calcStartTime(), "finished" === this.state && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start()
    }
    pause() {
        var e;
        this._resolved ? (this.state = "paused", this.holdTime = null !== (e = this.currentTime) && void 0 !== e ? e : 0) : this.pendingPlayState = "paused"
    }
    complete() {
        "running" !== this.state && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null
    }
    finish() {
        this.teardown(), this.state = "finished";
        const {
            onComplete: e
        } = this.options;
        e && e()
    }
    cancel() {
        null !== this.cancelTime && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise()
    }
    teardown() {
        this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel()
    }
    stopDriver() {
        this.driver && (this.driver.stop(), this.driver = void 0)
    }
    sample(e) {
        return this.startTime = 0, this.tick(e, !0)
    }
}
const As = new Set(["opacity", "clipPath", "filter", "transform"]);

function Ns(e, t, r, {
    delay: n = 0,
    duration: s = 300,
    repeat: i = 0,
    repeatType: o = "loop",
    ease: a = "easeInOut",
    times: l
} = {}) {
    const c = {
        [t]: r
    };
    l && (c.offset = l);
    const u = Qt(a, s);
    return Array.isArray(u) && (c.easing = u), e.animate(c, {
        delay: n,
        duration: s,
        easing: Array.isArray(u) ? "linear" : u,
        fill: "both",
        iterations: i + 1,
        direction: "reverse" === o ? "alternate" : "normal"
    })
}
const Rs = q((() => Object.hasOwnProperty.call(Element.prototype, "animate")));
const Is = {
    anticipate: Rr,
    backInOut: Nr,
    circInOut: Mr
};
class Ls extends In {
    constructor(e) {
        super(e);
        const {
            name: t,
            motionValue: r,
            element: n,
            keyframes: s
        } = this.options;
        this.resolver = new On(s, ((e, t) => this.onKeyframesResolved(e, t)), t, r, n), this.resolver.scheduleResolve()
    }
    initPlayback(e, t) {
        let {
            duration: r = 300,
            times: n,
            ease: s,
            type: i,
            motionValue: o,
            name: a,
            startTime: l
        } = this.options;
        if (!o.owner || !o.owner.current) return !1;
        if ("string" == typeof s && Gt() && s in Is && (s = Is[s]), function(e) {
                return zt(e.type) || "spring" === e.type || !Jt(e.ease)
            }(this.options)) {
            const {
                onComplete: t,
                onUpdate: o,
                motionValue: a,
                element: l,
                ...c
            } = this.options, u = function(e, t) {
                const r = new Os({ ...t,
                    keyframes: e,
                    repeat: 0,
                    delay: 0,
                    isGenerator: !0
                });
                let n = {
                    done: !1,
                    value: e[0]
                };
                const s = [];
                let i = 0;
                for (; !n.done && i < 2e4;) n = r.sample(i), s.push(n.value), i += 10;
                return {
                    times: void 0,
                    keyframes: s,
                    duration: i - 10,
                    ease: "linear"
                }
            }(e, c);
            1 === (e = u.keyframes).length && (e[1] = e[0]), r = u.duration, n = u.times, s = u.ease, i = "keyframes"
        }
        const c = Ns(o.owner.current, a, e, { ...this.options,
            duration: r,
            times: n,
            ease: s
        });
        return c.startTime = null != l ? l : this.calcStartTime(), this.pendingTimeline ? (Wt(c, this.pendingTimeline), this.pendingTimeline = void 0) : c.onfinish = () => {
            const {
                onComplete: r
            } = this.options;
            o.set(Rn(e, this.options, t)), r && r(), this.cancel(), this.resolveFinishedPromise()
        }, {
            animation: c,
            duration: r,
            times: n,
            type: i,
            ease: s,
            keyframes: e
        }
    }
    get duration() {
        const {
            resolved: e
        } = this;
        if (!e) return 0;
        const {
            duration: t
        } = e;
        return Y(t)
    }
    get time() {
        const {
            resolved: e
        } = this;
        if (!e) return 0;
        const {
            animation: t
        } = e;
        return Y(t.currentTime || 0)
    }
    set time(e) {
        const {
            resolved: t
        } = this;
        if (!t) return;
        const {
            animation: r
        } = t;
        r.currentTime = G(e)
    }
    get speed() {
        const {
            resolved: e
        } = this;
        if (!e) return 1;
        const {
            animation: t
        } = e;
        return t.playbackRate
    }
    set speed(e) {
        const {
            resolved: t
        } = this;
        if (!t) return;
        const {
            animation: r
        } = t;
        r.playbackRate = e
    }
    get state() {
        const {
            resolved: e
        } = this;
        if (!e) return "idle";
        const {
            animation: t
        } = e;
        return t.playState
    }
    get startTime() {
        const {
            resolved: e
        } = this;
        if (!e) return null;
        const {
            animation: t
        } = e;
        return t.startTime
    }
    attachTimeline(e) {
        if (this._resolved) {
            const {
                resolved: t
            } = this;
            if (!t) return W;
            const {
                animation: r
            } = t;
            Wt(r, e)
        } else this.pendingTimeline = e;
        return W
    }
    play() {
        if (this.isStopped) return;
        const {
            resolved: e
        } = this;
        if (!e) return;
        const {
            animation: t
        } = e;
        "finished" === t.playState && this.updateFinishedPromise(), t.play()
    }
    pause() {
        const {
            resolved: e
        } = this;
        if (!e) return;
        const {
            animation: t
        } = e;
        t.pause()
    }
    stop() {
        if (this.resolver.cancel(), this.isStopped = !0, "idle" === this.state) return;
        this.resolveFinishedPromise(), this.updateFinishedPromise();
        const {
            resolved: e
        } = this;
        if (!e) return;
        const {
            animation: t,
            keyframes: r,
            duration: n,
            type: s,
            ease: i,
            times: o
        } = e;
        if ("idle" === t.playState || "finished" === t.playState) return;
        if (this.time) {
            const {
                motionValue: e,
                onUpdate: t,
                onComplete: a,
                element: l,
                ...c
            } = this.options, u = new Os({ ...c,
                keyframes: r,
                duration: n,
                type: s,
                ease: i,
                times: o,
                isGenerator: !0
            }), d = G(this.time);
            e.setWithVelocity(u.sample(d - 10).value, u.sample(d).value, 10)
        }
        const {
            onStop: a
        } = this.options;
        a && a(), this.cancel()
    }
    complete() {
        const {
            resolved: e
        } = this;
        e && e.animation.finish()
    }
    cancel() {
        const {
            resolved: e
        } = this;
        e && e.animation.cancel()
    }
    static supports(e) {
        const {
            motionValue: t,
            name: r,
            repeatDelay: n,
            repeatType: s,
            damping: i,
            type: o
        } = e;
        if (!(t && t.owner && t.owner.current instanceof HTMLElement)) return !1;
        const {
            onUpdate: a,
            transformTemplate: l
        } = t.owner.getProps();
        return Rs() && r && As.has(r) && !a && !l && !n && "mirror" !== s && 0 !== i && "inertia" !== o
    }
}
const Ms = {
        type: "spring",
        stiffness: 500,
        damping: 25,
        restSpeed: 10
    },
    Us = {
        type: "keyframes",
        duration: .8
    },
    Ds = {
        type: "keyframes",
        ease: [.25, .1, .35, 1],
        duration: .3
    },
    $s = (e, {
        keyframes: t
    }) => t.length > 2 ? Us : Ve.has(e) ? e.startsWith("scale") ? {
        type: "spring",
        stiffness: 550,
        damping: 0 === t[1] ? 2 * Math.sqrt(550) : 30,
        restSpeed: 10
    } : Ms : Ds;
const Fs = (e, t, r, n = {}, s, i) => o => {
    const a = Ft(n, e) || {},
        l = a.delay || n.delay || 0;
    let {
        elapsed: c = 0
    } = n;
    c -= G(l);
    let u = {
        keyframes: Array.isArray(r) ? r : [null, r],
        ease: "easeOut",
        velocity: t.getVelocity(),
        ...a,
        delay: -c,
        onUpdate: e => {
            t.set(e), a.onUpdate && a.onUpdate(e)
        },
        onComplete: () => {
            o(), a.onComplete && a.onComplete()
        },
        name: e,
        motionValue: t,
        element: i ? void 0 : s
    };
    (function({
        when: e,
        delay: t,
        delayChildren: r,
        staggerChildren: n,
        staggerDirection: s,
        repeat: i,
        repeatType: o,
        repeatDelay: a,
        from: l,
        elapsed: c,
        ...u
    }) {
        return !!Object.keys(u).length
    })(a) || (u = { ...u,
        ...$s(e, u)
    }), u.duration && (u.duration = G(u.duration)), u.repeatDelay && (u.repeatDelay = G(u.repeatDelay)), void 0 !== u.from && (u.keyframes[0] = u.from);
    let d = !1;
    if ((!1 === u.type || 0 === u.duration && !u.repeatDelay) && (u.duration = 0, 0 === u.delay && (d = !0)), d && !i && void 0 !== t.get()) {
        const e = Rn(u.keyframes, a);
        if (void 0 !== e) return Q.update((() => {
            u.onUpdate(e), u.onComplete()
        })), new $t([])
    }
    return !i && Ls.supports(u) ? new Ls(u) : new Os(u)
};

function Vs({
    protectedKeys: e,
    needsAnimating: t
}, r) {
    const n = e.hasOwnProperty(r) && !0 !== t[r];
    return t[r] = !1, n
}

function Bs(e, t, {
    delay: r = 0,
    transitionOverride: n,
    type: s
} = {}) {
    var i;
    let {
        transition: o = e.getDefaultTransition(),
        transitionEnd: a,
        ...l
    } = t;
    n && (o = n);
    const c = [],
        u = s && e.animationState && e.animationState.getState()[s];
    for (const d in l) {
        const t = e.getValue(d, null !== (i = e.latestValues[d]) && void 0 !== i ? i : null),
            n = l[d];
        if (void 0 === n || u && Vs(u, d)) continue;
        const s = {
            delay: r,
            ...Ft(o || {}, d)
        };
        let a = !1;
        if (window.MotionHandoffAnimation) {
            const t = Tr(e);
            if (t) {
                const e = window.MotionHandoffAnimation(t, d, Q);
                null !== e && (s.startTime = e, a = !0)
            }
        }
        Sr(e, d), t.start(Fs(d, t, n, e.shouldReduceMotion && hr.has(d) ? {
            type: !1
        } : s, e, a));
        const h = t.animation;
        h && c.push(h)
    }
    return a && Promise.all(c).then((() => {
        Q.update((() => {
            a && jr(e, a)
        }))
    })), c
}

function zs(e, t, r = {}) {
    var n;
    const s = Mt(e, t, "exit" === r.type ? null === (n = e.presenceContext) || void 0 === n ? void 0 : n.custom : void 0);
    let {
        transition: i = e.getDefaultTransition() || {}
    } = s || {};
    r.transitionOverride && (i = r.transitionOverride);
    const o = s ? () => Promise.all(Bs(e, s, r)) : () => Promise.resolve(),
        a = e.variantChildren && e.variantChildren.size ? (n = 0) => {
            const {
                delayChildren: s = 0,
                staggerChildren: o,
                staggerDirection: a
            } = i;
            return function(e, t, r = 0, n = 0, s = 1, i) {
                const o = [],
                    a = (e.variantChildren.size - 1) * n,
                    l = 1 === s ? (e = 0) => e * n : (e = 0) => a - e * n;
                return Array.from(e.variantChildren).sort(Ws).forEach(((e, n) => {
                    e.notify("AnimationStart", t), o.push(zs(e, t, { ...i,
                        delay: r + l(n)
                    }).then((() => e.notify("AnimationComplete", t))))
                })), Promise.all(o)
            }(e, t, s + n, o, a, r)
        } : () => Promise.resolve(),
        {
            when: l
        } = i;
    if (l) {
        const [e, t] = "beforeChildren" === l ? [o, a] : [a, o];
        return e().then((() => t()))
    }
    return Promise.all([o(), a(r.delay)])
}

function Ws(e, t) {
    return e.sortNodePosition(t)
}

function Hs(e, t, r = {}) {
    let n;
    if (e.notify("AnimationStart", t), Array.isArray(t)) {
        const s = t.map((t => zs(e, t, r)));
        n = Promise.all(s)
    } else if ("string" == typeof t) n = zs(e, t, r);
    else {
        const s = "function" == typeof t ? Mt(e, t, r.custom) : t;
        n = Promise.all(Bs(e, s, r))
    }
    return n.then((() => {
        e.notify("AnimationComplete", t)
    }))
}
const qs = me.length;

function Ks(e) {
    if (!e) return;
    if (!e.isControllingVariants) {
        const t = e.parent && Ks(e.parent) || {};
        return void 0 !== e.props.initial && (t.initial = e.props.initial), t
    }
    const t = {};
    for (let r = 0; r < qs; r++) {
        const n = me[r],
            s = e.props[n];
        (he(s) || !1 === s) && (t[n] = s)
    }
    return t
}
const Gs = [...fe].reverse(),
    Ys = fe.length;

function Js(e) {
    let t = function(e) {
            return t => Promise.all(t.map((({
                animation: t,
                options: r
            }) => Hs(e, t, r))))
        }(e),
        r = Qs(),
        n = !0;
    const s = t => (r, n) => {
        var s;
        const i = Mt(e, n, "exit" === t ? null === (s = e.presenceContext) || void 0 === s ? void 0 : s.custom : void 0);
        if (i) {
            const {
                transition: e,
                transitionEnd: t,
                ...n
            } = i;
            r = { ...r,
                ...n,
                ...t
            }
        }
        return r
    };

    function i(i) {
        const {
            props: o
        } = e, a = Ks(e.parent) || {}, l = [], c = new Set;
        let u = {},
            d = 1 / 0;
        for (let t = 0; t < Ys; t++) {
            const h = Gs[t],
                p = r[h],
                f = void 0 !== o[h] ? o[h] : a[h],
                m = he(f),
                g = h === i ? p.isActive : null;
            !1 === g && (d = t);
            let y = f === a[h] && f !== o[h] && m;
            if (y && n && e.manuallyAnimateOnMount && (y = !1), p.protectedKeys = { ...u
                }, !p.isActive && null === g || !f && !p.prevProp || pe(f) || "boolean" == typeof f) continue;
            const v = Xs(p.prevProp, f);
            let b = v || h === i && p.isActive && !y && m || t > d && m,
                x = !1;
            const w = Array.isArray(f) ? f : [f];
            let k = w.reduce(s(h), {});
            !1 === g && (k = {});
            const {
                prevResolvedValues: j = {}
            } = p, S = { ...j,
                ...k
            }, T = t => {
                b = !0, c.has(t) && (x = !0, c.delete(t)), p.needsAnimating[t] = !0;
                const r = e.getValue(t);
                r && (r.liveStyle = !1)
            };
            for (const e in S) {
                const t = k[e],
                    r = j[e];
                if (u.hasOwnProperty(e)) continue;
                let n = !1;
                n = Le(t) && Le(r) ? !Lt(t, r) : t !== r, n ? null != t ? T(e) : c.add(e) : void 0 !== t && c.has(e) ? T(e) : p.protectedKeys[e] = !0
            }
            p.prevProp = f, p.prevResolvedValues = k, p.isActive && (u = { ...u,
                ...k
            }), n && e.blockInitialAnimation && (b = !1);
            b && (!(y && v) || x) && l.push(...w.map((e => ({
                animation: e,
                options: {
                    type: h
                }
            }))))
        }
        if (c.size) {
            const t = {};
            c.forEach((r => {
                const n = e.getBaseTarget(r),
                    s = e.getValue(r);
                s && (s.liveStyle = !0), t[r] = null != n ? n : null
            })), l.push({
                animation: t
            })
        }
        let h = Boolean(l.length);
        return !n || !1 !== o.initial && o.initial !== o.animate || e.manuallyAnimateOnMount || (h = !1), n = !1, h ? t(l) : Promise.resolve()
    }
    return {
        animateChanges: i,
        setActive: function(t, n) {
            var s;
            if (r[t].isActive === n) return Promise.resolve();
            null === (s = e.variantChildren) || void 0 === s || s.forEach((e => {
                var r;
                return null === (r = e.animationState) || void 0 === r ? void 0 : r.setActive(t, n)
            })), r[t].isActive = n;
            const o = i(t);
            for (const e in r) r[e].protectedKeys = {};
            return o
        },
        setAnimateFunction: function(r) {
            t = r(e)
        },
        getState: () => r,
        reset: () => {
            r = Qs(), n = !0
        }
    }
}

function Xs(e, t) {
    return "string" == typeof t ? t !== e : !!Array.isArray(t) && !Lt(t, e)
}

function Zs(e = !1) {
    return {
        isActive: e,
        protectedKeys: {},
        needsAnimating: {},
        prevResolvedValues: {}
    }
}

function Qs() {
    return {
        animate: Zs(!0),
        whileInView: Zs(),
        whileHover: Zs(),
        whileTap: Zs(),
        whileDrag: Zs(),
        whileFocus: Zs(),
        exit: Zs()
    }
}
class ei {
    constructor(e) {
        this.isMounted = !1, this.node = e
    }
    update() {}
}
let ti = 0;
const ri = {
    animation: {
        Feature: class extends ei {
            constructor(e) {
                super(e), e.animationState || (e.animationState = Js(e))
            }
            updateAnimationControlsSubscription() {
                const {
                    animate: e
                } = this.node.getProps();
                pe(e) && (this.unmountControls = e.subscribe(this.node))
            }
            mount() {
                this.updateAnimationControlsSubscription()
            }
            update() {
                const {
                    animate: e
                } = this.node.getProps(), {
                    animate: t
                } = this.node.prevProps || {};
                e !== t && this.updateAnimationControlsSubscription()
            }
            unmount() {
                var e;
                this.node.animationState.reset(), null === (e = this.unmountControls) || void 0 === e || e.call(this)
            }
        }
    },
    exit: {
        Feature: class extends ei {
            constructor() {
                super(...arguments), this.id = ti++
            }
            update() {
                if (!this.node.presenceContext) return;
                const {
                    isPresent: e,
                    onExitComplete: t
                } = this.node.presenceContext, {
                    isPresent: r
                } = this.node.prevPresenceContext || {};
                if (!this.node.animationState || e === r) return;
                const n = this.node.animationState.setActive("exit", !e);
                t && !e && n.then((() => t(this.id)))
            }
            mount() {
                const {
                    register: e
                } = this.node.presenceContext || {};
                e && (this.unmount = e(this.id))
            }
            unmount() {}
        }
    }
};

function ni(e, t, r, n = {
    passive: !0
}) {
    return e.addEventListener(t, r, n), () => e.removeEventListener(t, r)
}

function si(e) {
    return {
        point: {
            x: e.pageX,
            y: e.pageY
        }
    }
}

function ii(e, t, r, n) {
    return ni(e, t, (e => t => ir(t) && e(t, si(t)))(r), n)
}
const oi = (e, t) => Math.abs(e - t);
class ai {
    constructor(e, t, {
        transformPagePoint: r,
        contextWindow: n,
        dragSnapToOrigin: s = !1
    } = {}) {
        if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                if (!this.lastMoveEvent || !this.lastMoveEventInfo) return;
                const e = ui(this.lastMoveEventInfo, this.history),
                    t = null !== this.startEvent,
                    r = function(e, t) {
                        const r = oi(e.x, t.x),
                            n = oi(e.y, t.y);
                        return Math.sqrt(r ** 2 + n ** 2)
                    }(e.offset, {
                        x: 0,
                        y: 0
                    }) >= 3;
                if (!t && !r) return;
                const {
                    point: n
                } = e, {
                    timestamp: s
                } = te;
                this.history.push({ ...n,
                    timestamp: s
                });
                const {
                    onStart: i,
                    onMove: o
                } = this.handlers;
                t || (i && i(this.lastMoveEvent, e), this.startEvent = this.lastMoveEvent), o && o(this.lastMoveEvent, e)
            }, this.handlePointerMove = (e, t) => {
                this.lastMoveEvent = e, this.lastMoveEventInfo = li(t, this.transformPagePoint), Q.update(this.updatePoint, !0)
            }, this.handlePointerUp = (e, t) => {
                this.end();
                const {
                    onEnd: r,
                    onSessionEnd: n,
                    resumeAnimation: s
                } = this.handlers;
                if (this.dragSnapToOrigin && s && s(), !this.lastMoveEvent || !this.lastMoveEventInfo) return;
                const i = ui("pointercancel" === e.type ? this.lastMoveEventInfo : li(t, this.transformPagePoint), this.history);
                this.startEvent && r && r(e, i), n && n(e, i)
            }, !ir(e)) return;
        this.dragSnapToOrigin = s, this.handlers = t, this.transformPagePoint = r, this.contextWindow = n || window;
        const i = li(si(e), this.transformPagePoint),
            {
                point: o
            } = i,
            {
                timestamp: a
            } = te;
        this.history = [{ ...o,
            timestamp: a
        }];
        const {
            onSessionStart: l
        } = t;
        l && l(e, ui(i, this.history)), this.removeListeners = zn(ii(this.contextWindow, "pointermove", this.handlePointerMove), ii(this.contextWindow, "pointerup", this.handlePointerUp), ii(this.contextWindow, "pointercancel", this.handlePointerUp))
    }
    updateHandlers(e) {
        this.handlers = e
    }
    end() {
        this.removeListeners && this.removeListeners(), ee(this.updatePoint)
    }
}

function li(e, t) {
    return t ? {
        point: t(e.point)
    } : e
}

function ci(e, t) {
    return {
        x: e.x - t.x,
        y: e.y - t.y
    }
}

function ui({
    point: e
}, t) {
    return {
        point: e,
        delta: ci(e, hi(t)),
        offset: ci(e, di(t)),
        velocity: pi(t, .1)
    }
}

function di(e) {
    return e[0]
}

function hi(e) {
    return e[e.length - 1]
}

function pi(e, t) {
    if (e.length < 2) return {
        x: 0,
        y: 0
    };
    let r = e.length - 1,
        n = null;
    const s = hi(e);
    for (; r >= 0 && (n = e[r], !(s.timestamp - n.timestamp > G(t)));) r--;
    if (!n) return {
        x: 0,
        y: 0
    };
    const i = Y(s.timestamp - n.timestamp);
    if (0 === i) return {
        x: 0,
        y: 0
    };
    const o = {
        x: (s.x - n.x) / i,
        y: (s.y - n.y) / i
    };
    return o.x === 1 / 0 && (o.x = 0), o.y === 1 / 0 && (o.y = 0), o
}

function fi(e) {
    return e.max - e.min
}

function mi(e, t, r, n = .5) {
    e.origin = n, e.originPoint = Ln(t.min, t.max, e.origin), e.scale = fi(r) / fi(t), e.translate = Ln(r.min, r.max, e.origin) - e.originPoint, (e.scale >= .9999 && e.scale <= 1.0001 || isNaN(e.scale)) && (e.scale = 1), (e.translate >= -.01 && e.translate <= .01 || isNaN(e.translate)) && (e.translate = 0)
}

function gi(e, t, r, n) {
    mi(e.x, t.x, r.x, n ? n.originX : void 0), mi(e.y, t.y, r.y, n ? n.originY : void 0)
}

function yi(e, t, r) {
    e.min = r.min + t.min, e.max = e.min + fi(t)
}

function vi(e, t, r) {
    e.min = t.min - r.min, e.max = e.min + fi(t)
}

function bi(e, t, r) {
    vi(e.x, t.x, r.x), vi(e.y, t.y, r.y)
}

function xi(e, t, r) {
    return {
        min: void 0 !== t ? e.min + t : void 0,
        max: void 0 !== r ? e.max + r - (e.max - e.min) : void 0
    }
}

function wi(e, t) {
    let r = t.min - e.min,
        n = t.max - e.max;
    return t.max - t.min < e.max - e.min && ([r, n] = [n, r]), {
        min: r,
        max: n
    }
}
const ki = .35;

function ji(e, t, r) {
    return {
        min: Si(e, t),
        max: Si(e, r)
    }
}

function Si(e, t) {
    return "number" == typeof e ? e : e[t] || 0
}
const Ti = () => ({
    x: {
        min: 0,
        max: 0
    },
    y: {
        min: 0,
        max: 0
    }
});

function _i(e) {
    return [e("x"), e("y")]
}

function Ei({
    top: e,
    left: t,
    right: r,
    bottom: n
}) {
    return {
        x: {
            min: t,
            max: r
        },
        y: {
            min: e,
            max: n
        }
    }
}

function Pi(e) {
    return void 0 === e || 1 === e
}

function Ci({
    scale: e,
    scaleX: t,
    scaleY: r
}) {
    return !Pi(e) || !Pi(t) || !Pi(r)
}

function Oi(e) {
    return Ci(e) || Ai(e) || e.z || e.rotate || e.rotateX || e.rotateY || e.skewX || e.skewY
}

function Ai(e) {
    return Ni(e.x) || Ni(e.y)
}

function Ni(e) {
    return e && "0%" !== e
}

function Ri(e, t, r) {
    return r + t * (e - r)
}

function Ii(e, t, r, n, s) {
    return void 0 !== s && (e = Ri(e, s, n)), Ri(e, r, n) + t
}

function Li(e, t = 0, r = 1, n, s) {
    e.min = Ii(e.min, t, r, n, s), e.max = Ii(e.max, t, r, n, s)
}

function Mi(e, {
    x: t,
    y: r
}) {
    Li(e.x, t.translate, t.scale, t.originPoint), Li(e.y, r.translate, r.scale, r.originPoint)
}
const Ui = .999999999999,
    Di = 1.0000000000001;

function $i(e, t) {
    e.min = e.min + t, e.max = e.max + t
}

function Fi(e, t, r, n, s = .5) {
    Li(e, t, r, Ln(e.min, e.max, s), n)
}

function Vi(e, t) {
    Fi(e.x, t.x, t.scaleX, t.scale, t.originX), Fi(e.y, t.y, t.scaleY, t.scale, t.originY)
}

function Bi(e, t) {
    return Ei(function(e, t) {
        if (!t) return e;
        const r = t({
                x: e.left,
                y: e.top
            }),
            n = t({
                x: e.right,
                y: e.bottom
            });
        return {
            top: r.y,
            left: r.x,
            bottom: n.y,
            right: n.x
        }
    }(e.getBoundingClientRect(), t))
}
const zi = ({
        current: e
    }) => e ? e.ownerDocument.defaultView : null,
    Wi = new WeakMap;
class Hi {
    constructor(e) {
        this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
            x: 0,
            y: 0
        }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = {
            x: {
                min: 0,
                max: 0
            },
            y: {
                min: 0,
                max: 0
            }
        }, this.visualElement = e
    }
    start(e, {
        snapToCursor: t = !1
    } = {}) {
        const {
            presenceContext: r
        } = this.visualElement;
        if (r && !1 === r.isPresent) return;
        const {
            dragSnapToOrigin: n
        } = this.getProps();
        this.panSession = new ai(e, {
            onSessionStart: e => {
                const {
                    dragSnapToOrigin: r
                } = this.getProps();
                r ? this.pauseAnimation() : this.stopAnimation(), t && this.snapToCursor(si(e).point)
            },
            onStart: (e, t) => {
                const {
                    drag: r,
                    dragPropagation: n,
                    onDragStart: s
                } = this.getProps();
                if (r && !n && (this.openDragLock && this.openDragLock(), this.openDragLock = "x" === (i = r) || "y" === i ? er[i] ? null : (er[i] = !0, () => {
                        er[i] = !1
                    }) : er.x || er.y ? null : (er.x = er.y = !0, () => {
                        er.x = er.y = !1
                    }), !this.openDragLock)) return;
                var i;
                this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), _i((e => {
                    let t = this.getAxisMotionValue(e).get() || 0;
                    if (et.test(t)) {
                        const {
                            projection: r
                        } = this.visualElement;
                        if (r && r.layout) {
                            const n = r.layout.layoutBox[e];
                            if (n) {
                                t = fi(n) * (parseFloat(t) / 100)
                            }
                        }
                    }
                    this.originPoint[e] = t
                })), s && Q.postRender((() => s(e, t))), Sr(this.visualElement, "transform");
                const {
                    animationState: o
                } = this.visualElement;
                o && o.setActive("whileDrag", !0)
            },
            onMove: (e, t) => {
                const {
                    dragPropagation: r,
                    dragDirectionLock: n,
                    onDirectionLock: s,
                    onDrag: i
                } = this.getProps();
                if (!r && !this.openDragLock) return;
                const {
                    offset: o
                } = t;
                if (n && null === this.currentDirection) return this.currentDirection = function(e, t = 10) {
                    let r = null;
                    Math.abs(e.y) > t ? r = "y" : Math.abs(e.x) > t && (r = "x");
                    return r
                }(o), void(null !== this.currentDirection && s && s(this.currentDirection));
                this.updateAxis("x", t.point, o), this.updateAxis("y", t.point, o), this.visualElement.render(), i && i(e, t)
            },
            onSessionEnd: (e, t) => this.stop(e, t),
            resumeAnimation: () => _i((e => {
                var t;
                return "paused" === this.getAnimationState(e) && (null === (t = this.getAxisMotionValue(e).animation) || void 0 === t ? void 0 : t.play())
            }))
        }, {
            transformPagePoint: this.visualElement.getTransformPagePoint(),
            dragSnapToOrigin: n,
            contextWindow: zi(this.visualElement)
        })
    }
    stop(e, t) {
        const r = this.isDragging;
        if (this.cancel(), !r) return;
        const {
            velocity: n
        } = t;
        this.startAnimation(n);
        const {
            onDragEnd: s
        } = this.getProps();
        s && Q.postRender((() => s(e, t)))
    }
    cancel() {
        this.isDragging = !1;
        const {
            projection: e,
            animationState: t
        } = this.visualElement;
        e && (e.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
        const {
            dragPropagation: r
        } = this.getProps();
        !r && this.openDragLock && (this.openDragLock(), this.openDragLock = null), t && t.setActive("whileDrag", !1)
    }
    updateAxis(e, t, r) {
        const {
            drag: n
        } = this.getProps();
        if (!r || !qi(e, n, this.currentDirection)) return;
        const s = this.getAxisMotionValue(e);
        let i = this.originPoint[e] + r[e];
        this.constraints && this.constraints[e] && (i = function(e, {
            min: t,
            max: r
        }, n) {
            return void 0 !== t && e < t ? e = n ? Ln(t, e, n.min) : Math.max(e, t) : void 0 !== r && e > r && (e = n ? Ln(r, e, n.max) : Math.min(e, r)), e
        }(i, this.constraints[e], this.elastic[e])), s.set(i)
    }
    resolveConstraints() {
        var e;
        const {
            dragConstraints: t,
            dragElastic: r
        } = this.getProps(), n = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : null === (e = this.visualElement.projection) || void 0 === e ? void 0 : e.layout, s = this.constraints;
        t && we(t) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : this.constraints = !(!t || !n) && function(e, {
            top: t,
            left: r,
            bottom: n,
            right: s
        }) {
            return {
                x: xi(e.x, r, s),
                y: xi(e.y, t, n)
            }
        }(n.layoutBox, t), this.elastic = function(e = ki) {
            return !1 === e ? e = 0 : !0 === e && (e = ki), {
                x: ji(e, "left", "right"),
                y: ji(e, "top", "bottom")
            }
        }(r), s !== this.constraints && n && this.constraints && !this.hasMutatedConstraints && _i((e => {
            !1 !== this.constraints && this.getAxisMotionValue(e) && (this.constraints[e] = function(e, t) {
                const r = {};
                return void 0 !== t.min && (r.min = t.min - e.min), void 0 !== t.max && (r.max = t.max - e.min), r
            }(n.layoutBox[e], this.constraints[e]))
        }))
    }
    resolveRefConstraints() {
        const {
            dragConstraints: e,
            onMeasureDragConstraints: t
        } = this.getProps();
        if (!e || !we(e)) return !1;
        const r = e.current,
            {
                projection: n
            } = this.visualElement;
        if (!n || !n.layout) return !1;
        const s = function(e, t, r) {
            const n = Bi(e, r),
                {
                    scroll: s
                } = t;
            return s && ($i(n.x, s.offset.x), $i(n.y, s.offset.y)), n
        }(r, n.root, this.visualElement.getTransformPagePoint());
        let i = function(e, t) {
            return {
                x: wi(e.x, t.x),
                y: wi(e.y, t.y)
            }
        }(n.layout.layoutBox, s);
        if (t) {
            const e = t(function({
                x: e,
                y: t
            }) {
                return {
                    top: t.min,
                    right: e.max,
                    bottom: t.max,
                    left: e.min
                }
            }(i));
            this.hasMutatedConstraints = !!e, e && (i = Ei(e))
        }
        return i
    }
    startAnimation(e) {
        const {
            drag: t,
            dragMomentum: r,
            dragElastic: n,
            dragTransition: s,
            dragSnapToOrigin: i,
            onDragTransitionEnd: o
        } = this.getProps(), a = this.constraints || {}, l = _i((o => {
            if (!qi(o, t, this.currentDirection)) return;
            let l = a && a[o] || {};
            i && (l = {
                min: 0,
                max: 0
            });
            const c = n ? 200 : 1e6,
                u = n ? 40 : 1e7,
                d = {
                    type: "inertia",
                    velocity: r ? e[o] : 0,
                    bounceStiffness: c,
                    bounceDamping: u,
                    timeConstant: 750,
                    restDelta: 1,
                    restSpeed: 10,
                    ...s,
                    ...l
                };
            return this.startAxisValueAnimation(o, d)
        }));
        return Promise.all(l).then(o)
    }
    startAxisValueAnimation(e, t) {
        const r = this.getAxisMotionValue(e);
        return Sr(this.visualElement, e), r.start(Fs(e, r, 0, t, this.visualElement, !1))
    }
    stopAnimation() {
        _i((e => this.getAxisMotionValue(e).stop()))
    }
    pauseAnimation() {
        _i((e => {
            var t;
            return null === (t = this.getAxisMotionValue(e).animation) || void 0 === t ? void 0 : t.pause()
        }))
    }
    getAnimationState(e) {
        var t;
        return null === (t = this.getAxisMotionValue(e).animation) || void 0 === t ? void 0 : t.state
    }
    getAxisMotionValue(e) {
        const t = `_drag${e.toUpperCase()}`,
            r = this.visualElement.getProps(),
            n = r[t];
        return n || this.visualElement.getValue(e, (r.initial ? r.initial[e] : void 0) || 0)
    }
    snapToCursor(e) {
        _i((t => {
            const {
                drag: r
            } = this.getProps();
            if (!qi(t, r, this.currentDirection)) return;
            const {
                projection: n
            } = this.visualElement, s = this.getAxisMotionValue(t);
            if (n && n.layout) {
                const {
                    min: r,
                    max: i
                } = n.layout.layoutBox[t];
                s.set(e[t] - Ln(r, i, .5))
            }
        }))
    }
    scalePositionWithinConstraints() {
        if (!this.visualElement.current) return;
        const {
            drag: e,
            dragConstraints: t
        } = this.getProps(), {
            projection: r
        } = this.visualElement;
        if (!we(t) || !r || !this.constraints) return;
        this.stopAnimation();
        const n = {
            x: 0,
            y: 0
        };
        _i((e => {
            const t = this.getAxisMotionValue(e);
            if (t && !1 !== this.constraints) {
                const r = t.get();
                n[e] = function(e, t) {
                    let r = .5;
                    const n = fi(e),
                        s = fi(t);
                    return s > n ? r = K(t.min, t.max - n, e.min) : n > s && (r = K(e.min, e.max - s, t.min)), Ge(0, 1, r)
                }({
                    min: r,
                    max: r
                }, this.constraints[e])
            }
        }));
        const {
            transformTemplate: s
        } = this.visualElement.getProps();
        this.visualElement.current.style.transform = s ? s({}, "") : "none", r.root && r.root.updateScroll(), r.updateLayout(), this.resolveConstraints(), _i((t => {
            if (!qi(t, e, null)) return;
            const r = this.getAxisMotionValue(t),
                {
                    min: s,
                    max: i
                } = this.constraints[t];
            r.set(Ln(s, i, n[t]))
        }))
    }
    addListeners() {
        if (!this.visualElement.current) return;
        Wi.set(this.visualElement, this);
        const e = ii(this.visualElement.current, "pointerdown", (e => {
                const {
                    drag: t,
                    dragListener: r = !0
                } = this.getProps();
                t && r && this.start(e)
            })),
            t = () => {
                const {
                    dragConstraints: e
                } = this.getProps();
                we(e) && e.current && (this.constraints = this.resolveRefConstraints())
            },
            {
                projection: r
            } = this.visualElement,
            n = r.addEventListener("measure", t);
        r && !r.layout && (r.root && r.root.updateScroll(), r.updateLayout()), Q.read(t);
        const s = ni(window, "resize", (() => this.scalePositionWithinConstraints())),
            i = r.addEventListener("didUpdate", (({
                delta: e,
                hasLayoutChanged: t
            }) => {
                this.isDragging && t && (_i((t => {
                    const r = this.getAxisMotionValue(t);
                    r && (this.originPoint[t] += e[t].translate, r.set(r.get() + e[t].translate))
                })), this.visualElement.render())
            }));
        return () => {
            s(), e(), n(), i && i()
        }
    }
    getProps() {
        const e = this.visualElement.getProps(),
            {
                drag: t = !1,
                dragDirectionLock: r = !1,
                dragPropagation: n = !1,
                dragConstraints: s = !1,
                dragElastic: i = ki,
                dragMomentum: o = !0
            } = e;
        return { ...e,
            drag: t,
            dragDirectionLock: r,
            dragPropagation: n,
            dragConstraints: s,
            dragElastic: i,
            dragMomentum: o
        }
    }
}

function qi(e, t, r) {
    return !(!0 !== t && t !== e || null !== r && r !== e)
}
const Ki = e => (t, r) => {
    e && Q.postRender((() => e(t, r)))
};
const Gi = {
    hasAnimatedSinceResize: !0,
    hasEverUpdated: !1
};

function Yi(e, t) {
    return t.max === t.min ? 0 : e / (t.max - t.min) * 100
}
const Ji = {
        correct: (e, t) => {
            if (!t.target) return e;
            if ("string" == typeof e) {
                if (!tt.test(e)) return e;
                e = parseFloat(e)
            }
            return `${Yi(e,t.target.x)}% ${Yi(e,t.target.y)}%`
        }
    },
    Xi = {
        correct: (e, {
            treeScale: t,
            projectionDelta: r
        }) => {
            const n = e,
                s = rn.parse(e);
            if (s.length > 5) return n;
            const i = rn.createTransformer(e),
                o = "number" != typeof s[0] ? 1 : 0,
                a = r.x.scale * t.x,
                l = r.y.scale * t.y;
            s[0 + o] /= a, s[1 + o] /= l;
            const c = Ln(a, l, .5);
            return "number" == typeof s[2 + o] && (s[2 + o] /= c), "number" == typeof s[3 + o] && (s[3 + o] /= c), i(s)
        }
    };
class Zi extends o.Component {
    componentDidMount() {
        const {
            visualElement: e,
            layoutGroup: t,
            switchLayoutGroup: r,
            layoutId: n
        } = this.props, {
            projection: s
        } = e;
        var i;
        i = eo, Object.assign(kt, i), s && (t.group && t.group.add(s), r && r.register && n && r.register(s), s.root.didUpdate(), s.addEventListener("animationComplete", (() => {
            this.safeToRemove()
        })), s.setOptions({ ...s.options,
            onExitComplete: () => this.safeToRemove()
        })), Gi.hasEverUpdated = !0
    }
    getSnapshotBeforeUpdate(e) {
        const {
            layoutDependency: t,
            visualElement: r,
            drag: n,
            isPresent: s
        } = this.props, i = r.projection;
        return i ? (i.isPresent = s, n || e.layoutDependency !== t || void 0 === t ? i.willUpdate() : this.safeToRemove(), e.isPresent !== s && (s ? i.promote() : i.relegate() || Q.postRender((() => {
            const e = i.getStack();
            e && e.members.length || this.safeToRemove()
        }))), null) : null
    }
    componentDidUpdate() {
        const {
            projection: e
        } = this.props.visualElement;
        e && (e.root.didUpdate(), Te.postRender((() => {
            !e.currentAnimation && e.isLead() && this.safeToRemove()
        })))
    }
    componentWillUnmount() {
        const {
            visualElement: e,
            layoutGroup: t,
            switchLayoutGroup: r
        } = this.props, {
            projection: n
        } = e;
        n && (n.scheduleCheckAfterUnmount(), t && t.group && t.group.remove(n), r && r.deregister && r.deregister(n))
    }
    safeToRemove() {
        const {
            safeToRemove: e
        } = this.props;
        e && e()
    }
    render() {
        return null
    }
}

function Qi(e) {
    const [t, r] = D(), n = o.useContext(O);
    return T.jsx(Zi, { ...e,
        layoutGroup: n,
        switchLayoutGroup: o.useContext(_e),
        isPresent: t,
        safeToRemove: r
    })
}
const eo = {
    borderRadius: { ...Ji,
        applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
    },
    borderTopLeftRadius: Ji,
    borderTopRightRadius: Ji,
    borderBottomLeftRadius: Ji,
    borderBottomRightRadius: Ji,
    boxShadow: Xi
};
const to = (e, t) => e.depth - t.depth;
class ro {
    constructor() {
        this.children = [], this.isDirty = !1
    }
    add(e) {
        gr(this.children, e), this.isDirty = !0
    }
    remove(e) {
        yr(this.children, e), this.isDirty = !0
    }
    forEach(e) {
        this.isDirty && this.children.sort(to), this.isDirty = !1, this.children.forEach(e)
    }
}
const no = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
    so = no.length,
    io = e => "string" == typeof e ? parseFloat(e) : e,
    oo = e => "number" == typeof e || tt.test(e);

function ao(e, t) {
    return void 0 !== e[t] ? e[t] : e.borderRadius
}
const lo = uo(0, .5, Lr),
    co = uo(.5, .95, W);

function uo(e, t, r) {
    return n => n < e ? 0 : n > t ? 1 : r(K(e, t, n))
}

function ho(e, t) {
    e.min = t.min, e.max = t.max
}

function po(e, t) {
    ho(e.x, t.x), ho(e.y, t.y)
}

function fo(e, t) {
    e.translate = t.translate, e.scale = t.scale, e.originPoint = t.originPoint, e.origin = t.origin
}

function mo(e, t, r, n, s) {
    return e = Ri(e -= t, 1 / r, n), void 0 !== s && (e = Ri(e, 1 / s, n)), e
}

function go(e, t, [r, n, s], i, o) {
    ! function(e, t = 0, r = 1, n = .5, s, i = e, o = e) {
        et.test(t) && (t = parseFloat(t), t = Ln(o.min, o.max, t / 100) - o.min);
        if ("number" != typeof t) return;
        let a = Ln(i.min, i.max, n);
        e === i && (a -= t), e.min = mo(e.min, t, r, a, s), e.max = mo(e.max, t, r, a, s)
    }(e, t[r], t[n], t[s], t.scale, i, o)
}
const yo = ["x", "scaleX", "originX"],
    vo = ["y", "scaleY", "originY"];

function bo(e, t, r, n) {
    go(e.x, t, yo, r ? r.x : void 0, n ? n.x : void 0), go(e.y, t, vo, r ? r.y : void 0, n ? n.y : void 0)
}

function xo(e) {
    return 0 === e.translate && 1 === e.scale
}

function wo(e) {
    return xo(e.x) && xo(e.y)
}

function ko(e, t) {
    return e.min === t.min && e.max === t.max
}

function jo(e, t) {
    return Math.round(e.min) === Math.round(t.min) && Math.round(e.max) === Math.round(t.max)
}

function So(e, t) {
    return jo(e.x, t.x) && jo(e.y, t.y)
}

function To(e) {
    return fi(e.x) / fi(e.y)
}

function _o(e, t) {
    return e.translate === t.translate && e.scale === t.scale && e.originPoint === t.originPoint
}
class Eo {
    constructor() {
        this.members = []
    }
    add(e) {
        gr(this.members, e), e.scheduleRender()
    }
    remove(e) {
        if (yr(this.members, e), e === this.prevLead && (this.prevLead = void 0), e === this.lead) {
            const e = this.members[this.members.length - 1];
            e && this.promote(e)
        }
    }
    relegate(e) {
        const t = this.members.findIndex((t => e === t));
        if (0 === t) return !1;
        let r;
        for (let n = t; n >= 0; n--) {
            const e = this.members[n];
            if (!1 !== e.isPresent) {
                r = e;
                break
            }
        }
        return !!r && (this.promote(r), !0)
    }
    promote(e, t) {
        const r = this.lead;
        if (e !== r && (this.prevLead = r, this.lead = e, e.show(), r)) {
            r.instance && r.scheduleRender(), e.scheduleRender(), e.resumeFrom = r, t && (e.resumeFrom.preserveOpacity = !0), r.snapshot && (e.snapshot = r.snapshot, e.snapshot.latestValues = r.animationValues || r.latestValues), e.root && e.root.isUpdating && (e.isLayoutDirty = !0);
            const {
                crossfade: n
            } = e.options;
            !1 === n && r.hide()
        }
    }
    exitAnimationComplete() {
        this.members.forEach((e => {
            const {
                options: t,
                resumingFrom: r
            } = e;
            t.onExitComplete && t.onExitComplete(), r && r.options.onExitComplete && r.options.onExitComplete()
        }))
    }
    scheduleRender() {
        this.members.forEach((e => {
            e.instance && e.scheduleRender(!1)
        }))
    }
    removeLeadSnapshot() {
        this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
    }
}
const Po = {
        type: "projectionFrame",
        totalNodes: 0,
        resolvedTargetDeltas: 0,
        recalculatedProjection: 0
    },
    Co = "undefined" != typeof window && void 0 !== window.MotionDebug,
    Oo = ["", "X", "Y", "Z"],
    Ao = {
        visibility: "hidden"
    };
let No = 0;

function Ro(e, t, r, n) {
    const {
        latestValues: s
    } = t;
    s[e] && (r[e] = s[e], t.setStaticValue(e, 0), n && (n[e] = 0))
}

function Io(e) {
    if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
    const {
        visualElement: t
    } = e.options;
    if (!t) return;
    const r = Tr(t);
    if (window.MotionHasOptimisedAnimation(r, "transform")) {
        const {
            layout: t,
            layoutId: n
        } = e.options;
        window.MotionCancelOptimisedAnimation(r, "transform", Q, !(t || n))
    }
    const {
        parent: n
    } = e;
    n && !n.hasCheckedOptimisedAppear && Io(n)
}

function Lo({
    attachResizeListener: e,
    defaultParent: t,
    measureScroll: r,
    checkIsScrollRoot: n,
    resetTransform: s
}) {
    return class {
        constructor(e = {}, r = (null == t ? void 0 : t())) {
            this.id = No++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                x: 1,
                y: 1
            }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
            }, this.updateProjection = () => {
                this.projectionUpdateScheduled = !1, Co && (Po.totalNodes = Po.resolvedTargetDeltas = Po.recalculatedProjection = 0), this.nodes.forEach(Do), this.nodes.forEach(Ho), this.nodes.forEach(qo), this.nodes.forEach($o), Co && window.MotionDebug.record(Po)
            }, this.resolvedRelativeTargetAt = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = e, this.root = r ? r.root || r : this, this.path = r ? [...r.path, r] : [], this.parent = r, this.depth = r ? r.depth + 1 : 0;
            for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
            this.root === this && (this.nodes = new ro)
        }
        addEventListener(e, t) {
            return this.eventHandlers.has(e) || this.eventHandlers.set(e, new vr), this.eventHandlers.get(e).add(t)
        }
        notifyListeners(e, ...t) {
            const r = this.eventHandlers.get(e);
            r && r.notify(...t)
        }
        hasListeners(e) {
            return this.eventHandlers.has(e)
        }
        mount(t, r = this.root.hasTreeAnimated) {
            if (this.instance) return;
            var n;
            this.isSVG = (n = t) instanceof SVGElement && "svg" !== n.tagName, this.instance = t;
            const {
                layoutId: s,
                layout: i,
                visualElement: o
            } = this.options;
            if (o && !o.current && o.mount(t), this.root.nodes.add(this), this.parent && this.parent.children.add(this), r && (i || s) && (this.isLayoutDirty = !0), e) {
                let r;
                const n = () => this.root.updateBlockedByResize = !1;
                e(t, (() => {
                    this.root.updateBlockedByResize = !0, r && r(), r = function(e, t) {
                        const r = mr.now(),
                            n = ({
                                timestamp: s
                            }) => {
                                const i = s - r;
                                i >= t && (ee(n), e(i - t))
                            };
                        return Q.read(n, !0), () => ee(n)
                    }(n, 250), Gi.hasAnimatedSinceResize && (Gi.hasAnimatedSinceResize = !1, this.nodes.forEach(Wo))
                }))
            }
            s && this.root.registerSharedNode(s, this), !1 !== this.options.animate && o && (s || i) && this.addEventListener("didUpdate", (({
                delta: e,
                hasLayoutChanged: t,
                hasRelativeTargetChanged: r,
                layout: n
            }) => {
                if (this.isTreeAnimationBlocked()) return this.target = void 0, void(this.relativeTarget = void 0);
                const s = this.options.transition || o.getDefaultTransition() || Zo,
                    {
                        onLayoutAnimationStart: i,
                        onLayoutAnimationComplete: a
                    } = o.getProps(),
                    l = !this.targetLayout || !So(this.targetLayout, n) || r,
                    c = !t && r;
                if (this.options.layoutRoot || this.resumeFrom && this.resumeFrom.instance || c || t && (l || !this.currentAnimation)) {
                    this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(e, c);
                    const t = { ...Ft(s, "layout"),
                        onPlay: i,
                        onComplete: a
                    };
                    (o.shouldReduceMotion || this.options.layoutRoot) && (t.delay = 0, t.type = !1), this.startAnimation(t)
                } else t || Wo(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                this.targetLayout = n
            }))
        }
        unmount() {
            this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
            const e = this.getStack();
            e && e.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, ee(this.updateProjection)
        }
        blockUpdate() {
            this.updateManuallyBlocked = !0
        }
        unblockUpdate() {
            this.updateManuallyBlocked = !1
        }
        isUpdateBlocked() {
            return this.updateManuallyBlocked || this.updateBlockedByResize
        }
        isTreeAnimationBlocked() {
            return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
        }
        startUpdate() {
            this.isUpdateBlocked() || (this.isUpdating = !0, this.nodes && this.nodes.forEach(Ko), this.animationId++)
        }
        getTransformTemplate() {
            const {
                visualElement: e
            } = this.options;
            return e && e.getProps().transformTemplate
        }
        willUpdate(e = !0) {
            if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) return void(this.options.onExitComplete && this.options.onExitComplete());
            if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && Io(this), !this.root.isUpdating && this.root.startUpdate(), this.isLayoutDirty) return;
            this.isLayoutDirty = !0;
            for (let s = 0; s < this.path.length; s++) {
                const e = this.path[s];
                e.shouldResetTransform = !0, e.updateScroll("snapshot"), e.options.layoutRoot && e.willUpdate(!1)
            }
            const {
                layoutId: t,
                layout: r
            } = this.options;
            if (void 0 === t && !r) return;
            const n = this.getTransformTemplate();
            this.prevTransformTemplateValue = n ? n(this.latestValues, "") : void 0, this.updateSnapshot(), e && this.notifyListeners("willUpdate")
        }
        update() {
            this.updateScheduled = !1;
            if (this.isUpdateBlocked()) return this.unblockUpdate(), this.clearAllSnapshots(), void this.nodes.forEach(Vo);
            this.isUpdating || this.nodes.forEach(Bo), this.isUpdating = !1, this.nodes.forEach(zo), this.nodes.forEach(Mo), this.nodes.forEach(Uo), this.clearAllSnapshots();
            const e = mr.now();
            te.delta = Ge(0, 1e3 / 60, e - te.timestamp), te.timestamp = e, te.isProcessing = !0, re.update.process(te), re.preRender.process(te), re.render.process(te), te.isProcessing = !1
        }
        didUpdate() {
            this.updateScheduled || (this.updateScheduled = !0, Te.read(this.scheduleUpdate))
        }
        clearAllSnapshots() {
            this.nodes.forEach(Fo), this.sharedNodes.forEach(Go)
        }
        scheduleUpdateProjection() {
            this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, Q.preRender(this.updateProjection, !1, !0))
        }
        scheduleCheckAfterUnmount() {
            Q.postRender((() => {
                this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
            }))
        }
        updateSnapshot() {
            !this.snapshot && this.instance && (this.snapshot = this.measure())
        }
        updateLayout() {
            if (!this.instance) return;
            if (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead() || this.isLayoutDirty)) return;
            if (this.resumeFrom && !this.resumeFrom.instance)
                for (let r = 0; r < this.path.length; r++) {
                    this.path[r].updateScroll()
                }
            const e = this.layout;
            this.layout = this.measure(!1), this.layoutCorrected = {
                x: {
                    min: 0,
                    max: 0
                },
                y: {
                    min: 0,
                    max: 0
                }
            }, this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
            const {
                visualElement: t
            } = this.options;
            t && t.notify("LayoutMeasure", this.layout.layoutBox, e ? e.layoutBox : void 0)
        }
        updateScroll(e = "measure") {
            let t = Boolean(this.options.layoutScroll && this.instance);
            if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === e && (t = !1), t) {
                const t = n(this.instance);
                this.scroll = {
                    animationId: this.root.animationId,
                    phase: e,
                    isRoot: t,
                    offset: r(this.instance),
                    wasRoot: this.scroll ? this.scroll.isRoot : t
                }
            }
        }
        resetTransform() {
            if (!s) return;
            const e = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                t = this.projectionDelta && !wo(this.projectionDelta),
                r = this.getTransformTemplate(),
                n = r ? r(this.latestValues, "") : void 0,
                i = n !== this.prevTransformTemplateValue;
            e && (t || Oi(this.latestValues) || i) && (s(this.instance, n), this.shouldResetTransform = !1, this.scheduleRender())
        }
        measure(e = !0) {
            const t = this.measurePageBox();
            let r = this.removeElementScroll(t);
            var n;
            return e && (r = this.removeTransform(r)), ta((n = r).x), ta(n.y), {
                animationId: this.root.animationId,
                measuredBox: t,
                layoutBox: r,
                latestValues: {},
                source: this.id
            }
        }
        measurePageBox() {
            var e;
            const {
                visualElement: t
            } = this.options;
            if (!t) return {
                x: {
                    min: 0,
                    max: 0
                },
                y: {
                    min: 0,
                    max: 0
                }
            };
            const r = t.measureViewportBox();
            if (!((null === (e = this.scroll) || void 0 === e ? void 0 : e.wasRoot) || this.path.some(na))) {
                const {
                    scroll: e
                } = this.root;
                e && ($i(r.x, e.offset.x), $i(r.y, e.offset.y))
            }
            return r
        }
        removeElementScroll(e) {
            var t;
            const r = {
                x: {
                    min: 0,
                    max: 0
                },
                y: {
                    min: 0,
                    max: 0
                }
            };
            if (po(r, e), null === (t = this.scroll) || void 0 === t ? void 0 : t.wasRoot) return r;
            for (let n = 0; n < this.path.length; n++) {
                const t = this.path[n],
                    {
                        scroll: s,
                        options: i
                    } = t;
                t !== this.root && s && i.layoutScroll && (s.wasRoot && po(r, e), $i(r.x, s.offset.x), $i(r.y, s.offset.y))
            }
            return r
        }
        applyTransform(e, t = !1) {
            const r = {
                x: {
                    min: 0,
                    max: 0
                },
                y: {
                    min: 0,
                    max: 0
                }
            };
            po(r, e);
            for (let n = 0; n < this.path.length; n++) {
                const e = this.path[n];
                !t && e.options.layoutScroll && e.scroll && e !== e.root && Vi(r, {
                    x: -e.scroll.offset.x,
                    y: -e.scroll.offset.y
                }), Oi(e.latestValues) && Vi(r, e.latestValues)
            }
            return Oi(this.latestValues) && Vi(r, this.latestValues), r
        }
        removeTransform(e) {
            const t = {
                x: {
                    min: 0,
                    max: 0
                },
                y: {
                    min: 0,
                    max: 0
                }
            };
            po(t, e);
            for (let r = 0; r < this.path.length; r++) {
                const e = this.path[r];
                if (!e.instance) continue;
                if (!Oi(e.latestValues)) continue;
                Ci(e.latestValues) && e.updateSnapshot();
                const n = {
                    x: {
                        min: 0,
                        max: 0
                    },
                    y: {
                        min: 0,
                        max: 0
                    }
                };
                po(n, e.measurePageBox()), bo(t, e.latestValues, e.snapshot ? e.snapshot.layoutBox : void 0, n)
            }
            return Oi(this.latestValues) && bo(t, this.latestValues), t
        }
        setTargetDelta(e) {
            this.targetDelta = e, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
        }
        setOptions(e) {
            this.options = { ...this.options,
                ...e,
                crossfade: void 0 === e.crossfade || e.crossfade
            }
        }
        clearMeasurements() {
            this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
        }
        forceRelativeParentToResolveTarget() {
            this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== te.timestamp && this.relativeParent.resolveTargetDelta(!0)
        }
        resolveTargetDelta(e = !1) {
            var t;
            const r = this.getLead();
            this.isProjectionDirty || (this.isProjectionDirty = r.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = r.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = r.isSharedProjectionDirty);
            const n = Boolean(this.resumingFrom) || this !== r;
            if (!(e || n && this.isSharedProjectionDirty || this.isProjectionDirty || (null === (t = this.parent) || void 0 === t ? void 0 : t.isProjectionDirty) || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
            const {
                layout: s,
                layoutId: i
            } = this.options;
            if (this.layout && (s || i)) {
                if (this.resolvedRelativeTargetAt = te.timestamp, !this.targetDelta && !this.relativeTarget) {
                    const e = this.getClosestProjectingParent();
                    e && e.layout && 1 !== this.animationProgress ? (this.relativeParent = e, this.forceRelativeParentToResolveTarget(), this.relativeTarget = {
                        x: {
                            min: 0,
                            max: 0
                        },
                        y: {
                            min: 0,
                            max: 0
                        }
                    }, this.relativeTargetOrigin = {
                        x: {
                            min: 0,
                            max: 0
                        },
                        y: {
                            min: 0,
                            max: 0
                        }
                    }, bi(this.relativeTargetOrigin, this.layout.layoutBox, e.layout.layoutBox), po(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                }
                if (this.relativeTarget || this.targetDelta) {
                    var o, a, l;
                    if (this.target || (this.target = {
                            x: {
                                min: 0,
                                max: 0
                            },
                            y: {
                                min: 0,
                                max: 0
                            }
                        }, this.targetWithTransforms = {
                            x: {
                                min: 0,
                                max: 0
                            },
                            y: {
                                min: 0,
                                max: 0
                            }
                        }), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), o = this.target, a = this.relativeTarget, l = this.relativeParent.target, yi(o.x, a.x, l.x), yi(o.y, a.y, l.y)) : this.targetDelta ? (Boolean(this.resumingFrom) ? this.target = this.applyTransform(this.layout.layoutBox) : po(this.target, this.layout.layoutBox), Mi(this.target, this.targetDelta)) : po(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget) {
                        this.attemptToResolveRelativeTarget = !1;
                        const e = this.getClosestProjectingParent();
                        e && Boolean(e.resumingFrom) === Boolean(this.resumingFrom) && !e.options.layoutScroll && e.target && 1 !== this.animationProgress ? (this.relativeParent = e, this.forceRelativeParentToResolveTarget(), this.relativeTarget = {
                            x: {
                                min: 0,
                                max: 0
                            },
                            y: {
                                min: 0,
                                max: 0
                            }
                        }, this.relativeTargetOrigin = {
                            x: {
                                min: 0,
                                max: 0
                            },
                            y: {
                                min: 0,
                                max: 0
                            }
                        }, bi(this.relativeTargetOrigin, this.target, e.target), po(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                    }
                    Co && Po.resolvedTargetDeltas++
                }
            }
        }
        getClosestProjectingParent() {
            if (this.parent && !Ci(this.parent.latestValues) && !Ai(this.parent.latestValues)) return this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
        }
        isProjecting() {
            return Boolean((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
        }
        calcProjection() {
            var e;
            const t = this.getLead(),
                r = Boolean(this.resumingFrom) || this !== t;
            let n = !0;
            if ((this.isProjectionDirty || (null === (e = this.parent) || void 0 === e ? void 0 : e.isProjectionDirty)) && (n = !1), r && (this.isSharedProjectionDirty || this.isTransformDirty) && (n = !1), this.resolvedRelativeTargetAt === te.timestamp && (n = !1), n) return;
            const {
                layout: s,
                layoutId: i
            } = this.options;
            if (this.isTreeAnimating = Boolean(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !s && !i) return;
            po(this.layoutCorrected, this.layout.layoutBox);
            const o = this.treeScale.x,
                a = this.treeScale.y;
            ! function(e, t, r, n = !1) {
                const s = r.length;
                if (!s) return;
                let i, o;
                t.x = t.y = 1;
                for (let a = 0; a < s; a++) {
                    i = r[a], o = i.projectionDelta;
                    const {
                        visualElement: s
                    } = i.options;
                    s && s.props.style && "contents" === s.props.style.display || (n && i.options.layoutScroll && i.scroll && i !== i.root && Vi(e, {
                        x: -i.scroll.offset.x,
                        y: -i.scroll.offset.y
                    }), o && (t.x *= o.x.scale, t.y *= o.y.scale, Mi(e, o)), n && Oi(i.latestValues) && Vi(e, i.latestValues))
                }
                t.x < Di && t.x > Ui && (t.x = 1), t.y < Di && t.y > Ui && (t.y = 1)
            }(this.layoutCorrected, this.treeScale, this.path, r), !t.layout || t.target || 1 === this.treeScale.x && 1 === this.treeScale.y || (t.target = t.layout.layoutBox, t.targetWithTransforms = {
                x: {
                    min: 0,
                    max: 0
                },
                y: {
                    min: 0,
                    max: 0
                }
            });
            const {
                target: l
            } = t;
            l ? (this.projectionDelta && this.prevProjectionDelta ? (fo(this.prevProjectionDelta.x, this.projectionDelta.x), fo(this.prevProjectionDelta.y, this.projectionDelta.y)) : this.createProjectionDeltas(), gi(this.projectionDelta, this.layoutCorrected, l, this.latestValues), this.treeScale.x === o && this.treeScale.y === a && _o(this.projectionDelta.x, this.prevProjectionDelta.x) && _o(this.projectionDelta.y, this.prevProjectionDelta.y) || (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", l)), Co && Po.recalculatedProjection++) : this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender())
        }
        hide() {
            this.isVisible = !1
        }
        show() {
            this.isVisible = !0
        }
        scheduleRender(e = !0) {
            var t;
            if (null === (t = this.options.visualElement) || void 0 === t || t.scheduleRender(), e) {
                const e = this.getStack();
                e && e.scheduleRender()
            }
            this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
        }
        createProjectionDeltas() {
            this.prevProjectionDelta = {
                x: {
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                },
                y: {
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                }
            }, this.projectionDelta = {
                x: {
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                },
                y: {
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                }
            }, this.projectionDeltaWithTransform = {
                x: {
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                },
                y: {
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                }
            }
        }
        setAnimationOrigin(e, t = !1) {
            const r = this.snapshot,
                n = r ? r.latestValues : {},
                s = { ...this.latestValues
                },
                i = {
                    x: {
                        translate: 0,
                        scale: 1,
                        origin: 0,
                        originPoint: 0
                    },
                    y: {
                        translate: 0,
                        scale: 1,
                        origin: 0,
                        originPoint: 0
                    }
                };
            this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !t;
            const o = {
                    x: {
                        min: 0,
                        max: 0
                    },
                    y: {
                        min: 0,
                        max: 0
                    }
                },
                a = (r ? r.source : void 0) !== (this.layout ? this.layout.source : void 0),
                l = this.getStack(),
                c = !l || l.members.length <= 1,
                u = Boolean(a && !c && !0 === this.options.crossfade && !this.path.some(Xo));
            let d;
            this.animationProgress = 0, this.mixTargetDelta = t => {
                const r = t / 1e3;
                var l, h, p, f, m, g;
                Yo(i.x, e.x, r), Yo(i.y, e.y, r), this.setTargetDelta(i), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && (bi(o, this.layout.layoutBox, this.relativeParent.layout.layoutBox), p = this.relativeTarget, f = this.relativeTargetOrigin, m = o, g = r, Jo(p.x, f.x, m.x, g), Jo(p.y, f.y, m.y, g), d && (l = this.relativeTarget, h = d, ko(l.x, h.x) && ko(l.y, h.y)) && (this.isProjectionDirty = !1), d || (d = {
                    x: {
                        min: 0,
                        max: 0
                    },
                    y: {
                        min: 0,
                        max: 0
                    }
                }), po(d, this.relativeTarget)), a && (this.animationValues = s, function(e, t, r, n, s, i) {
                    s ? (e.opacity = Ln(0, void 0 !== r.opacity ? r.opacity : 1, lo(n)), e.opacityExit = Ln(void 0 !== t.opacity ? t.opacity : 1, 0, co(n))) : i && (e.opacity = Ln(void 0 !== t.opacity ? t.opacity : 1, void 0 !== r.opacity ? r.opacity : 1, n));
                    for (let o = 0; o < so; o++) {
                        const s = `border${no[o]}Radius`;
                        let i = ao(t, s),
                            a = ao(r, s);
                        void 0 === i && void 0 === a || (i || (i = 0), a || (a = 0), 0 === i || 0 === a || oo(i) === oo(a) ? (e[s] = Math.max(Ln(io(i), io(a), n), 0), (et.test(a) || et.test(i)) && (e[s] += "%")) : e[s] = a)
                    }(t.rotate || r.rotate) && (e.rotate = Ln(t.rotate || 0, r.rotate || 0, n))
                }(s, n, this.latestValues, r, u, c)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = r
            }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
        }
        startAnimation(e) {
            this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && (ee(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = Q.update((() => {
                Gi.hasAnimatedSinceResize = !0, this.currentAnimation = function(e, t, r) {
                    const n = Me(e) ? e : wr(e);
                    return n.start(Fs("", n, t, r)), n.animation
                }(0, 1e3, { ...e,
                    onUpdate: t => {
                        this.mixTargetDelta(t), e.onUpdate && e.onUpdate(t)
                    },
                    onComplete: () => {
                        e.onComplete && e.onComplete(), this.completeAnimation()
                    }
                }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
            }))
        }
        completeAnimation() {
            this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
            const e = this.getStack();
            e && e.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
        }
        finishAnimation() {
            this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(1e3), this.currentAnimation.stop()), this.completeAnimation()
        }
        applyTransformsToTarget() {
            const e = this.getLead();
            let {
                targetWithTransforms: t,
                target: r,
                layout: n,
                latestValues: s
            } = e;
            if (t && r && n) {
                if (this !== e && this.layout && n && ra(this.options.animationType, this.layout.layoutBox, n.layoutBox)) {
                    r = this.target || {
                        x: {
                            min: 0,
                            max: 0
                        },
                        y: {
                            min: 0,
                            max: 0
                        }
                    };
                    const t = fi(this.layout.layoutBox.x);
                    r.x.min = e.target.x.min, r.x.max = r.x.min + t;
                    const n = fi(this.layout.layoutBox.y);
                    r.y.min = e.target.y.min, r.y.max = r.y.min + n
                }
                po(t, r), Vi(t, s), gi(this.projectionDeltaWithTransform, this.layoutCorrected, t, s)
            }
        }
        registerSharedNode(e, t) {
            this.sharedNodes.has(e) || this.sharedNodes.set(e, new Eo);
            this.sharedNodes.get(e).add(t);
            const r = t.options.initialPromotionConfig;
            t.promote({
                transition: r ? r.transition : void 0,
                preserveFollowOpacity: r && r.shouldPreserveFollowOpacity ? r.shouldPreserveFollowOpacity(t) : void 0
            })
        }
        isLead() {
            const e = this.getStack();
            return !e || e.lead === this
        }
        getLead() {
            var e;
            const {
                layoutId: t
            } = this.options;
            return t && (null === (e = this.getStack()) || void 0 === e ? void 0 : e.lead) || this
        }
        getPrevLead() {
            var e;
            const {
                layoutId: t
            } = this.options;
            return t ? null === (e = this.getStack()) || void 0 === e ? void 0 : e.prevLead : void 0
        }
        getStack() {
            const {
                layoutId: e
            } = this.options;
            if (e) return this.root.sharedNodes.get(e)
        }
        promote({
            needsReset: e,
            transition: t,
            preserveFollowOpacity: r
        } = {}) {
            const n = this.getStack();
            n && n.promote(this, r), e && (this.projectionDelta = void 0, this.needsReset = !0), t && this.setOptions({
                transition: t
            })
        }
        relegate() {
            const e = this.getStack();
            return !!e && e.relegate(this)
        }
        resetSkewAndRotation() {
            const {
                visualElement: e
            } = this.options;
            if (!e) return;
            let t = !1;
            const {
                latestValues: r
            } = e;
            if ((r.z || r.rotate || r.rotateX || r.rotateY || r.rotateZ || r.skewX || r.skewY) && (t = !0), !t) return;
            const n = {};
            r.z && Ro("z", e, n, this.animationValues);
            for (let s = 0; s < Oo.length; s++) Ro(`rotate${Oo[s]}`, e, n, this.animationValues), Ro(`skew${Oo[s]}`, e, n, this.animationValues);
            e.render();
            for (const s in n) e.setStaticValue(s, n[s]), this.animationValues && (this.animationValues[s] = n[s]);
            e.scheduleRender()
        }
        getProjectionStyles(e) {
            var t, r;
            if (!this.instance || this.isSVG) return;
            if (!this.isVisible) return Ao;
            const n = {
                    visibility: ""
                },
                s = this.getTransformTemplate();
            if (this.needsReset) return this.needsReset = !1, n.opacity = "", n.pointerEvents = Ue(null == e ? void 0 : e.pointerEvents) || "", n.transform = s ? s(this.latestValues, "") : "none", n;
            const i = this.getLead();
            if (!this.projectionDelta || !this.layout || !i.target) {
                const t = {};
                return this.options.layoutId && (t.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, t.pointerEvents = Ue(null == e ? void 0 : e.pointerEvents) || ""), this.hasProjected && !Oi(this.latestValues) && (t.transform = s ? s({}, "") : "none", this.hasProjected = !1), t
            }
            const o = i.animationValues || i.latestValues;
            this.applyTransformsToTarget(), n.transform = function(e, t, r) {
                let n = "";
                const s = e.x.translate / t.x,
                    i = e.y.translate / t.y,
                    o = (null == r ? void 0 : r.z) || 0;
                if ((s || i || o) && (n = `translate3d(${s}px, ${i}px, ${o}px) `), 1 === t.x && 1 === t.y || (n += `scale(${1/t.x}, ${1/t.y}) `), r) {
                    const {
                        transformPerspective: e,
                        rotate: t,
                        rotateX: s,
                        rotateY: i,
                        skewX: o,
                        skewY: a
                    } = r;
                    e && (n = `perspective(${e}px) ${n}`), t && (n += `rotate(${t}deg) `), s && (n += `rotateX(${s}deg) `), i && (n += `rotateY(${i}deg) `), o && (n += `skewX(${o}deg) `), a && (n += `skewY(${a}deg) `)
                }
                const a = e.x.scale * t.x,
                    l = e.y.scale * t.y;
                return 1 === a && 1 === l || (n += `scale(${a}, ${l})`), n || "none"
            }(this.projectionDeltaWithTransform, this.treeScale, o), s && (n.transform = s(o, n.transform));
            const {
                x: a,
                y: l
            } = this.projectionDelta;
            n.transformOrigin = `${100*a.origin}% ${100*l.origin}% 0`, i.animationValues ? n.opacity = i === this ? null !== (r = null !== (t = o.opacity) && void 0 !== t ? t : this.latestValues.opacity) && void 0 !== r ? r : 1 : this.preserveOpacity ? this.latestValues.opacity : o.opacityExit : n.opacity = i === this ? void 0 !== o.opacity ? o.opacity : "" : void 0 !== o.opacityExit ? o.opacityExit : 0;
            for (const c in kt) {
                if (void 0 === o[c]) continue;
                const {
                    correct: e,
                    applyTo: t
                } = kt[c], r = "none" === n.transform ? o[c] : e(o[c], i);
                if (t) {
                    const e = t.length;
                    for (let s = 0; s < e; s++) n[t[s]] = r
                } else n[c] = r
            }
            return this.options.layoutId && (n.pointerEvents = i === this ? Ue(null == e ? void 0 : e.pointerEvents) || "" : "none"), n
        }
        clearSnapshot() {
            this.resumeFrom = this.snapshot = void 0
        }
        resetTree() {
            this.root.nodes.forEach((e => {
                var t;
                return null === (t = e.currentAnimation) || void 0 === t ? void 0 : t.stop()
            })), this.root.nodes.forEach(Vo), this.root.sharedNodes.clear()
        }
    }
}

function Mo(e) {
    e.updateLayout()
}

function Uo(e) {
    var t;
    const r = (null === (t = e.resumeFrom) || void 0 === t ? void 0 : t.snapshot) || e.snapshot;
    if (e.isLead() && e.layout && r && e.hasListeners("didUpdate")) {
        const {
            layoutBox: t,
            measuredBox: n
        } = e.layout, {
            animationType: s
        } = e.options, i = r.source !== e.layout.source;
        "size" === s ? _i((e => {
            const n = i ? r.measuredBox[e] : r.layoutBox[e],
                s = fi(n);
            n.min = t[e].min, n.max = n.min + s
        })) : ra(s, r.layoutBox, t) && _i((n => {
            const s = i ? r.measuredBox[n] : r.layoutBox[n],
                o = fi(t[n]);
            s.max = s.min + o, e.relativeTarget && !e.currentAnimation && (e.isProjectionDirty = !0, e.relativeTarget[n].max = e.relativeTarget[n].min + o)
        }));
        const o = {
            x: {
                translate: 0,
                scale: 1,
                origin: 0,
                originPoint: 0
            },
            y: {
                translate: 0,
                scale: 1,
                origin: 0,
                originPoint: 0
            }
        };
        gi(o, t, r.layoutBox);
        const a = {
            x: {
                translate: 0,
                scale: 1,
                origin: 0,
                originPoint: 0
            },
            y: {
                translate: 0,
                scale: 1,
                origin: 0,
                originPoint: 0
            }
        };
        i ? gi(a, e.applyTransform(n, !0), r.measuredBox) : gi(a, t, r.layoutBox);
        const l = !wo(o);
        let c = !1;
        if (!e.resumeFrom) {
            const n = e.getClosestProjectingParent();
            if (n && !n.resumeFrom) {
                const {
                    snapshot: s,
                    layout: i
                } = n;
                if (s && i) {
                    const o = {
                        x: {
                            min: 0,
                            max: 0
                        },
                        y: {
                            min: 0,
                            max: 0
                        }
                    };
                    bi(o, r.layoutBox, s.layoutBox);
                    const a = {
                        x: {
                            min: 0,
                            max: 0
                        },
                        y: {
                            min: 0,
                            max: 0
                        }
                    };
                    bi(a, t, i.layoutBox), So(o, a) || (c = !0), n.options.layoutRoot && (e.relativeTarget = a, e.relativeTargetOrigin = o, e.relativeParent = n)
                }
            }
        }
        e.notifyListeners("didUpdate", {
            layout: t,
            snapshot: r,
            delta: a,
            layoutDelta: o,
            hasLayoutChanged: l,
            hasRelativeTargetChanged: c
        })
    } else if (e.isLead()) {
        const {
            onExitComplete: t
        } = e.options;
        t && t()
    }
    e.options.transition = void 0
}

function Do(e) {
    Co && Po.totalNodes++, e.parent && (e.isProjecting() || (e.isProjectionDirty = e.parent.isProjectionDirty), e.isSharedProjectionDirty || (e.isSharedProjectionDirty = Boolean(e.isProjectionDirty || e.parent.isProjectionDirty || e.parent.isSharedProjectionDirty)), e.isTransformDirty || (e.isTransformDirty = e.parent.isTransformDirty))
}

function $o(e) {
    e.isProjectionDirty = e.isSharedProjectionDirty = e.isTransformDirty = !1
}

function Fo(e) {
    e.clearSnapshot()
}

function Vo(e) {
    e.clearMeasurements()
}

function Bo(e) {
    e.isLayoutDirty = !1
}

function zo(e) {
    const {
        visualElement: t
    } = e.options;
    t && t.getProps().onBeforeLayoutMeasure && t.notify("BeforeLayoutMeasure"), e.resetTransform()
}

function Wo(e) {
    e.finishAnimation(), e.targetDelta = e.relativeTarget = e.target = void 0, e.isProjectionDirty = !0
}

function Ho(e) {
    e.resolveTargetDelta()
}

function qo(e) {
    e.calcProjection()
}

function Ko(e) {
    e.resetSkewAndRotation()
}

function Go(e) {
    e.removeLeadSnapshot()
}

function Yo(e, t, r) {
    e.translate = Ln(t.translate, 0, r), e.scale = Ln(t.scale, 1, r), e.origin = t.origin, e.originPoint = t.originPoint
}

function Jo(e, t, r, n) {
    e.min = Ln(t.min, r.min, n), e.max = Ln(t.max, r.max, n)
}

function Xo(e) {
    return e.animationValues && void 0 !== e.animationValues.opacityExit
}
const Zo = {
        duration: .45,
        ease: [.4, 0, .1, 1]
    },
    Qo = e => "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().includes(e),
    ea = Qo("applewebkit/") && !Qo("chrome/") ? Math.round : W;

function ta(e) {
    e.min = ea(e.min), e.max = ea(e.max)
}

function ra(e, t, r) {
    return "position" === e || "preserve-aspect" === e && (n = To(t), s = To(r), i = .2, !(Math.abs(n - s) <= i));
    var n, s, i
}

function na(e) {
    var t;
    return e !== e.root && (null === (t = e.scroll) || void 0 === t ? void 0 : t.wasRoot)
}
const sa = Lo({
        attachResizeListener: (e, t) => ni(e, "resize", t),
        measureScroll: () => ({
            x: document.documentElement.scrollLeft || document.body.scrollLeft,
            y: document.documentElement.scrollTop || document.body.scrollTop
        }),
        checkIsScrollRoot: () => !0
    }),
    ia = {
        current: void 0
    },
    oa = Lo({
        measureScroll: e => ({
            x: e.scrollLeft,
            y: e.scrollTop
        }),
        defaultParent: () => {
            if (!ia.current) {
                const e = new sa({});
                e.mount(window), e.setOptions({
                    layoutScroll: !0
                }), ia.current = e
            }
            return ia.current
        },
        resetTransform: (e, t) => {
            e.style.transform = void 0 !== t ? t : "none"
        },
        checkIsScrollRoot: e => Boolean("fixed" === window.getComputedStyle(e).position)
    }),
    aa = {
        pan: {
            Feature: class extends ei {
                constructor() {
                    super(...arguments), this.removePointerDownListener = W
                }
                onPointerDown(e) {
                    this.session = new ai(e, this.createPanHandlers(), {
                        transformPagePoint: this.node.getTransformPagePoint(),
                        contextWindow: zi(this.node)
                    })
                }
                createPanHandlers() {
                    const {
                        onPanSessionStart: e,
                        onPanStart: t,
                        onPan: r,
                        onPanEnd: n
                    } = this.node.getProps();
                    return {
                        onSessionStart: Ki(e),
                        onStart: Ki(t),
                        onMove: r,
                        onEnd: (e, t) => {
                            delete this.session, n && Q.postRender((() => n(e, t)))
                        }
                    }
                }
                mount() {
                    this.removePointerDownListener = ii(this.node.current, "pointerdown", (e => this.onPointerDown(e)))
                }
                update() {
                    this.session && this.session.updateHandlers(this.createPanHandlers())
                }
                unmount() {
                    this.removePointerDownListener(), this.session && this.session.end()
                }
            }
        },
        drag: {
            Feature: class extends ei {
                constructor(e) {
                    super(e), this.removeGroupControls = W, this.removeListeners = W, this.controls = new Hi(e)
                }
                mount() {
                    const {
                        dragControls: e
                    } = this.node.getProps();
                    e && (this.removeGroupControls = e.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || W
                }
                unmount() {
                    this.removeGroupControls(), this.removeListeners()
                }
            },
            ProjectionNode: oa,
            MeasureLayout: Qi
        }
    };

function la(e, t, r) {
    const {
        props: n
    } = e;
    e.animationState && n.whileHover && e.animationState.setActive("whileHover", "Start" === r);
    const s = n["onHover" + r];
    s && Q.postRender((() => s(t, si(t))))
}

function ca(e, t, r) {
    const {
        props: n
    } = e;
    e.animationState && n.whileTap && e.animationState.setActive("whileTap", "Start" === r);
    const s = n["onTap" + ("End" === r ? "" : r)];
    s && Q.postRender((() => s(t, si(t))))
}
const ua = new WeakMap,
    da = new WeakMap,
    ha = e => {
        const t = ua.get(e.target);
        t && t(e)
    },
    pa = e => {
        e.forEach(ha)
    };

function fa(e, t, r) {
    const n = function({
        root: e,
        ...t
    }) {
        const r = e || document;
        da.has(r) || da.set(r, {});
        const n = da.get(r),
            s = JSON.stringify(t);
        return n[s] || (n[s] = new IntersectionObserver(pa, {
            root: e,
            ...t
        })), n[s]
    }(t);
    return ua.set(e, r), n.observe(e), () => {
        ua.delete(e), n.unobserve(e)
    }
}
const ma = {
    some: 0,
    all: 1
};
const ga = {
        inView: {
            Feature: class extends ei {
                constructor() {
                    super(...arguments), this.hasEnteredView = !1, this.isInView = !1
                }
                startObserver() {
                    this.unmount();
                    const {
                        viewport: e = {}
                    } = this.node.getProps(), {
                        root: t,
                        margin: r,
                        amount: n = "some",
                        once: s
                    } = e, i = {
                        root: t ? t.current : void 0,
                        rootMargin: r,
                        threshold: "number" == typeof n ? n : ma[n]
                    };
                    return fa(this.node.current, i, (e => {
                        const {
                            isIntersecting: t
                        } = e;
                        if (this.isInView === t) return;
                        if (this.isInView = t, s && !t && this.hasEnteredView) return;
                        t && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", t);
                        const {
                            onViewportEnter: r,
                            onViewportLeave: n
                        } = this.node.getProps(), i = t ? r : n;
                        i && i(e)
                    }))
                }
                mount() {
                    this.startObserver()
                }
                update() {
                    if ("undefined" == typeof IntersectionObserver) return;
                    const {
                        props: e,
                        prevProps: t
                    } = this.node;
                    ["amount", "margin", "root"].some(function({
                        viewport: e = {}
                    }, {
                        viewport: t = {}
                    } = {}) {
                        return r => e[r] !== t[r]
                    }(e, t)) && this.startObserver()
                }
                unmount() {}
            }
        },
        tap: {
            Feature: class extends ei {
                mount() {
                    const {
                        current: e
                    } = this.node;
                    e && (this.unmount = dr(e, (e => (ca(this.node, e, "Start"), (e, {
                        success: t
                    }) => ca(this.node, e, t ? "End" : "Cancel"))), {
                        useGlobalTarget: this.node.props.globalTapTarget
                    }))
                }
                unmount() {}
            }
        },
        focus: {
            Feature: class extends ei {
                constructor() {
                    super(...arguments), this.isActive = !1
                }
                onFocus() {
                    let e = !1;
                    try {
                        e = this.node.current.matches(":focus-visible")
                    } catch (t) {
                        e = !0
                    }
                    e && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
                }
                onBlur() {
                    this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
                }
                mount() {
                    this.unmount = zn(ni(this.node.current, "focus", (() => this.onFocus())), ni(this.node.current, "blur", (() => this.onBlur())))
                }
                unmount() {}
            }
        },
        hover: {
            Feature: class extends ei {
                mount() {
                    const {
                        current: e
                    } = this.node;
                    e && (this.unmount = function(e, t, r = {}) {
                        const [n, s, i] = rr(e, r), o = nr((e => {
                            const {
                                target: r
                            } = e, n = t(e);
                            if ("function" != typeof n || !r) return;
                            const i = nr((e => {
                                n(e), r.removeEventListener("pointerleave", i)
                            }));
                            r.addEventListener("pointerleave", i, s)
                        }));
                        return n.forEach((e => {
                            e.addEventListener("pointerenter", o, s)
                        })), i
                    }(e, (e => (la(this.node, e, "Start"), e => la(this.node, e, "End")))))
                }
                unmount() {}
            }
        }
    },
    ya = {
        layout: {
            ProjectionNode: oa,
            MeasureLayout: Qi
        }
    },
    va = {
        current: null
    },
    ba = {
        current: !1
    };
const xa = [...Pn, Kr, rn],
    wa = new WeakMap;
const ka = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"];
class ja {
    scrapeMotionValuesFromProps(e, t, r) {
        return {}
    }
    constructor({
        parent: e,
        props: t,
        presenceContext: r,
        reducedMotionConfig: n,
        blockInitialAnimation: s,
        visualState: i
    }, o = {}) {
        this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = jn, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
            this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
        }, this.renderScheduledAt = 0, this.scheduleRender = () => {
            const e = mr.now();
            this.renderScheduledAt < e && (this.renderScheduledAt = e, Q.render(this.render, !1, !0))
        };
        const {
            latestValues: a,
            renderState: l,
            onUpdate: c
        } = i;
        this.onUpdate = c, this.latestValues = a, this.baseTarget = { ...a
        }, this.initialValues = t.initial ? { ...a
        } : {}, this.renderState = l, this.parent = e, this.props = t, this.presenceContext = r, this.depth = e ? e.depth + 1 : 0, this.reducedMotionConfig = n, this.options = o, this.blockInitialAnimation = Boolean(s), this.isControllingVariants = ge(t), this.isVariantNode = ye(t), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = Boolean(e && e.current);
        const {
            willChange: u,
            ...d
        } = this.scrapeMotionValuesFromProps(t, {}, this);
        for (const h in d) {
            const e = d[h];
            void 0 !== a[h] && Me(e) && e.set(a[h], !1)
        }
    }
    mount(e) {
        this.current = e, wa.set(e, this), this.projection && !this.projection.instance && this.projection.mount(e), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach(((e, t) => this.bindToMotionValue(t, e))), ba.current || function() {
            if (ba.current = !0, V)
                if (window.matchMedia) {
                    const e = window.matchMedia("(prefers-reduced-motion)"),
                        t = () => va.current = e.matches;
                    e.addListener(t), t()
                } else va.current = !1
        }(), this.shouldReduceMotion = "never" !== this.reducedMotionConfig && ("always" === this.reducedMotionConfig || va.current), this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext)
    }
    unmount() {
        wa.delete(this.current), this.projection && this.projection.unmount(), ee(this.notifyUpdate), ee(this.render), this.valueSubscriptions.forEach((e => e())), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this);
        for (const e in this.events) this.events[e].clear();
        for (const e in this.features) {
            const t = this.features[e];
            t && (t.unmount(), t.isMounted = !1)
        }
        this.current = null
    }
    bindToMotionValue(e, t) {
        this.valueSubscriptions.has(e) && this.valueSubscriptions.get(e)();
        const r = Ve.has(e),
            n = t.on("change", (t => {
                this.latestValues[e] = t, this.props.onUpdate && Q.preRender(this.notifyUpdate), r && this.projection && (this.projection.isTransformDirty = !0)
            })),
            s = t.on("renderRequest", this.scheduleRender);
        let i;
        window.MotionCheckAppearSync && (i = window.MotionCheckAppearSync(this, e, t)), this.valueSubscriptions.set(e, (() => {
            n(), s(), i && i(), t.owner && t.stop()
        }))
    }
    sortNodePosition(e) {
        return this.current && this.sortInstanceNodePosition && this.type === e.type ? this.sortInstanceNodePosition(this.current, e.current) : 0
    }
    updateFeatures() {
        let e = "animation";
        for (e in ie) {
            const t = ie[e];
            if (!t) continue;
            const {
                isEnabled: r,
                Feature: n
            } = t;
            if (!this.features[e] && n && r(this.props) && (this.features[e] = new n(this)), this.features[e]) {
                const t = this.features[e];
                t.isMounted ? t.update() : (t.mount(), t.isMounted = !0)
            }
        }
    }
    triggerBuild() {
        this.build(this.renderState, this.latestValues, this.props)
    }
    measureViewportBox() {
        return this.current ? this.measureInstanceViewportBox(this.current, this.props) : {
            x: {
                min: 0,
                max: 0
            },
            y: {
                min: 0,
                max: 0
            }
        }
    }
    getStaticValue(e) {
        return this.latestValues[e]
    }
    setStaticValue(e, t) {
        this.latestValues[e] = t
    }
    update(e, t) {
        (e.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = e, this.prevPresenceContext = this.presenceContext, this.presenceContext = t;
        for (let r = 0; r < ka.length; r++) {
            const t = ka[r];
            this.propEventSubscriptions[t] && (this.propEventSubscriptions[t](), delete this.propEventSubscriptions[t]);
            const n = e["on" + t];
            n && (this.propEventSubscriptions[t] = this.on(t, n))
        }
        this.prevMotionValues = function(e, t, r) {
            for (const n in t) {
                const s = t[n],
                    i = r[n];
                if (Me(s)) e.addValue(n, s);
                else if (Me(i)) e.addValue(n, wr(s, {
                    owner: e
                }));
                else if (i !== s)
                    if (e.hasValue(n)) {
                        const t = e.getValue(n);
                        !0 === t.liveStyle ? t.jump(s) : t.hasAnimated || t.set(s)
                    } else {
                        const t = e.getStaticValue(n);
                        e.addValue(n, wr(void 0 !== t ? t : s, {
                            owner: e
                        }))
                    }
            }
            for (const n in r) void 0 === t[n] && e.removeValue(n);
            return t
        }(this, this.scrapeMotionValuesFromProps(e, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue(), this.onUpdate && this.onUpdate(this)
    }
    getProps() {
        return this.props
    }
    getVariant(e) {
        return this.props.variants ? this.props.variants[e] : void 0
    }
    getDefaultTransition() {
        return this.props.transition
    }
    getTransformPagePoint() {
        return this.props.transformPagePoint
    }
    getClosestVariantNode() {
        return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
    }
    addVariantChild(e) {
        const t = this.getClosestVariantNode();
        if (t) return t.variantChildren && t.variantChildren.add(e), () => t.variantChildren.delete(e)
    }
    addValue(e, t) {
        const r = this.values.get(e);
        t !== r && (r && this.removeValue(e), this.bindToMotionValue(e, t), this.values.set(e, t), this.latestValues[e] = t.get())
    }
    removeValue(e) {
        this.values.delete(e);
        const t = this.valueSubscriptions.get(e);
        t && (t(), this.valueSubscriptions.delete(e)), delete this.latestValues[e], this.removeValueFromRenderState(e, this.renderState)
    }
    hasValue(e) {
        return this.values.has(e)
    }
    getValue(e, t) {
        if (this.props.values && this.props.values[e]) return this.props.values[e];
        let r = this.values.get(e);
        return void 0 === r && void 0 !== t && (r = wr(null === t ? void 0 : t, {
            owner: this
        }), this.addValue(e, r)), r
    }
    readValue(e, t) {
        var r;
        let n = void 0 === this.latestValues[e] && this.current ? null !== (r = this.getBaseTargetFromProps(this.props, e)) && void 0 !== r ? r : this.readValueFromInstance(this.current, e, this.options) : this.latestValues[e];
        var s;
        return null != n && ("string" == typeof n && (Sn(n) || Ur(n)) ? n = parseFloat(n) : (s = n, !xa.find(En(s)) && rn.test(t) && (n = un(e, t))), this.setBaseTarget(e, Me(n) ? n.get() : n)), Me(n) ? n.get() : n
    }
    setBaseTarget(e, t) {
        this.baseTarget[e] = t
    }
    getBaseTarget(e) {
        var t;
        const {
            initial: r
        } = this.props;
        let n;
        if ("string" == typeof r || "object" == typeof r) {
            const s = Ie(this.props, r, null === (t = this.presenceContext) || void 0 === t ? void 0 : t.custom);
            s && (n = s[e])
        }
        if (r && void 0 !== n) return n;
        const s = this.getBaseTargetFromProps(this.props, e);
        return void 0 === s || Me(s) ? void 0 !== this.initialValues[e] && void 0 === n ? void 0 : this.baseTarget[e] : s
    }
    on(e, t) {
        return this.events[e] || (this.events[e] = new vr), this.events[e].add(t)
    }
    notify(e, ...t) {
        this.events[e] && this.events[e].notify(...t)
    }
}
class Sa extends ja {
    constructor() {
        super(...arguments), this.KeyframeResolver = On
    }
    sortInstanceNodePosition(e, t) {
        return 2 & e.compareDocumentPosition(t) ? 1 : -1
    }
    getBaseTargetFromProps(e, t) {
        return e.style ? e.style[t] : void 0
    }
    removeValueFromRenderState(e, {
        vars: t,
        style: r
    }) {
        delete t[e], delete r[e]
    }
    handleChildMotionValue() {
        this.childSubscription && (this.childSubscription(), delete this.childSubscription);
        const {
            children: e
        } = this.props;
        Me(e) && (this.childSubscription = e.on("change", (e => {
            this.current && (this.current.textContent = `${e}`)
        })))
    }
}
class Ta extends Sa {
    constructor() {
        super(...arguments), this.type = "html", this.renderInstance = bt
    }
    readValueFromInstance(e, t) {
        if (Ve.has(t)) {
            const e = cn(t);
            return e && e.default || 0
        } {
            const n = (r = e, window.getComputedStyle(r)),
                s = (ze(t) ? n.getPropertyValue(t) : n[t]) || 0;
            return "string" == typeof s ? s.trim() : s
        }
        var r
    }
    measureInstanceViewportBox(e, {
        transformPagePoint: t
    }) {
        return Bi(e, t)
    }
    build(e, t, r) {
        dt(e, t, r.transformTemplate)
    }
    scrapeMotionValuesFromProps(e, t, r) {
        return St(e, t, r)
    }
}
class _a extends Sa {
    constructor() {
        super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = Ti
    }
    getBaseTargetFromProps(e, t) {
        return e[t]
    }
    readValueFromInstance(e, t) {
        if (Ve.has(t)) {
            const e = cn(t);
            return e && e.default || 0
        }
        return t = xt.has(t) ? t : je(t), e.getAttribute(t)
    }
    scrapeMotionValuesFromProps(e, t, r) {
        return Tt(e, t, r)
    }
    build(e, t, r) {
        mt(e, t, this.isSVGTag, r.transformTemplate)
    }
    renderInstance(e, t, r, n) {
        wt(e, t, 0, n)
    }
    mount(e) {
        this.isSVGTag = vt(e.tagName), super.mount(e)
    }
}
const Ea = (e, t) => Ne(e) ? new _a(t) : new Ta(t, {
        allowProjection: e !== o.Fragment
    }),
    Pa = ue(It({ ...ri,
        ...ga,
        ...aa,
        ...ya
    }, Ea)),
    Ca = ({
        size: e = "md",
        color: t = "default",
        text: r,
        fullScreen: n = !1
    }) => {
        const s = {
                sm: {
                    container: "h-8 w-8",
                    dot: "h-1.5 w-1.5"
                },
                md: {
                    container: "h-12 w-12",
                    dot: "h-2 w-2"
                },
                lg: {
                    container: "h-16 w-16",
                    dot: "h-3 w-3"
                }
            },
            i = {
                default: "bg-black",
                primary: "bg-black-800",
                secondary: "bg-gray-600"
            },
            o = n ? "fixed inset-0 flex items-center justify-center bg-white/80 backdrop-blur-sm z-50" : "flex items-center justify-center",
            a = n ? "mt-6 text-lg font-medium text-black" : "mt-3 text-sm font-medium text-black",
            l = {
                initial: {
                    y: 0,
                    opacity: .2
                },
                animate: {
                    y: [0, -10, 0],
                    opacity: [.2, 1, .2],
                    transition: {
                        repeat: 1 / 0,
                        duration: 1
                    }
                }
            };
        return T.jsx("div", {
            className: o,
            children: T.jsxs("div", {
                className: "flex flex-col items-center justify-center",
                children: [T.jsx(Pa.div, {
                    className: `relative ${s[e].container}`,
                    variants: {
                        animate: {
                            transition: {
                                staggerChildren: .12
                            }
                        }
                    },
                    initial: "initial",
                    animate: "animate",
                    children: [...Array(4)].map(((r, n) => T.jsx(Pa.span, {
                        className: `absolute ${s[e].dot} ${i[t]} rounded-full`,
                        style: {
                            left: "50%",
                            top: "50%",
                            transform: `rotate(${90*n}deg) translateX(${parseInt(s[e].container.split(" ")[1].split("-")[1])/2-2}px)`,
                            transformOrigin: "0 0"
                        },
                        variants: l
                    }, n)))
                }), r && T.jsx("p", {
                    className: a,
                    children: r
                })]
            })
        })
    };
class Oa extends Error {
    constructor(e, t = "FunctionsError", r) {
        super(e), this.name = t, this.context = r
    }
}
class Aa extends Oa {
    constructor(e) {
        super("Failed to send a request to the Edge Function", "FunctionsFetchError", e)
    }
}
class Na extends Oa {
    constructor(e) {
        super("Relay Error invoking the Edge Function", "FunctionsRelayError", e)
    }
}
class Ra extends Oa {
    constructor(e) {
        super("Edge Function returned a non-2xx status code", "FunctionsHttpError", e)
    }
}
var Ia, La;
(La = Ia || (Ia = {})).Any = "any", La.ApNortheast1 = "ap-northeast-1", La.ApNortheast2 = "ap-northeast-2", La.ApSouth1 = "ap-south-1", La.ApSoutheast1 = "ap-southeast-1", La.ApSoutheast2 = "ap-southeast-2", La.CaCentral1 = "ca-central-1", La.EuCentral1 = "eu-central-1", La.EuWest1 = "eu-west-1", La.EuWest2 = "eu-west-2", La.EuWest3 = "eu-west-3", La.SaEast1 = "sa-east-1", La.UsEast1 = "us-east-1", La.UsWest1 = "us-west-1", La.UsWest2 = "us-west-2";
var Ma = function(e, t, r, n) {
    return new(r || (r = Promise))((function(s, i) {
        function o(e) {
            try {
                l(n.next(e))
            } catch (t) {
                i(t)
            }
        }

        function a(e) {
            try {
                l(n.throw(e))
            } catch (t) {
                i(t)
            }
        }

        function l(e) {
            var t;
            e.done ? s(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                e(t)
            }))).then(o, a)
        }
        l((n = n.apply(e, t || [])).next())
    }))
};
class Ua {
    constructor(e, {
        headers: t = {},
        customFetch: r,
        region: n = Ia.Any
    } = {}) {
        this.url = e, this.headers = t, this.region = n, this.fetch = (e => {
            let t;
            return t = e || ("undefined" == typeof fetch ? (...e) => C((async () => {
                const {
                    default: e
                } = await Promise.resolve().then((() => Ja));
                return {
                    default: e
                }
            }), void 0).then((({
                default: t
            }) => t(...e))) : fetch), (...e) => t(...e)
        })(r)
    }
    setAuth(e) {
        this.headers.Authorization = `Bearer ${e}`
    }
    invoke(e, t = {}) {
        var r;
        return Ma(this, void 0, void 0, (function*() {
            try {
                const {
                    headers: n,
                    method: s,
                    body: i
                } = t;
                let o, a = {},
                    {
                        region: l
                    } = t;
                l || (l = this.region), l && "any" !== l && (a["x-region"] = l), i && (n && !Object.prototype.hasOwnProperty.call(n, "Content-Type") || !n) && ("undefined" != typeof Blob && i instanceof Blob || i instanceof ArrayBuffer ? (a["Content-Type"] = "application/octet-stream", o = i) : "string" == typeof i ? (a["Content-Type"] = "text/plain", o = i) : "undefined" != typeof FormData && i instanceof FormData ? o = i : (a["Content-Type"] = "application/json", o = JSON.stringify(i)));
                const c = yield this.fetch(`${this.url}/${e}`, {
                    method: s || "POST",
                    headers: Object.assign(Object.assign(Object.assign({}, a), this.headers), n),
                    body: o
                }).catch((e => {
                    throw new Aa(e)
                })), u = c.headers.get("x-relay-error");
                if (u && "true" === u) throw new Na(c);
                if (!c.ok) throw new Ra(c);
                let d, h = (null !== (r = c.headers.get("Content-Type")) && void 0 !== r ? r : "text/plain").split(";")[0].trim();
                return d = "application/json" === h ? yield c.json(): "application/octet-stream" === h ? yield c.blob(): "text/event-stream" === h ? c : "multipart/form-data" === h ? yield c.formData(): yield c.text(), {
                    data: d,
                    error: null
                }
            } catch (n) {
                return {
                    data: null,
                    error: n
                }
            }
        }))
    }
}
var Da = {},
    $a = {},
    Fa = {},
    Va = {},
    Ba = {},
    za = {},
    Wa = function() {
        if ("undefined" != typeof self) return self;
        if ("undefined" != typeof window) return window;
        if ("undefined" != typeof global) return global;
        throw new Error("unable to locate global object")
    }();
const Ha = Wa.fetch,
    qa = Wa.fetch.bind(Wa),
    Ka = Wa.Headers,
    Ga = Wa.Request,
    Ya = Wa.Response,
    Ja = Object.freeze(Object.defineProperty({
        __proto__: null,
        Headers: Ka,
        Request: Ga,
        Response: Ya,
        default: qa,
        fetch: Ha
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Xa = a(Ja);
var Za, Qa, el, tl, rl, nl = {};

function sl() {
    if (Za) return nl;
    Za = 1, Object.defineProperty(nl, "__esModule", {
        value: !0
    });
    let e = class extends Error {
        constructor(e) {
            super(e.message), this.name = "PostgrestError", this.details = e.details, this.hint = e.hint, this.code = e.code
        }
    };
    return nl.default = e, nl
}

function il() {
    if (Qa) return za;
    Qa = 1;
    var e = za && za.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    };
    Object.defineProperty(za, "__esModule", {
        value: !0
    });
    const t = e(Xa),
        r = e(sl());
    return za.default = class {
        constructor(e) {
            this.shouldThrowOnError = !1, this.method = e.method, this.url = e.url, this.headers = e.headers, this.schema = e.schema, this.body = e.body, this.shouldThrowOnError = e.shouldThrowOnError, this.signal = e.signal, this.isMaybeSingle = e.isMaybeSingle, e.fetch ? this.fetch = e.fetch : "undefined" == typeof fetch ? this.fetch = t.default : this.fetch = fetch
        }
        throwOnError() {
            return this.shouldThrowOnError = !0, this
        }
        setHeader(e, t) {
            return this.headers = Object.assign({}, this.headers), this.headers[e] = t, this
        }
        then(e, t) {
            void 0 === this.schema || (["GET", "HEAD"].includes(this.method) ? this.headers["Accept-Profile"] = this.schema : this.headers["Content-Profile"] = this.schema), "GET" !== this.method && "HEAD" !== this.method && (this.headers["Content-Type"] = "application/json");
            let n = (0, this.fetch)(this.url.toString(), {
                method: this.method,
                headers: this.headers,
                body: JSON.stringify(this.body),
                signal: this.signal
            }).then((async e => {
                var t, n, s;
                let i = null,
                    o = null,
                    a = null,
                    l = e.status,
                    c = e.statusText;
                if (e.ok) {
                    if ("HEAD" !== this.method) {
                        const t = await e.text();
                        "" === t || (o = "text/csv" === this.headers.Accept || this.headers.Accept && this.headers.Accept.includes("application/vnd.pgrst.plan+text") ? t : JSON.parse(t))
                    }
                    const r = null === (t = this.headers.Prefer) || void 0 === t ? void 0 : t.match(/count=(exact|planned|estimated)/),
                        s = null === (n = e.headers.get("content-range")) || void 0 === n ? void 0 : n.split("/");
                    r && s && s.length > 1 && (a = parseInt(s[1])), this.isMaybeSingle && "GET" === this.method && Array.isArray(o) && (o.length > 1 ? (i = {
                        code: "PGRST116",
                        details: `Results contain ${o.length} rows, application/vnd.pgrst.object+json requires 1 row`,
                        hint: null,
                        message: "JSON object requested, multiple (or no) rows returned"
                    }, o = null, a = null, l = 406, c = "Not Acceptable") : o = 1 === o.length ? o[0] : null)
                } else {
                    const t = await e.text();
                    try {
                        i = JSON.parse(t), Array.isArray(i) && 404 === e.status && (o = [], i = null, l = 200, c = "OK")
                    } catch (u) {
                        404 === e.status && "" === t ? (l = 204, c = "No Content") : i = {
                            message: t
                        }
                    }
                    if (i && this.isMaybeSingle && (null === (s = null == i ? void 0 : i.details) || void 0 === s ? void 0 : s.includes("0 rows")) && (i = null, l = 200, c = "OK"), i && this.shouldThrowOnError) throw new r.default(i)
                }
                return {
                    error: i,
                    data: o,
                    count: a,
                    status: l,
                    statusText: c
                }
            }));
            return this.shouldThrowOnError || (n = n.catch((e => {
                var t, r, n;
                return {
                    error: {
                        message: `${null!==(t=null==e?void 0:e.name)&&void 0!==t?t:"FetchError"}: ${null==e?void 0:e.message}`,
                        details: `${null!==(r=null==e?void 0:e.stack)&&void 0!==r?r:""}`,
                        hint: "",
                        code: `${null!==(n=null==e?void 0:e.code)&&void 0!==n?n:""}`
                    },
                    data: null,
                    count: null,
                    status: 0,
                    statusText: ""
                }
            }))), n.then(e, t)
        }
    }, za
}

function ol() {
    if (el) return Ba;
    el = 1;
    var e = Ba && Ba.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    };
    Object.defineProperty(Ba, "__esModule", {
        value: !0
    });
    const t = e(il());
    class r extends t.default {
        select(e) {
            let t = !1;
            const r = (null != e ? e : "*").split("").map((e => /\s/.test(e) && !t ? "" : ('"' === e && (t = !t), e))).join("");
            return this.url.searchParams.set("select", r), this.headers.Prefer && (this.headers.Prefer += ","), this.headers.Prefer += "return=representation", this
        }
        order(e, {
            ascending: t = !0,
            nullsFirst: r,
            foreignTable: n,
            referencedTable: s = n
        } = {}) {
            const i = s ? `${s}.order` : "order",
                o = this.url.searchParams.get(i);
            return this.url.searchParams.set(i, `${o?`${o},`:""}${e}.${t?"asc":"desc"}${void 0===r?"":r?".nullsfirst":".nullslast"}`), this
        }
        limit(e, {
            foreignTable: t,
            referencedTable: r = t
        } = {}) {
            const n = void 0 === r ? "limit" : `${r}.limit`;
            return this.url.searchParams.set(n, `${e}`), this
        }
        range(e, t, {
            foreignTable: r,
            referencedTable: n = r
        } = {}) {
            const s = void 0 === n ? "offset" : `${n}.offset`,
                i = void 0 === n ? "limit" : `${n}.limit`;
            return this.url.searchParams.set(s, `${e}`), this.url.searchParams.set(i, "" + (t - e + 1)), this
        }
        abortSignal(e) {
            return this.signal = e, this
        }
        single() {
            return this.headers.Accept = "application/vnd.pgrst.object+json", this
        }
        maybeSingle() {
            return "GET" === this.method ? this.headers.Accept = "application/json" : this.headers.Accept = "application/vnd.pgrst.object+json", this.isMaybeSingle = !0, this
        }
        csv() {
            return this.headers.Accept = "text/csv", this
        }
        geojson() {
            return this.headers.Accept = "application/geo+json", this
        }
        explain({
            analyze: e = !1,
            verbose: t = !1,
            settings: r = !1,
            buffers: n = !1,
            wal: s = !1,
            format: i = "text"
        } = {}) {
            var o;
            const a = [e ? "analyze" : null, t ? "verbose" : null, r ? "settings" : null, n ? "buffers" : null, s ? "wal" : null].filter(Boolean).join("|"),
                l = null !== (o = this.headers.Accept) && void 0 !== o ? o : "application/json";
            return this.headers.Accept = `application/vnd.pgrst.plan+${i}; for="${l}"; options=${a};`, this
        }
        rollback() {
            var e;
            return (null !== (e = this.headers.Prefer) && void 0 !== e ? e : "").trim().length > 0 ? this.headers.Prefer += ",tx=rollback" : this.headers.Prefer = "tx=rollback", this
        }
        returns() {
            return this
        }
    }
    return Ba.default = r, Ba
}

function al() {
    if (tl) return Va;
    tl = 1;
    var e = Va && Va.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    };
    Object.defineProperty(Va, "__esModule", {
        value: !0
    });
    const t = e(ol());
    class r extends t.default {
        eq(e, t) {
            return this.url.searchParams.append(e, `eq.${t}`), this
        }
        neq(e, t) {
            return this.url.searchParams.append(e, `neq.${t}`), this
        }
        gt(e, t) {
            return this.url.searchParams.append(e, `gt.${t}`), this
        }
        gte(e, t) {
            return this.url.searchParams.append(e, `gte.${t}`), this
        }
        lt(e, t) {
            return this.url.searchParams.append(e, `lt.${t}`), this
        }
        lte(e, t) {
            return this.url.searchParams.append(e, `lte.${t}`), this
        }
        like(e, t) {
            return this.url.searchParams.append(e, `like.${t}`), this
        }
        likeAllOf(e, t) {
            return this.url.searchParams.append(e, `like(all).{${t.join(",")}}`), this
        }
        likeAnyOf(e, t) {
            return this.url.searchParams.append(e, `like(any).{${t.join(",")}}`), this
        }
        ilike(e, t) {
            return this.url.searchParams.append(e, `ilike.${t}`), this
        }
        ilikeAllOf(e, t) {
            return this.url.searchParams.append(e, `ilike(all).{${t.join(",")}}`), this
        }
        ilikeAnyOf(e, t) {
            return this.url.searchParams.append(e, `ilike(any).{${t.join(",")}}`), this
        }
        is(e, t) {
            return this.url.searchParams.append(e, `is.${t}`), this
        } in (e, t) {
            const r = Array.from(new Set(t)).map((e => "string" == typeof e && new RegExp("[,()]").test(e) ? `"${e}"` : `${e}`)).join(",");
            return this.url.searchParams.append(e, `in.(${r})`), this
        }
        contains(e, t) {
            return "string" == typeof t ? this.url.searchParams.append(e, `cs.${t}`) : Array.isArray(t) ? this.url.searchParams.append(e, `cs.{${t.join(",")}}`) : this.url.searchParams.append(e, `cs.${JSON.stringify(t)}`), this
        }
        containedBy(e, t) {
            return "string" == typeof t ? this.url.searchParams.append(e, `cd.${t}`) : Array.isArray(t) ? this.url.searchParams.append(e, `cd.{${t.join(",")}}`) : this.url.searchParams.append(e, `cd.${JSON.stringify(t)}`), this
        }
        rangeGt(e, t) {
            return this.url.searchParams.append(e, `sr.${t}`), this
        }
        rangeGte(e, t) {
            return this.url.searchParams.append(e, `nxl.${t}`), this
        }
        rangeLt(e, t) {
            return this.url.searchParams.append(e, `sl.${t}`), this
        }
        rangeLte(e, t) {
            return this.url.searchParams.append(e, `nxr.${t}`), this
        }
        rangeAdjacent(e, t) {
            return this.url.searchParams.append(e, `adj.${t}`), this
        }
        overlaps(e, t) {
            return "string" == typeof t ? this.url.searchParams.append(e, `ov.${t}`) : this.url.searchParams.append(e, `ov.{${t.join(",")}}`), this
        }
        textSearch(e, t, {
            config: r,
            type: n
        } = {}) {
            let s = "";
            "plain" === n ? s = "pl" : "phrase" === n ? s = "ph" : "websearch" === n && (s = "w");
            const i = void 0 === r ? "" : `(${r})`;
            return this.url.searchParams.append(e, `${s}fts${i}.${t}`), this
        }
        match(e) {
            return Object.entries(e).forEach((([e, t]) => {
                this.url.searchParams.append(e, `eq.${t}`)
            })), this
        }
        not(e, t, r) {
            return this.url.searchParams.append(e, `not.${t}.${r}`), this
        }
        or(e, {
            foreignTable: t,
            referencedTable: r = t
        } = {}) {
            const n = r ? `${r}.or` : "or";
            return this.url.searchParams.append(n, `(${e})`), this
        }
        filter(e, t, r) {
            return this.url.searchParams.append(e, `${t}.${r}`), this
        }
    }
    return Va.default = r, Va
}

function ll() {
    if (rl) return Fa;
    rl = 1;
    var e = Fa && Fa.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    };
    Object.defineProperty(Fa, "__esModule", {
        value: !0
    });
    const t = e(al());
    return Fa.default = class {
        constructor(e, {
            headers: t = {},
            schema: r,
            fetch: n
        }) {
            this.url = e, this.headers = t, this.schema = r, this.fetch = n
        }
        select(e, {
            head: r = !1,
            count: n
        } = {}) {
            const s = r ? "HEAD" : "GET";
            let i = !1;
            const o = (null != e ? e : "*").split("").map((e => /\s/.test(e) && !i ? "" : ('"' === e && (i = !i), e))).join("");
            return this.url.searchParams.set("select", o), n && (this.headers.Prefer = `count=${n}`), new t.default({
                method: s,
                url: this.url,
                headers: this.headers,
                schema: this.schema,
                fetch: this.fetch,
                allowEmpty: !1
            })
        }
        insert(e, {
            count: r,
            defaultToNull: n = !0
        } = {}) {
            const s = [];
            if (this.headers.Prefer && s.push(this.headers.Prefer), r && s.push(`count=${r}`), n || s.push("missing=default"), this.headers.Prefer = s.join(","), Array.isArray(e)) {
                const t = e.reduce(((e, t) => e.concat(Object.keys(t))), []);
                if (t.length > 0) {
                    const e = [...new Set(t)].map((e => `"${e}"`));
                    this.url.searchParams.set("columns", e.join(","))
                }
            }
            return new t.default({
                method: "POST",
                url: this.url,
                headers: this.headers,
                schema: this.schema,
                body: e,
                fetch: this.fetch,
                allowEmpty: !1
            })
        }
        upsert(e, {
            onConflict: r,
            ignoreDuplicates: n = !1,
            count: s,
            defaultToNull: i = !0
        } = {}) {
            const o = [`resolution=${n?"ignore":"merge"}-duplicates`];
            if (void 0 !== r && this.url.searchParams.set("on_conflict", r), this.headers.Prefer && o.push(this.headers.Prefer), s && o.push(`count=${s}`), i || o.push("missing=default"), this.headers.Prefer = o.join(","), Array.isArray(e)) {
                const t = e.reduce(((e, t) => e.concat(Object.keys(t))), []);
                if (t.length > 0) {
                    const e = [...new Set(t)].map((e => `"${e}"`));
                    this.url.searchParams.set("columns", e.join(","))
                }
            }
            return new t.default({
                method: "POST",
                url: this.url,
                headers: this.headers,
                schema: this.schema,
                body: e,
                fetch: this.fetch,
                allowEmpty: !1
            })
        }
        update(e, {
            count: r
        } = {}) {
            const n = [];
            return this.headers.Prefer && n.push(this.headers.Prefer), r && n.push(`count=${r}`), this.headers.Prefer = n.join(","), new t.default({
                method: "PATCH",
                url: this.url,
                headers: this.headers,
                schema: this.schema,
                body: e,
                fetch: this.fetch,
                allowEmpty: !1
            })
        }
        delete({
            count: e
        } = {}) {
            const r = [];
            return e && r.push(`count=${e}`), this.headers.Prefer && r.unshift(this.headers.Prefer), this.headers.Prefer = r.join(","), new t.default({
                method: "DELETE",
                url: this.url,
                headers: this.headers,
                schema: this.schema,
                fetch: this.fetch,
                allowEmpty: !1
            })
        }
    }, Fa
}
var cl, ul, dl, hl, pl = {},
    fl = {};

function ml() {
    if (ul) return pl;
    ul = 1, Object.defineProperty(pl, "__esModule", {
        value: !0
    }), pl.DEFAULT_HEADERS = void 0;
    const e = (cl || (cl = 1, Object.defineProperty(fl, "__esModule", {
        value: !0
    }), fl.version = void 0, fl.version = "0.0.0-automated"), fl);
    return pl.DEFAULT_HEADERS = {
        "X-Client-Info": `postgrest-js/${e.version}`
    }, pl
}
var gl = function() {
    if (hl) return Da;
    hl = 1;
    var e = Da && Da.__importDefault || function(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    };
    Object.defineProperty(Da, "__esModule", {
        value: !0
    }), Da.PostgrestError = Da.PostgrestBuilder = Da.PostgrestTransformBuilder = Da.PostgrestFilterBuilder = Da.PostgrestQueryBuilder = Da.PostgrestClient = void 0;
    const t = e(function() {
        if (dl) return $a;
        dl = 1;
        var e = $a && $a.__importDefault || function(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        };
        Object.defineProperty($a, "__esModule", {
            value: !0
        });
        const t = e(ll()),
            r = e(al()),
            n = ml();
        class s {
            constructor(e, {
                headers: t = {},
                schema: r,
                fetch: s
            } = {}) {
                this.url = e, this.headers = Object.assign(Object.assign({}, n.DEFAULT_HEADERS), t), this.schemaName = r, this.fetch = s
            }
            from(e) {
                const r = new URL(`${this.url}/${e}`);
                return new t.default(r, {
                    headers: Object.assign({}, this.headers),
                    schema: this.schemaName,
                    fetch: this.fetch
                })
            }
            schema(e) {
                return new s(this.url, {
                    headers: this.headers,
                    schema: e,
                    fetch: this.fetch
                })
            }
            rpc(e, t = {}, {
                head: n = !1,
                get: s = !1,
                count: i
            } = {}) {
                let o;
                const a = new URL(`${this.url}/rpc/${e}`);
                let l;
                n || s ? (o = n ? "HEAD" : "GET", Object.entries(t).filter((([e, t]) => void 0 !== t)).map((([e, t]) => [e, Array.isArray(t) ? `{${t.join(",")}}` : `${t}`])).forEach((([e, t]) => {
                    a.searchParams.append(e, t)
                }))) : (o = "POST", l = t);
                const c = Object.assign({}, this.headers);
                return i && (c.Prefer = `count=${i}`), new r.default({
                    method: o,
                    url: a,
                    headers: c,
                    schema: this.schemaName,
                    body: l,
                    fetch: this.fetch,
                    allowEmpty: !1
                })
            }
        }
        return $a.default = s, $a
    }());
    Da.PostgrestClient = t.default;
    const r = e(ll());
    Da.PostgrestQueryBuilder = r.default;
    const n = e(al());
    Da.PostgrestFilterBuilder = n.default;
    const s = e(ol());
    Da.PostgrestTransformBuilder = s.default;
    const i = e(il());
    Da.PostgrestBuilder = i.default;
    const o = e(sl());
    return Da.PostgrestError = o.default, Da.default = {
        PostgrestClient: t.default,
        PostgrestQueryBuilder: r.default,
        PostgrestFilterBuilder: n.default,
        PostgrestTransformBuilder: s.default,
        PostgrestBuilder: i.default,
        PostgrestError: o.default
    }, Da
}();
const yl = l(gl),
    {
        PostgrestClient: vl,
        PostgrestQueryBuilder: bl,
        PostgrestFilterBuilder: xl,
        PostgrestTransformBuilder: wl,
        PostgrestBuilder: kl
    } = yl,
    jl = {
        "X-Client-Info": "realtime-js/2.10.7"
    };
var Sl, Tl, _l, El, Pl, Cl, Ol, Al, Nl, Rl, Il;
(Tl = Sl || (Sl = {}))[Tl.connecting = 0] = "connecting", Tl[Tl.open = 1] = "open", Tl[Tl.closing = 2] = "closing", Tl[Tl.closed = 3] = "closed", (El = _l || (_l = {})).closed = "closed", El.errored = "errored", El.joined = "joined", El.joining = "joining", El.leaving = "leaving", (Cl = Pl || (Pl = {})).close = "phx_close", Cl.error = "phx_error", Cl.join = "phx_join", Cl.reply = "phx_reply", Cl.leave = "phx_leave", Cl.access_token = "access_token", (Ol || (Ol = {})).websocket = "websocket", (Nl = Al || (Al = {})).Connecting = "connecting", Nl.Open = "open", Nl.Closing = "closing", Nl.Closed = "closed";
class Ll {
    constructor() {
        this.HEADER_LENGTH = 1
    }
    decode(e, t) {
        return e.constructor === ArrayBuffer ? t(this._binaryDecode(e)) : t("string" == typeof e ? JSON.parse(e) : {})
    }
    _binaryDecode(e) {
        const t = new DataView(e),
            r = new TextDecoder;
        return this._decodeBroadcast(e, t, r)
    }
    _decodeBroadcast(e, t, r) {
        const n = t.getUint8(1),
            s = t.getUint8(2);
        let i = this.HEADER_LENGTH + 2;
        const o = r.decode(e.slice(i, i + n));
        i += n;
        const a = r.decode(e.slice(i, i + s));
        i += s;
        return {
            ref: null,
            topic: o,
            event: a,
            payload: JSON.parse(r.decode(e.slice(i, e.byteLength)))
        }
    }
}
class Ml {
    constructor(e, t) {
        this.callback = e, this.timerCalc = t, this.timer = void 0, this.tries = 0, this.callback = e, this.timerCalc = t
    }
    reset() {
        this.tries = 0, clearTimeout(this.timer)
    }
    scheduleTimeout() {
        clearTimeout(this.timer), this.timer = setTimeout((() => {
            this.tries = this.tries + 1, this.callback()
        }), this.timerCalc(this.tries + 1))
    }
}(Il = Rl || (Rl = {})).abstime = "abstime", Il.bool = "bool", Il.date = "date", Il.daterange = "daterange", Il.float4 = "float4", Il.float8 = "float8", Il.int2 = "int2", Il.int4 = "int4", Il.int4range = "int4range", Il.int8 = "int8", Il.int8range = "int8range", Il.json = "json", Il.jsonb = "jsonb", Il.money = "money", Il.numeric = "numeric", Il.oid = "oid", Il.reltime = "reltime", Il.text = "text", Il.time = "time", Il.timestamp = "timestamp", Il.timestamptz = "timestamptz", Il.timetz = "timetz", Il.tsrange = "tsrange", Il.tstzrange = "tstzrange";
const Ul = (e, t, r = {}) => {
        var n;
        const s = null !== (n = r.skipTypes) && void 0 !== n ? n : [];
        return Object.keys(t).reduce(((r, n) => (r[n] = Dl(n, e, t, s), r)), {})
    },
    Dl = (e, t, r, n) => {
        const s = t.find((t => t.name === e)),
            i = null == s ? void 0 : s.type,
            o = r[e];
        return i && !n.includes(i) ? $l(i, o) : Fl(o)
    },
    $l = (e, t) => {
        if ("_" === e.charAt(0)) {
            const r = e.slice(1, e.length);
            return Wl(t, r)
        }
        switch (e) {
            case Rl.bool:
                return Vl(t);
            case Rl.float4:
            case Rl.float8:
            case Rl.int2:
            case Rl.int4:
            case Rl.int8:
            case Rl.numeric:
            case Rl.oid:
                return Bl(t);
            case Rl.json:
            case Rl.jsonb:
                return zl(t);
            case Rl.timestamp:
                return Hl(t);
            case Rl.abstime:
            case Rl.date:
            case Rl.daterange:
            case Rl.int4range:
            case Rl.int8range:
            case Rl.money:
            case Rl.reltime:
            case Rl.text:
            case Rl.time:
            case Rl.timestamptz:
            case Rl.timetz:
            case Rl.tsrange:
            case Rl.tstzrange:
            default:
                return Fl(t)
        }
    },
    Fl = e => e,
    Vl = e => {
        switch (e) {
            case "t":
                return !0;
            case "f":
                return !1;
            default:
                return e
        }
    },
    Bl = e => {
        if ("string" == typeof e) {
            const t = parseFloat(e);
            if (!Number.isNaN(t)) return t
        }
        return e
    },
    zl = e => {
        if ("string" == typeof e) try {
            return JSON.parse(e)
        } catch (t) {
            return console.log(`JSON parse error: ${t}`), e
        }
        return e
    },
    Wl = (e, t) => {
        if ("string" != typeof e) return e;
        const r = e.length - 1,
            n = e[r];
        if ("{" === e[0] && "}" === n) {
            let n;
            const i = e.slice(1, r);
            try {
                n = JSON.parse("[" + i + "]")
            } catch (s) {
                n = i ? i.split(",") : []
            }
            return n.map((e => $l(t, e)))
        }
        return e
    },
    Hl = e => "string" == typeof e ? e.replace(" ", "T") : e,
    ql = e => {
        let t = e;
        return t = t.replace(/^ws/i, "http"), t = t.replace(/(\/socket\/websocket|\/socket|\/websocket)\/?$/i, ""), t.replace(/\/+$/, "")
    };
class Kl {
    constructor(e, t, r = {}, n = 1e4) {
        this.channel = e, this.event = t, this.payload = r, this.timeout = n, this.sent = !1, this.timeoutTimer = void 0, this.ref = "", this.receivedResp = null, this.recHooks = [], this.refEvent = null
    }
    resend(e) {
        this.timeout = e, this._cancelRefEvent(), this.ref = "", this.refEvent = null, this.receivedResp = null, this.sent = !1, this.send()
    }
    send() {
        this._hasReceived("timeout") || (this.startTimeout(), this.sent = !0, this.channel.socket.push({
            topic: this.channel.topic,
            event: this.event,
            payload: this.payload,
            ref: this.ref,
            join_ref: this.channel._joinRef()
        }))
    }
    updatePayload(e) {
        this.payload = Object.assign(Object.assign({}, this.payload), e)
    }
    receive(e, t) {
        var r;
        return this._hasReceived(e) && t(null === (r = this.receivedResp) || void 0 === r ? void 0 : r.response), this.recHooks.push({
            status: e,
            callback: t
        }), this
    }
    startTimeout() {
        if (this.timeoutTimer) return;
        this.ref = this.channel.socket._makeRef(), this.refEvent = this.channel._replyEventName(this.ref);
        this.channel._on(this.refEvent, {}, (e => {
            this._cancelRefEvent(), this._cancelTimeout(), this.receivedResp = e, this._matchReceive(e)
        })), this.timeoutTimer = setTimeout((() => {
            this.trigger("timeout", {})
        }), this.timeout)
    }
    trigger(e, t) {
        this.refEvent && this.channel._trigger(this.refEvent, {
            status: e,
            response: t
        })
    }
    destroy() {
        this._cancelRefEvent(), this._cancelTimeout()
    }
    _cancelRefEvent() {
        this.refEvent && this.channel._off(this.refEvent, {})
    }
    _cancelTimeout() {
        clearTimeout(this.timeoutTimer), this.timeoutTimer = void 0
    }
    _matchReceive({
        status: e,
        response: t
    }) {
        this.recHooks.filter((t => t.status === e)).forEach((e => e.callback(t)))
    }
    _hasReceived(e) {
        return this.receivedResp && this.receivedResp.status === e
    }
}
var Gl, Yl, Jl, Xl, Zl, Ql, ec, tc;
(Yl = Gl || (Gl = {})).SYNC = "sync", Yl.JOIN = "join", Yl.LEAVE = "leave";
class rc {
    constructor(e, t) {
        this.channel = e, this.state = {}, this.pendingDiffs = [], this.joinRef = null, this.caller = {
            onJoin: () => {},
            onLeave: () => {},
            onSync: () => {}
        };
        const r = (null == t ? void 0 : t.events) || {
            state: "presence_state",
            diff: "presence_diff"
        };
        this.channel._on(r.state, {}, (e => {
            const {
                onJoin: t,
                onLeave: r,
                onSync: n
            } = this.caller;
            this.joinRef = this.channel._joinRef(), this.state = rc.syncState(this.state, e, t, r), this.pendingDiffs.forEach((e => {
                this.state = rc.syncDiff(this.state, e, t, r)
            })), this.pendingDiffs = [], n()
        })), this.channel._on(r.diff, {}, (e => {
            const {
                onJoin: t,
                onLeave: r,
                onSync: n
            } = this.caller;
            this.inPendingSyncState() ? this.pendingDiffs.push(e) : (this.state = rc.syncDiff(this.state, e, t, r), n())
        })), this.onJoin(((e, t, r) => {
            this.channel._trigger("presence", {
                event: "join",
                key: e,
                currentPresences: t,
                newPresences: r
            })
        })), this.onLeave(((e, t, r) => {
            this.channel._trigger("presence", {
                event: "leave",
                key: e,
                currentPresences: t,
                leftPresences: r
            })
        })), this.onSync((() => {
            this.channel._trigger("presence", {
                event: "sync"
            })
        }))
    }
    static syncState(e, t, r, n) {
        const s = this.cloneDeep(e),
            i = this.transformState(t),
            o = {},
            a = {};
        return this.map(s, ((e, t) => {
            i[e] || (a[e] = t)
        })), this.map(i, ((e, t) => {
            const r = s[e];
            if (r) {
                const n = t.map((e => e.presence_ref)),
                    s = r.map((e => e.presence_ref)),
                    i = t.filter((e => s.indexOf(e.presence_ref) < 0)),
                    l = r.filter((e => n.indexOf(e.presence_ref) < 0));
                i.length > 0 && (o[e] = i), l.length > 0 && (a[e] = l)
            } else o[e] = t
        })), this.syncDiff(s, {
            joins: o,
            leaves: a
        }, r, n)
    }
    static syncDiff(e, t, r, n) {
        const {
            joins: s,
            leaves: i
        } = {
            joins: this.transformState(t.joins),
            leaves: this.transformState(t.leaves)
        };
        return r || (r = () => {}), n || (n = () => {}), this.map(s, ((t, n) => {
            var s;
            const i = null !== (s = e[t]) && void 0 !== s ? s : [];
            if (e[t] = this.cloneDeep(n), i.length > 0) {
                const r = e[t].map((e => e.presence_ref)),
                    n = i.filter((e => r.indexOf(e.presence_ref) < 0));
                e[t].unshift(...n)
            }
            r(t, i, n)
        })), this.map(i, ((t, r) => {
            let s = e[t];
            if (!s) return;
            const i = r.map((e => e.presence_ref));
            s = s.filter((e => i.indexOf(e.presence_ref) < 0)), e[t] = s, n(t, s, r), 0 === s.length && delete e[t]
        })), e
    }
    static map(e, t) {
        return Object.getOwnPropertyNames(e).map((r => t(r, e[r])))
    }
    static transformState(e) {
        return e = this.cloneDeep(e), Object.getOwnPropertyNames(e).reduce(((t, r) => {
            const n = e[r];
            return t[r] = "metas" in n ? n.metas.map((e => (e.presence_ref = e.phx_ref, delete e.phx_ref, delete e.phx_ref_prev, e))) : n, t
        }), {})
    }
    static cloneDeep(e) {
        return JSON.parse(JSON.stringify(e))
    }
    onJoin(e) {
        this.caller.onJoin = e
    }
    onLeave(e) {
        this.caller.onLeave = e
    }
    onSync(e) {
        this.caller.onSync = e
    }
    inPendingSyncState() {
        return !this.joinRef || this.joinRef !== this.channel._joinRef()
    }
}(Xl = Jl || (Jl = {})).ALL = "*", Xl.INSERT = "INSERT", Xl.UPDATE = "UPDATE", Xl.DELETE = "DELETE", (Ql = Zl || (Zl = {})).BROADCAST = "broadcast", Ql.PRESENCE = "presence", Ql.POSTGRES_CHANGES = "postgres_changes", Ql.SYSTEM = "system", (tc = ec || (ec = {})).SUBSCRIBED = "SUBSCRIBED", tc.TIMED_OUT = "TIMED_OUT", tc.CLOSED = "CLOSED", tc.CHANNEL_ERROR = "CHANNEL_ERROR";
class nc {
    constructor(e, t = {
        config: {}
    }, r) {
        this.topic = e, this.params = t, this.socket = r, this.bindings = {}, this.state = _l.closed, this.joinedOnce = !1, this.pushBuffer = [], this.subTopic = e.replace(/^realtime:/i, ""), this.params.config = Object.assign({
            broadcast: {
                ack: !1,
                self: !1
            },
            presence: {
                key: ""
            },
            private: !1
        }, t.config), this.timeout = this.socket.timeout, this.joinPush = new Kl(this, Pl.join, this.params, this.timeout), this.rejoinTimer = new Ml((() => this._rejoinUntilConnected()), this.socket.reconnectAfterMs), this.joinPush.receive("ok", (() => {
            this.state = _l.joined, this.rejoinTimer.reset(), this.pushBuffer.forEach((e => e.send())), this.pushBuffer = []
        })), this._onClose((() => {
            this.rejoinTimer.reset(), this.socket.log("channel", `close ${this.topic} ${this._joinRef()}`), this.state = _l.closed, this.socket._remove(this)
        })), this._onError((e => {
            this._isLeaving() || this._isClosed() || (this.socket.log("channel", `error ${this.topic}`, e), this.state = _l.errored, this.rejoinTimer.scheduleTimeout())
        })), this.joinPush.receive("timeout", (() => {
            this._isJoining() && (this.socket.log("channel", `timeout ${this.topic}`, this.joinPush.timeout), this.state = _l.errored, this.rejoinTimer.scheduleTimeout())
        })), this._on(Pl.reply, {}, ((e, t) => {
            this._trigger(this._replyEventName(t), e)
        })), this.presence = new rc(this), this.broadcastEndpointURL = ql(this.socket.endPoint) + "/api/broadcast", this.private = this.params.config.private || !1
    }
    subscribe(e, t = this.timeout) {
        var r, n;
        if (this.socket.isConnected() || this.socket.connect(), this.joinedOnce) throw "tried to subscribe multiple times. 'subscribe' can only be called a single time per channel instance"; {
            const {
                config: {
                    broadcast: s,
                    presence: i,
                    private: o
                }
            } = this.params;
            this._onError((t => e && e("CHANNEL_ERROR", t))), this._onClose((() => e && e("CLOSED")));
            const a = {},
                l = {
                    broadcast: s,
                    presence: i,
                    postgres_changes: null !== (n = null === (r = this.bindings.postgres_changes) || void 0 === r ? void 0 : r.map((e => e.filter))) && void 0 !== n ? n : [],
                    private: o
                };
            this.socket.accessToken && (a.access_token = this.socket.accessToken), this.updateJoinPayload(Object.assign({
                config: l
            }, a)), this.joinedOnce = !0, this._rejoin(t), this.joinPush.receive("ok", (({
                postgres_changes: t
            }) => {
                var r;
                if (this.socket.accessToken && this.socket.setAuth(this.socket.accessToken), void 0 !== t) {
                    const n = this.bindings.postgres_changes,
                        s = null !== (r = null == n ? void 0 : n.length) && void 0 !== r ? r : 0,
                        i = [];
                    for (let r = 0; r < s; r++) {
                        const s = n[r],
                            {
                                filter: {
                                    event: o,
                                    schema: a,
                                    table: l,
                                    filter: c
                                }
                            } = s,
                            u = t && t[r];
                        if (!u || u.event !== o || u.schema !== a || u.table !== l || u.filter !== c) return this.unsubscribe(), void(e && e("CHANNEL_ERROR", new Error("mismatch between server and client bindings for postgres changes")));
                        i.push(Object.assign(Object.assign({}, s), {
                            id: u.id
                        }))
                    }
                    return this.bindings.postgres_changes = i, void(e && e("SUBSCRIBED"))
                }
                e && e("SUBSCRIBED")
            })).receive("error", (t => {
                e && e("CHANNEL_ERROR", new Error(JSON.stringify(Object.values(t).join(", ") || "error")))
            })).receive("timeout", (() => {
                e && e("TIMED_OUT")
            }))
        }
        return this
    }
    presenceState() {
        return this.presence.state
    }
    async track(e, t = {}) {
        return await this.send({
            type: "presence",
            event: "track",
            payload: e
        }, t.timeout || this.timeout)
    }
    async untrack(e = {}) {
        return await this.send({
            type: "presence",
            event: "untrack"
        }, e)
    }
    on(e, t, r) {
        return this._on(e, t, r)
    }
    async send(e, t = {}) {
        var r, n;
        if (this._canPush() || "broadcast" !== e.type) return new Promise((r => {
            var n, s, i;
            const o = this._push(e.type, e, t.timeout || this.timeout);
            "broadcast" !== e.type || (null === (i = null === (s = null === (n = this.params) || void 0 === n ? void 0 : n.config) || void 0 === s ? void 0 : s.broadcast) || void 0 === i ? void 0 : i.ack) || r("ok"), o.receive("ok", (() => r("ok"))), o.receive("error", (() => r("error"))), o.receive("timeout", (() => r("timed out")))
        })); {
            const {
                event: i,
                payload: o
            } = e, a = {
                method: "POST",
                headers: {
                    Authorization: this.socket.accessToken ? `Bearer ${this.socket.accessToken}` : "",
                    apikey: this.socket.apiKey ? this.socket.apiKey : "",
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    messages: [{
                        topic: this.subTopic,
                        event: i,
                        payload: o,
                        private: this.private
                    }]
                })
            };
            try {
                const e = await this._fetchWithTimeout(this.broadcastEndpointURL, a, null !== (r = t.timeout) && void 0 !== r ? r : this.timeout);
                return await (null === (n = e.body) || void 0 === n ? void 0 : n.cancel()), e.ok ? "ok" : "error"
            } catch (s) {
                return "AbortError" === s.name ? "timed out" : "error"
            }
        }
    }
    updateJoinPayload(e) {
        this.joinPush.updatePayload(e)
    }
    unsubscribe(e = this.timeout) {
        this.state = _l.leaving;
        const t = () => {
            this.socket.log("channel", `leave ${this.topic}`), this._trigger(Pl.close, "leave", this._joinRef())
        };
        return this.rejoinTimer.reset(), this.joinPush.destroy(), new Promise((r => {
            const n = new Kl(this, Pl.leave, {}, e);
            n.receive("ok", (() => {
                t(), r("ok")
            })).receive("timeout", (() => {
                t(), r("timed out")
            })).receive("error", (() => {
                r("error")
            })), n.send(), this._canPush() || n.trigger("ok", {})
        }))
    }
    async _fetchWithTimeout(e, t, r) {
        const n = new AbortController,
            s = setTimeout((() => n.abort()), r),
            i = await this.socket.fetch(e, Object.assign(Object.assign({}, t), {
                signal: n.signal
            }));
        return clearTimeout(s), i
    }
    _push(e, t, r = this.timeout) {
        if (!this.joinedOnce) throw `tried to push '${e}' to '${this.topic}' before joining. Use channel.subscribe() before pushing events`;
        let n = new Kl(this, e, t, r);
        return this._canPush() ? n.send() : (n.startTimeout(), this.pushBuffer.push(n)), n
    }
    _onMessage(e, t, r) {
        return t
    }
    _isMember(e) {
        return this.topic === e
    }
    _joinRef() {
        return this.joinPush.ref
    }
    _trigger(e, t, r) {
        var n, s;
        const i = e.toLocaleLowerCase(),
            {
                close: o,
                error: a,
                leave: l,
                join: c
            } = Pl;
        if (r && [o, a, l, c].indexOf(i) >= 0 && r !== this._joinRef()) return;
        let u = this._onMessage(i, t, r);
        if (t && !u) throw "channel onMessage callbacks must return the payload, modified or unmodified";
        ["insert", "update", "delete"].includes(i) ? null === (n = this.bindings.postgres_changes) || void 0 === n || n.filter((e => {
            var t, r, n;
            return "*" === (null === (t = e.filter) || void 0 === t ? void 0 : t.event) || (null === (n = null === (r = e.filter) || void 0 === r ? void 0 : r.event) || void 0 === n ? void 0 : n.toLocaleLowerCase()) === i
        })).map((e => e.callback(u, r))) : null === (s = this.bindings[i]) || void 0 === s || s.filter((e => {
            var r, n, s, o, a, l;
            if (["broadcast", "presence", "postgres_changes"].includes(i)) {
                if ("id" in e) {
                    const i = e.id,
                        o = null === (r = e.filter) || void 0 === r ? void 0 : r.event;
                    return i && (null === (n = t.ids) || void 0 === n ? void 0 : n.includes(i)) && ("*" === o || (null == o ? void 0 : o.toLocaleLowerCase()) === (null === (s = t.data) || void 0 === s ? void 0 : s.type.toLocaleLowerCase()))
                } {
                    const r = null === (a = null === (o = null == e ? void 0 : e.filter) || void 0 === o ? void 0 : o.event) || void 0 === a ? void 0 : a.toLocaleLowerCase();
                    return "*" === r || r === (null === (l = null == t ? void 0 : t.event) || void 0 === l ? void 0 : l.toLocaleLowerCase())
                }
            }
            return e.type.toLocaleLowerCase() === i
        })).map((e => {
            if ("object" == typeof u && "ids" in u) {
                const e = u.data,
                    {
                        schema: t,
                        table: r,
                        commit_timestamp: n,
                        type: s,
                        errors: i
                    } = e,
                    o = {
                        schema: t,
                        table: r,
                        commit_timestamp: n,
                        eventType: s,
                        new: {},
                        old: {},
                        errors: i
                    };
                u = Object.assign(Object.assign({}, o), this._getPayloadRecords(e))
            }
            e.callback(u, r)
        }))
    }
    _isClosed() {
        return this.state === _l.closed
    }
    _isJoined() {
        return this.state === _l.joined
    }
    _isJoining() {
        return this.state === _l.joining
    }
    _isLeaving() {
        return this.state === _l.leaving
    }
    _replyEventName(e) {
        return `chan_reply_${e}`
    }
    _on(e, t, r) {
        const n = e.toLocaleLowerCase(),
            s = {
                type: n,
                filter: t,
                callback: r
            };
        return this.bindings[n] ? this.bindings[n].push(s) : this.bindings[n] = [s], this
    }
    _off(e, t) {
        const r = e.toLocaleLowerCase();
        return this.bindings[r] = this.bindings[r].filter((e => {
            var n;
            return !((null === (n = e.type) || void 0 === n ? void 0 : n.toLocaleLowerCase()) === r && nc.isEqual(e.filter, t))
        })), this
    }
    static isEqual(e, t) {
        if (Object.keys(e).length !== Object.keys(t).length) return !1;
        for (const r in e)
            if (e[r] !== t[r]) return !1;
        return !0
    }
    _rejoinUntilConnected() {
        this.rejoinTimer.scheduleTimeout(), this.socket.isConnected() && this._rejoin()
    }
    _onClose(e) {
        this._on(Pl.close, {}, e)
    }
    _onError(e) {
        this._on(Pl.error, {}, (t => e(t)))
    }
    _canPush() {
        return this.socket.isConnected() && this._isJoined()
    }
    _rejoin(e = this.timeout) {
        this._isLeaving() || (this.socket._leaveOpenTopic(this.topic), this.state = _l.joining, this.joinPush.resend(e))
    }
    _getPayloadRecords(e) {
        const t = {
            new: {},
            old: {}
        };
        return "INSERT" !== e.type && "UPDATE" !== e.type || (t.new = Ul(e.columns, e.record)), "UPDATE" !== e.type && "DELETE" !== e.type || (t.old = Ul(e.columns, e.old_record)), t
    }
}
const sc = () => {},
    ic = "undefined" != typeof WebSocket;
class oc {
    constructor(e, t) {
        var r;
        this.accessToken = null, this.apiKey = null, this.channels = [], this.endPoint = "", this.httpEndpoint = "", this.headers = jl, this.params = {}, this.timeout = 1e4, this.heartbeatIntervalMs = 3e4, this.heartbeatTimer = void 0, this.pendingHeartbeatRef = null, this.ref = 0, this.logger = sc, this.conn = null, this.sendBuffer = [], this.serializer = new Ll, this.stateChangeCallbacks = {
            open: [],
            close: [],
            error: [],
            message: []
        }, this._resolveFetch = e => {
            let t;
            return t = e || ("undefined" == typeof fetch ? (...e) => C((async () => {
                const {
                    default: e
                } = await Promise.resolve().then((() => Ja));
                return {
                    default: e
                }
            }), void 0).then((({
                default: t
            }) => t(...e))) : fetch), (...e) => t(...e)
        }, this.endPoint = `${e}/${Ol.websocket}`, this.httpEndpoint = ql(e), (null == t ? void 0 : t.transport) ? this.transport = t.transport : this.transport = null, (null == t ? void 0 : t.params) && (this.params = t.params), (null == t ? void 0 : t.headers) && (this.headers = Object.assign(Object.assign({}, this.headers), t.headers)), (null == t ? void 0 : t.timeout) && (this.timeout = t.timeout), (null == t ? void 0 : t.logger) && (this.logger = t.logger), (null == t ? void 0 : t.heartbeatIntervalMs) && (this.heartbeatIntervalMs = t.heartbeatIntervalMs);
        const n = null === (r = null == t ? void 0 : t.params) || void 0 === r ? void 0 : r.apikey;
        if (n && (this.accessToken = n, this.apiKey = n), this.reconnectAfterMs = (null == t ? void 0 : t.reconnectAfterMs) ? t.reconnectAfterMs : e => [1e3, 2e3, 5e3, 1e4][e - 1] || 1e4, this.encode = (null == t ? void 0 : t.encode) ? t.encode : (e, t) => t(JSON.stringify(e)), this.decode = (null == t ? void 0 : t.decode) ? t.decode : this.serializer.decode.bind(this.serializer), this.reconnectTimer = new Ml((async () => {
                this.disconnect(), this.connect()
            }), this.reconnectAfterMs), this.fetch = this._resolveFetch(null == t ? void 0 : t.fetch), null == t ? void 0 : t.worker) {
            if ("undefined" != typeof window && !window.Worker) throw new Error("Web Worker is not supported");
            this.worker = (null == t ? void 0 : t.worker) || !1, this.workerUrl = null == t ? void 0 : t.workerUrl
        }
    }
    connect() {
        if (!this.conn)
            if (this.transport) this.conn = new this.transport(this._endPointURL(), void 0, {
                headers: this.headers
            });
            else {
                if (ic) return this.conn = new WebSocket(this._endPointURL()), void this.setupConnection();
                this.conn = new ac(this._endPointURL(), void 0, {
                    close: () => {
                        this.conn = null
                    }
                }), C((async () => {
                    const {
                        default: e
                    } = await
                    import ("./browser-Cix0Qkrg.js").then((e => e.b));
                    return {
                        default: e
                    }
                }), __vite__mapDeps([0, 1])).then((({
                    default: e
                }) => {
                    this.conn = new e(this._endPointURL(), void 0, {
                        headers: this.headers
                    }), this.setupConnection()
                }))
            }
    }
    disconnect(e, t) {
        this.conn && (this.conn.onclose = function() {}, e ? this.conn.close(e, null != t ? t : "") : this.conn.close(), this.conn = null, this.heartbeatTimer && clearInterval(this.heartbeatTimer), this.reconnectTimer.reset())
    }
    getChannels() {
        return this.channels
    }
    async removeChannel(e) {
        const t = await e.unsubscribe();
        return 0 === this.channels.length && this.disconnect(), t
    }
    async removeAllChannels() {
        const e = await Promise.all(this.channels.map((e => e.unsubscribe())));
        return this.disconnect(), e
    }
    log(e, t, r) {
        this.logger(e, t, r)
    }
    connectionState() {
        switch (this.conn && this.conn.readyState) {
            case Sl.connecting:
                return Al.Connecting;
            case Sl.open:
                return Al.Open;
            case Sl.closing:
                return Al.Closing;
            default:
                return Al.Closed
        }
    }
    isConnected() {
        return this.connectionState() === Al.Open
    }
    channel(e, t = {
        config: {}
    }) {
        const r = new nc(`realtime:${e}`, t, this);
        return this.channels.push(r), r
    }
    push(e) {
        const {
            topic: t,
            event: r,
            payload: n,
            ref: s
        } = e, i = () => {
            this.encode(e, (e => {
                var t;
                null === (t = this.conn) || void 0 === t || t.send(e)
            }))
        };
        this.log("push", `${t} ${r} (${s})`, n), this.isConnected() ? i() : this.sendBuffer.push(i)
    }
    setAuth(e) {
        this.accessToken = e, this.channels.forEach((t => {
            e && t.updateJoinPayload({
                access_token: e
            }), t.joinedOnce && t._isJoined() && t._push(Pl.access_token, {
                access_token: e
            })
        }))
    }
    _makeRef() {
        let e = this.ref + 1;
        return e === this.ref ? this.ref = 0 : this.ref = e, this.ref.toString()
    }
    _leaveOpenTopic(e) {
        let t = this.channels.find((t => t.topic === e && (t._isJoined() || t._isJoining())));
        t && (this.log("transport", `leaving duplicate topic "${e}"`), t.unsubscribe())
    }
    _remove(e) {
        this.channels = this.channels.filter((t => t._joinRef() !== e._joinRef()))
    }
    setupConnection() {
        this.conn && (this.conn.binaryType = "arraybuffer", this.conn.onopen = () => this._onConnOpen(), this.conn.onerror = e => this._onConnError(e), this.conn.onmessage = e => this._onConnMessage(e), this.conn.onclose = e => this._onConnClose(e))
    }
    _endPointURL() {
        return this._appendParams(this.endPoint, Object.assign({}, this.params, {
            vsn: "1.0.0"
        }))
    }
    _onConnMessage(e) {
        this.decode(e.data, (e => {
            let {
                topic: t,
                event: r,
                payload: n,
                ref: s
            } = e;
            (s && s === this.pendingHeartbeatRef || r === (null == n ? void 0 : n.type)) && (this.pendingHeartbeatRef = null), this.log("receive", `${n.status||""} ${t} ${r} ${s&&"("+s+")"||""}`, n), this.channels.filter((e => e._isMember(t))).forEach((e => e._trigger(r, n, s))), this.stateChangeCallbacks.message.forEach((t => t(e)))
        }))
    }
    async _onConnOpen() {
        if (this.log("transport", `connected to ${this._endPointURL()}`), this._flushSendBuffer(), this.reconnectTimer.reset(), this.worker) {
            this.workerUrl ? this.log("worker", `starting worker for from ${this.workerUrl}`) : this.log("worker", "starting default worker");
            const e = this._workerObjectUrl(this.workerUrl);
            this.workerRef = new Worker(e), this.workerRef.onerror = e => {
                this.log("worker", "worker error", e.message), this.workerRef.terminate()
            }, this.workerRef.onmessage = e => {
                "keepAlive" === e.data.event && this._sendHeartbeat()
            }, this.workerRef.postMessage({
                event: "start",
                interval: this.heartbeatIntervalMs
            })
        } else this.heartbeatTimer && clearInterval(this.heartbeatTimer), this.heartbeatTimer = setInterval((() => this._sendHeartbeat()), this.heartbeatIntervalMs);
        this.stateChangeCallbacks.open.forEach((e => e()))
    }
    _onConnClose(e) {
        this.log("transport", "close", e), this._triggerChanError(), this.heartbeatTimer && clearInterval(this.heartbeatTimer), this.reconnectTimer.scheduleTimeout(), this.stateChangeCallbacks.close.forEach((t => t(e)))
    }
    _onConnError(e) {
        this.log("transport", e.message), this._triggerChanError(), this.stateChangeCallbacks.error.forEach((t => t(e)))
    }
    _triggerChanError() {
        this.channels.forEach((e => e._trigger(Pl.error)))
    }
    _appendParams(e, t) {
        if (0 === Object.keys(t).length) return e;
        const r = e.match(/\?/) ? "&" : "?";
        return `${e}${r}${new URLSearchParams(t)}`
    }
    _flushSendBuffer() {
        this.isConnected() && this.sendBuffer.length > 0 && (this.sendBuffer.forEach((e => e())), this.sendBuffer = [])
    }
    _sendHeartbeat() {
        var e;
        if (this.isConnected()) {
            if (this.pendingHeartbeatRef) return this.pendingHeartbeatRef = null, this.log("transport", "heartbeat timeout. Attempting to re-establish connection"), void(null === (e = this.conn) || void 0 === e || e.close(1e3, "hearbeat timeout"));
            this.pendingHeartbeatRef = this._makeRef(), this.push({
                topic: "phoenix",
                event: "heartbeat",
                payload: {},
                ref: this.pendingHeartbeatRef
            }), this.setAuth(this.accessToken)
        }
    }
    _workerObjectUrl(e) {
        let t;
        if (e) t = e;
        else {
            const e = new Blob(['\n  addEventListener("message", (e) => {\n    if (e.data.event === "start") {\n      setInterval(() => postMessage({ event: "keepAlive" }), e.data.interval);\n    }\n  });'], {
                type: "application/javascript"
            });
            t = URL.createObjectURL(e)
        }
        return t
    }
}
class ac {
    constructor(e, t, r) {
        this.binaryType = "arraybuffer", this.onclose = () => {}, this.onerror = () => {}, this.onmessage = () => {}, this.onopen = () => {}, this.readyState = Sl.connecting, this.send = () => {}, this.url = null, this.url = e, this.close = r.close
    }
}
class lc extends Error {
    constructor(e) {
        super(e), this.__isStorageError = !0, this.name = "StorageError"
    }
}

function cc(e) {
    return "object" == typeof e && null !== e && "__isStorageError" in e
}
class uc extends lc {
    constructor(e, t) {
        super(e), this.name = "StorageApiError", this.status = t
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            status: this.status
        }
    }
}
class dc extends lc {
    constructor(e, t) {
        super(e), this.name = "StorageUnknownError", this.originalError = t
    }
}
var hc = function(e, t, r, n) {
    return new(r || (r = Promise))((function(s, i) {
        function o(e) {
            try {
                l(n.next(e))
            } catch (t) {
                i(t)
            }
        }

        function a(e) {
            try {
                l(n.throw(e))
            } catch (t) {
                i(t)
            }
        }

        function l(e) {
            var t;
            e.done ? s(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                e(t)
            }))).then(o, a)
        }
        l((n = n.apply(e, t || [])).next())
    }))
};
const pc = e => {
        let t;
        return t = e || ("undefined" == typeof fetch ? (...e) => C((async () => {
            const {
                default: e
            } = await Promise.resolve().then((() => Ja));
            return {
                default: e
            }
        }), void 0).then((({
            default: t
        }) => t(...e))) : fetch), (...e) => t(...e)
    },
    fc = e => {
        if (Array.isArray(e)) return e.map((e => fc(e)));
        if ("function" == typeof e || e !== Object(e)) return e;
        const t = {};
        return Object.entries(e).forEach((([e, r]) => {
            const n = e.replace(/([-_][a-z])/gi, (e => e.toUpperCase().replace(/[-_]/g, "")));
            t[n] = fc(r)
        })), t
    };
var mc = function(e, t, r, n) {
    return new(r || (r = Promise))((function(s, i) {
        function o(e) {
            try {
                l(n.next(e))
            } catch (t) {
                i(t)
            }
        }

        function a(e) {
            try {
                l(n.throw(e))
            } catch (t) {
                i(t)
            }
        }

        function l(e) {
            var t;
            e.done ? s(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                e(t)
            }))).then(o, a)
        }
        l((n = n.apply(e, t || [])).next())
    }))
};
const gc = e => e.msg || e.message || e.error_description || e.error || JSON.stringify(e),
    yc = (e, t, r) => mc(void 0, void 0, void 0, (function*() {
        const n = yield hc(void 0, void 0, void 0, (function*() {
            return "undefined" == typeof Response ? (yield C((() => Promise.resolve().then((() => Ja))), void 0)).Response : Response
        }));
        e instanceof n && !(null == r ? void 0 : r.noResolveJson) ? e.json().then((r => {
            t(new uc(gc(r), e.status || 500))
        })).catch((e => {
            t(new dc(gc(e), e))
        })) : t(new dc(gc(e), e))
    }));

function vc(e, t, r, n, s, i) {
    return mc(this, void 0, void 0, (function*() {
        return new Promise(((o, a) => {
            e(r, ((e, t, r, n) => {
                const s = {
                    method: e,
                    headers: (null == t ? void 0 : t.headers) || {}
                };
                return "GET" === e ? s : (s.headers = Object.assign({
                    "Content-Type": "application/json"
                }, null == t ? void 0 : t.headers), n && (s.body = JSON.stringify(n)), Object.assign(Object.assign({}, s), r))
            })(t, n, s, i)).then((e => {
                if (!e.ok) throw e;
                return (null == n ? void 0 : n.noResolveJson) ? e : e.json()
            })).then((e => o(e))).catch((e => yc(e, a, n)))
        }))
    }))
}

function bc(e, t, r, n) {
    return mc(this, void 0, void 0, (function*() {
        return vc(e, "GET", t, r, n)
    }))
}

function xc(e, t, r, n, s) {
    return mc(this, void 0, void 0, (function*() {
        return vc(e, "POST", t, n, s, r)
    }))
}

function wc(e, t, r, n, s) {
    return mc(this, void 0, void 0, (function*() {
        return vc(e, "DELETE", t, n, s, r)
    }))
}
var kc = function(e, t, r, n) {
    return new(r || (r = Promise))((function(s, i) {
        function o(e) {
            try {
                l(n.next(e))
            } catch (t) {
                i(t)
            }
        }

        function a(e) {
            try {
                l(n.throw(e))
            } catch (t) {
                i(t)
            }
        }

        function l(e) {
            var t;
            e.done ? s(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                e(t)
            }))).then(o, a)
        }
        l((n = n.apply(e, t || [])).next())
    }))
};
const jc = {
        limit: 100,
        offset: 0,
        sortBy: {
            column: "name",
            order: "asc"
        }
    },
    Sc = {
        cacheControl: "3600",
        contentType: "text/plain;charset=UTF-8",
        upsert: !1
    };
class Tc {
    constructor(e, t = {}, r, n) {
        this.url = e, this.headers = t, this.bucketId = r, this.fetch = pc(n)
    }
    uploadOrUpdate(e, t, r, n) {
        return kc(this, void 0, void 0, (function*() {
            try {
                let s;
                const i = Object.assign(Object.assign({}, Sc), n);
                let o = Object.assign(Object.assign({}, this.headers), "POST" === e && {
                    "x-upsert": String(i.upsert)
                });
                const a = i.metadata;
                "undefined" != typeof Blob && r instanceof Blob ? (s = new FormData, s.append("cacheControl", i.cacheControl), a && s.append("metadata", this.encodeMetadata(a)), s.append("", r)) : "undefined" != typeof FormData && r instanceof FormData ? (s = r, s.append("cacheControl", i.cacheControl), a && s.append("metadata", this.encodeMetadata(a))) : (s = r, o["cache-control"] = `max-age=${i.cacheControl}`, o["content-type"] = i.contentType, a && (o["x-metadata"] = this.toBase64(this.encodeMetadata(a)))), (null == n ? void 0 : n.headers) && (o = Object.assign(Object.assign({}, o), n.headers));
                const l = this._removeEmptyFolders(t),
                    c = this._getFinalPath(l),
                    u = yield this.fetch(`${this.url}/object/${c}`, Object.assign({
                        method: e,
                        body: s,
                        headers: o
                    }, (null == i ? void 0 : i.duplex) ? {
                        duplex: i.duplex
                    } : {})), d = yield u.json();
                if (u.ok) return {
                    data: {
                        path: l,
                        id: d.Id,
                        fullPath: d.Key
                    },
                    error: null
                };
                return {
                    data: null,
                    error: d
                }
            } catch (s) {
                if (cc(s)) return {
                    data: null,
                    error: s
                };
                throw s
            }
        }))
    }
    upload(e, t, r) {
        return kc(this, void 0, void 0, (function*() {
            return this.uploadOrUpdate("POST", e, t, r)
        }))
    }
    uploadToSignedUrl(e, t, r, n) {
        return kc(this, void 0, void 0, (function*() {
            const s = this._removeEmptyFolders(e),
                i = this._getFinalPath(s),
                o = new URL(this.url + `/object/upload/sign/${i}`);
            o.searchParams.set("token", t);
            try {
                let e;
                const t = Object.assign({
                        upsert: Sc.upsert
                    }, n),
                    i = Object.assign(Object.assign({}, this.headers), {
                        "x-upsert": String(t.upsert)
                    });
                "undefined" != typeof Blob && r instanceof Blob ? (e = new FormData, e.append("cacheControl", t.cacheControl), e.append("", r)) : "undefined" != typeof FormData && r instanceof FormData ? (e = r, e.append("cacheControl", t.cacheControl)) : (e = r, i["cache-control"] = `max-age=${t.cacheControl}`, i["content-type"] = t.contentType);
                const a = yield this.fetch(o.toString(), {
                    method: "PUT",
                    body: e,
                    headers: i
                }), l = yield a.json();
                if (a.ok) return {
                    data: {
                        path: s,
                        fullPath: l.Key
                    },
                    error: null
                };
                return {
                    data: null,
                    error: l
                }
            } catch (a) {
                if (cc(a)) return {
                    data: null,
                    error: a
                };
                throw a
            }
        }))
    }
    createSignedUploadUrl(e, t) {
        return kc(this, void 0, void 0, (function*() {
            try {
                let r = this._getFinalPath(e);
                const n = Object.assign({}, this.headers);
                (null == t ? void 0 : t.upsert) && (n["x-upsert"] = "true");
                const s = yield xc(this.fetch, `${this.url}/object/upload/sign/${r}`, {}, {
                    headers: n
                }), i = new URL(this.url + s.url), o = i.searchParams.get("token");
                if (!o) throw new lc("No token returned by API");
                return {
                    data: {
                        signedUrl: i.toString(),
                        path: e,
                        token: o
                    },
                    error: null
                }
            } catch (r) {
                if (cc(r)) return {
                    data: null,
                    error: r
                };
                throw r
            }
        }))
    }
    update(e, t, r) {
        return kc(this, void 0, void 0, (function*() {
            return this.uploadOrUpdate("PUT", e, t, r)
        }))
    }
    move(e, t, r) {
        return kc(this, void 0, void 0, (function*() {
            try {
                return {
                    data: yield xc(this.fetch, `${this.url}/object/move`, {
                        bucketId: this.bucketId,
                        sourceKey: e,
                        destinationKey: t,
                        destinationBucket: null == r ? void 0 : r.destinationBucket
                    }, {
                        headers: this.headers
                    }), error: null
                }
            } catch (n) {
                if (cc(n)) return {
                    data: null,
                    error: n
                };
                throw n
            }
        }))
    }
    copy(e, t, r) {
        return kc(this, void 0, void 0, (function*() {
            try {
                return {
                    data: {
                        path: (yield xc(this.fetch, `${this.url}/object/copy`, {
                            bucketId: this.bucketId,
                            sourceKey: e,
                            destinationKey: t,
                            destinationBucket: null == r ? void 0 : r.destinationBucket
                        }, {
                            headers: this.headers
                        })).Key
                    },
                    error: null
                }
            } catch (n) {
                if (cc(n)) return {
                    data: null,
                    error: n
                };
                throw n
            }
        }))
    }
    createSignedUrl(e, t, r) {
        return kc(this, void 0, void 0, (function*() {
            try {
                let n = this._getFinalPath(e),
                    s = yield xc(this.fetch, `${this.url}/object/sign/${n}`, Object.assign({
                        expiresIn: t
                    }, (null == r ? void 0 : r.transform) ? {
                        transform: r.transform
                    } : {}), {
                        headers: this.headers
                    });
                const i = (null == r ? void 0 : r.download) ? `&download=${!0===r.download?"":r.download}` : "";
                return s = {
                    signedUrl: encodeURI(`${this.url}${s.signedURL}${i}`)
                }, {
                    data: s,
                    error: null
                }
            } catch (n) {
                if (cc(n)) return {
                    data: null,
                    error: n
                };
                throw n
            }
        }))
    }
    createSignedUrls(e, t, r) {
        return kc(this, void 0, void 0, (function*() {
            try {
                const n = yield xc(this.fetch, `${this.url}/object/sign/${this.bucketId}`, {
                    expiresIn: t,
                    paths: e
                }, {
                    headers: this.headers
                }), s = (null == r ? void 0 : r.download) ? `&download=${!0===r.download?"":r.download}` : "";
                return {
                    data: n.map((e => Object.assign(Object.assign({}, e), {
                        signedUrl: e.signedURL ? encodeURI(`${this.url}${e.signedURL}${s}`) : null
                    }))),
                    error: null
                }
            } catch (n) {
                if (cc(n)) return {
                    data: null,
                    error: n
                };
                throw n
            }
        }))
    }
    download(e, t) {
        return kc(this, void 0, void 0, (function*() {
            const r = void 0 !== (null == t ? void 0 : t.transform) ? "render/image/authenticated" : "object",
                n = this.transformOptsToQueryString((null == t ? void 0 : t.transform) || {}),
                s = n ? `?${n}` : "";
            try {
                const t = this._getFinalPath(e),
                    n = yield bc(this.fetch, `${this.url}/${r}/${t}${s}`, {
                        headers: this.headers,
                        noResolveJson: !0
                    });
                return {
                    data: yield n.blob(), error: null
                }
            } catch (i) {
                if (cc(i)) return {
                    data: null,
                    error: i
                };
                throw i
            }
        }))
    }
    info(e) {
        return kc(this, void 0, void 0, (function*() {
            const t = this._getFinalPath(e);
            try {
                const e = yield bc(this.fetch, `${this.url}/object/info/${t}`, {
                    headers: this.headers
                });
                return {
                    data: fc(e),
                    error: null
                }
            } catch (r) {
                if (cc(r)) return {
                    data: null,
                    error: r
                };
                throw r
            }
        }))
    }
    exists(e) {
        return kc(this, void 0, void 0, (function*() {
            const t = this._getFinalPath(e);
            try {
                return yield function(e, t, r, n) {
                    return mc(this, void 0, void 0, (function*() {
                        return vc(e, "HEAD", t, Object.assign(Object.assign({}, r), {
                            noResolveJson: !0
                        }), n)
                    }))
                }(this.fetch, `${this.url}/object/${t}`, {
                    headers: this.headers
                }), {
                    data: !0,
                    error: null
                }
            } catch (r) {
                if (cc(r) && r instanceof dc) {
                    const e = r.originalError;
                    if ([400, 404].includes(null == e ? void 0 : e.status)) return {
                        data: !1,
                        error: r
                    }
                }
                throw r
            }
        }))
    }
    getPublicUrl(e, t) {
        const r = this._getFinalPath(e),
            n = [],
            s = (null == t ? void 0 : t.download) ? `download=${!0===t.download?"":t.download}` : "";
        "" !== s && n.push(s);
        const i = void 0 !== (null == t ? void 0 : t.transform) ? "render/image" : "object",
            o = this.transformOptsToQueryString((null == t ? void 0 : t.transform) || {});
        "" !== o && n.push(o);
        let a = n.join("&");
        return "" !== a && (a = `?${a}`), {
            data: {
                publicUrl: encodeURI(`${this.url}/${i}/public/${r}${a}`)
            }
        }
    }
    remove(e) {
        return kc(this, void 0, void 0, (function*() {
            try {
                return {
                    data: yield wc(this.fetch, `${this.url}/object/${this.bucketId}`, {
                        prefixes: e
                    }, {
                        headers: this.headers
                    }), error: null
                }
            } catch (t) {
                if (cc(t)) return {
                    data: null,
                    error: t
                };
                throw t
            }
        }))
    }
    list(e, t, r) {
        return kc(this, void 0, void 0, (function*() {
            try {
                const n = Object.assign(Object.assign(Object.assign({}, jc), t), {
                    prefix: e || ""
                });
                return {
                    data: yield xc(this.fetch, `${this.url}/object/list/${this.bucketId}`, n, {
                        headers: this.headers
                    }, r), error: null
                }
            } catch (n) {
                if (cc(n)) return {
                    data: null,
                    error: n
                };
                throw n
            }
        }))
    }
    encodeMetadata(e) {
        return JSON.stringify(e)
    }
    toBase64(e) {
        return "undefined" != typeof Buffer ? Buffer.from(e).toString("base64") : btoa(e)
    }
    _getFinalPath(e) {
        return `${this.bucketId}/${e}`
    }
    _removeEmptyFolders(e) {
        return e.replace(/^\/|\/$/g, "").replace(/\/+/g, "/")
    }
    transformOptsToQueryString(e) {
        const t = [];
        return e.width && t.push(`width=${e.width}`), e.height && t.push(`height=${e.height}`), e.resize && t.push(`resize=${e.resize}`), e.format && t.push(`format=${e.format}`), e.quality && t.push(`quality=${e.quality}`), t.join("&")
    }
}
const _c = {
    "X-Client-Info": "storage-js/2.7.1"
};
var Ec = function(e, t, r, n) {
    return new(r || (r = Promise))((function(s, i) {
        function o(e) {
            try {
                l(n.next(e))
            } catch (t) {
                i(t)
            }
        }

        function a(e) {
            try {
                l(n.throw(e))
            } catch (t) {
                i(t)
            }
        }

        function l(e) {
            var t;
            e.done ? s(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                e(t)
            }))).then(o, a)
        }
        l((n = n.apply(e, t || [])).next())
    }))
};
class Pc {
    constructor(e, t = {}, r) {
        this.url = e, this.headers = Object.assign(Object.assign({}, _c), t), this.fetch = pc(r)
    }
    listBuckets() {
        return Ec(this, void 0, void 0, (function*() {
            try {
                return {
                    data: yield bc(this.fetch, `${this.url}/bucket`, {
                        headers: this.headers
                    }), error: null
                }
            } catch (e) {
                if (cc(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }))
    }
    getBucket(e) {
        return Ec(this, void 0, void 0, (function*() {
            try {
                return {
                    data: yield bc(this.fetch, `${this.url}/bucket/${e}`, {
                        headers: this.headers
                    }), error: null
                }
            } catch (t) {
                if (cc(t)) return {
                    data: null,
                    error: t
                };
                throw t
            }
        }))
    }
    createBucket(e, t = {
        public: !1
    }) {
        return Ec(this, void 0, void 0, (function*() {
            try {
                return {
                    data: yield xc(this.fetch, `${this.url}/bucket`, {
                        id: e,
                        name: e,
                        public: t.public,
                        file_size_limit: t.fileSizeLimit,
                        allowed_mime_types: t.allowedMimeTypes
                    }, {
                        headers: this.headers
                    }), error: null
                }
            } catch (r) {
                if (cc(r)) return {
                    data: null,
                    error: r
                };
                throw r
            }
        }))
    }
    updateBucket(e, t) {
        return Ec(this, void 0, void 0, (function*() {
            try {
                const r = yield function(e, t, r, n, s) {
                    return mc(this, void 0, void 0, (function*() {
                        return vc(e, "PUT", t, n, s, r)
                    }))
                }(this.fetch, `${this.url}/bucket/${e}`, {
                    id: e,
                    name: e,
                    public: t.public,
                    file_size_limit: t.fileSizeLimit,
                    allowed_mime_types: t.allowedMimeTypes
                }, {
                    headers: this.headers
                });
                return {
                    data: r,
                    error: null
                }
            } catch (r) {
                if (cc(r)) return {
                    data: null,
                    error: r
                };
                throw r
            }
        }))
    }
    emptyBucket(e) {
        return Ec(this, void 0, void 0, (function*() {
            try {
                return {
                    data: yield xc(this.fetch, `${this.url}/bucket/${e}/empty`, {}, {
                        headers: this.headers
                    }), error: null
                }
            } catch (t) {
                if (cc(t)) return {
                    data: null,
                    error: t
                };
                throw t
            }
        }))
    }
    deleteBucket(e) {
        return Ec(this, void 0, void 0, (function*() {
            try {
                return {
                    data: yield wc(this.fetch, `${this.url}/bucket/${e}`, {}, {
                        headers: this.headers
                    }), error: null
                }
            } catch (t) {
                if (cc(t)) return {
                    data: null,
                    error: t
                };
                throw t
            }
        }))
    }
}
class Cc extends Pc {
    constructor(e, t = {}, r) {
        super(e, t, r)
    }
    from(e) {
        return new Tc(this.url, this.headers, e, this.fetch)
    }
}
let Oc = "";
Oc = "undefined" != typeof Deno ? "deno" : "undefined" != typeof document ? "web" : "undefined" != typeof navigator && "ReactNative" === navigator.product ? "react-native" : "node";
const Ac = {
        headers: {
            "X-Client-Info": `supabase-js-${Oc}/2.45.6`
        }
    },
    Nc = {
        schema: "public"
    },
    Rc = {
        autoRefreshToken: !0,
        persistSession: !0,
        detectSessionInUrl: !0,
        flowType: "implicit"
    },
    Ic = {};
var Lc = function(e, t, r, n) {
    return new(r || (r = Promise))((function(s, i) {
        function o(e) {
            try {
                l(n.next(e))
            } catch (t) {
                i(t)
            }
        }

        function a(e) {
            try {
                l(n.throw(e))
            } catch (t) {
                i(t)
            }
        }

        function l(e) {
            var t;
            e.done ? s(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                e(t)
            }))).then(o, a)
        }
        l((n = n.apply(e, t || [])).next())
    }))
};
const Mc = (e, t, r) => {
    const n = (e => {
            let t;
            return t = e || ("undefined" == typeof fetch ? qa : fetch), (...e) => t(...e)
        })(r),
        s = "undefined" == typeof Headers ? Ka : Headers;
    return (r, i) => Lc(void 0, void 0, void 0, (function*() {
        var o;
        const a = null !== (o = yield t()) && void 0 !== o ? o : e;
        let l = new s(null == i ? void 0 : i.headers);
        return l.has("apikey") || l.set("apikey", e), l.has("Authorization") || l.set("Authorization", `Bearer ${a}`), n(r, Object.assign(Object.assign({}, i), {
            headers: l
        }))
    }))
};
var Uc = function(e, t, r, n) {
    return new(r || (r = Promise))((function(s, i) {
        function o(e) {
            try {
                l(n.next(e))
            } catch (t) {
                i(t)
            }
        }

        function a(e) {
            try {
                l(n.throw(e))
            } catch (t) {
                i(t)
            }
        }

        function l(e) {
            var t;
            e.done ? s(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                e(t)
            }))).then(o, a)
        }
        l((n = n.apply(e, t || [])).next())
    }))
};
const Dc = "2.65.1",
    $c = {
        "X-Client-Info": `gotrue-js/${Dc}`
    },
    Fc = "X-Supabase-Api-Version",
    Vc = {
        timestamp: Date.parse("2024-01-01T00:00:00.0Z"),
        name: "2024-01-01"
    };
const Bc = () => "undefined" != typeof document,
    zc = {
        tested: !1,
        writable: !1
    },
    Wc = () => {
        if (!Bc()) return !1;
        try {
            if ("object" != typeof globalThis.localStorage) return !1
        } catch (t) {
            return !1
        }
        if (zc.tested) return zc.writable;
        const e = `lswt-${Math.random()}${Math.random()}`;
        try {
            globalThis.localStorage.setItem(e, e), globalThis.localStorage.removeItem(e), zc.tested = !0, zc.writable = !0
        } catch (t) {
            zc.tested = !0, zc.writable = !1
        }
        return zc.writable
    };

function Hc(e) {
    const t = {},
        r = new URL(e);
    if (r.hash && "#" === r.hash[0]) try {
        new URLSearchParams(r.hash.substring(1)).forEach(((e, r) => {
            t[r] = e
        }))
    } catch (n) {}
    return r.searchParams.forEach(((e, r) => {
        t[r] = e
    })), t
}
const qc = e => {
        let t;
        return t = e || ("undefined" == typeof fetch ? (...e) => C((async () => {
            const {
                default: e
            } = await Promise.resolve().then((() => Ja));
            return {
                default: e
            }
        }), void 0).then((({
            default: t
        }) => t(...e))) : fetch), (...e) => t(...e)
    },
    Kc = async (e, t, r) => {
        await e.setItem(t, JSON.stringify(r))
    },
    Gc = async (e, t) => {
        const r = await e.getItem(t);
        if (!r) return null;
        try {
            return JSON.parse(r)
        } catch (Rw) {
            return r
        }
    },
    Yc = async (e, t) => {
        await e.removeItem(t)
    };
class Jc {
    constructor() {
        this.promise = new Jc.promiseConstructor(((e, t) => {
            this.resolve = e, this.reject = t
        }))
    }
}

function Xc(e) {
    const t = e.split(".");
    if (3 !== t.length) throw new Error("JWT is not valid: not a JWT structure");
    if (!/^([a-z0-9_-]{4})*($|[a-z0-9_-]{3}=?$|[a-z0-9_-]{2}(==)?$)$/i.test(t[1])) throw new Error("JWT is not valid: payload is not in base64url format");
    const r = t[1];
    return JSON.parse(function(e) {
        const t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
        let r, n, s, i, o, a, l, c = "",
            u = 0;
        for (e = e.replace("-", "+").replace("_", "/"); u < e.length;) i = t.indexOf(e.charAt(u++)), o = t.indexOf(e.charAt(u++)), a = t.indexOf(e.charAt(u++)), l = t.indexOf(e.charAt(u++)), r = i << 2 | o >> 4, n = (15 & o) << 4 | a >> 2, s = (3 & a) << 6 | l, c += String.fromCharCode(r), 64 != a && 0 != n && (c += String.fromCharCode(n)), 64 != l && 0 != s && (c += String.fromCharCode(s));
        return c
    }(r))
}

function Zc(e) {
    return ("0" + e.toString(16)).substr(-2)
}
async function Qc(e) {
    if (!("undefined" != typeof crypto && void 0 !== crypto.subtle && "undefined" != typeof TextEncoder)) return console.warn("WebCrypto API is not supported. Code challenge method will default to use plain instead of sha256."), e;
    const t = await async function(e) {
        const t = (new TextEncoder).encode(e),
            r = await crypto.subtle.digest("SHA-256", t),
            n = new Uint8Array(r);
        return Array.from(n).map((e => String.fromCharCode(e))).join("")
    }(e);
    return btoa(t).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
}
async function eu(e, t, r = !1) {
    const n = function() {
        const e = new Uint32Array(56);
        if ("undefined" == typeof crypto) {
            const e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~",
                t = e.length;
            let r = "";
            for (let n = 0; n < 56; n++) r += e.charAt(Math.floor(Math.random() * t));
            return r
        }
        return crypto.getRandomValues(e), Array.from(e, Zc).join("")
    }();
    let s = n;
    r && (s += "/PASSWORD_RECOVERY"), await Kc(e, `${t}-code-verifier`, s);
    const i = await Qc(n);
    return [i, n === i ? "plain" : "s256"]
}
Jc.promiseConstructor = Promise;
const tu = /^2[0-9]{3}-(0[1-9]|1[0-2])-(0[1-9]|1[0-9]|2[0-9]|3[0-1])$/i;
class ru extends Error {
    constructor(e, t, r) {
        super(e), this.__isAuthError = !0, this.name = "AuthError", this.status = t, this.code = r
    }
}

function nu(e) {
    return "object" == typeof e && null !== e && "__isAuthError" in e
}
class su extends ru {
    constructor(e, t, r) {
        super(e, t, r), this.name = "AuthApiError", this.status = t, this.code = r
    }
}
class iu extends ru {
    constructor(e, t) {
        super(e), this.name = "AuthUnknownError", this.originalError = t
    }
}
class ou extends ru {
    constructor(e, t, r, n) {
        super(e, r, n), this.name = t, this.status = r
    }
}
class au extends ou {
    constructor() {
        super("Auth session missing!", "AuthSessionMissingError", 400, void 0)
    }
}
class lu extends ou {
    constructor() {
        super("Auth session or user missing", "AuthInvalidTokenResponseError", 500, void 0)
    }
}
class cu extends ou {
    constructor(e) {
        super(e, "AuthInvalidCredentialsError", 400, void 0)
    }
}
class uu extends ou {
    constructor(e, t = null) {
        super(e, "AuthImplicitGrantRedirectError", 500, void 0), this.details = null, this.details = t
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            status: this.status,
            details: this.details
        }
    }
}
class du extends ou {
    constructor(e, t = null) {
        super(e, "AuthPKCEGrantCodeExchangeError", 500, void 0), this.details = null, this.details = t
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            status: this.status,
            details: this.details
        }
    }
}
class hu extends ou {
    constructor(e, t) {
        super(e, "AuthRetryableFetchError", t, void 0)
    }
}

function pu(e) {
    return nu(e) && "AuthRetryableFetchError" === e.name
}
class fu extends ou {
    constructor(e, t, r) {
        super(e, "AuthWeakPasswordError", t, "weak_password"), this.reasons = r
    }
}
const mu = e => e.msg || e.message || e.error_description || e.error || JSON.stringify(e),
    gu = [502, 503, 504];
async function yu(e) {
    var t, r;
    if (!("object" == typeof(r = e) && null !== r && "status" in r && "ok" in r && "json" in r && "function" == typeof r.json)) throw new hu(mu(e), 0);
    if (gu.includes(e.status)) throw new hu(mu(e), e.status);
    let n, s;
    try {
        n = await e.json()
    } catch (o) {
        throw new iu(mu(o), o)
    }
    const i = function(e) {
        const t = e.headers.get(Fc);
        if (!t) return null;
        if (!t.match(tu)) return null;
        try {
            return new Date(`${t}T00:00:00.0Z`)
        } catch (o) {
            return null
        }
    }(e);
    if (i && i.getTime() >= Vc.timestamp && "object" == typeof n && n && "string" == typeof n.code ? s = n.code : "object" == typeof n && n && "string" == typeof n.error_code && (s = n.error_code), s) {
        if ("weak_password" === s) throw new fu(mu(n), e.status, (null === (t = n.weak_password) || void 0 === t ? void 0 : t.reasons) || []);
        if ("session_not_found" === s) throw new au
    } else if ("object" == typeof n && n && "object" == typeof n.weak_password && n.weak_password && Array.isArray(n.weak_password.reasons) && n.weak_password.reasons.length && n.weak_password.reasons.reduce(((e, t) => e && "string" == typeof t), !0)) throw new fu(mu(n), e.status, n.weak_password.reasons);
    throw new su(mu(n), e.status || 500, s)
}
async function vu(e, t, r, n) {
    var s;
    const i = Object.assign({}, null == n ? void 0 : n.headers);
    i[Fc] || (i[Fc] = Vc.name), (null == n ? void 0 : n.jwt) && (i.Authorization = `Bearer ${n.jwt}`);
    const o = null !== (s = null == n ? void 0 : n.query) && void 0 !== s ? s : {};
    (null == n ? void 0 : n.redirectTo) && (o.redirect_to = n.redirectTo);
    const a = Object.keys(o).length ? "?" + new URLSearchParams(o).toString() : "",
        l = await async function(e, t, r, n, s, i) {
            const o = ((e, t, r, n) => {
                const s = {
                    method: e,
                    headers: (null == t ? void 0 : t.headers) || {}
                };
                return "GET" === e ? s : (s.headers = Object.assign({
                    "Content-Type": "application/json;charset=UTF-8"
                }, null == t ? void 0 : t.headers), s.body = JSON.stringify(n), Object.assign(Object.assign({}, s), r))
            })(t, n, s, i);
            let a;
            try {
                a = await e(r, Object.assign({}, o))
            } catch (l) {
                throw console.error(l), new hu(mu(l), 0)
            }
            a.ok || await yu(a);
            if (null == n ? void 0 : n.noResolveJson) return a;
            try {
                return await a.json()
            } catch (l) {
                await yu(l)
            }
        }(e, t, r + a, {
            headers: i,
            noResolveJson: null == n ? void 0 : n.noResolveJson
        }, {}, null == n ? void 0 : n.body);
    return (null == n ? void 0 : n.xform) ? null == n ? void 0 : n.xform(l) : {
        data: Object.assign({}, l),
        error: null
    }
}

function bu(e) {
    var t;
    let r = null;
    var n;
    (function(e) {
        return e.access_token && e.refresh_token && e.expires_in
    })(e) && (r = Object.assign({}, e), e.expires_at || (r.expires_at = (n = e.expires_in, Math.round(Date.now() / 1e3) + n)));
    return {
        data: {
            session: r,
            user: null !== (t = e.user) && void 0 !== t ? t : e
        },
        error: null
    }
}

function xu(e) {
    const t = bu(e);
    return !t.error && e.weak_password && "object" == typeof e.weak_password && Array.isArray(e.weak_password.reasons) && e.weak_password.reasons.length && e.weak_password.message && "string" == typeof e.weak_password.message && e.weak_password.reasons.reduce(((e, t) => e && "string" == typeof t), !0) && (t.data.weak_password = e.weak_password), t
}

function wu(e) {
    var t;
    return {
        data: {
            user: null !== (t = e.user) && void 0 !== t ? t : e
        },
        error: null
    }
}

function ku(e) {
    return {
        data: e,
        error: null
    }
}

function ju(e) {
    const {
        action_link: t,
        email_otp: r,
        hashed_token: n,
        redirect_to: s,
        verification_type: i
    } = e, o = function(e, t) {
        var r = {};
        for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
        if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
            var s = 0;
            for (n = Object.getOwnPropertySymbols(e); s < n.length; s++) t.indexOf(n[s]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[s]) && (r[n[s]] = e[n[s]])
        }
        return r
    }(e, ["action_link", "email_otp", "hashed_token", "redirect_to", "verification_type"]);
    return {
        data: {
            properties: {
                action_link: t,
                email_otp: r,
                hashed_token: n,
                redirect_to: s,
                verification_type: i
            },
            user: Object.assign({}, o)
        },
        error: null
    }
}

function Su(e) {
    return e
}
class Tu {
    constructor({
        url: e = "",
        headers: t = {},
        fetch: r
    }) {
        this.url = e, this.headers = t, this.fetch = qc(r), this.mfa = {
            listFactors: this._listFactors.bind(this),
            deleteFactor: this._deleteFactor.bind(this)
        }
    }
    async signOut(e, t = "global") {
        try {
            return await vu(this.fetch, "POST", `${this.url}/logout?scope=${t}`, {
                headers: this.headers,
                jwt: e,
                noResolveJson: !0
            }), {
                data: null,
                error: null
            }
        } catch (r) {
            if (nu(r)) return {
                data: null,
                error: r
            };
            throw r
        }
    }
    async inviteUserByEmail(e, t = {}) {
        try {
            return await vu(this.fetch, "POST", `${this.url}/invite`, {
                body: {
                    email: e,
                    data: t.data
                },
                headers: this.headers,
                redirectTo: t.redirectTo,
                xform: wu
            })
        } catch (r) {
            if (nu(r)) return {
                data: {
                    user: null
                },
                error: r
            };
            throw r
        }
    }
    async generateLink(e) {
        try {
            const {
                options: t
            } = e, r = function(e, t) {
                var r = {};
                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                    var s = 0;
                    for (n = Object.getOwnPropertySymbols(e); s < n.length; s++) t.indexOf(n[s]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[s]) && (r[n[s]] = e[n[s]])
                }
                return r
            }(e, ["options"]), n = Object.assign(Object.assign({}, r), t);
            return "newEmail" in r && (n.new_email = null == r ? void 0 : r.newEmail, delete n.newEmail), await vu(this.fetch, "POST", `${this.url}/admin/generate_link`, {
                body: n,
                headers: this.headers,
                xform: ju,
                redirectTo: null == t ? void 0 : t.redirectTo
            })
        } catch (t) {
            if (nu(t)) return {
                data: {
                    properties: null,
                    user: null
                },
                error: t
            };
            throw t
        }
    }
    async createUser(e) {
        try {
            return await vu(this.fetch, "POST", `${this.url}/admin/users`, {
                body: e,
                headers: this.headers,
                xform: wu
            })
        } catch (t) {
            if (nu(t)) return {
                data: {
                    user: null
                },
                error: t
            };
            throw t
        }
    }
    async listUsers(e) {
        var t, r, n, s, i, o, a;
        try {
            const l = {
                    nextPage: null,
                    lastPage: 0,
                    total: 0
                },
                c = await vu(this.fetch, "GET", `${this.url}/admin/users`, {
                    headers: this.headers,
                    noResolveJson: !0,
                    query: {
                        page: null !== (r = null === (t = null == e ? void 0 : e.page) || void 0 === t ? void 0 : t.toString()) && void 0 !== r ? r : "",
                        per_page: null !== (s = null === (n = null == e ? void 0 : e.perPage) || void 0 === n ? void 0 : n.toString()) && void 0 !== s ? s : ""
                    },
                    xform: Su
                });
            if (c.error) throw c.error;
            const u = await c.json(),
                d = null !== (i = c.headers.get("x-total-count")) && void 0 !== i ? i : 0,
                h = null !== (a = null === (o = c.headers.get("link")) || void 0 === o ? void 0 : o.split(",")) && void 0 !== a ? a : [];
            return h.length > 0 && (h.forEach((e => {
                const t = parseInt(e.split(";")[0].split("=")[1].substring(0, 1)),
                    r = JSON.parse(e.split(";")[1].split("=")[1]);
                l[`${r}Page`] = t
            })), l.total = parseInt(d)), {
                data: Object.assign(Object.assign({}, u), l),
                error: null
            }
        } catch (l) {
            if (nu(l)) return {
                data: {
                    users: []
                },
                error: l
            };
            throw l
        }
    }
    async getUserById(e) {
        try {
            return await vu(this.fetch, "GET", `${this.url}/admin/users/${e}`, {
                headers: this.headers,
                xform: wu
            })
        } catch (t) {
            if (nu(t)) return {
                data: {
                    user: null
                },
                error: t
            };
            throw t
        }
    }
    async updateUserById(e, t) {
        try {
            return await vu(this.fetch, "PUT", `${this.url}/admin/users/${e}`, {
                body: t,
                headers: this.headers,
                xform: wu
            })
        } catch (r) {
            if (nu(r)) return {
                data: {
                    user: null
                },
                error: r
            };
            throw r
        }
    }
    async deleteUser(e, t = !1) {
        try {
            return await vu(this.fetch, "DELETE", `${this.url}/admin/users/${e}`, {
                headers: this.headers,
                body: {
                    should_soft_delete: t
                },
                xform: wu
            })
        } catch (r) {
            if (nu(r)) return {
                data: {
                    user: null
                },
                error: r
            };
            throw r
        }
    }
    async _listFactors(e) {
        try {
            const {
                data: t,
                error: r
            } = await vu(this.fetch, "GET", `${this.url}/admin/users/${e.userId}/factors`, {
                headers: this.headers,
                xform: e => ({
                    data: {
                        factors: e
                    },
                    error: null
                })
            });
            return {
                data: t,
                error: r
            }
        } catch (t) {
            if (nu(t)) return {
                data: null,
                error: t
            };
            throw t
        }
    }
    async _deleteFactor(e) {
        try {
            return {
                data: await vu(this.fetch, "DELETE", `${this.url}/admin/users/${e.userId}/factors/${e.id}`, {
                    headers: this.headers
                }),
                error: null
            }
        } catch (t) {
            if (nu(t)) return {
                data: null,
                error: t
            };
            throw t
        }
    }
}
const _u = {
    getItem: e => Wc() ? globalThis.localStorage.getItem(e) : null,
    setItem: (e, t) => {
        Wc() && globalThis.localStorage.setItem(e, t)
    },
    removeItem: e => {
        Wc() && globalThis.localStorage.removeItem(e)
    }
};

function Eu(e = {}) {
    return {
        getItem: t => e[t] || null,
        setItem: (t, r) => {
            e[t] = r
        },
        removeItem: t => {
            delete e[t]
        }
    }
}
const Pu = !!(globalThis && Wc() && globalThis.localStorage && "true" === globalThis.localStorage.getItem("supabase.gotrue-js.locks.debug"));
class Cu extends Error {
    constructor(e) {
        super(e), this.isAcquireTimeout = !0
    }
}
class Ou extends Cu {}
async function Au(e, t, r) {
    Pu && console.log("@supabase/gotrue-js: navigatorLock: acquire lock", e, t);
    const n = new globalThis.AbortController;
    return t > 0 && setTimeout((() => {
        n.abort(), Pu && console.log("@supabase/gotrue-js: navigatorLock acquire timed out", e)
    }), t), await globalThis.navigator.locks.request(e, 0 === t ? {
        mode: "exclusive",
        ifAvailable: !0
    } : {
        mode: "exclusive",
        signal: n.signal
    }, (async n => {
        if (!n) {
            if (0 === t) throw Pu && console.log("@supabase/gotrue-js: navigatorLock: not immediately available", e), new Ou(`Acquiring an exclusive Navigator LockManager lock "${e}" immediately failed`);
            if (Pu) try {
                const e = await globalThis.navigator.locks.query();
                console.log("@supabase/gotrue-js: Navigator LockManager state", JSON.stringify(e, null, "  "))
            } catch (s) {
                console.warn("@supabase/gotrue-js: Error when querying Navigator LockManager state", s)
            }
            return console.warn("@supabase/gotrue-js: Navigator LockManager returned a null lock when using #request without ifAvailable set to true, it appears this browser is not following the LockManager spec https://developer.mozilla.org/en-US/docs/Web/API/LockManager/request"), await r()
        }
        Pu && console.log("@supabase/gotrue-js: navigatorLock: acquired", e, n.name);
        try {
            return await r()
        } finally {
            Pu && console.log("@supabase/gotrue-js: navigatorLock: released", e, n.name)
        }
    }))
}! function() {
    if ("object" != typeof globalThis) try {
        Object.defineProperty(Object.prototype, "__magic__", {
            get: function() {
                return this
            },
            configurable: !0
        }), __magic__.globalThis = __magic__, delete Object.prototype.__magic__
    } catch (e) {
        "undefined" != typeof self && (self.globalThis = self)
    }
}();
const Nu = {
        url: "http://localhost:9999",
        storageKey: "supabase.auth.token",
        autoRefreshToken: !0,
        persistSession: !0,
        detectSessionInUrl: !0,
        headers: $c,
        flowType: "implicit",
        debug: !1,
        hasCustomAuthorizationHeader: !1
    },
    Ru = 3e4;
async function Iu(e, t, r) {
    return await r()
}
class Lu {
    constructor(e) {
        var t, r;
        this.memoryStorage = null, this.stateChangeEmitters = new Map, this.autoRefreshTicker = null, this.visibilityChangedCallback = null, this.refreshingDeferred = null, this.initializePromise = null, this.detectSessionInUrl = !0, this.hasCustomAuthorizationHeader = !1, this.suppressGetSessionWarning = !1, this.lockAcquired = !1, this.pendingInLock = [], this.broadcastChannel = null, this.logger = console.log, this.instanceID = Lu.nextInstanceID, Lu.nextInstanceID += 1, this.instanceID > 0 && Bc() && console.warn("Multiple GoTrueClient instances detected in the same browser context. It is not an error, but this should be avoided as it may produce undefined behavior when used concurrently under the same storage key.");
        const n = Object.assign(Object.assign({}, Nu), e);
        if (this.logDebugMessages = !!n.debug, "function" == typeof n.debug && (this.logger = n.debug), this.persistSession = n.persistSession, this.storageKey = n.storageKey, this.autoRefreshToken = n.autoRefreshToken, this.admin = new Tu({
                url: n.url,
                headers: n.headers,
                fetch: n.fetch
            }), this.url = n.url, this.headers = n.headers, this.fetch = qc(n.fetch), this.lock = n.lock || Iu, this.detectSessionInUrl = n.detectSessionInUrl, this.flowType = n.flowType, this.hasCustomAuthorizationHeader = n.hasCustomAuthorizationHeader, n.lock ? this.lock = n.lock : Bc() && (null === (t = null === globalThis || void 0 === globalThis ? void 0 : globalThis.navigator) || void 0 === t ? void 0 : t.locks) ? this.lock = Au : this.lock = Iu, this.mfa = {
                verify: this._verify.bind(this),
                enroll: this._enroll.bind(this),
                unenroll: this._unenroll.bind(this),
                challenge: this._challenge.bind(this),
                listFactors: this._listFactors.bind(this),
                challengeAndVerify: this._challengeAndVerify.bind(this),
                getAuthenticatorAssuranceLevel: this._getAuthenticatorAssuranceLevel.bind(this)
            }, this.persistSession ? n.storage ? this.storage = n.storage : Wc() ? this.storage = _u : (this.memoryStorage = {}, this.storage = Eu(this.memoryStorage)) : (this.memoryStorage = {}, this.storage = Eu(this.memoryStorage)), Bc() && globalThis.BroadcastChannel && this.persistSession && this.storageKey) {
            try {
                this.broadcastChannel = new globalThis.BroadcastChannel(this.storageKey)
            } catch (s) {
                console.error("Failed to create a new BroadcastChannel, multi-tab state changes will not be available", s)
            }
            null === (r = this.broadcastChannel) || void 0 === r || r.addEventListener("message", (async e => {
                this._debug("received broadcast notification from other tab or client", e), await this._notifyAllSubscribers(e.data.event, e.data.session, !1)
            }))
        }
        this.initialize()
    }
    _debug(...e) {
        return this.logDebugMessages && this.logger(`GoTrueClient@${this.instanceID} (${Dc}) ${(new Date).toISOString()}`, ...e), this
    }
    async initialize() {
        return this.initializePromise || (this.initializePromise = (async () => await this._acquireLock(-1, (async () => await this._initialize())))()), await this.initializePromise
    }
    async _initialize() {
        try {
            const e = !!Bc() && await this._isPKCEFlow();
            if (this._debug("#_initialize()", "begin", "is PKCE flow", e), e || this.detectSessionInUrl && this._isImplicitGrantFlow()) {
                const {
                    data: t,
                    error: r
                } = await this._getSessionFromURL(e);
                if (r) return this._debug("#_initialize()", "error detecting session from URL", r), "identity_already_exists" === (null == r ? void 0 : r.code) || await this._removeSession(), {
                    error: r
                };
                const {
                    session: n,
                    redirectType: s
                } = t;
                return this._debug("#_initialize()", "detected session in URL", n, "redirect type", s), await this._saveSession(n), setTimeout((async () => {
                    "recovery" === s ? await this._notifyAllSubscribers("PASSWORD_RECOVERY", n) : await this._notifyAllSubscribers("SIGNED_IN", n)
                }), 0), {
                    error: null
                }
            }
            return await this._recoverAndRefresh(), {
                error: null
            }
        } catch (e) {
            return nu(e) ? {
                error: e
            } : {
                error: new iu("Unexpected error during initialization", e)
            }
        } finally {
            await this._handleVisibilityChange(), this._debug("#_initialize()", "end")
        }
    }
    async signInAnonymously(e) {
        var t, r, n;
        try {
            const s = await vu(this.fetch, "POST", `${this.url}/signup`, {
                    headers: this.headers,
                    body: {
                        data: null !== (r = null === (t = null == e ? void 0 : e.options) || void 0 === t ? void 0 : t.data) && void 0 !== r ? r : {},
                        gotrue_meta_security: {
                            captcha_token: null === (n = null == e ? void 0 : e.options) || void 0 === n ? void 0 : n.captchaToken
                        }
                    },
                    xform: bu
                }),
                {
                    data: i,
                    error: o
                } = s;
            if (o || !i) return {
                data: {
                    user: null,
                    session: null
                },
                error: o
            };
            const a = i.session,
                l = i.user;
            return i.session && (await this._saveSession(i.session), await this._notifyAllSubscribers("SIGNED_IN", a)), {
                data: {
                    user: l,
                    session: a
                },
                error: null
            }
        } catch (s) {
            if (nu(s)) return {
                data: {
                    user: null,
                    session: null
                },
                error: s
            };
            throw s
        }
    }
    async signUp(e) {
        var t, r, n;
        try {
            let s;
            if ("email" in e) {
                const {
                    email: r,
                    password: n,
                    options: i
                } = e;
                let o = null,
                    a = null;
                "pkce" === this.flowType && ([o, a] = await eu(this.storage, this.storageKey)), s = await vu(this.fetch, "POST", `${this.url}/signup`, {
                    headers: this.headers,
                    redirectTo: null == i ? void 0 : i.emailRedirectTo,
                    body: {
                        email: r,
                        password: n,
                        data: null !== (t = null == i ? void 0 : i.data) && void 0 !== t ? t : {},
                        gotrue_meta_security: {
                            captcha_token: null == i ? void 0 : i.captchaToken
                        },
                        code_challenge: o,
                        code_challenge_method: a
                    },
                    xform: bu
                })
            } else {
                if (!("phone" in e)) throw new cu("You must provide either an email or phone number and a password"); {
                    const {
                        phone: t,
                        password: i,
                        options: o
                    } = e;
                    s = await vu(this.fetch, "POST", `${this.url}/signup`, {
                        headers: this.headers,
                        body: {
                            phone: t,
                            password: i,
                            data: null !== (r = null == o ? void 0 : o.data) && void 0 !== r ? r : {},
                            channel: null !== (n = null == o ? void 0 : o.channel) && void 0 !== n ? n : "sms",
                            gotrue_meta_security: {
                                captcha_token: null == o ? void 0 : o.captchaToken
                            }
                        },
                        xform: bu
                    })
                }
            }
            const {
                data: i,
                error: o
            } = s;
            if (o || !i) return {
                data: {
                    user: null,
                    session: null
                },
                error: o
            };
            const a = i.session,
                l = i.user;
            return i.session && (await this._saveSession(i.session), await this._notifyAllSubscribers("SIGNED_IN", a)), {
                data: {
                    user: l,
                    session: a
                },
                error: null
            }
        } catch (s) {
            if (nu(s)) return {
                data: {
                    user: null,
                    session: null
                },
                error: s
            };
            throw s
        }
    }
    async signInWithPassword(e) {
        try {
            let t;
            if ("email" in e) {
                const {
                    email: r,
                    password: n,
                    options: s
                } = e;
                t = await vu(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
                    headers: this.headers,
                    body: {
                        email: r,
                        password: n,
                        gotrue_meta_security: {
                            captcha_token: null == s ? void 0 : s.captchaToken
                        }
                    },
                    xform: xu
                })
            } else {
                if (!("phone" in e)) throw new cu("You must provide either an email or phone number and a password"); {
                    const {
                        phone: r,
                        password: n,
                        options: s
                    } = e;
                    t = await vu(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
                        headers: this.headers,
                        body: {
                            phone: r,
                            password: n,
                            gotrue_meta_security: {
                                captcha_token: null == s ? void 0 : s.captchaToken
                            }
                        },
                        xform: xu
                    })
                }
            }
            const {
                data: r,
                error: n
            } = t;
            return n ? {
                data: {
                    user: null,
                    session: null
                },
                error: n
            } : r && r.session && r.user ? (r.session && (await this._saveSession(r.session), await this._notifyAllSubscribers("SIGNED_IN", r.session)), {
                data: Object.assign({
                    user: r.user,
                    session: r.session
                }, r.weak_password ? {
                    weakPassword: r.weak_password
                } : null),
                error: n
            }) : {
                data: {
                    user: null,
                    session: null
                },
                error: new lu
            }
        } catch (t) {
            if (nu(t)) return {
                data: {
                    user: null,
                    session: null
                },
                error: t
            };
            throw t
        }
    }
    async signInWithOAuth(e) {
        var t, r, n, s;
        return await this._handleProviderSignIn(e.provider, {
            redirectTo: null === (t = e.options) || void 0 === t ? void 0 : t.redirectTo,
            scopes: null === (r = e.options) || void 0 === r ? void 0 : r.scopes,
            queryParams: null === (n = e.options) || void 0 === n ? void 0 : n.queryParams,
            skipBrowserRedirect: null === (s = e.options) || void 0 === s ? void 0 : s.skipBrowserRedirect
        })
    }
    async exchangeCodeForSession(e) {
        return await this.initializePromise, this._acquireLock(-1, (async () => this._exchangeCodeForSession(e)))
    }
    async _exchangeCodeForSession(e) {
        const t = await Gc(this.storage, `${this.storageKey}-code-verifier`),
            [r, n] = (null != t ? t : "").split("/");
        try {
            const {
                data: t,
                error: s
            } = await vu(this.fetch, "POST", `${this.url}/token?grant_type=pkce`, {
                headers: this.headers,
                body: {
                    auth_code: e,
                    code_verifier: r
                },
                xform: bu
            });
            if (await Yc(this.storage, `${this.storageKey}-code-verifier`), s) throw s;
            return t && t.session && t.user ? (t.session && (await this._saveSession(t.session), await this._notifyAllSubscribers("SIGNED_IN", t.session)), {
                data: Object.assign(Object.assign({}, t), {
                    redirectType: null != n ? n : null
                }),
                error: s
            }) : {
                data: {
                    user: null,
                    session: null,
                    redirectType: null
                },
                error: new lu
            }
        } catch (s) {
            if (nu(s)) return {
                data: {
                    user: null,
                    session: null,
                    redirectType: null
                },
                error: s
            };
            throw s
        }
    }
    async signInWithIdToken(e) {
        try {
            const {
                options: t,
                provider: r,
                token: n,
                access_token: s,
                nonce: i
            } = e, o = await vu(this.fetch, "POST", `${this.url}/token?grant_type=id_token`, {
                headers: this.headers,
                body: {
                    provider: r,
                    id_token: n,
                    access_token: s,
                    nonce: i,
                    gotrue_meta_security: {
                        captcha_token: null == t ? void 0 : t.captchaToken
                    }
                },
                xform: bu
            }), {
                data: a,
                error: l
            } = o;
            return l ? {
                data: {
                    user: null,
                    session: null
                },
                error: l
            } : a && a.session && a.user ? (a.session && (await this._saveSession(a.session), await this._notifyAllSubscribers("SIGNED_IN", a.session)), {
                data: a,
                error: l
            }) : {
                data: {
                    user: null,
                    session: null
                },
                error: new lu
            }
        } catch (t) {
            if (nu(t)) return {
                data: {
                    user: null,
                    session: null
                },
                error: t
            };
            throw t
        }
    }
    async signInWithOtp(e) {
        var t, r, n, s, i;
        try {
            if ("email" in e) {
                const {
                    email: n,
                    options: s
                } = e;
                let i = null,
                    o = null;
                "pkce" === this.flowType && ([i, o] = await eu(this.storage, this.storageKey));
                const {
                    error: a
                } = await vu(this.fetch, "POST", `${this.url}/otp`, {
                    headers: this.headers,
                    body: {
                        email: n,
                        data: null !== (t = null == s ? void 0 : s.data) && void 0 !== t ? t : {},
                        create_user: null === (r = null == s ? void 0 : s.shouldCreateUser) || void 0 === r || r,
                        gotrue_meta_security: {
                            captcha_token: null == s ? void 0 : s.captchaToken
                        },
                        code_challenge: i,
                        code_challenge_method: o
                    },
                    redirectTo: null == s ? void 0 : s.emailRedirectTo
                });
                return {
                    data: {
                        user: null,
                        session: null
                    },
                    error: a
                }
            }
            if ("phone" in e) {
                const {
                    phone: t,
                    options: r
                } = e, {
                    data: o,
                    error: a
                } = await vu(this.fetch, "POST", `${this.url}/otp`, {
                    headers: this.headers,
                    body: {
                        phone: t,
                        data: null !== (n = null == r ? void 0 : r.data) && void 0 !== n ? n : {},
                        create_user: null === (s = null == r ? void 0 : r.shouldCreateUser) || void 0 === s || s,
                        gotrue_meta_security: {
                            captcha_token: null == r ? void 0 : r.captchaToken
                        },
                        channel: null !== (i = null == r ? void 0 : r.channel) && void 0 !== i ? i : "sms"
                    }
                });
                return {
                    data: {
                        user: null,
                        session: null,
                        messageId: null == o ? void 0 : o.message_id
                    },
                    error: a
                }
            }
            throw new cu("You must provide either an email or phone number.")
        } catch (o) {
            if (nu(o)) return {
                data: {
                    user: null,
                    session: null
                },
                error: o
            };
            throw o
        }
    }
    async verifyOtp(e) {
        var t, r;
        try {
            let n, s;
            "options" in e && (n = null === (t = e.options) || void 0 === t ? void 0 : t.redirectTo, s = null === (r = e.options) || void 0 === r ? void 0 : r.captchaToken);
            const {
                data: i,
                error: o
            } = await vu(this.fetch, "POST", `${this.url}/verify`, {
                headers: this.headers,
                body: Object.assign(Object.assign({}, e), {
                    gotrue_meta_security: {
                        captcha_token: s
                    }
                }),
                redirectTo: n,
                xform: bu
            });
            if (o) throw o;
            if (!i) throw new Error("An error occurred on token verification.");
            const a = i.session,
                l = i.user;
            return (null == a ? void 0 : a.access_token) && (await this._saveSession(a), await this._notifyAllSubscribers("recovery" == e.type ? "PASSWORD_RECOVERY" : "SIGNED_IN", a)), {
                data: {
                    user: l,
                    session: a
                },
                error: null
            }
        } catch (n) {
            if (nu(n)) return {
                data: {
                    user: null,
                    session: null
                },
                error: n
            };
            throw n
        }
    }
    async signInWithSSO(e) {
        var t, r, n;
        try {
            let s = null,
                i = null;
            return "pkce" === this.flowType && ([s, i] = await eu(this.storage, this.storageKey)), await vu(this.fetch, "POST", `${this.url}/sso`, {
                body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, "providerId" in e ? {
                    provider_id: e.providerId
                } : null), "domain" in e ? {
                    domain: e.domain
                } : null), {
                    redirect_to: null !== (r = null === (t = e.options) || void 0 === t ? void 0 : t.redirectTo) && void 0 !== r ? r : void 0
                }), (null === (n = null == e ? void 0 : e.options) || void 0 === n ? void 0 : n.captchaToken) ? {
                    gotrue_meta_security: {
                        captcha_token: e.options.captchaToken
                    }
                } : null), {
                    skip_http_redirect: !0,
                    code_challenge: s,
                    code_challenge_method: i
                }),
                headers: this.headers,
                xform: ku
            })
        } catch (s) {
            if (nu(s)) return {
                data: null,
                error: s
            };
            throw s
        }
    }
    async reauthenticate() {
        return await this.initializePromise, await this._acquireLock(-1, (async () => await this._reauthenticate()))
    }
    async _reauthenticate() {
        try {
            return await this._useSession((async e => {
                const {
                    data: {
                        session: t
                    },
                    error: r
                } = e;
                if (r) throw r;
                if (!t) throw new au;
                const {
                    error: n
                } = await vu(this.fetch, "GET", `${this.url}/reauthenticate`, {
                    headers: this.headers,
                    jwt: t.access_token
                });
                return {
                    data: {
                        user: null,
                        session: null
                    },
                    error: n
                }
            }))
        } catch (e) {
            if (nu(e)) return {
                data: {
                    user: null,
                    session: null
                },
                error: e
            };
            throw e
        }
    }
    async resend(e) {
        try {
            const t = `${this.url}/resend`;
            if ("email" in e) {
                const {
                    email: r,
                    type: n,
                    options: s
                } = e, {
                    error: i
                } = await vu(this.fetch, "POST", t, {
                    headers: this.headers,
                    body: {
                        email: r,
                        type: n,
                        gotrue_meta_security: {
                            captcha_token: null == s ? void 0 : s.captchaToken
                        }
                    },
                    redirectTo: null == s ? void 0 : s.emailRedirectTo
                });
                return {
                    data: {
                        user: null,
                        session: null
                    },
                    error: i
                }
            }
            if ("phone" in e) {
                const {
                    phone: r,
                    type: n,
                    options: s
                } = e, {
                    data: i,
                    error: o
                } = await vu(this.fetch, "POST", t, {
                    headers: this.headers,
                    body: {
                        phone: r,
                        type: n,
                        gotrue_meta_security: {
                            captcha_token: null == s ? void 0 : s.captchaToken
                        }
                    }
                });
                return {
                    data: {
                        user: null,
                        session: null,
                        messageId: null == i ? void 0 : i.message_id
                    },
                    error: o
                }
            }
            throw new cu("You must provide either an email or phone number and a type")
        } catch (t) {
            if (nu(t)) return {
                data: {
                    user: null,
                    session: null
                },
                error: t
            };
            throw t
        }
    }
    async getSession() {
        await this.initializePromise;
        return await this._acquireLock(-1, (async () => this._useSession((async e => e))))
    }
    async _acquireLock(e, t) {
        this._debug("#_acquireLock", "begin", e);
        try {
            if (this.lockAcquired) {
                const e = this.pendingInLock.length ? this.pendingInLock[this.pendingInLock.length - 1] : Promise.resolve(),
                    r = (async () => (await e, await t()))();
                return this.pendingInLock.push((async () => {
                    try {
                        await r
                    } catch (e) {}
                })()), r
            }
            return await this.lock(`lock:${this.storageKey}`, e, (async () => {
                this._debug("#_acquireLock", "lock acquired for storage key", this.storageKey);
                try {
                    this.lockAcquired = !0;
                    const e = t();
                    for (this.pendingInLock.push((async () => {
                            try {
                                await e
                            } catch (t) {}
                        })()), await e; this.pendingInLock.length;) {
                        const e = [...this.pendingInLock];
                        await Promise.all(e), this.pendingInLock.splice(0, e.length)
                    }
                    return await e
                } finally {
                    this._debug("#_acquireLock", "lock released for storage key", this.storageKey), this.lockAcquired = !1
                }
            }))
        } finally {
            this._debug("#_acquireLock", "end")
        }
    }
    async _useSession(e) {
        this._debug("#_useSession", "begin");
        try {
            const t = await this.__loadSession();
            return await e(t)
        } finally {
            this._debug("#_useSession", "end")
        }
    }
    async __loadSession() {
        this._debug("#__loadSession()", "begin"), this.lockAcquired || this._debug("#__loadSession()", "used outside of an acquired lock!", (new Error).stack);
        try {
            let e = null;
            const t = await Gc(this.storage, this.storageKey);
            if (this._debug("#getSession()", "session from storage", t), null !== t && (this._isValidSession(t) ? e = t : (this._debug("#getSession()", "session from storage is not valid"), await this._removeSession())), !e) return {
                data: {
                    session: null
                },
                error: null
            };
            const r = !!e.expires_at && e.expires_at <= Date.now() / 1e3;
            if (this._debug("#__loadSession()", `session has${r?"":" not"} expired`, "expires_at", e.expires_at), !r) {
                if (this.storage.isServer) {
                    let t = this.suppressGetSessionWarning;
                    e = new Proxy(e, {
                        get: (e, r, n) => (t || "user" !== r || (console.warn("Using the user object as returned from supabase.auth.getSession() or from some supabase.auth.onAuthStateChange() events could be insecure! This value comes directly from the storage medium (usually cookies on the server) and many not be authentic. Use supabase.auth.getUser() instead which authenticates the data by contacting the Supabase Auth server."), t = !0, this.suppressGetSessionWarning = !0), Reflect.get(e, r, n))
                    })
                }
                return {
                    data: {
                        session: e
                    },
                    error: null
                }
            }
            const {
                session: n,
                error: s
            } = await this._callRefreshToken(e.refresh_token);
            return s ? {
                data: {
                    session: null
                },
                error: s
            } : {
                data: {
                    session: n
                },
                error: null
            }
        } finally {
            this._debug("#__loadSession()", "end")
        }
    }
    async getUser(e) {
        if (e) return await this._getUser(e);
        await this.initializePromise;
        return await this._acquireLock(-1, (async () => await this._getUser()))
    }
    async _getUser(e) {
        try {
            return e ? await vu(this.fetch, "GET", `${this.url}/user`, {
                headers: this.headers,
                jwt: e,
                xform: wu
            }) : await this._useSession((async e => {
                var t, r, n;
                const {
                    data: s,
                    error: i
                } = e;
                if (i) throw i;
                return (null === (t = s.session) || void 0 === t ? void 0 : t.access_token) || this.hasCustomAuthorizationHeader ? await vu(this.fetch, "GET", `${this.url}/user`, {
                    headers: this.headers,
                    jwt: null !== (n = null === (r = s.session) || void 0 === r ? void 0 : r.access_token) && void 0 !== n ? n : void 0,
                    xform: wu
                }) : {
                    data: {
                        user: null
                    },
                    error: new au
                }
            }))
        } catch (t) {
            if (nu(t)) return function(e) {
                return nu(e) && "AuthSessionMissingError" === e.name
            }(t) && (await this._removeSession(), await Yc(this.storage, `${this.storageKey}-code-verifier`)), {
                data: {
                    user: null
                },
                error: t
            };
            throw t
        }
    }
    async updateUser(e, t = {}) {
        return await this.initializePromise, await this._acquireLock(-1, (async () => await this._updateUser(e, t)))
    }
    async _updateUser(e, t = {}) {
        try {
            return await this._useSession((async r => {
                const {
                    data: n,
                    error: s
                } = r;
                if (s) throw s;
                if (!n.session) throw new au;
                const i = n.session;
                let o = null,
                    a = null;
                "pkce" === this.flowType && null != e.email && ([o, a] = await eu(this.storage, this.storageKey));
                const {
                    data: l,
                    error: c
                } = await vu(this.fetch, "PUT", `${this.url}/user`, {
                    headers: this.headers,
                    redirectTo: null == t ? void 0 : t.emailRedirectTo,
                    body: Object.assign(Object.assign({}, e), {
                        code_challenge: o,
                        code_challenge_method: a
                    }),
                    jwt: i.access_token,
                    xform: wu
                });
                if (c) throw c;
                return i.user = l.user, await this._saveSession(i), await this._notifyAllSubscribers("USER_UPDATED", i), {
                    data: {
                        user: i.user
                    },
                    error: null
                }
            }))
        } catch (r) {
            if (nu(r)) return {
                data: {
                    user: null
                },
                error: r
            };
            throw r
        }
    }
    _decodeJWT(e) {
        return Xc(e)
    }
    async setSession(e) {
        return await this.initializePromise, await this._acquireLock(-1, (async () => await this._setSession(e)))
    }
    async _setSession(e) {
        try {
            if (!e.access_token || !e.refresh_token) throw new au;
            const t = Date.now() / 1e3;
            let r = t,
                n = !0,
                s = null;
            const i = Xc(e.access_token);
            if (i.exp && (r = i.exp, n = r <= t), n) {
                const {
                    session: t,
                    error: r
                } = await this._callRefreshToken(e.refresh_token);
                if (r) return {
                    data: {
                        user: null,
                        session: null
                    },
                    error: r
                };
                if (!t) return {
                    data: {
                        user: null,
                        session: null
                    },
                    error: null
                };
                s = t
            } else {
                const {
                    data: n,
                    error: i
                } = await this._getUser(e.access_token);
                if (i) throw i;
                s = {
                    access_token: e.access_token,
                    refresh_token: e.refresh_token,
                    user: n.user,
                    token_type: "bearer",
                    expires_in: r - t,
                    expires_at: r
                }, await this._saveSession(s), await this._notifyAllSubscribers("SIGNED_IN", s)
            }
            return {
                data: {
                    user: s.user,
                    session: s
                },
                error: null
            }
        } catch (t) {
            if (nu(t)) return {
                data: {
                    session: null,
                    user: null
                },
                error: t
            };
            throw t
        }
    }
    async refreshSession(e) {
        return await this.initializePromise, await this._acquireLock(-1, (async () => await this._refreshSession(e)))
    }
    async _refreshSession(e) {
        try {
            return await this._useSession((async t => {
                var r;
                if (!e) {
                    const {
                        data: n,
                        error: s
                    } = t;
                    if (s) throw s;
                    e = null !== (r = n.session) && void 0 !== r ? r : void 0
                }
                if (!(null == e ? void 0 : e.refresh_token)) throw new au;
                const {
                    session: n,
                    error: s
                } = await this._callRefreshToken(e.refresh_token);
                return s ? {
                    data: {
                        user: null,
                        session: null
                    },
                    error: s
                } : n ? {
                    data: {
                        user: n.user,
                        session: n
                    },
                    error: null
                } : {
                    data: {
                        user: null,
                        session: null
                    },
                    error: null
                }
            }))
        } catch (t) {
            if (nu(t)) return {
                data: {
                    user: null,
                    session: null
                },
                error: t
            };
            throw t
        }
    }
    async _getSessionFromURL(e) {
        try {
            if (!Bc()) throw new uu("No browser detected.");
            if ("implicit" === this.flowType && !this._isImplicitGrantFlow()) throw new uu("Not a valid implicit grant flow url.");
            if ("pkce" == this.flowType && !e) throw new du("Not a valid PKCE flow url.");
            const t = Hc(window.location.href);
            if (e) {
                if (!t.code) throw new du("No code detected.");
                const {
                    data: e,
                    error: r
                } = await this._exchangeCodeForSession(t.code);
                if (r) throw r;
                const n = new URL(window.location.href);
                return n.searchParams.delete("code"), window.history.replaceState(window.history.state, "", n.toString()), {
                    data: {
                        session: e.session,
                        redirectType: null
                    },
                    error: null
                }
            }
            if (t.error || t.error_description || t.error_code) throw new uu(t.error_description || "Error in URL with unspecified error_description", {
                error: t.error || "unspecified_error",
                code: t.error_code || "unspecified_code"
            });
            const {
                provider_token: r,
                provider_refresh_token: n,
                access_token: s,
                refresh_token: i,
                expires_in: o,
                expires_at: a,
                token_type: l
            } = t;
            if (!(s && o && i && l)) throw new uu("No session defined in URL");
            const c = Math.round(Date.now() / 1e3),
                u = parseInt(o);
            let d = c + u;
            a && (d = parseInt(a));
            const h = d - c;
            1e3 * h <= Ru && console.warn(`@supabase/gotrue-js: Session as retrieved from URL expires in ${h}s, should have been closer to ${u}s`);
            const p = d - u;
            c - p >= 120 ? console.warn("@supabase/gotrue-js: Session as retrieved from URL was issued over 120s ago, URL could be stale", p, d, c) : c - p < 0 && console.warn("@supabase/gotrue-js: Session as retrieved from URL was issued in the future? Check the device clock for skew", p, d, c);
            const {
                data: f,
                error: m
            } = await this._getUser(s);
            if (m) throw m;
            const g = {
                provider_token: r,
                provider_refresh_token: n,
                access_token: s,
                expires_in: u,
                expires_at: d,
                refresh_token: i,
                token_type: l,
                user: f.user
            };
            return window.location.hash = "", this._debug("#_getSessionFromURL()", "clearing window.location.hash"), {
                data: {
                    session: g,
                    redirectType: t.type
                },
                error: null
            }
        } catch (t) {
            if (nu(t)) return {
                data: {
                    session: null,
                    redirectType: null
                },
                error: t
            };
            throw t
        }
    }
    _isImplicitGrantFlow() {
        const e = Hc(window.location.href);
        return !(!Bc() || !e.access_token && !e.error_description)
    }
    async _isPKCEFlow() {
        const e = Hc(window.location.href),
            t = await Gc(this.storage, `${this.storageKey}-code-verifier`);
        return !(!e.code || !t)
    }
    async signOut(e = {
        scope: "global"
    }) {
        return await this.initializePromise, await this._acquireLock(-1, (async () => await this._signOut(e)))
    }
    async _signOut({
        scope: e
    } = {
        scope: "global"
    }) {
        return await this._useSession((async t => {
            var r;
            const {
                data: n,
                error: s
            } = t;
            if (s) return {
                error: s
            };
            const i = null === (r = n.session) || void 0 === r ? void 0 : r.access_token;
            if (i) {
                const {
                    error: t
                } = await this.admin.signOut(i, e);
                if (t && (! function(e) {
                        return nu(e) && "AuthApiError" === e.name
                    }(t) || 404 !== t.status && 401 !== t.status && 403 !== t.status)) return {
                    error: t
                }
            }
            return "others" !== e && (await this._removeSession(), await Yc(this.storage, `${this.storageKey}-code-verifier`)), {
                error: null
            }
        }))
    }
    onAuthStateChange(e) {
        const t = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(e) {
                const t = 16 * Math.random() | 0;
                return ("x" == e ? t : 3 & t | 8).toString(16)
            })),
            r = {
                id: t,
                callback: e,
                unsubscribe: () => {
                    this._debug("#unsubscribe()", "state change callback with id removed", t), this.stateChangeEmitters.delete(t)
                }
            };
        return this._debug("#onAuthStateChange()", "registered callback with id", t), this.stateChangeEmitters.set(t, r), (async () => {
            await this.initializePromise, await this._acquireLock(-1, (async () => {
                this._emitInitialSession(t)
            }))
        })(), {
            data: {
                subscription: r
            }
        }
    }
    async _emitInitialSession(e) {
        return await this._useSession((async t => {
            var r, n;
            try {
                const {
                    data: {
                        session: n
                    },
                    error: s
                } = t;
                if (s) throw s;
                await (null === (r = this.stateChangeEmitters.get(e)) || void 0 === r ? void 0 : r.callback("INITIAL_SESSION", n)), this._debug("INITIAL_SESSION", "callback id", e, "session", n)
            } catch (s) {
                await (null === (n = this.stateChangeEmitters.get(e)) || void 0 === n ? void 0 : n.callback("INITIAL_SESSION", null)), this._debug("INITIAL_SESSION", "callback id", e, "error", s), console.error(s)
            }
        }))
    }
    async resetPasswordForEmail(e, t = {}) {
        let r = null,
            n = null;
        "pkce" === this.flowType && ([r, n] = await eu(this.storage, this.storageKey, !0));
        try {
            return await vu(this.fetch, "POST", `${this.url}/recover`, {
                body: {
                    email: e,
                    code_challenge: r,
                    code_challenge_method: n,
                    gotrue_meta_security: {
                        captcha_token: t.captchaToken
                    }
                },
                headers: this.headers,
                redirectTo: t.redirectTo
            })
        } catch (s) {
            if (nu(s)) return {
                data: null,
                error: s
            };
            throw s
        }
    }
    async getUserIdentities() {
        var e;
        try {
            const {
                data: t,
                error: r
            } = await this.getUser();
            if (r) throw r;
            return {
                data: {
                    identities: null !== (e = t.user.identities) && void 0 !== e ? e : []
                },
                error: null
            }
        } catch (t) {
            if (nu(t)) return {
                data: null,
                error: t
            };
            throw t
        }
    }
    async linkIdentity(e) {
        var t;
        try {
            const {
                data: r,
                error: n
            } = await this._useSession((async t => {
                var r, n, s, i, o;
                const {
                    data: a,
                    error: l
                } = t;
                if (l) throw l;
                const c = await this._getUrlForProvider(`${this.url}/user/identities/authorize`, e.provider, {
                    redirectTo: null === (r = e.options) || void 0 === r ? void 0 : r.redirectTo,
                    scopes: null === (n = e.options) || void 0 === n ? void 0 : n.scopes,
                    queryParams: null === (s = e.options) || void 0 === s ? void 0 : s.queryParams,
                    skipBrowserRedirect: !0
                });
                return await vu(this.fetch, "GET", c, {
                    headers: this.headers,
                    jwt: null !== (o = null === (i = a.session) || void 0 === i ? void 0 : i.access_token) && void 0 !== o ? o : void 0
                })
            }));
            if (n) throw n;
            return Bc() && !(null === (t = e.options) || void 0 === t ? void 0 : t.skipBrowserRedirect) && window.location.assign(null == r ? void 0 : r.url), {
                data: {
                    provider: e.provider,
                    url: null == r ? void 0 : r.url
                },
                error: null
            }
        } catch (r) {
            if (nu(r)) return {
                data: {
                    provider: e.provider,
                    url: null
                },
                error: r
            };
            throw r
        }
    }
    async unlinkIdentity(e) {
        try {
            return await this._useSession((async t => {
                var r, n;
                const {
                    data: s,
                    error: i
                } = t;
                if (i) throw i;
                return await vu(this.fetch, "DELETE", `${this.url}/user/identities/${e.identity_id}`, {
                    headers: this.headers,
                    jwt: null !== (n = null === (r = s.session) || void 0 === r ? void 0 : r.access_token) && void 0 !== n ? n : void 0
                })
            }))
        } catch (t) {
            if (nu(t)) return {
                data: null,
                error: t
            };
            throw t
        }
    }
    async _refreshAccessToken(e) {
        const t = `#_refreshAccessToken(${e.substring(0,5)}...)`;
        this._debug(t, "begin");
        try {
            const s = Date.now();
            return await (r = async r => (r > 0 && await async function(e) {
                return await new Promise((t => {
                    setTimeout((() => t(null)), e)
                }))
            }(200 * Math.pow(2, r - 1)), this._debug(t, "refreshing attempt", r), await vu(this.fetch, "POST", `${this.url}/token?grant_type=refresh_token`, {
                body: {
                    refresh_token: e
                },
                headers: this.headers,
                xform: bu
            })), n = (e, t) => {
                const r = 200 * Math.pow(2, e);
                return t && pu(t) && Date.now() + r - s < Ru
            }, new Promise(((e, t) => {
                (async () => {
                    for (let i = 0; i < 1 / 0; i++) try {
                        const t = await r(i);
                        if (!n(i, null, t)) return void e(t)
                    } catch (s) {
                        if (!n(i, s)) return void t(s)
                    }
                })()
            })))
        } catch (s) {
            if (this._debug(t, "error", s), nu(s)) return {
                data: {
                    session: null,
                    user: null
                },
                error: s
            };
            throw s
        } finally {
            this._debug(t, "end")
        }
        var r, n
    }
    _isValidSession(e) {
        return "object" == typeof e && null !== e && "access_token" in e && "refresh_token" in e && "expires_at" in e
    }
    async _handleProviderSignIn(e, t) {
        const r = await this._getUrlForProvider(`${this.url}/authorize`, e, {
            redirectTo: t.redirectTo,
            scopes: t.scopes,
            queryParams: t.queryParams
        });
        return this._debug("#_handleProviderSignIn()", "provider", e, "options", t, "url", r), Bc() && !t.skipBrowserRedirect && window.location.assign(r), {
            data: {
                provider: e,
                url: r
            },
            error: null
        }
    }
    async _recoverAndRefresh() {
        var e;
        const t = "#_recoverAndRefresh()";
        this._debug(t, "begin");
        try {
            const r = await Gc(this.storage, this.storageKey);
            if (this._debug(t, "session from storage", r), !this._isValidSession(r)) return this._debug(t, "session is not valid"), void(null !== r && await this._removeSession());
            const n = Math.round(Date.now() / 1e3),
                s = (null !== (e = r.expires_at) && void 0 !== e ? e : 1 / 0) < n + 10;
            if (this._debug(t, `session has${s?"":" not"} expired with margin of 10s`), s) {
                if (this.autoRefreshToken && r.refresh_token) {
                    const {
                        error: e
                    } = await this._callRefreshToken(r.refresh_token);
                    e && (console.error(e), pu(e) || (this._debug(t, "refresh failed with a non-retryable error, removing the session", e), await this._removeSession()))
                }
            } else await this._notifyAllSubscribers("SIGNED_IN", r)
        } catch (r) {
            return this._debug(t, "error", r), void console.error(r)
        } finally {
            this._debug(t, "end")
        }
    }
    async _callRefreshToken(e) {
        var t, r;
        if (!e) throw new au;
        if (this.refreshingDeferred) return this.refreshingDeferred.promise;
        const n = `#_callRefreshToken(${e.substring(0,5)}...)`;
        this._debug(n, "begin");
        try {
            this.refreshingDeferred = new Jc;
            const {
                data: t,
                error: r
            } = await this._refreshAccessToken(e);
            if (r) throw r;
            if (!t.session) throw new au;
            await this._saveSession(t.session), await this._notifyAllSubscribers("TOKEN_REFRESHED", t.session);
            const n = {
                session: t.session,
                error: null
            };
            return this.refreshingDeferred.resolve(n), n
        } catch (s) {
            if (this._debug(n, "error", s), nu(s)) {
                const e = {
                    session: null,
                    error: s
                };
                return pu(s) || await this._removeSession(), null === (t = this.refreshingDeferred) || void 0 === t || t.resolve(e), e
            }
            throw null === (r = this.refreshingDeferred) || void 0 === r || r.reject(s), s
        } finally {
            this.refreshingDeferred = null, this._debug(n, "end")
        }
    }
    async _notifyAllSubscribers(e, t, r = !0) {
        const n = `#_notifyAllSubscribers(${e})`;
        this._debug(n, "begin", t, `broadcast = ${r}`);
        try {
            this.broadcastChannel && r && this.broadcastChannel.postMessage({
                event: e,
                session: t
            });
            const n = [],
                s = Array.from(this.stateChangeEmitters.values()).map((async r => {
                    try {
                        await r.callback(e, t)
                    } catch (s) {
                        n.push(s)
                    }
                }));
            if (await Promise.all(s), n.length > 0) {
                for (let e = 0; e < n.length; e += 1) console.error(n[e]);
                throw n[0]
            }
        } finally {
            this._debug(n, "end")
        }
    }
    async _saveSession(e) {
        this._debug("#_saveSession()", e), this.suppressGetSessionWarning = !0, await Kc(this.storage, this.storageKey, e)
    }
    async _removeSession() {
        this._debug("#_removeSession()"), await Yc(this.storage, this.storageKey), await this._notifyAllSubscribers("SIGNED_OUT", null)
    }
    _removeVisibilityChangedCallback() {
        this._debug("#_removeVisibilityChangedCallback()");
        const e = this.visibilityChangedCallback;
        this.visibilityChangedCallback = null;
        try {
            e && Bc() && (null === window || void 0 === window ? void 0 : window.removeEventListener) && window.removeEventListener("visibilitychange", e)
        } catch (t) {
            console.error("removing visibilitychange callback failed", t)
        }
    }
    async _startAutoRefresh() {
        await this._stopAutoRefresh(), this._debug("#_startAutoRefresh()");
        const e = setInterval((() => this._autoRefreshTokenTick()), Ru);
        this.autoRefreshTicker = e, e && "object" == typeof e && "function" == typeof e.unref ? e.unref() : "undefined" != typeof Deno && "function" == typeof Deno.unrefTimer && Deno.unrefTimer(e), setTimeout((async () => {
            await this.initializePromise, await this._autoRefreshTokenTick()
        }), 0)
    }
    async _stopAutoRefresh() {
        this._debug("#_stopAutoRefresh()");
        const e = this.autoRefreshTicker;
        this.autoRefreshTicker = null, e && clearInterval(e)
    }
    async startAutoRefresh() {
        this._removeVisibilityChangedCallback(), await this._startAutoRefresh()
    }
    async stopAutoRefresh() {
        this._removeVisibilityChangedCallback(), await this._stopAutoRefresh()
    }
    async _autoRefreshTokenTick() {
        this._debug("#_autoRefreshTokenTick()", "begin");
        try {
            await this._acquireLock(0, (async () => {
                try {
                    const t = Date.now();
                    try {
                        return await this._useSession((async e => {
                            const {
                                data: {
                                    session: r
                                }
                            } = e;
                            if (!r || !r.refresh_token || !r.expires_at) return void this._debug("#_autoRefreshTokenTick()", "no session");
                            const n = Math.floor((1e3 * r.expires_at - t) / Ru);
                            this._debug("#_autoRefreshTokenTick()", `access token expires in ${n} ticks, a tick lasts 30000ms, refresh threshold is 3 ticks`), n <= 3 && await this._callRefreshToken(r.refresh_token)
                        }))
                    } catch (e) {
                        console.error("Auto refresh tick failed with error. This is likely a transient error.", e)
                    }
                } finally {
                    this._debug("#_autoRefreshTokenTick()", "end")
                }
            }))
        } catch (e) {
            if (!(e.isAcquireTimeout || e instanceof Cu)) throw e;
            this._debug("auto refresh token tick lock not available")
        }
    }
    async _handleVisibilityChange() {
        if (this._debug("#_handleVisibilityChange()"), !Bc() || !(null === window || void 0 === window ? void 0 : window.addEventListener)) return this.autoRefreshToken && this.startAutoRefresh(), !1;
        try {
            this.visibilityChangedCallback = async () => await this._onVisibilityChanged(!1), null === window || void 0 === window || window.addEventListener("visibilitychange", this.visibilityChangedCallback), await this._onVisibilityChanged(!0)
        } catch (e) {
            console.error("_handleVisibilityChange", e)
        }
    }
    async _onVisibilityChanged(e) {
        const t = `#_onVisibilityChanged(${e})`;
        this._debug(t, "visibilityState", document.visibilityState), "visible" === document.visibilityState ? (this.autoRefreshToken && this._startAutoRefresh(), e || (await this.initializePromise, await this._acquireLock(-1, (async () => {
            "visible" === document.visibilityState ? await this._recoverAndRefresh() : this._debug(t, "acquired the lock to recover the session, but the browser visibilityState is no longer visible, aborting")
        })))) : "hidden" === document.visibilityState && this.autoRefreshToken && this._stopAutoRefresh()
    }
    async _getUrlForProvider(e, t, r) {
        const n = [`provider=${encodeURIComponent(t)}`];
        if ((null == r ? void 0 : r.redirectTo) && n.push(`redirect_to=${encodeURIComponent(r.redirectTo)}`), (null == r ? void 0 : r.scopes) && n.push(`scopes=${encodeURIComponent(r.scopes)}`), "pkce" === this.flowType) {
            const [e, t] = await eu(this.storage, this.storageKey), r = new URLSearchParams({
                code_challenge: `${encodeURIComponent(e)}`,
                code_challenge_method: `${encodeURIComponent(t)}`
            });
            n.push(r.toString())
        }
        if (null == r ? void 0 : r.queryParams) {
            const e = new URLSearchParams(r.queryParams);
            n.push(e.toString())
        }
        return (null == r ? void 0 : r.skipBrowserRedirect) && n.push(`skip_http_redirect=${r.skipBrowserRedirect}`), `${e}?${n.join("&")}`
    }
    async _unenroll(e) {
        try {
            return await this._useSession((async t => {
                var r;
                const {
                    data: n,
                    error: s
                } = t;
                return s ? {
                    data: null,
                    error: s
                } : await vu(this.fetch, "DELETE", `${this.url}/factors/${e.factorId}`, {
                    headers: this.headers,
                    jwt: null === (r = null == n ? void 0 : n.session) || void 0 === r ? void 0 : r.access_token
                })
            }))
        } catch (t) {
            if (nu(t)) return {
                data: null,
                error: t
            };
            throw t
        }
    }
    async _enroll(e) {
        try {
            return await this._useSession((async t => {
                var r, n;
                const {
                    data: s,
                    error: i
                } = t;
                if (i) return {
                    data: null,
                    error: i
                };
                const o = Object.assign({
                        friendly_name: e.friendlyName,
                        factor_type: e.factorType
                    }, "phone" === e.factorType ? {
                        phone: e.phone
                    } : {
                        issuer: e.issuer
                    }),
                    {
                        data: a,
                        error: l
                    } = await vu(this.fetch, "POST", `${this.url}/factors`, {
                        body: o,
                        headers: this.headers,
                        jwt: null === (r = null == s ? void 0 : s.session) || void 0 === r ? void 0 : r.access_token
                    });
                return l ? {
                    data: null,
                    error: l
                } : ("totp" === e.factorType && (null === (n = null == a ? void 0 : a.totp) || void 0 === n ? void 0 : n.qr_code) && (a.totp.qr_code = `data:image/svg+xml;utf-8,${a.totp.qr_code}`), {
                    data: a,
                    error: null
                })
            }))
        } catch (t) {
            if (nu(t)) return {
                data: null,
                error: t
            };
            throw t
        }
    }
    async _verify(e) {
        return this._acquireLock(-1, (async () => {
            try {
                return await this._useSession((async t => {
                    var r;
                    const {
                        data: n,
                        error: s
                    } = t;
                    if (s) return {
                        data: null,
                        error: s
                    };
                    const {
                        data: i,
                        error: o
                    } = await vu(this.fetch, "POST", `${this.url}/factors/${e.factorId}/verify`, {
                        body: {
                            code: e.code,
                            challenge_id: e.challengeId
                        },
                        headers: this.headers,
                        jwt: null === (r = null == n ? void 0 : n.session) || void 0 === r ? void 0 : r.access_token
                    });
                    return o ? {
                        data: null,
                        error: o
                    } : (await this._saveSession(Object.assign({
                        expires_at: Math.round(Date.now() / 1e3) + i.expires_in
                    }, i)), await this._notifyAllSubscribers("MFA_CHALLENGE_VERIFIED", i), {
                        data: i,
                        error: o
                    })
                }))
            } catch (t) {
                if (nu(t)) return {
                    data: null,
                    error: t
                };
                throw t
            }
        }))
    }
    async _challenge(e) {
        return this._acquireLock(-1, (async () => {
            try {
                return await this._useSession((async t => {
                    var r;
                    const {
                        data: n,
                        error: s
                    } = t;
                    return s ? {
                        data: null,
                        error: s
                    } : await vu(this.fetch, "POST", `${this.url}/factors/${e.factorId}/challenge`, {
                        body: {
                            channel: e.channel
                        },
                        headers: this.headers,
                        jwt: null === (r = null == n ? void 0 : n.session) || void 0 === r ? void 0 : r.access_token
                    })
                }))
            } catch (t) {
                if (nu(t)) return {
                    data: null,
                    error: t
                };
                throw t
            }
        }))
    }
    async _challengeAndVerify(e) {
        const {
            data: t,
            error: r
        } = await this._challenge({
            factorId: e.factorId
        });
        return r ? {
            data: null,
            error: r
        } : await this._verify({
            factorId: e.factorId,
            challengeId: t.id,
            code: e.code
        })
    }
    async _listFactors() {
        const {
            data: {
                user: e
            },
            error: t
        } = await this.getUser();
        if (t) return {
            data: null,
            error: t
        };
        const r = (null == e ? void 0 : e.factors) || [],
            n = r.filter((e => "totp" === e.factor_type && "verified" === e.status)),
            s = r.filter((e => "phone" === e.factor_type && "verified" === e.status));
        return {
            data: {
                all: r,
                totp: n,
                phone: s
            },
            error: null
        }
    }
    async _getAuthenticatorAssuranceLevel() {
        return this._acquireLock(-1, (async () => await this._useSession((async e => {
            var t, r;
            const {
                data: {
                    session: n
                },
                error: s
            } = e;
            if (s) return {
                data: null,
                error: s
            };
            if (!n) return {
                data: {
                    currentLevel: null,
                    nextLevel: null,
                    currentAuthenticationMethods: []
                },
                error: null
            };
            const i = this._decodeJWT(n.access_token);
            let o = null;
            i.aal && (o = i.aal);
            let a = o;
            (null !== (r = null === (t = n.user.factors) || void 0 === t ? void 0 : t.filter((e => "verified" === e.status))) && void 0 !== r ? r : []).length > 0 && (a = "aal2");
            return {
                data: {
                    currentLevel: o,
                    nextLevel: a,
                    currentAuthenticationMethods: i.amr || []
                },
                error: null
            }
        }))))
    }
}
Lu.nextInstanceID = 0;
const Mu = Lu;
class Uu extends Mu {
    constructor(e) {
        super(e)
    }
}
var Du = function(e, t, r, n) {
    return new(r || (r = Promise))((function(s, i) {
        function o(e) {
            try {
                l(n.next(e))
            } catch (t) {
                i(t)
            }
        }

        function a(e) {
            try {
                l(n.throw(e))
            } catch (t) {
                i(t)
            }
        }

        function l(e) {
            var t;
            e.done ? s(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                e(t)
            }))).then(o, a)
        }
        l((n = n.apply(e, t || [])).next())
    }))
};
class $u {
    constructor(e, t, r) {
        var n, s, i;
        if (this.supabaseUrl = e, this.supabaseKey = t, !e) throw new Error("supabaseUrl is required.");
        if (!t) throw new Error("supabaseKey is required.");
        const o = e.replace(/\/$/, "");
        this.realtimeUrl = `${o}/realtime/v1`.replace(/^http/i, "ws"), this.authUrl = `${o}/auth/v1`, this.storageUrl = `${o}/storage/v1`, this.functionsUrl = `${o}/functions/v1`;
        const a = `sb-${new URL(this.authUrl).hostname.split(".")[0]}-auth-token`,
            l = function(e, t) {
                const {
                    db: r,
                    auth: n,
                    realtime: s,
                    global: i
                } = e, {
                    db: o,
                    auth: a,
                    realtime: l,
                    global: c
                } = t, u = {
                    db: Object.assign(Object.assign({}, o), r),
                    auth: Object.assign(Object.assign({}, a), n),
                    realtime: Object.assign(Object.assign({}, l), s),
                    global: Object.assign(Object.assign({}, c), i),
                    accessToken: () => Uc(this, void 0, void 0, (function*() {
                        return ""
                    }))
                };
                return e.accessToken ? u.accessToken = e.accessToken : delete u.accessToken, u
            }(null != r ? r : {}, {
                db: Nc,
                realtime: Ic,
                auth: Object.assign(Object.assign({}, Rc), {
                    storageKey: a
                }),
                global: Ac
            });
        this.storageKey = null !== (n = l.auth.storageKey) && void 0 !== n ? n : "", this.headers = null !== (s = l.global.headers) && void 0 !== s ? s : {}, l.accessToken ? (this.accessToken = l.accessToken, this.auth = new Proxy({}, {
            get: (e, t) => {
                throw new Error(`@supabase/supabase-js: Supabase Client is configured with the accessToken option, accessing supabase.auth.${String(t)} is not possible`)
            }
        })) : this.auth = this._initSupabaseAuthClient(null !== (i = l.auth) && void 0 !== i ? i : {}, this.headers, l.global.fetch), this.fetch = Mc(t, this._getAccessToken.bind(this), l.global.fetch), this.realtime = this._initRealtimeClient(Object.assign({
            headers: this.headers
        }, l.realtime)), this.rest = new vl(`${o}/rest/v1`, {
            headers: this.headers,
            schema: l.db.schema,
            fetch: this.fetch
        }), l.accessToken || this._listenForAuthEvents()
    }
    get functions() {
        return new Ua(this.functionsUrl, {
            headers: this.headers,
            customFetch: this.fetch
        })
    }
    get storage() {
        return new Cc(this.storageUrl, this.headers, this.fetch)
    }
    from(e) {
        return this.rest.from(e)
    }
    schema(e) {
        return this.rest.schema(e)
    }
    rpc(e, t = {}, r = {}) {
        return this.rest.rpc(e, t, r)
    }
    channel(e, t = {
        config: {}
    }) {
        return this.realtime.channel(e, t)
    }
    getChannels() {
        return this.realtime.getChannels()
    }
    removeChannel(e) {
        return this.realtime.removeChannel(e)
    }
    removeAllChannels() {
        return this.realtime.removeAllChannels()
    }
    _getAccessToken() {
        var e, t;
        return Du(this, void 0, void 0, (function*() {
            if (this.accessToken) return yield this.accessToken();
            const {
                data: r
            } = yield this.auth.getSession();
            return null !== (t = null === (e = r.session) || void 0 === e ? void 0 : e.access_token) && void 0 !== t ? t : null
        }))
    }
    _initSupabaseAuthClient({
        autoRefreshToken: e,
        persistSession: t,
        detectSessionInUrl: r,
        storage: n,
        storageKey: s,
        flowType: i,
        lock: o,
        debug: a
    }, l, c) {
        var u;
        const d = {
            Authorization: `Bearer ${this.supabaseKey}`,
            apikey: `${this.supabaseKey}`
        };
        return new Uu({
            url: this.authUrl,
            headers: Object.assign(Object.assign({}, d), l),
            storageKey: s,
            autoRefreshToken: e,
            persistSession: t,
            detectSessionInUrl: r,
            storage: n,
            flowType: i,
            lock: o,
            debug: a,
            fetch: c,
            hasCustomAuthorizationHeader: null !== (u = "Authorization" in this.headers) && void 0 !== u && u
        })
    }
    _initRealtimeClient(e) {
        return new oc(this.realtimeUrl, Object.assign(Object.assign({}, e), {
            params: Object.assign({
                apikey: this.supabaseKey
            }, null == e ? void 0 : e.params)
        }))
    }
    _listenForAuthEvents() {
        return this.auth.onAuthStateChange(((e, t) => {
            this._handleTokenChanged(e, "CLIENT", null == t ? void 0 : t.access_token)
        }))
    }
    _handleTokenChanged(e, t, r) {
        "TOKEN_REFRESHED" !== e && "SIGNED_IN" !== e || this.changedAccessToken === r ? "SIGNED_OUT" === e && (this.realtime.setAuth(this.supabaseKey), "STORAGE" == t && this.auth.signOut(), this.changedAccessToken = void 0) : (this.realtime.setAuth(null != r ? r : null), this.changedAccessToken = r)
    }
}
console.warn("Using mock Supabase configuration. Auth functionality will be limited.");
const Fu = ((e, t, r) => new $u(e, t, r))("https://example.supabase.co", "mock-key-for-development");
let Vu = 0;
const Bu = new Map,
    zu = e => {
        if (Bu.has(e)) return;
        const t = setTimeout((() => {
            Bu.delete(e), Ku({
                type: "REMOVE_TOAST",
                toastId: e
            })
        }), 1e6);
        Bu.set(e, t)
    },
    Wu = (e, t) => {
        switch (t.type) {
            case "ADD_TOAST":
                return { ...e,
                    toasts: [t.toast, ...e.toasts].slice(0, 1)
                };
            case "UPDATE_TOAST":
                return { ...e,
                    toasts: e.toasts.map((e => e.id === t.toast.id ? { ...e,
                        ...t.toast
                    } : e))
                };
            case "DISMISS_TOAST":
                {
                    const {
                        toastId: r
                    } = t;
                    return r ? zu(r) : e.toasts.forEach((e => {
                        zu(e.id)
                    })),
                    { ...e,
                        toasts: e.toasts.map((e => e.id === r || void 0 === r ? { ...e,
                            open: !1
                        } : e))
                    }
                }
            case "REMOVE_TOAST":
                return void 0 === t.toastId ? { ...e,
                    toasts: []
                } : { ...e,
                    toasts: e.toasts.filter((e => e.id !== t.toastId))
                }
        }
    },
    Hu = [];
let qu = {
    toasts: []
};

function Ku(e) {
    qu = Wu(qu, e), Hu.forEach((e => {
        e(qu)
    }))
}

function Gu({ ...e
}) {
    const t = (Vu = (Vu + 1) % Number.MAX_SAFE_INTEGER, Vu.toString()),
        r = () => Ku({
            type: "DISMISS_TOAST",
            toastId: t
        });
    return Ku({
        type: "ADD_TOAST",
        toast: { ...e,
            id: t,
            open: !0,
            onOpenChange: e => {
                e || r()
            }
        }
    }), {
        id: t,
        dismiss: r,
        update: e => Ku({
            type: "UPDATE_TOAST",
            toast: { ...e,
                id: t
            }
        })
    }
}

function Yu() {
    const [e, t] = o.useState(qu);
    return o.useEffect((() => (Hu.push(t), () => {
        const e = Hu.indexOf(t);
        e > -1 && Hu.splice(e, 1)
    })), [e]), { ...e,
        toast: Gu,
        dismiss: e => Ku({
            type: "DISMISS_TOAST",
            toastId: e
        })
    }
}
const Ju = o.createContext(void 0);

function Xu({
    children: e
}) {
    const [t, r] = o.useState(null), [n, s] = o.useState(null), [i, a] = o.useState(null), [l, c] = o.useState(!0), {
        toast: u
    } = Yu();
    o.useEffect((() => {
        Fu.auth.getSession().then((({
            data: {
                session: e
            }
        }) => {
            r(e), s((null == e ? void 0 : e.user) ? ? null), (null == e ? void 0 : e.user) ? d(e.user.id) : c(!1)
        }));
        const {
            data: {
                subscription: e
            }
        } = Fu.auth.onAuthStateChange(((e, t) => {
            r(t), s((null == t ? void 0 : t.user) ? ? null), (null == t ? void 0 : t.user) ? d(t.user.id) : (a(null), c(!1))
        }));
        return () => {
            e.unsubscribe()
        }
    }), []);
    const d = async e => {
            c(!0);
            const {
                data: t,
                error: r
            } = await Fu.from("profiles").select("*").eq("id", e).single();
            r ? console.error("Error fetching profile:", r) : a(t), c(!1)
        },
        h = {
            session: t,
            user: n,
            profile: i,
            isLoading: l,
            signIn: async (e, t) => {
                const {
                    error: r
                } = await Fu.auth.signInWithPassword({
                    email: e,
                    password: t
                });
                return r && u({
                    title: "Error signing in",
                    description: r.message,
                    variant: "destructive"
                }), {
                    error: r
                }
            },
            signUp: async (e, t, r) => {
                const {
                    data: n,
                    error: s
                } = await Fu.auth.signUp({
                    email: e,
                    password: t,
                    options: {
                        data: {
                            full_name: r
                        }
                    }
                });
                if (s) u({
                    title: "Error signing up",
                    description: s.message,
                    variant: "destructive"
                });
                else if (n.user) {
                    const {
                        error: t
                    } = await Fu.from("profiles").insert([{
                        id: n.user.id,
                        email: e,
                        full_name: r
                    }]);
                    t ? (console.error("Error creating profile:", t), u({
                        title: "Error creating profile",
                        description: t.message,
                        variant: "destructive"
                    })) : u({
                        title: "Success!",
                        description: "Please check your email to confirm your account."
                    })
                }
                return {
                    error: s,
                    data: n
                }
            },
            signOut: async () => {
                await Fu.auth.signOut()
            },
            signInWithGoogle: async () => {
                await Fu.auth.signInWithOAuth({
                    provider: "google",
                    options: {
                        redirectTo: `${window.location.origin}/auth/callback`
                    }
                })
            },
            signInWithGithub: async () => {
                await Fu.auth.signInWithOAuth({
                    provider: "github",
                    options: {
                        redirectTo: `${window.location.origin}/auth/callback`
                    }
                })
            },
            signInWithTwitter: async () => {
                await Fu.auth.signInWithOAuth({
                    provider: "twitter",
                    options: {
                        redirectTo: `${window.location.origin}/auth/callback`
                    }
                })
            },
            resetPassword: async e => {
                const {
                    error: t
                } = await Fu.auth.resetPasswordForEmail(e, {
                    redirectTo: `${window.location.origin}/auth/reset-password`
                });
                return u(t ? {
                    title: "Error resetting password",
                    description: t.message,
                    variant: "destructive"
                } : {
                    title: "Password reset email sent",
                    description: "Please check your email for the password reset link."
                }), {
                    error: t
                }
            },
            updateProfile: async e => {
                if (!n) return {
                    error: new Error("No user logged in")
                };
                const {
                    error: t
                } = await Fu.from("profiles").update(e).eq("id", n.id);
                return t ? u({
                    title: "Error updating profile",
                    description: t.message,
                    variant: "destructive"
                }) : (u({
                    title: "Profile updated",
                    description: "Your profile has been updated successfully."
                }), d(n.id)), {
                    error: t
                }
            }
        };
    return T.jsx(Ju.Provider, {
        value: h,
        children: e
    })
}

function Zu() {
    const e = o.useContext(Ju);
    if (void 0 === e) throw new Error("useAuth must be used within an AuthProvider");
    return e
}

function Qu(...e) {
    return t => e.forEach((e => function(e, t) {
        "function" == typeof e ? e(t) : null != e && (e.current = t)
    }(e, t)))
}

function ed(...e) {
    return o.useCallback(Qu(...e), e)
}
var td = o.forwardRef(((e, t) => {
    const {
        children: r,
        ...n
    } = e, s = o.Children.toArray(r), i = s.find(sd);
    if (i) {
        const e = i.props.children,
            r = s.map((t => t === i ? o.Children.count(e) > 1 ? o.Children.only(null) : o.isValidElement(e) ? e.props.children : null : t));
        return T.jsx(rd, { ...n,
            ref: t,
            children: o.isValidElement(e) ? o.cloneElement(e, void 0, r) : null
        })
    }
    return T.jsx(rd, { ...n,
        ref: t,
        children: r
    })
}));
td.displayName = "Slot";
var rd = o.forwardRef(((e, t) => {
    const {
        children: r,
        ...n
    } = e;
    if (o.isValidElement(r)) {
        const e = function(e) {
            var t, r;
            let n = null == (t = Object.getOwnPropertyDescriptor(e.props, "ref")) ? void 0 : t.get,
                s = n && "isReactWarning" in n && n.isReactWarning;
            if (s) return e.ref;
            if (n = null == (r = Object.getOwnPropertyDescriptor(e, "ref")) ? void 0 : r.get, s = n && "isReactWarning" in n && n.isReactWarning, s) return e.props.ref;
            return e.props.ref || e.ref
        }(r);
        return o.cloneElement(r, { ...id(n, r.props),
            ref: t ? Qu(t, e) : e
        })
    }
    return o.Children.count(r) > 1 ? o.Children.only(null) : null
}));
rd.displayName = "SlotClone";
var nd = ({
    children: e
}) => T.jsx(T.Fragment, {
    children: e
});

function sd(e) {
    return o.isValidElement(e) && e.type === nd
}

function id(e, t) {
    const r = { ...t
    };
    for (const n in t) {
        const s = e[n],
            i = t[n];
        /^on[A-Z]/.test(n) ? s && i ? r[n] = (...e) => {
            i(...e), s(...e)
        } : s && (r[n] = s) : "style" === n ? r[n] = { ...s,
            ...i
        } : "className" === n && (r[n] = [s, i].filter(Boolean).join(" "))
    }
    return { ...e,
        ...r
    }
}

function od(e) {
    var t, r, n = "";
    if ("string" == typeof e || "number" == typeof e) n += e;
    else if ("object" == typeof e)
        if (Array.isArray(e))
            for (t = 0; t < e.length; t++) e[t] && (r = od(e[t])) && (n && (n += " "), n += r);
        else
            for (t in e) e[t] && (n && (n += " "), n += t);
    return n
}
const ad = e => "boolean" == typeof e ? "".concat(e) : 0 === e ? "0" : e,
    ld = function() {
        for (var e, t, r = 0, n = ""; r < arguments.length;)(e = arguments[r++]) && (t = od(e)) && (n && (n += " "), n += t);
        return n
    },
    cd = (e, t) => r => {
        var n;
        if (null == (null == t ? void 0 : t.variants)) return ld(e, null == r ? void 0 : r.class, null == r ? void 0 : r.className);
        const {
            variants: s,
            defaultVariants: i
        } = t, o = Object.keys(s).map((e => {
            const t = null == r ? void 0 : r[e],
                n = null == i ? void 0 : i[e];
            if (null === t) return null;
            const o = ad(t) || ad(n);
            return s[e][o]
        })), a = r && Object.entries(r).reduce(((e, t) => {
            let [r, n] = t;
            return void 0 === n || (e[r] = n), e
        }), {}), l = null == t || null === (n = t.compoundVariants) || void 0 === n ? void 0 : n.reduce(((e, t) => {
            let {
                class: r,
                className: n,
                ...s
            } = t;
            return Object.entries(s).every((e => {
                let [t, r] = e;
                return Array.isArray(r) ? r.includes({ ...i,
                    ...a
                }[t]) : { ...i,
                    ...a
                }[t] === r
            })) ? [...e, r, n] : e
        }), []);
        return ld(e, o, l, null == r ? void 0 : r.class, null == r ? void 0 : r.className)
    };

function ud(e) {
    var t, r, n = "";
    if ("string" == typeof e || "number" == typeof e) n += e;
    else if ("object" == typeof e)
        if (Array.isArray(e)) {
            var s = e.length;
            for (t = 0; t < s; t++) e[t] && (r = ud(e[t])) && (n && (n += " "), n += r)
        } else
            for (r in e) e[r] && (n && (n += " "), n += r);
    return n
}
const dd = e => {
        const t = md(e),
            {
                conflictingClassGroups: r,
                conflictingClassGroupModifiers: n
            } = e;
        return {
            getClassGroupId: e => {
                const r = e.split("-");
                return "" === r[0] && 1 !== r.length && r.shift(), hd(r, t) || fd(e)
            },
            getConflictingClassGroupIds: (e, t) => {
                const s = r[e] || [];
                return t && n[e] ? [...s, ...n[e]] : s
            }
        }
    },
    hd = (e, t) => {
        var r;
        if (0 === e.length) return t.classGroupId;
        const n = e[0],
            s = t.nextPart.get(n),
            i = s ? hd(e.slice(1), s) : void 0;
        if (i) return i;
        if (0 === t.validators.length) return;
        const o = e.join("-");
        return null == (r = t.validators.find((({
            validator: e
        }) => e(o)))) ? void 0 : r.classGroupId
    },
    pd = /^\[(.+)\]$/,
    fd = e => {
        if (pd.test(e)) {
            const t = pd.exec(e)[1],
                r = null == t ? void 0 : t.substring(0, t.indexOf(":"));
            if (r) return "arbitrary.." + r
        }
    },
    md = e => {
        const {
            theme: t,
            prefix: r
        } = e, n = {
            nextPart: new Map,
            validators: []
        };
        return bd(Object.entries(e.classGroups), r).forEach((([e, r]) => {
            gd(r, n, e, t)
        })), n
    },
    gd = (e, t, r, n) => {
        e.forEach((e => {
            if ("string" != typeof e) {
                if ("function" == typeof e) return vd(e) ? void gd(e(n), t, r, n) : void t.validators.push({
                    validator: e,
                    classGroupId: r
                });
                Object.entries(e).forEach((([e, s]) => {
                    gd(s, yd(t, e), r, n)
                }))
            } else {
                ("" === e ? t : yd(t, e)).classGroupId = r
            }
        }))
    },
    yd = (e, t) => {
        let r = e;
        return t.split("-").forEach((e => {
            r.nextPart.has(e) || r.nextPart.set(e, {
                nextPart: new Map,
                validators: []
            }), r = r.nextPart.get(e)
        })), r
    },
    vd = e => e.isThemeGetter,
    bd = (e, t) => t ? e.map((([e, r]) => [e, r.map((e => "string" == typeof e ? t + e : "object" == typeof e ? Object.fromEntries(Object.entries(e).map((([e, r]) => [t + e, r]))) : e))])) : e,
    xd = e => {
        if (e < 1) return {
            get: () => {},
            set: () => {}
        };
        let t = 0,
            r = new Map,
            n = new Map;
        const s = (s, i) => {
            r.set(s, i), t++, t > e && (t = 0, n = r, r = new Map)
        };
        return {
            get(e) {
                let t = r.get(e);
                return void 0 !== t ? t : void 0 !== (t = n.get(e)) ? (s(e, t), t) : void 0
            },
            set(e, t) {
                r.has(e) ? r.set(e, t) : s(e, t)
            }
        }
    },
    wd = e => {
        const {
            separator: t,
            experimentalParseClassName: r
        } = e, n = 1 === t.length, s = t[0], i = t.length, o = e => {
            const r = [];
            let o, a = 0,
                l = 0;
            for (let d = 0; d < e.length; d++) {
                let c = e[d];
                if (0 === a) {
                    if (c === s && (n || e.slice(d, d + i) === t)) {
                        r.push(e.slice(l, d)), l = d + i;
                        continue
                    }
                    if ("/" === c) {
                        o = d;
                        continue
                    }
                }
                "[" === c ? a++ : "]" === c && a--
            }
            const c = 0 === r.length ? e : e.substring(l),
                u = c.startsWith("!");
            return {
                modifiers: r,
                hasImportantModifier: u,
                baseClassName: u ? c.substring(1) : c,
                maybePostfixModifierPosition: o && o > l ? o - l : void 0
            }
        };
        return r ? e => r({
            className: e,
            parseClassName: o
        }) : o
    },
    kd = e => {
        if (e.length <= 1) return e;
        const t = [];
        let r = [];
        return e.forEach((e => {
            "[" === e[0] ? (t.push(...r.sort(), e), r = []) : r.push(e)
        })), t.push(...r.sort()), t
    },
    jd = /\s+/;

function Sd() {
    let e, t, r = 0,
        n = "";
    for (; r < arguments.length;)(e = arguments[r++]) && (t = Td(e)) && (n && (n += " "), n += t);
    return n
}
const Td = e => {
    if ("string" == typeof e) return e;
    let t, r = "";
    for (let n = 0; n < e.length; n++) e[n] && (t = Td(e[n])) && (r && (r += " "), r += t);
    return r
};

function _d(e, ...t) {
    let r, n, s, i = function(a) {
        const l = t.reduce(((e, t) => t(e)), e());
        return r = (e => ({
            cache: xd(e.cacheSize),
            parseClassName: wd(e),
            ...dd(e)
        }))(l), n = r.cache.get, s = r.cache.set, i = o, o(a)
    };

    function o(e) {
        const t = n(e);
        if (t) return t;
        const i = ((e, t) => {
            const {
                parseClassName: r,
                getClassGroupId: n,
                getConflictingClassGroupIds: s
            } = t, i = [], o = e.trim().split(jd);
            let a = "";
            for (let l = o.length - 1; l >= 0; l -= 1) {
                const e = o[l],
                    {
                        modifiers: t,
                        hasImportantModifier: c,
                        baseClassName: u,
                        maybePostfixModifierPosition: d
                    } = r(e);
                let h = Boolean(d),
                    p = n(h ? u.substring(0, d) : u);
                if (!p) {
                    if (!h) {
                        a = e + (a.length > 0 ? " " + a : a);
                        continue
                    }
                    if (p = n(u), !p) {
                        a = e + (a.length > 0 ? " " + a : a);
                        continue
                    }
                    h = !1
                }
                const f = kd(t).join(":"),
                    m = c ? f + "!" : f,
                    g = m + p;
                if (i.includes(g)) continue;
                i.push(g);
                const y = s(p, h);
                for (let r = 0; r < y.length; ++r) {
                    const e = y[r];
                    i.push(m + e)
                }
                a = e + (a.length > 0 ? " " + a : a)
            }
            return a
        })(e, r);
        return s(e, i), i
    }
    return function() {
        return i(Sd.apply(null, arguments))
    }
}
const Ed = e => {
        const t = t => t[e] || [];
        return t.isThemeGetter = !0, t
    },
    Pd = /^\[(?:([a-z-]+):)?(.+)\]$/i,
    Cd = /^\d+\/\d+$/,
    Od = new Set(["px", "full", "screen"]),
    Ad = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
    Nd = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
    Rd = /^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/,
    Id = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
    Ld = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,
    Md = e => Dd(e) || Od.has(e) || Cd.test(e),
    Ud = e => Xd(e, "length", Zd),
    Dd = e => Boolean(e) && !Number.isNaN(Number(e)),
    $d = e => Xd(e, "number", Dd),
    Fd = e => Boolean(e) && Number.isInteger(Number(e)),
    Vd = e => e.endsWith("%") && Dd(e.slice(0, -1)),
    Bd = e => Pd.test(e),
    zd = e => Ad.test(e),
    Wd = new Set(["length", "size", "percentage"]),
    Hd = e => Xd(e, Wd, Qd),
    qd = e => Xd(e, "position", Qd),
    Kd = new Set(["image", "url"]),
    Gd = e => Xd(e, Kd, th),
    Yd = e => Xd(e, "", eh),
    Jd = () => !0,
    Xd = (e, t, r) => {
        const n = Pd.exec(e);
        return !!n && (n[1] ? "string" == typeof t ? n[1] === t : t.has(n[1]) : r(n[2]))
    },
    Zd = e => Nd.test(e) && !Rd.test(e),
    Qd = () => !1,
    eh = e => Id.test(e),
    th = e => Ld.test(e),
    rh = _d((() => {
        const e = Ed("colors"),
            t = Ed("spacing"),
            r = Ed("blur"),
            n = Ed("brightness"),
            s = Ed("borderColor"),
            i = Ed("borderRadius"),
            o = Ed("borderSpacing"),
            a = Ed("borderWidth"),
            l = Ed("contrast"),
            c = Ed("grayscale"),
            u = Ed("hueRotate"),
            d = Ed("invert"),
            h = Ed("gap"),
            p = Ed("gradientColorStops"),
            f = Ed("gradientColorStopPositions"),
            m = Ed("inset"),
            g = Ed("margin"),
            y = Ed("opacity"),
            v = Ed("padding"),
            b = Ed("saturate"),
            x = Ed("scale"),
            w = Ed("sepia"),
            k = Ed("skew"),
            j = Ed("space"),
            S = Ed("translate"),
            T = () => ["auto", Bd, t],
            _ = () => [Bd, t],
            E = () => ["", Md, Ud],
            P = () => ["auto", Dd, Bd],
            C = () => ["", "0", Bd],
            O = () => [Dd, Bd];
        return {
            cacheSize: 500,
            separator: ":",
            theme: {
                colors: [Jd],
                spacing: [Md, Ud],
                blur: ["none", "", zd, Bd],
                brightness: O(),
                borderColor: [e],
                borderRadius: ["none", "", "full", zd, Bd],
                borderSpacing: _(),
                borderWidth: E(),
                contrast: O(),
                grayscale: C(),
                hueRotate: O(),
                invert: C(),
                gap: _(),
                gradientColorStops: [e],
                gradientColorStopPositions: [Vd, Ud],
                inset: T(),
                margin: T(),
                opacity: O(),
                padding: _(),
                saturate: O(),
                scale: O(),
                sepia: C(),
                skew: O(),
                space: _(),
                translate: _()
            },
            classGroups: {
                aspect: [{
                    aspect: ["auto", "square", "video", Bd]
                }],
                container: ["container"],
                columns: [{
                    columns: [zd]
                }],
                "break-after": [{
                    "break-after": ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"]
                }],
                "break-before": [{
                    "break-before": ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"]
                }],
                "break-inside": [{
                    "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
                }],
                "box-decoration": [{
                    "box-decoration": ["slice", "clone"]
                }],
                box: [{
                    box: ["border", "content"]
                }],
                display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
                float: [{
                    float: ["right", "left", "none", "start", "end"]
                }],
                clear: [{
                    clear: ["left", "right", "both", "none", "start", "end"]
                }],
                isolation: ["isolate", "isolation-auto"],
                "object-fit": [{
                    object: ["contain", "cover", "fill", "none", "scale-down"]
                }],
                "object-position": [{
                    object: ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top", Bd]
                }],
                overflow: [{
                    overflow: ["auto", "hidden", "clip", "visible", "scroll"]
                }],
                "overflow-x": [{
                    "overflow-x": ["auto", "hidden", "clip", "visible", "scroll"]
                }],
                "overflow-y": [{
                    "overflow-y": ["auto", "hidden", "clip", "visible", "scroll"]
                }],
                overscroll: [{
                    overscroll: ["auto", "contain", "none"]
                }],
                "overscroll-x": [{
                    "overscroll-x": ["auto", "contain", "none"]
                }],
                "overscroll-y": [{
                    "overscroll-y": ["auto", "contain", "none"]
                }],
                position: ["static", "fixed", "absolute", "relative", "sticky"],
                inset: [{
                    inset: [m]
                }],
                "inset-x": [{
                    "inset-x": [m]
                }],
                "inset-y": [{
                    "inset-y": [m]
                }],
                start: [{
                    start: [m]
                }],
                end: [{
                    end: [m]
                }],
                top: [{
                    top: [m]
                }],
                right: [{
                    right: [m]
                }],
                bottom: [{
                    bottom: [m]
                }],
                left: [{
                    left: [m]
                }],
                visibility: ["visible", "invisible", "collapse"],
                z: [{
                    z: ["auto", Fd, Bd]
                }],
                basis: [{
                    basis: T()
                }],
                "flex-direction": [{
                    flex: ["row", "row-reverse", "col", "col-reverse"]
                }],
                "flex-wrap": [{
                    flex: ["wrap", "wrap-reverse", "nowrap"]
                }],
                flex: [{
                    flex: ["1", "auto", "initial", "none", Bd]
                }],
                grow: [{
                    grow: C()
                }],
                shrink: [{
                    shrink: C()
                }],
                order: [{
                    order: ["first", "last", "none", Fd, Bd]
                }],
                "grid-cols": [{
                    "grid-cols": [Jd]
                }],
                "col-start-end": [{
                    col: ["auto", {
                        span: ["full", Fd, Bd]
                    }, Bd]
                }],
                "col-start": [{
                    "col-start": P()
                }],
                "col-end": [{
                    "col-end": P()
                }],
                "grid-rows": [{
                    "grid-rows": [Jd]
                }],
                "row-start-end": [{
                    row: ["auto", {
                        span: [Fd, Bd]
                    }, Bd]
                }],
                "row-start": [{
                    "row-start": P()
                }],
                "row-end": [{
                    "row-end": P()
                }],
                "grid-flow": [{
                    "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
                }],
                "auto-cols": [{
                    "auto-cols": ["auto", "min", "max", "fr", Bd]
                }],
                "auto-rows": [{
                    "auto-rows": ["auto", "min", "max", "fr", Bd]
                }],
                gap: [{
                    gap: [h]
                }],
                "gap-x": [{
                    "gap-x": [h]
                }],
                "gap-y": [{
                    "gap-y": [h]
                }],
                "justify-content": [{
                    justify: ["normal", "start", "end", "center", "between", "around", "evenly", "stretch"]
                }],
                "justify-items": [{
                    "justify-items": ["start", "end", "center", "stretch"]
                }],
                "justify-self": [{
                    "justify-self": ["auto", "start", "end", "center", "stretch"]
                }],
                "align-content": [{
                    content: ["normal", "start", "end", "center", "between", "around", "evenly", "stretch", "baseline"]
                }],
                "align-items": [{
                    items: ["start", "end", "center", "baseline", "stretch"]
                }],
                "align-self": [{
                    self: ["auto", "start", "end", "center", "stretch", "baseline"]
                }],
                "place-content": [{
                    "place-content": ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline"]
                }],
                "place-items": [{
                    "place-items": ["start", "end", "center", "baseline", "stretch"]
                }],
                "place-self": [{
                    "place-self": ["auto", "start", "end", "center", "stretch"]
                }],
                p: [{
                    p: [v]
                }],
                px: [{
                    px: [v]
                }],
                py: [{
                    py: [v]
                }],
                ps: [{
                    ps: [v]
                }],
                pe: [{
                    pe: [v]
                }],
                pt: [{
                    pt: [v]
                }],
                pr: [{
                    pr: [v]
                }],
                pb: [{
                    pb: [v]
                }],
                pl: [{
                    pl: [v]
                }],
                m: [{
                    m: [g]
                }],
                mx: [{
                    mx: [g]
                }],
                my: [{
                    my: [g]
                }],
                ms: [{
                    ms: [g]
                }],
                me: [{
                    me: [g]
                }],
                mt: [{
                    mt: [g]
                }],
                mr: [{
                    mr: [g]
                }],
                mb: [{
                    mb: [g]
                }],
                ml: [{
                    ml: [g]
                }],
                "space-x": [{
                    "space-x": [j]
                }],
                "space-x-reverse": ["space-x-reverse"],
                "space-y": [{
                    "space-y": [j]
                }],
                "space-y-reverse": ["space-y-reverse"],
                w: [{
                    w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", Bd, t]
                }],
                "min-w": [{
                    "min-w": [Bd, t, "min", "max", "fit"]
                }],
                "max-w": [{
                    "max-w": [Bd, t, "none", "full", "min", "max", "fit", "prose", {
                        screen: [zd]
                    }, zd]
                }],
                h: [{
                    h: [Bd, t, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
                }],
                "min-h": [{
                    "min-h": [Bd, t, "min", "max", "fit", "svh", "lvh", "dvh"]
                }],
                "max-h": [{
                    "max-h": [Bd, t, "min", "max", "fit", "svh", "lvh", "dvh"]
                }],
                size: [{
                    size: [Bd, t, "auto", "min", "max", "fit"]
                }],
                "font-size": [{
                    text: ["base", zd, Ud]
                }],
                "font-smoothing": ["antialiased", "subpixel-antialiased"],
                "font-style": ["italic", "not-italic"],
                "font-weight": [{
                    font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", $d]
                }],
                "font-family": [{
                    font: [Jd]
                }],
                "fvn-normal": ["normal-nums"],
                "fvn-ordinal": ["ordinal"],
                "fvn-slashed-zero": ["slashed-zero"],
                "fvn-figure": ["lining-nums", "oldstyle-nums"],
                "fvn-spacing": ["proportional-nums", "tabular-nums"],
                "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
                tracking: [{
                    tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", Bd]
                }],
                "line-clamp": [{
                    "line-clamp": ["none", Dd, $d]
                }],
                leading: [{
                    leading: ["none", "tight", "snug", "normal", "relaxed", "loose", Md, Bd]
                }],
                "list-image": [{
                    "list-image": ["none", Bd]
                }],
                "list-style-type": [{
                    list: ["none", "disc", "decimal", Bd]
                }],
                "list-style-position": [{
                    list: ["inside", "outside"]
                }],
                "placeholder-color": [{
                    placeholder: [e]
                }],
                "placeholder-opacity": [{
                    "placeholder-opacity": [y]
                }],
                "text-alignment": [{
                    text: ["left", "center", "right", "justify", "start", "end"]
                }],
                "text-color": [{
                    text: [e]
                }],
                "text-opacity": [{
                    "text-opacity": [y]
                }],
                "text-decoration": ["underline", "overline", "line-through", "no-underline"],
                "text-decoration-style": [{
                    decoration: ["solid", "dashed", "dotted", "double", "none", "wavy"]
                }],
                "text-decoration-thickness": [{
                    decoration: ["auto", "from-font", Md, Ud]
                }],
                "underline-offset": [{
                    "underline-offset": ["auto", Md, Bd]
                }],
                "text-decoration-color": [{
                    decoration: [e]
                }],
                "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
                "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
                "text-wrap": [{
                    text: ["wrap", "nowrap", "balance", "pretty"]
                }],
                indent: [{
                    indent: _()
                }],
                "vertical-align": [{
                    align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", Bd]
                }],
                whitespace: [{
                    whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
                }],
                break: [{
                    break: ["normal", "words", "all", "keep"]
                }],
                hyphens: [{
                    hyphens: ["none", "manual", "auto"]
                }],
                content: [{
                    content: ["none", Bd]
                }],
                "bg-attachment": [{
                    bg: ["fixed", "local", "scroll"]
                }],
                "bg-clip": [{
                    "bg-clip": ["border", "padding", "content", "text"]
                }],
                "bg-opacity": [{
                    "bg-opacity": [y]
                }],
                "bg-origin": [{
                    "bg-origin": ["border", "padding", "content"]
                }],
                "bg-position": [{
                    bg: ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top", qd]
                }],
                "bg-repeat": [{
                    bg: ["no-repeat", {
                        repeat: ["", "x", "y", "round", "space"]
                    }]
                }],
                "bg-size": [{
                    bg: ["auto", "cover", "contain", Hd]
                }],
                "bg-image": [{
                    bg: ["none", {
                        "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
                    }, Gd]
                }],
                "bg-color": [{
                    bg: [e]
                }],
                "gradient-from-pos": [{
                    from: [f]
                }],
                "gradient-via-pos": [{
                    via: [f]
                }],
                "gradient-to-pos": [{
                    to: [f]
                }],
                "gradient-from": [{
                    from: [p]
                }],
                "gradient-via": [{
                    via: [p]
                }],
                "gradient-to": [{
                    to: [p]
                }],
                rounded: [{
                    rounded: [i]
                }],
                "rounded-s": [{
                    "rounded-s": [i]
                }],
                "rounded-e": [{
                    "rounded-e": [i]
                }],
                "rounded-t": [{
                    "rounded-t": [i]
                }],
                "rounded-r": [{
                    "rounded-r": [i]
                }],
                "rounded-b": [{
                    "rounded-b": [i]
                }],
                "rounded-l": [{
                    "rounded-l": [i]
                }],
                "rounded-ss": [{
                    "rounded-ss": [i]
                }],
                "rounded-se": [{
                    "rounded-se": [i]
                }],
                "rounded-ee": [{
                    "rounded-ee": [i]
                }],
                "rounded-es": [{
                    "rounded-es": [i]
                }],
                "rounded-tl": [{
                    "rounded-tl": [i]
                }],
                "rounded-tr": [{
                    "rounded-tr": [i]
                }],
                "rounded-br": [{
                    "rounded-br": [i]
                }],
                "rounded-bl": [{
                    "rounded-bl": [i]
                }],
                "border-w": [{
                    border: [a]
                }],
                "border-w-x": [{
                    "border-x": [a]
                }],
                "border-w-y": [{
                    "border-y": [a]
                }],
                "border-w-s": [{
                    "border-s": [a]
                }],
                "border-w-e": [{
                    "border-e": [a]
                }],
                "border-w-t": [{
                    "border-t": [a]
                }],
                "border-w-r": [{
                    "border-r": [a]
                }],
                "border-w-b": [{
                    "border-b": [a]
                }],
                "border-w-l": [{
                    "border-l": [a]
                }],
                "border-opacity": [{
                    "border-opacity": [y]
                }],
                "border-style": [{
                    border: ["solid", "dashed", "dotted", "double", "none", "hidden"]
                }],
                "divide-x": [{
                    "divide-x": [a]
                }],
                "divide-x-reverse": ["divide-x-reverse"],
                "divide-y": [{
                    "divide-y": [a]
                }],
                "divide-y-reverse": ["divide-y-reverse"],
                "divide-opacity": [{
                    "divide-opacity": [y]
                }],
                "divide-style": [{
                    divide: ["solid", "dashed", "dotted", "double", "none"]
                }],
                "border-color": [{
                    border: [s]
                }],
                "border-color-x": [{
                    "border-x": [s]
                }],
                "border-color-y": [{
                    "border-y": [s]
                }],
                "border-color-s": [{
                    "border-s": [s]
                }],
                "border-color-e": [{
                    "border-e": [s]
                }],
                "border-color-t": [{
                    "border-t": [s]
                }],
                "border-color-r": [{
                    "border-r": [s]
                }],
                "border-color-b": [{
                    "border-b": [s]
                }],
                "border-color-l": [{
                    "border-l": [s]
                }],
                "divide-color": [{
                    divide: [s]
                }],
                "outline-style": [{
                    outline: ["", "solid", "dashed", "dotted", "double", "none"]
                }],
                "outline-offset": [{
                    "outline-offset": [Md, Bd]
                }],
                "outline-w": [{
                    outline: [Md, Ud]
                }],
                "outline-color": [{
                    outline: [e]
                }],
                "ring-w": [{
                    ring: E()
                }],
                "ring-w-inset": ["ring-inset"],
                "ring-color": [{
                    ring: [e]
                }],
                "ring-opacity": [{
                    "ring-opacity": [y]
                }],
                "ring-offset-w": [{
                    "ring-offset": [Md, Ud]
                }],
                "ring-offset-color": [{
                    "ring-offset": [e]
                }],
                shadow: [{
                    shadow: ["", "inner", "none", zd, Yd]
                }],
                "shadow-color": [{
                    shadow: [Jd]
                }],
                opacity: [{
                    opacity: [y]
                }],
                "mix-blend": [{
                    "mix-blend": ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity", "plus-lighter", "plus-darker"]
                }],
                "bg-blend": [{
                    "bg-blend": ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"]
                }],
                filter: [{
                    filter: ["", "none"]
                }],
                blur: [{
                    blur: [r]
                }],
                brightness: [{
                    brightness: [n]
                }],
                contrast: [{
                    contrast: [l]
                }],
                "drop-shadow": [{
                    "drop-shadow": ["", "none", zd, Bd]
                }],
                grayscale: [{
                    grayscale: [c]
                }],
                "hue-rotate": [{
                    "hue-rotate": [u]
                }],
                invert: [{
                    invert: [d]
                }],
                saturate: [{
                    saturate: [b]
                }],
                sepia: [{
                    sepia: [w]
                }],
                "backdrop-filter": [{
                    "backdrop-filter": ["", "none"]
                }],
                "backdrop-blur": [{
                    "backdrop-blur": [r]
                }],
                "backdrop-brightness": [{
                    "backdrop-brightness": [n]
                }],
                "backdrop-contrast": [{
                    "backdrop-contrast": [l]
                }],
                "backdrop-grayscale": [{
                    "backdrop-grayscale": [c]
                }],
                "backdrop-hue-rotate": [{
                    "backdrop-hue-rotate": [u]
                }],
                "backdrop-invert": [{
                    "backdrop-invert": [d]
                }],
                "backdrop-opacity": [{
                    "backdrop-opacity": [y]
                }],
                "backdrop-saturate": [{
                    "backdrop-saturate": [b]
                }],
                "backdrop-sepia": [{
                    "backdrop-sepia": [w]
                }],
                "border-collapse": [{
                    border: ["collapse", "separate"]
                }],
                "border-spacing": [{
                    "border-spacing": [o]
                }],
                "border-spacing-x": [{
                    "border-spacing-x": [o]
                }],
                "border-spacing-y": [{
                    "border-spacing-y": [o]
                }],
                "table-layout": [{
                    table: ["auto", "fixed"]
                }],
                caption: [{
                    caption: ["top", "bottom"]
                }],
                transition: [{
                    transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", Bd]
                }],
                duration: [{
                    duration: O()
                }],
                ease: [{
                    ease: ["linear", "in", "out", "in-out", Bd]
                }],
                delay: [{
                    delay: O()
                }],
                animate: [{
                    animate: ["none", "spin", "ping", "pulse", "bounce", Bd]
                }],
                transform: [{
                    transform: ["", "gpu", "none"]
                }],
                scale: [{
                    scale: [x]
                }],
                "scale-x": [{
                    "scale-x": [x]
                }],
                "scale-y": [{
                    "scale-y": [x]
                }],
                rotate: [{
                    rotate: [Fd, Bd]
                }],
                "translate-x": [{
                    "translate-x": [S]
                }],
                "translate-y": [{
                    "translate-y": [S]
                }],
                "skew-x": [{
                    "skew-x": [k]
                }],
                "skew-y": [{
                    "skew-y": [k]
                }],
                "transform-origin": [{
                    origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", Bd]
                }],
                accent: [{
                    accent: ["auto", e]
                }],
                appearance: [{
                    appearance: ["none", "auto"]
                }],
                cursor: [{
                    cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", Bd]
                }],
                "caret-color": [{
                    caret: [e]
                }],
                "pointer-events": [{
                    "pointer-events": ["none", "auto"]
                }],
                resize: [{
                    resize: ["none", "y", "x", ""]
                }],
                "scroll-behavior": [{
                    scroll: ["auto", "smooth"]
                }],
                "scroll-m": [{
                    "scroll-m": _()
                }],
                "scroll-mx": [{
                    "scroll-mx": _()
                }],
                "scroll-my": [{
                    "scroll-my": _()
                }],
                "scroll-ms": [{
                    "scroll-ms": _()
                }],
                "scroll-me": [{
                    "scroll-me": _()
                }],
                "scroll-mt": [{
                    "scroll-mt": _()
                }],
                "scroll-mr": [{
                    "scroll-mr": _()
                }],
                "scroll-mb": [{
                    "scroll-mb": _()
                }],
                "scroll-ml": [{
                    "scroll-ml": _()
                }],
                "scroll-p": [{
                    "scroll-p": _()
                }],
                "scroll-px": [{
                    "scroll-px": _()
                }],
                "scroll-py": [{
                    "scroll-py": _()
                }],
                "scroll-ps": [{
                    "scroll-ps": _()
                }],
                "scroll-pe": [{
                    "scroll-pe": _()
                }],
                "scroll-pt": [{
                    "scroll-pt": _()
                }],
                "scroll-pr": [{
                    "scroll-pr": _()
                }],
                "scroll-pb": [{
                    "scroll-pb": _()
                }],
                "scroll-pl": [{
                    "scroll-pl": _()
                }],
                "snap-align": [{
                    snap: ["start", "end", "center", "align-none"]
                }],
                "snap-stop": [{
                    snap: ["normal", "always"]
                }],
                "snap-type": [{
                    snap: ["none", "x", "y", "both"]
                }],
                "snap-strictness": [{
                    snap: ["mandatory", "proximity"]
                }],
                touch: [{
                    touch: ["auto", "none", "manipulation"]
                }],
                "touch-x": [{
                    "touch-pan": ["x", "left", "right"]
                }],
                "touch-y": [{
                    "touch-pan": ["y", "up", "down"]
                }],
                "touch-pz": ["touch-pinch-zoom"],
                select: [{
                    select: ["none", "text", "all", "auto"]
                }],
                "will-change": [{
                    "will-change": ["auto", "scroll", "contents", "transform", Bd]
                }],
                fill: [{
                    fill: [e, "none"]
                }],
                "stroke-w": [{
                    stroke: [Md, Ud, $d]
                }],
                stroke: [{
                    stroke: [e, "none"]
                }],
                sr: ["sr-only", "not-sr-only"],
                "forced-color-adjust": [{
                    "forced-color-adjust": ["auto", "none"]
                }]
            },
            conflictingClassGroups: {
                overflow: ["overflow-x", "overflow-y"],
                overscroll: ["overscroll-x", "overscroll-y"],
                inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
                "inset-x": ["right", "left"],
                "inset-y": ["top", "bottom"],
                flex: ["basis", "grow", "shrink"],
                gap: ["gap-x", "gap-y"],
                p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
                px: ["pr", "pl"],
                py: ["pt", "pb"],
                m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
                mx: ["mr", "ml"],
                my: ["mt", "mb"],
                size: ["w", "h"],
                "font-size": ["leading"],
                "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
                "fvn-ordinal": ["fvn-normal"],
                "fvn-slashed-zero": ["fvn-normal"],
                "fvn-figure": ["fvn-normal"],
                "fvn-spacing": ["fvn-normal"],
                "fvn-fraction": ["fvn-normal"],
                "line-clamp": ["display", "overflow"],
                rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
                "rounded-s": ["rounded-ss", "rounded-es"],
                "rounded-e": ["rounded-se", "rounded-ee"],
                "rounded-t": ["rounded-tl", "rounded-tr"],
                "rounded-r": ["rounded-tr", "rounded-br"],
                "rounded-b": ["rounded-br", "rounded-bl"],
                "rounded-l": ["rounded-tl", "rounded-bl"],
                "border-spacing": ["border-spacing-x", "border-spacing-y"],
                "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
                "border-w-x": ["border-w-r", "border-w-l"],
                "border-w-y": ["border-w-t", "border-w-b"],
                "border-color": ["border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
                "border-color-x": ["border-color-r", "border-color-l"],
                "border-color-y": ["border-color-t", "border-color-b"],
                "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
                "scroll-mx": ["scroll-mr", "scroll-ml"],
                "scroll-my": ["scroll-mt", "scroll-mb"],
                "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
                "scroll-px": ["scroll-pr", "scroll-pl"],
                "scroll-py": ["scroll-pt", "scroll-pb"],
                touch: ["touch-x", "touch-y", "touch-pz"],
                "touch-x": ["touch"],
                "touch-y": ["touch"],
                "touch-pz": ["touch"]
            },
            conflictingClassGroupModifiers: {
                "font-size": ["leading"]
            }
        }
    }));

function nh(...e) {
    return rh(function() {
        for (var e, t, r = 0, n = "", s = arguments.length; r < s; r++)(e = arguments[r]) && (t = ud(e)) && (n && (n += " "), n += t);
        return n
    }(e))
}
const sh = cd("inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50", {
        variants: {
            variant: {
                default: "bg-black-900 text-white shadow hover:bg-black-800",
                destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
                outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
                secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
                ghost: "hover:bg-accent hover:text-accent-foreground",
                link: "text-primary underline-offset-4 hover:underline"
            },
            size: {
                default: "h-9 px-4 py-2",
                sm: "h-8 rounded-md px-3 text-xs",
                lg: "h-10 rounded-md px-8",
                icon: "h-9 w-9"
            }
        },
        defaultVariants: {
            variant: "default",
            size: "default"
        }
    }),
    ih = o.forwardRef((({
        className: e,
        variant: t,
        size: r,
        asChild: n = !1,
        ...s
    }, i) => {
        const o = n ? td : "button";
        return T.jsx(o, {
            className: nh(sh({
                variant: t,
                size: r,
                className: e
            })),
            ref: i,
            ...s
        })
    }));
ih.displayName = "Button";
/**
 * @license lucide-react v0.394.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const oh = (...e) => e.filter(((e, t, r) => Boolean(e) && r.indexOf(e) === t)).join(" ")
/**
 * @license lucide-react v0.394.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
;
var ah = {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
};
/**
 * @license lucide-react v0.394.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const lh = o.forwardRef((({
        color: e = "currentColor",
        size: t = 24,
        strokeWidth: r = 2,
        absoluteStrokeWidth: n,
        className: s = "",
        children: i,
        iconNode: a,
        ...l
    }, c) => o.createElement("svg", {
        ref: c,
        ...ah,
        width: t,
        height: t,
        stroke: e,
        strokeWidth: n ? 24 * Number(r) / Number(t) : r,
        className: oh("lucide", s),
        ...l
    }, [...a.map((([e, t]) => o.createElement(e, t))), ...Array.isArray(i) ? i : [i]]))),
    ch = (e, t) => {
        const r = o.forwardRef((({
            className: r,
            ...n
        }, s) => {
            return o.createElement(lh, {
                ref: s,
                iconNode: t,
                className: oh(`lucide-${i=e,i.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`, r),
                ...n
            });
            var i
        }));
        return r.displayName = `${e}`, r
    },
    uh = ch("ArrowRight", [
        ["path", {
            d: "M5 12h14",
            key: "1ays0h"
        }],
        ["path", {
            d: "m12 5 7 7-7 7",
            key: "xquz4c"
        }]
    ]),
    dh = ch("Award", [
        ["path", {
            d: "m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",
            key: "1yiouv"
        }],
        ["circle", {
            cx: "12",
            cy: "8",
            r: "6",
            key: "1vp47v"
        }]
    ]),
    hh = ch("BarChart", [
        ["line", {
            x1: "12",
            x2: "12",
            y1: "20",
            y2: "10",
            key: "1vz5eb"
        }],
        ["line", {
            x1: "18",
            x2: "18",
            y1: "20",
            y2: "4",
            key: "cun8e5"
        }],
        ["line", {
            x1: "6",
            x2: "6",
            y1: "20",
            y2: "16",
            key: "hq0ia6"
        }]
    ]),
    ph = ch("ChevronDown", [
        ["path", {
            d: "m6 9 6 6 6-6",
            key: "qrunsl"
        }]
    ]),
    fh = ch("ChevronRight", [
        ["path", {
            d: "m9 18 6-6-6-6",
            key: "mthhwq"
        }]
    ]),
    mh = ch("CircleCheckBig", [
        ["path", {
            d: "M22 11.08V12a10 10 0 1 1-5.93-9.14",
            key: "g774vq"
        }],
        ["path", {
            d: "m9 11 3 3L22 4",
            key: "1pflzl"
        }]
    ]),
    gh = ch("CircleUser", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }],
        ["circle", {
            cx: "12",
            cy: "10",
            r: "3",
            key: "ilqhr7"
        }],
        ["path", {
            d: "M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662",
            key: "154egf"
        }]
    ]),
    yh = ch("Clock", [
        ["circle", {
            cx: "12",
            cy: "12",
            r: "10",
            key: "1mglay"
        }],
        ["polyline", {
            points: "12 6 12 12 16 14",
            key: "68esgv"
        }]
    ]),
    vh = ch("Facebook", [
        ["path", {
            d: "M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z",
            key: "1jg4f8"
        }]
    ]),
    bh = ch("GraduationCap", [
        ["path", {
            d: "M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",
            key: "j76jl0"
        }],
        ["path", {
            d: "M22 10v6",
            key: "1lu8f3"
        }],
        ["path", {
            d: "M6 12.5V16a6 3 0 0 0 12 0v-3.5",
            key: "1r8lef"
        }]
    ]),
    xh = ch("Home", [
        ["path", {
            d: "m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
            key: "y5dka4"
        }],
        ["polyline", {
            points: "9 22 9 12 15 12 15 22",
            key: "e2us08"
        }]
    ]),
    wh = ch("Instagram", [
        ["rect", {
            width: "20",
            height: "20",
            x: "2",
            y: "2",
            rx: "5",
            ry: "5",
            key: "2e1cvw"
        }],
        ["path", {
            d: "M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z",
            key: "9exkf1"
        }],
        ["line", {
            x1: "17.5",
            x2: "17.51",
            y1: "6.5",
            y2: "6.5",
            key: "r4j83e"
        }]
    ]),
    kh = ch("Landmark", [
        ["line", {
            x1: "3",
            x2: "21",
            y1: "22",
            y2: "22",
            key: "j8o0r"
        }],
        ["line", {
            x1: "6",
            x2: "6",
            y1: "18",
            y2: "11",
            key: "10tf0k"
        }],
        ["line", {
            x1: "10",
            x2: "10",
            y1: "18",
            y2: "11",
            key: "54lgf6"
        }],
        ["line", {
            x1: "14",
            x2: "14",
            y1: "18",
            y2: "11",
            key: "380y"
        }],
        ["line", {
            x1: "18",
            x2: "18",
            y1: "18",
            y2: "11",
            key: "1kevvc"
        }],
        ["polygon", {
            points: "12 2 20 7 4 7",
            key: "jkujk7"
        }]
    ]),
    jh = ch("LayoutDashboard", [
        ["rect", {
            width: "7",
            height: "9",
            x: "3",
            y: "3",
            rx: "1",
            key: "10lvy0"
        }],
        ["rect", {
            width: "7",
            height: "5",
            x: "14",
            y: "3",
            rx: "1",
            key: "16une8"
        }],
        ["rect", {
            width: "7",
            height: "9",
            x: "14",
            y: "12",
            rx: "1",
            key: "1hutg5"
        }],
        ["rect", {
            width: "7",
            height: "5",
            x: "3",
            y: "16",
            rx: "1",
            key: "ldoo1y"
        }]
    ]),
    Sh = ch("Lightbulb", [
        ["path", {
            d: "M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",
            key: "1gvzjb"
        }],
        ["path", {
            d: "M9 18h6",
            key: "x1upvd"
        }],
        ["path", {
            d: "M10 22h4",
            key: "ceow96"
        }]
    ]),
    Th = ch("Linkedin", [
        ["path", {
            d: "M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z",
            key: "c2jq9f"
        }],
        ["rect", {
            width: "4",
            height: "12",
            x: "2",
            y: "9",
            key: "mk3on5"
        }],
        ["circle", {
            cx: "4",
            cy: "4",
            r: "2",
            key: "bt5ra8"
        }]
    ]),
    _h = ch("LoaderCircle", [
        ["path", {
            d: "M21 12a9 9 0 1 1-6.219-8.56",
            key: "13zald"
        }]
    ]),
    Eh = ch("LogIn", [
        ["path", {
            d: "M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",
            key: "u53s6r"
        }],
        ["polyline", {
            points: "10 17 15 12 10 7",
            key: "1ail0h"
        }],
        ["line", {
            x1: "15",
            x2: "3",
            y1: "12",
            y2: "12",
            key: "v6grx8"
        }]
    ]),
    Ph = ch("Mail", [
        ["rect", {
            width: "20",
            height: "16",
            x: "2",
            y: "4",
            rx: "2",
            key: "18n3k1"
        }],
        ["path", {
            d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",
            key: "1ocrg3"
        }]
    ]),
    Ch = ch("Menu", [
        ["line", {
            x1: "4",
            x2: "20",
            y1: "12",
            y2: "12",
            key: "1e0a9i"
        }],
        ["line", {
            x1: "4",
            x2: "20",
            y1: "6",
            y2: "6",
            key: "1owob3"
        }],
        ["line", {
            x1: "4",
            x2: "20",
            y1: "18",
            y2: "18",
            key: "yk5zj1"
        }]
    ]),
    Oh = ch("Search", [
        ["circle", {
            cx: "11",
            cy: "11",
            r: "8",
            key: "4ej97u"
        }],
        ["path", {
            d: "m21 21-4.3-4.3",
            key: "1qie3q"
        }]
    ]),
    Ah = ch("TriangleAlert", [
        ["path", {
            d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
            key: "wmoenq"
        }],
        ["path", {
            d: "M12 9v4",
            key: "juzpu7"
        }],
        ["path", {
            d: "M12 17h.01",
            key: "p32p05"
        }]
    ]),
    Nh = ch("Twitter", [
        ["path", {
            d: "M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z",
            key: "pff0z6"
        }]
    ]),
    Rh = ch("X", [
        ["path", {
            d: "M18 6 6 18",
            key: "1bl5f8"
        }],
        ["path", {
            d: "m6 6 12 12",
            key: "d8bk6v"
        }]
    ]),
    Ih = ch("Youtube", [
        ["path", {
            d: "M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17",
            key: "1q2vi4"
        }],
        ["path", {
            d: "m10 15 5-3-5-3z",
            key: "1jp15x"
        }]
    ]),
    Lh = ({
        type: e,
        onClose: t
    }) => {
        const r = {
            hidden: {
                opacity: 0,
                y: 10
            },
            visible: {
                opacity: 1,
                y: 0
            }
        };
        return T.jsxs(Pa.div, {
            className: "bg-white rounded-lg shadow-xl border border-gray-200 overflow-hidden w-full",
            variants: {
                hidden: {
                    opacity: 0,
                    y: -20
                },
                visible: {
                    opacity: 1,
                    y: 0,
                    transition: {
                        duration: .3,
                        staggerChildren: .05
                    }
                }
            },
            initial: "hidden",
            animate: "visible",
            exit: "hidden",
            children: ["work" === e && T.jsxs("div", {
                className: "grid grid-cols-3 gap-8 p-8",
                children: [T.jsx(Pa.div, {
                    variants: r,
                    className: "col-span-1",
                    children: T.jsxs(c, {
                        to: "/work/research-development",
                        className: "group flex items-start",
                        onClick: t,
                        children: [T.jsx("div", {
                            className: "mr-4 p-3 bg-black-100 rounded-lg group-hover:bg-black-200 transition-colors",
                            children: T.jsx(Sh, {
                                className: "h-6 w-6 text-black-700"
                            })
                        }), T.jsxs("div", {
                            children: [T.jsx("h3", {
                                className: "text-lg font-semibold text-gray-900 group-hover:text-black-700 transition-colors",
                                children: "Research & Development"
                            }), T.jsx("p", {
                                className: "text-gray-600 mt-1",
                                children: "Pioneering breakthrough technologies and scientific advancements"
                            }), T.jsxs("span", {
                                className: "inline-flex items-center mt-2 text-black-700 font-medium group-hover:translate-x-1 transition-transform",
                                children: ["Learn more ", T.jsx(uh, {
                                    className: "ml-1 h-4 w-4"
                                })]
                            })]
                        })]
                    })
                }), T.jsx(Pa.div, {
                    variants: r,
                    className: "col-span-1",
                    children: T.jsxs(c, {
                        to: "/work/billionaire-fund",
                        className: "group flex items-start",
                        onClick: t,
                        children: [T.jsx("div", {
                            className: "mr-4 p-3 bg-black-100 rounded-lg group-hover:bg-black-200 transition-colors",
                            children: T.jsx(kh, {
                                className: "h-6 w-6 text-black-700"
                            })
                        }), T.jsxs("div", {
                            children: [T.jsx("h3", {
                                className: "text-lg font-semibold text-gray-900 group-hover:text-black-700 transition-colors",
                                children: "Billionaire Fund"
                            }), T.jsx("p", {
                                className: "text-gray-600 mt-1",
                                children: "Strategic investments in transformative global initiatives"
                            }), T.jsxs("span", {
                                className: "inline-flex items-center mt-2 text-black-700 font-medium group-hover:translate-x-1 transition-transform",
                                children: ["Learn more ", T.jsx(uh, {
                                    className: "ml-1 h-4 w-4"
                                })]
                            })]
                        })]
                    })
                }), T.jsx(Pa.div, {
                    variants: r,
                    className: "col-span-1",
                    children: T.jsxs(c, {
                        to: "/work/education-stem",
                        className: "group flex items-start",
                        onClick: t,
                        children: [T.jsx("div", {
                            className: "mr-4 p-3 bg-black-100 rounded-lg group-hover:bg-black-200 transition-colors",
                            children: T.jsx(bh, {
                                className: "h-6 w-6 text-black-700"
                            })
                        }), T.jsxs("div", {
                            children: [T.jsx("h3", {
                                className: "text-lg font-semibold text-gray-900 group-hover:text-black-700 transition-colors",
                                children: "Education & STEM"
                            }), T.jsx("p", {
                                className: "text-gray-600 mt-1",
                                children: "Empowering the next generation through educational initiatives"
                            }), T.jsxs("span", {
                                className: "inline-flex items-center mt-2 text-black-700 font-medium group-hover:translate-x-1 transition-transform",
                                children: ["Learn more ", T.jsx(uh, {
                                    className: "ml-1 h-4 w-4"
                                })]
                            })]
                        })]
                    })
                }), T.jsx(Pa.div, {
                    variants: r,
                    className: "col-span-3",
                    children: T.jsxs("div", {
                        className: "mt-4 pt-6 border-t border-gray-200",
                        children: [T.jsx("h4", {
                            className: "text-sm font-semibold text-gray-500 mb-4",
                            children: "EXPLORE OUR IMPACT"
                        }), T.jsxs("div", {
                            className: "grid grid-cols-2 gap-4",
                            children: [T.jsxs(c, {
                                to: "/impact/stories",
                                className: "text-gray-700 hover:text-black-700 transition-colors flex items-center",
                                onClick: t,
                                children: [T.jsx(uh, {
                                    className: "mr-2 h-4 w-4"
                                }), " Impact Stories"]
                            }), T.jsxs(c, {
                                to: "/impact/reports",
                                className: "text-gray-700 hover:text-black-700 transition-colors flex items-center",
                                onClick: t,
                                children: [T.jsx(uh, {
                                    className: "mr-2 h-4 w-4"
                                }), " Annual Reports"]
                            })]
                        })]
                    })
                })]
            }), "about" === e && T.jsxs("div", {
                className: "grid grid-cols-3 gap-6 p-8",
                children: [T.jsx(Pa.div, {
                    variants: r,
                    className: "col-span-1",
                    children: T.jsxs(c, {
                        to: "/about/vision-mission",
                        className: "group flex flex-col",
                        onClick: t,
                        children: [T.jsx("div", {
                            className: "mb-3 p-3 bg-black-100 rounded-lg w-12 h-12 flex items-center justify-center group-hover:bg-black-200 transition-colors",
                            children: T.jsx(dh, {
                                className: "h-6 w-6 text-black-700"
                            })
                        }), T.jsx("h3", {
                            className: "text-base font-semibold text-gray-900 group-hover:text-black-700 transition-colors",
                            children: "Vision & Mission"
                        }), T.jsx("p", {
                            className: "text-sm text-gray-600 mt-1",
                            children: "Our guiding principles and goals"
                        })]
                    })
                }), T.jsx(Pa.div, {
                    variants: r,
                    className: "col-span-1",
                    children: T.jsxs(c, {
                        to: "/about/timeline",
                        className: "group flex flex-col",
                        onClick: t,
                        children: [T.jsx("div", {
                            className: "mb-3 p-3 bg-black-100 rounded-lg w-12 h-12 flex items-center justify-center group-hover:bg-black-200 transition-colors",
                            children: T.jsx(yh, {
                                className: "h-6 w-6 text-black-700"
                            })
                        }), T.jsx("h3", {
                            className: "text-base font-semibold text-gray-900 group-hover:text-black-700 transition-colors",
                            children: "History & Timeline"
                        }), T.jsx("p", {
                            className: "text-sm text-gray-600 mt-1",
                            children: "Our journey from vision to impact"
                        })]
                    })
                }), T.jsx(Pa.div, {
                    variants: r,
                    className: "col-span-1",
                    children: T.jsxs(c, {
                        to: "/about/governance",
                        className: "group flex flex-col",
                        onClick: t,
                        children: [T.jsx("div", {
                            className: "mb-3 p-3 bg-black-100 rounded-lg w-12 h-12 flex items-center justify-center group-hover:bg-black-200 transition-colors",
                            children: T.jsx(hh, {
                                className: "h-6 w-6 text-black-700"
                            })
                        }), T.jsx("h3", {
                            className: "text-base font-semibold text-gray-900 group-hover:text-black-700 transition-colors",
                            children: "Governance, Leadership & Transparency"
                        }), T.jsx("p", {
                            className: "text-sm text-gray-600 mt-1",
                            children: "Our structure, leadership, and commitment to accountability"
                        })]
                    })
                }), T.jsx(Pa.div, {
                    variants: r,
                    className: "col-span-3",
                    children: T.jsx("div", {
                        className: "mt-6 p-6 bg-gray-50 rounded-lg",
                        children: T.jsxs("div", {
                            className: "flex items-start",
                            children: [T.jsx("div", {
                                className: "flex-shrink-0",
                                children: T.jsx("img", {
                                    src: "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=300&q=80",
                                    alt: "Annual Report",
                                    className: "h-24 w-24 object-cover rounded-md"
                                })
                            }), T.jsxs("div", {
                                className: "ml-4",
                                children: [T.jsx("h3", {
                                    className: "text-lg font-semibold text-gray-900",
                                    children: "2023 Annual Impact Report"
                                }), T.jsx("p", {
                                    className: "text-gray-600 mt-1",
                                    children: "Explore how our initiatives have transformed lives and advanced scientific progress over the past year."
                                }), T.jsxs(c, {
                                    to: "/impact/reports/2023",
                                    className: "inline-flex items-center mt-2 text-black-700 font-medium hover:underline",
                                    onClick: t,
                                    children: ["Read the report ", T.jsx(uh, {
                                        className: "ml-1 h-4 w-4"
                                    })]
                                })]
                            })]
                        })
                    })
                })]
            })]
        })
    };
/**
 * @license lucide-react v0.394.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
function Mh(e, t, {
    checkForDefaultPrevented: r = !0
} = {}) {
    return function(n) {
        if (null == e || e(n), !1 === r || !n.defaultPrevented) return null == t ? void 0 : t(n)
    }
}

function Uh(e, t = []) {
    let r = [];
    const n = () => {
        const t = r.map((e => o.createContext(e)));
        return function(r) {
            const n = (null == r ? void 0 : r[e]) || t;
            return o.useMemo((() => ({
                [`__scope${e}`]: { ...r,
                    [e]: n
                }
            })), [r, n])
        }
    };
    return n.scopeName = e, [function(t, n) {
        const s = o.createContext(n),
            i = r.length;

        function a(t) {
            const {
                scope: r,
                children: n,
                ...a
            } = t, l = (null == r ? void 0 : r[e][i]) || s, c = o.useMemo((() => a), Object.values(a));
            return T.jsx(l.Provider, {
                value: c,
                children: n
            })
        }
        return r = [...r, n], a.displayName = t + "Provider", [a, function(r, a) {
            const l = (null == a ? void 0 : a[e][i]) || s,
                c = o.useContext(l);
            if (c) return c;
            if (void 0 !== n) return n;
            throw new Error(`\`${r}\` must be used within \`${t}\``)
        }]
    }, Dh(n, ...t)]
}

function Dh(...e) {
    const t = e[0];
    if (1 === e.length) return t;
    const r = () => {
        const r = e.map((e => ({
            useScope: e(),
            scopeName: e.scopeName
        })));
        return function(e) {
            const n = r.reduce(((t, {
                useScope: r,
                scopeName: n
            }) => ({ ...t,
                ...r(e)[`__scope${n}`]
            })), {});
            return o.useMemo((() => ({
                [`__scope${t.scopeName}`]: n
            })), [n])
        }
    };
    return r.scopeName = t.scopeName, r
}
var $h = Boolean(null == globalThis ? void 0 : globalThis.document) ? o.useLayoutEffect : () => {},
    Fh = u["useId".toString()] || (() => {}),
    Vh = 0;

function Bh(e) {
    const [t, r] = o.useState(Fh());
    return $h((() => {
        r((e => e ? ? String(Vh++)))
    }), [e]), e || (t ? `radix-${t}` : "")
}

function zh(e) {
    const t = o.useRef(e);
    return o.useEffect((() => {
        t.current = e
    })), o.useMemo((() => (...e) => {
        var r;
        return null == (r = t.current) ? void 0 : r.call(t, ...e)
    }), [])
}

function Wh({
    prop: e,
    defaultProp: t,
    onChange: r = () => {}
}) {
    const [n, s] = function({
        defaultProp: e,
        onChange: t
    }) {
        const r = o.useState(e),
            [n] = r,
            s = o.useRef(n),
            i = zh(t);
        return o.useEffect((() => {
            s.current !== n && (i(n), s.current = n)
        }), [n, s, i]), r
    }({
        defaultProp: t,
        onChange: r
    }), i = void 0 !== e, a = i ? e : n, l = zh(r);
    return [a, o.useCallback((t => {
        if (i) {
            const r = "function" == typeof t ? t(e) : t;
            r !== e && l(r)
        } else s(t)
    }), [i, e, s, l])]
}
var Hh = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce(((e, t) => {
    const r = o.forwardRef(((e, r) => {
        const {
            asChild: n,
            ...s
        } = e, i = n ? td : t;
        return "undefined" != typeof window && (window[Symbol.for("radix-ui")] = !0), T.jsx(i, { ...s,
            ref: r
        })
    }));
    return r.displayName = `Primitive.${t}`, { ...e,
        [t]: r
    }
}), {});

function qh(e, t) {
    e && d.flushSync((() => e.dispatchEvent(t)))
}
var Kh, Gh = "dismissableLayer.update",
    Yh = "dismissableLayer.pointerDownOutside",
    Jh = "dismissableLayer.focusOutside",
    Xh = o.createContext({
        layers: new Set,
        layersWithOutsidePointerEventsDisabled: new Set,
        branches: new Set
    }),
    Zh = o.forwardRef(((e, t) => {
        const {
            disableOutsidePointerEvents: r = !1,
            onEscapeKeyDown: n,
            onPointerDownOutside: s,
            onFocusOutside: i,
            onInteractOutside: a,
            onDismiss: l,
            ...c
        } = e, u = o.useContext(Xh), [d, h] = o.useState(null), p = (null == d ? void 0 : d.ownerDocument) ? ? (null == globalThis ? void 0 : globalThis.document), [, f] = o.useState({}), m = ed(t, (e => h(e))), g = Array.from(u.layers), [y] = [...u.layersWithOutsidePointerEventsDisabled].slice(-1), v = g.indexOf(y), b = d ? g.indexOf(d) : -1, x = u.layersWithOutsidePointerEventsDisabled.size > 0, w = b >= v, k = function(e, t = (null == globalThis ? void 0 : globalThis.document)) {
            const r = zh(e),
                n = o.useRef(!1),
                s = o.useRef((() => {}));
            return o.useEffect((() => {
                const e = e => {
                        if (e.target && !n.current) {
                            let n = function() {
                                tp(Yh, r, i, {
                                    discrete: !0
                                })
                            };
                            const i = {
                                originalEvent: e
                            };
                            "touch" === e.pointerType ? (t.removeEventListener("click", s.current), s.current = n, t.addEventListener("click", s.current, {
                                once: !0
                            })) : n()
                        } else t.removeEventListener("click", s.current);
                        n.current = !1
                    },
                    i = window.setTimeout((() => {
                        t.addEventListener("pointerdown", e)
                    }), 0);
                return () => {
                    window.clearTimeout(i), t.removeEventListener("pointerdown", e), t.removeEventListener("click", s.current)
                }
            }), [t, r]), {
                onPointerDownCapture: () => n.current = !0
            }
        }((e => {
            const t = e.target,
                r = [...u.branches].some((e => e.contains(t)));
            w && !r && (null == s || s(e), null == a || a(e), e.defaultPrevented || null == l || l())
        }), p), j = function(e, t = (null == globalThis ? void 0 : globalThis.document)) {
            const r = zh(e),
                n = o.useRef(!1);
            return o.useEffect((() => {
                const e = e => {
                    if (e.target && !n.current) {
                        tp(Jh, r, {
                            originalEvent: e
                        }, {
                            discrete: !1
                        })
                    }
                };
                return t.addEventListener("focusin", e), () => t.removeEventListener("focusin", e)
            }), [t, r]), {
                onFocusCapture: () => n.current = !0,
                onBlurCapture: () => n.current = !1
            }
        }((e => {
            const t = e.target;
            [...u.branches].some((e => e.contains(t))) || (null == i || i(e), null == a || a(e), e.defaultPrevented || null == l || l())
        }), p);
        return function(e, t = (null == globalThis ? void 0 : globalThis.document)) {
            const r = zh(e);
            o.useEffect((() => {
                const e = e => {
                    "Escape" === e.key && r(e)
                };
                return t.addEventListener("keydown", e, {
                    capture: !0
                }), () => t.removeEventListener("keydown", e, {
                    capture: !0
                })
            }), [r, t])
        }((e => {
            b === u.layers.size - 1 && (null == n || n(e), !e.defaultPrevented && l && (e.preventDefault(), l()))
        }), p), o.useEffect((() => {
            if (d) return r && (0 === u.layersWithOutsidePointerEventsDisabled.size && (Kh = p.body.style.pointerEvents, p.body.style.pointerEvents = "none"), u.layersWithOutsidePointerEventsDisabled.add(d)), u.layers.add(d), ep(), () => {
                r && 1 === u.layersWithOutsidePointerEventsDisabled.size && (p.body.style.pointerEvents = Kh)
            }
        }), [d, p, r, u]), o.useEffect((() => () => {
            d && (u.layers.delete(d), u.layersWithOutsidePointerEventsDisabled.delete(d), ep())
        }), [d, u]), o.useEffect((() => {
            const e = () => f({});
            return document.addEventListener(Gh, e), () => document.removeEventListener(Gh, e)
        }), []), T.jsx(Hh.div, { ...c,
            ref: m,
            style: {
                pointerEvents: x ? w ? "auto" : "none" : void 0,
                ...e.style
            },
            onFocusCapture: Mh(e.onFocusCapture, j.onFocusCapture),
            onBlurCapture: Mh(e.onBlurCapture, j.onBlurCapture),
            onPointerDownCapture: Mh(e.onPointerDownCapture, k.onPointerDownCapture)
        })
    }));
Zh.displayName = "DismissableLayer";
var Qh = o.forwardRef(((e, t) => {
    const r = o.useContext(Xh),
        n = o.useRef(null),
        s = ed(t, n);
    return o.useEffect((() => {
        const e = n.current;
        if (e) return r.branches.add(e), () => {
            r.branches.delete(e)
        }
    }), [r.branches]), T.jsx(Hh.div, { ...e,
        ref: s
    })
}));

function ep() {
    const e = new CustomEvent(Gh);
    document.dispatchEvent(e)
}

function tp(e, t, r, {
    discrete: n
}) {
    const s = r.originalEvent.target,
        i = new CustomEvent(e, {
            bubbles: !1,
            cancelable: !0,
            detail: r
        });
    t && s.addEventListener(e, t, {
        once: !0
    }), n ? qh(s, i) : s.dispatchEvent(i)
}
Qh.displayName = "DismissableLayerBranch";
var rp = Zh,
    np = Qh,
    sp = "focusScope.autoFocusOnMount",
    ip = "focusScope.autoFocusOnUnmount",
    op = {
        bubbles: !1,
        cancelable: !0
    },
    ap = o.forwardRef(((e, t) => {
        const {
            loop: r = !1,
            trapped: n = !1,
            onMountAutoFocus: s,
            onUnmountAutoFocus: i,
            ...a
        } = e, [l, c] = o.useState(null), u = zh(s), d = zh(i), h = o.useRef(null), p = ed(t, (e => c(e))), f = o.useRef({
            paused: !1,
            pause() {
                this.paused = !0
            },
            resume() {
                this.paused = !1
            }
        }).current;
        o.useEffect((() => {
            if (n) {
                let e = function(e) {
                        if (f.paused || !l) return;
                        const t = e.target;
                        l.contains(t) ? h.current = t : dp(h.current, {
                            select: !0
                        })
                    },
                    t = function(e) {
                        if (f.paused || !l) return;
                        const t = e.relatedTarget;
                        null !== t && (l.contains(t) || dp(h.current, {
                            select: !0
                        }))
                    },
                    r = function(e) {
                        if (document.activeElement === document.body)
                            for (const t of e) t.removedNodes.length > 0 && dp(l)
                    };
                document.addEventListener("focusin", e), document.addEventListener("focusout", t);
                const n = new MutationObserver(r);
                return l && n.observe(l, {
                    childList: !0,
                    subtree: !0
                }), () => {
                    document.removeEventListener("focusin", e), document.removeEventListener("focusout", t), n.disconnect()
                }
            }
        }), [n, l, f.paused]), o.useEffect((() => {
            if (l) {
                hp.add(f);
                const t = document.activeElement;
                if (!l.contains(t)) {
                    const r = new CustomEvent(sp, op);
                    l.addEventListener(sp, u), l.dispatchEvent(r), r.defaultPrevented || (! function(e, {
                        select: t = !1
                    } = {}) {
                        const r = document.activeElement;
                        for (const n of e)
                            if (dp(n, {
                                    select: t
                                }), document.activeElement !== r) return
                    }((e = lp(l), e.filter((e => "A" !== e.tagName))), {
                        select: !0
                    }), document.activeElement === t && dp(l))
                }
                return () => {
                    l.removeEventListener(sp, u), setTimeout((() => {
                        const e = new CustomEvent(ip, op);
                        l.addEventListener(ip, d), l.dispatchEvent(e), e.defaultPrevented || dp(t ? ? document.body, {
                            select: !0
                        }), l.removeEventListener(ip, d), hp.remove(f)
                    }), 0)
                }
            }
            var e
        }), [l, u, d, f]);
        const m = o.useCallback((e => {
            if (!r && !n) return;
            if (f.paused) return;
            const t = "Tab" === e.key && !e.altKey && !e.ctrlKey && !e.metaKey,
                s = document.activeElement;
            if (t && s) {
                const t = e.currentTarget,
                    [n, i] = function(e) {
                        const t = lp(e),
                            r = cp(t, e),
                            n = cp(t.reverse(), e);
                        return [r, n]
                    }(t);
                n && i ? e.shiftKey || s !== i ? e.shiftKey && s === n && (e.preventDefault(), r && dp(i, {
                    select: !0
                })) : (e.preventDefault(), r && dp(n, {
                    select: !0
                })) : s === t && e.preventDefault()
            }
        }), [r, n, f.paused]);
        return T.jsx(Hh.div, {
            tabIndex: -1,
            ...a,
            ref: p,
            onKeyDown: m
        })
    }));

function lp(e) {
    const t = [],
        r = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
            acceptNode: e => {
                const t = "INPUT" === e.tagName && "hidden" === e.type;
                return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
            }
        });
    for (; r.nextNode();) t.push(r.currentNode);
    return t
}

function cp(e, t) {
    for (const r of e)
        if (!up(r, {
                upTo: t
            })) return r
}

function up(e, {
    upTo: t
}) {
    if ("hidden" === getComputedStyle(e).visibility) return !0;
    for (; e;) {
        if (void 0 !== t && e === t) return !1;
        if ("none" === getComputedStyle(e).display) return !0;
        e = e.parentElement
    }
    return !1
}

function dp(e, {
    select: t = !1
} = {}) {
    if (e && e.focus) {
        const r = document.activeElement;
        e.focus({
            preventScroll: !0
        }), e !== r && function(e) {
            return e instanceof HTMLInputElement && "select" in e
        }(e) && t && e.select()
    }
}
ap.displayName = "FocusScope";
var hp = function() {
    let e = [];
    return {
        add(t) {
            const r = e[0];
            t !== r && (null == r || r.pause()), e = pp(e, t), e.unshift(t)
        },
        remove(t) {
            var r;
            e = pp(e, t), null == (r = e[0]) || r.resume()
        }
    }
}();

function pp(e, t) {
    const r = [...e],
        n = r.indexOf(t);
    return -1 !== n && r.splice(n, 1), r
}
var fp = o.forwardRef(((e, t) => {
    var r;
    const {
        container: n,
        ...s
    } = e, [i, a] = o.useState(!1);
    $h((() => a(!0)), []);
    const l = n || i && (null == (r = null == globalThis ? void 0 : globalThis.document) ? void 0 : r.body);
    return l ? h.createPortal(T.jsx(Hh.div, { ...s,
        ref: t
    }), l) : null
}));
fp.displayName = "Portal";
var mp = e => {
    const {
        present: t,
        children: r
    } = e, n = function(e) {
        const [t, r] = o.useState(), n = o.useRef({}), s = o.useRef(e), i = o.useRef("none"), a = e ? "mounted" : "unmounted", [l, c] = function(e, t) {
            return o.useReducer(((e, r) => t[e][r] ? ? e), e)
        }(a, {
            mounted: {
                UNMOUNT: "unmounted",
                ANIMATION_OUT: "unmountSuspended"
            },
            unmountSuspended: {
                MOUNT: "mounted",
                ANIMATION_END: "unmounted"
            },
            unmounted: {
                MOUNT: "mounted"
            }
        });
        return o.useEffect((() => {
            const e = gp(n.current);
            i.current = "mounted" === l ? e : "none"
        }), [l]), $h((() => {
            const t = n.current,
                r = s.current;
            if (r !== e) {
                const n = i.current,
                    o = gp(t);
                if (e) c("MOUNT");
                else if ("none" === o || "none" === (null == t ? void 0 : t.display)) c("UNMOUNT");
                else {
                    c(r && n !== o ? "ANIMATION_OUT" : "UNMOUNT")
                }
                s.current = e
            }
        }), [e, c]), $h((() => {
            if (t) {
                const e = e => {
                        const r = gp(n.current).includes(e.animationName);
                        e.target === t && r && d.flushSync((() => c("ANIMATION_END")))
                    },
                    r = e => {
                        e.target === t && (i.current = gp(n.current))
                    };
                return t.addEventListener("animationstart", r), t.addEventListener("animationcancel", e), t.addEventListener("animationend", e), () => {
                    t.removeEventListener("animationstart", r), t.removeEventListener("animationcancel", e), t.removeEventListener("animationend", e)
                }
            }
            c("ANIMATION_END")
        }), [t, c]), {
            isPresent: ["mounted", "unmountSuspended"].includes(l),
            ref: o.useCallback((e => {
                e && (n.current = getComputedStyle(e)), r(e)
            }), [])
        }
    }(t), s = "function" == typeof r ? r({
        present: n.isPresent
    }) : o.Children.only(r), i = ed(n.ref, function(e) {
        var t, r;
        let n = null == (t = Object.getOwnPropertyDescriptor(e.props, "ref")) ? void 0 : t.get,
            s = n && "isReactWarning" in n && n.isReactWarning;
        if (s) return e.ref;
        if (n = null == (r = Object.getOwnPropertyDescriptor(e, "ref")) ? void 0 : r.get, s = n && "isReactWarning" in n && n.isReactWarning, s) return e.props.ref;
        return e.props.ref || e.ref
    }(s));
    return "function" == typeof r || n.isPresent ? o.cloneElement(s, {
        ref: i
    }) : null
};

function gp(e) {
    return (null == e ? void 0 : e.animationName) || "none"
}
mp.displayName = "Presence";
var yp = 0;

function vp() {
    const e = document.createElement("span");
    return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e
}
var bp = function() {
    return bp = Object.assign || function(e) {
        for (var t, r = 1, n = arguments.length; r < n; r++)
            for (var s in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, s) && (e[s] = t[s]);
        return e
    }, bp.apply(this, arguments)
};

function xp(e, t) {
    var r = {};
    for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var s = 0;
        for (n = Object.getOwnPropertySymbols(e); s < n.length; s++) t.indexOf(n[s]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[s]) && (r[n[s]] = e[n[s]])
    }
    return r
}
"function" == typeof SuppressedError && SuppressedError;
var wp = "right-scroll-bar-position",
    kp = "width-before-scroll-bar";

function jp(e, t) {
    return "function" == typeof e ? e(t) : e && (e.current = t), e
}
var Sp = "undefined" != typeof window ? o.useLayoutEffect : o.useEffect,
    Tp = new WeakMap;

function _p(e, t) {
    var r, n, s, i = (r = null, n = function(t) {
        return e.forEach((function(e) {
            return jp(e, t)
        }))
    }, (s = o.useState((function() {
        return {
            value: r,
            callback: n,
            facade: {
                get current() {
                    return s.value
                },
                set current(e) {
                    var t = s.value;
                    t !== e && (s.value = e, s.callback(e, t))
                }
            }
        }
    }))[0]).callback = n, s.facade);
    return Sp((function() {
        var t = Tp.get(i);
        if (t) {
            var r = new Set(t),
                n = new Set(e),
                s = i.current;
            r.forEach((function(e) {
                n.has(e) || jp(e, null)
            })), n.forEach((function(e) {
                r.has(e) || jp(e, s)
            }))
        }
        Tp.set(i, e)
    }), [e]), i
}

function Ep(e) {
    return e
}
var Pp = function(e) {
    var t = e.sideCar,
        r = xp(e, ["sideCar"]);
    if (!t) throw new Error("Sidecar: please provide `sideCar` property to import the right car");
    var n = t.read();
    if (!n) throw new Error("Sidecar medium not found");
    return o.createElement(n, bp({}, r))
};
Pp.isSideCarExport = !0;
var Cp = function(e) {
        void 0 === e && (e = {});
        var t = function(e, t) {
            void 0 === t && (t = Ep);
            var r = [],
                n = !1;
            return {
                read: function() {
                    if (n) throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
                    return r.length ? r[r.length - 1] : e
                },
                useMedium: function(e) {
                    var s = t(e, n);
                    return r.push(s),
                        function() {
                            r = r.filter((function(e) {
                                return e !== s
                            }))
                        }
                },
                assignSyncMedium: function(e) {
                    for (n = !0; r.length;) {
                        var t = r;
                        r = [], t.forEach(e)
                    }
                    r = {
                        push: function(t) {
                            return e(t)
                        },
                        filter: function() {
                            return r
                        }
                    }
                },
                assignMedium: function(e) {
                    n = !0;
                    var t = [];
                    if (r.length) {
                        var s = r;
                        r = [], s.forEach(e), t = r
                    }
                    var i = function() {
                            var r = t;
                            t = [], r.forEach(e)
                        },
                        o = function() {
                            return Promise.resolve().then(i)
                        };
                    o(), r = {
                        push: function(e) {
                            t.push(e), o()
                        },
                        filter: function(e) {
                            return t = t.filter(e), r
                        }
                    }
                }
            }
        }(null);
        return t.options = bp({
            async: !0,
            ssr: !1
        }, e), t
    }(),
    Op = function() {},
    Ap = o.forwardRef((function(e, t) {
        var r = o.useRef(null),
            n = o.useState({
                onScrollCapture: Op,
                onWheelCapture: Op,
                onTouchMoveCapture: Op
            }),
            s = n[0],
            i = n[1],
            a = e.forwardProps,
            l = e.children,
            c = e.className,
            u = e.removeScrollBar,
            d = e.enabled,
            h = e.shards,
            p = e.sideCar,
            f = e.noIsolation,
            m = e.inert,
            g = e.allowPinchZoom,
            y = e.as,
            v = void 0 === y ? "div" : y,
            b = e.gapMode,
            x = xp(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]),
            w = p,
            k = _p([r, t]),
            j = bp(bp({}, x), s);
        return o.createElement(o.Fragment, null, d && o.createElement(w, {
            sideCar: Cp,
            removeScrollBar: u,
            shards: h,
            noIsolation: f,
            inert: m,
            setCallbacks: i,
            allowPinchZoom: !!g,
            lockRef: r,
            gapMode: b
        }), a ? o.cloneElement(o.Children.only(l), bp(bp({}, j), {
            ref: k
        })) : o.createElement(v, bp({}, j, {
            className: c,
            ref: k
        }), l))
    }));
Ap.defaultProps = {
    enabled: !0,
    removeScrollBar: !0,
    inert: !1
}, Ap.classNames = {
    fullWidth: kp,
    zeroRight: wp
};

function Np() {
    if (!document) return null;
    var e = document.createElement("style");
    e.type = "text/css";
    var t = function() {
        if ("undefined" != typeof __webpack_nonce__) return __webpack_nonce__
    }();
    return t && e.setAttribute("nonce", t), e
}
var Rp = function() {
        var e = 0,
            t = null;
        return {
            add: function(r) {
                var n, s;
                0 == e && (t = Np()) && (s = r, (n = t).styleSheet ? n.styleSheet.cssText = s : n.appendChild(document.createTextNode(s)), function(e) {
                    (document.head || document.getElementsByTagName("head")[0]).appendChild(e)
                }(t)), e++
            },
            remove: function() {
                !--e && t && (t.parentNode && t.parentNode.removeChild(t), t = null)
            }
        }
    },
    Ip = function() {
        var e, t = (e = Rp(), function(t, r) {
            o.useEffect((function() {
                return e.add(t),
                    function() {
                        e.remove()
                    }
            }), [t && r])
        });
        return function(e) {
            var r = e.styles,
                n = e.dynamic;
            return t(r, n), null
        }
    },
    Lp = {
        left: 0,
        top: 0,
        right: 0,
        gap: 0
    },
    Mp = function(e) {
        return parseInt(e || "", 10) || 0
    },
    Up = function(e) {
        if (void 0 === e && (e = "margin"), "undefined" == typeof window) return Lp;
        var t = function(e) {
                var t = window.getComputedStyle(document.body),
                    r = t["padding" === e ? "paddingLeft" : "marginLeft"],
                    n = t["padding" === e ? "paddingTop" : "marginTop"],
                    s = t["padding" === e ? "paddingRight" : "marginRight"];
                return [Mp(r), Mp(n), Mp(s)]
            }(e),
            r = document.documentElement.clientWidth,
            n = window.innerWidth;
        return {
            left: t[0],
            top: t[1],
            right: t[2],
            gap: Math.max(0, n - r + t[2] - t[0])
        }
    },
    Dp = Ip(),
    $p = "data-scroll-locked",
    Fp = function(e, t, r, n) {
        var s = e.left,
            i = e.top,
            o = e.right,
            a = e.gap;
        return void 0 === r && (r = "margin"), "\n  .".concat("with-scroll-bars-hidden", " {\n   overflow: hidden ").concat(n, ";\n   padding-right: ").concat(a, "px ").concat(n, ";\n  }\n  body[").concat($p, "] {\n    overflow: hidden ").concat(n, ";\n    overscroll-behavior: contain;\n    ").concat([t && "position: relative ".concat(n, ";"), "margin" === r && "\n    padding-left: ".concat(s, "px;\n    padding-top: ").concat(i, "px;\n    padding-right: ").concat(o, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(a, "px ").concat(n, ";\n    "), "padding" === r && "padding-right: ".concat(a, "px ").concat(n, ";")].filter(Boolean).join(""), "\n  }\n  \n  .").concat(wp, " {\n    right: ").concat(a, "px ").concat(n, ";\n  }\n  \n  .").concat(kp, " {\n    margin-right: ").concat(a, "px ").concat(n, ";\n  }\n  \n  .").concat(wp, " .").concat(wp, " {\n    right: 0 ").concat(n, ";\n  }\n  \n  .").concat(kp, " .").concat(kp, " {\n    margin-right: 0 ").concat(n, ";\n  }\n  \n  body[").concat($p, "] {\n    ").concat("--removed-body-scroll-bar-size", ": ").concat(a, "px;\n  }\n")
    },
    Vp = function() {
        var e = parseInt(document.body.getAttribute($p) || "0", 10);
        return isFinite(e) ? e : 0
    },
    Bp = function(e) {
        var t = e.noRelative,
            r = e.noImportant,
            n = e.gapMode,
            s = void 0 === n ? "margin" : n;
        o.useEffect((function() {
            return document.body.setAttribute($p, (Vp() + 1).toString()),
                function() {
                    var e = Vp() - 1;
                    e <= 0 ? document.body.removeAttribute($p) : document.body.setAttribute($p, e.toString())
                }
        }), []);
        var i = o.useMemo((function() {
            return Up(s)
        }), [s]);
        return o.createElement(Dp, {
            styles: Fp(i, !t, s, r ? "" : "!important")
        })
    },
    zp = !1;
if ("undefined" != typeof window) try {
    var Wp = Object.defineProperty({}, "passive", {
        get: function() {
            return zp = !0, !0
        }
    });
    window.addEventListener("test", Wp, Wp), window.removeEventListener("test", Wp, Wp)
} catch (Iw) {
    zp = !1
}
var Hp = !!zp && {
        passive: !1
    },
    qp = function(e, t) {
        var r = window.getComputedStyle(e);
        return "hidden" !== r[t] && !(r.overflowY === r.overflowX && ! function(e) {
            return "TEXTAREA" === e.tagName
        }(e) && "visible" === r[t])
    },
    Kp = function(e, t) {
        var r = t.ownerDocument,
            n = t;
        do {
            if ("undefined" != typeof ShadowRoot && n instanceof ShadowRoot && (n = n.host), Gp(e, n)) {
                var s = Yp(e, n);
                if (s[1] > s[2]) return !0
            }
            n = n.parentNode
        } while (n && n !== r.body);
        return !1
    },
    Gp = function(e, t) {
        return "v" === e ? function(e) {
            return qp(e, "overflowY")
        }(t) : function(e) {
            return qp(e, "overflowX")
        }(t)
    },
    Yp = function(e, t) {
        return "v" === e ? [(r = t).scrollTop, r.scrollHeight, r.clientHeight] : function(e) {
            return [e.scrollLeft, e.scrollWidth, e.clientWidth]
        }(t);
        var r
    },
    Jp = function(e) {
        return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0]
    },
    Xp = function(e) {
        return [e.deltaX, e.deltaY]
    },
    Zp = function(e) {
        return e && "current" in e ? e.current : e
    },
    Qp = function(e) {
        return "\n  .block-interactivity-".concat(e, " {pointer-events: none;}\n  .allow-interactivity-").concat(e, " {pointer-events: all;}\n")
    },
    ef = 0,
    tf = [];

function rf(e) {
    for (var t = null; null !== e;) e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
    return t
}
const nf = (sf = function(e) {
    var t = o.useRef([]),
        r = o.useRef([0, 0]),
        n = o.useRef(),
        s = o.useState(ef++)[0],
        i = o.useState(Ip)[0],
        a = o.useRef(e);
    o.useEffect((function() {
        a.current = e
    }), [e]), o.useEffect((function() {
        if (e.inert) {
            document.body.classList.add("block-interactivity-".concat(s));
            var t = function(e, t, r) {
                if (r || 2 === arguments.length)
                    for (var n, s = 0, i = t.length; s < i; s++) !n && s in t || (n || (n = Array.prototype.slice.call(t, 0, s)), n[s] = t[s]);
                return e.concat(n || Array.prototype.slice.call(t))
            }([e.lockRef.current], (e.shards || []).map(Zp), !0).filter(Boolean);
            return t.forEach((function(e) {
                    return e.classList.add("allow-interactivity-".concat(s))
                })),
                function() {
                    document.body.classList.remove("block-interactivity-".concat(s)), t.forEach((function(e) {
                        return e.classList.remove("allow-interactivity-".concat(s))
                    }))
                }
        }
    }), [e.inert, e.lockRef.current, e.shards]);
    var l = o.useCallback((function(e, t) {
            if ("touches" in e && 2 === e.touches.length) return !a.current.allowPinchZoom;
            var s, i = Jp(e),
                o = r.current,
                l = "deltaX" in e ? e.deltaX : o[0] - i[0],
                c = "deltaY" in e ? e.deltaY : o[1] - i[1],
                u = e.target,
                d = Math.abs(l) > Math.abs(c) ? "h" : "v";
            if ("touches" in e && "h" === d && "range" === u.type) return !1;
            var h = Kp(d, u);
            if (!h) return !0;
            if (h ? s = d : (s = "v" === d ? "h" : "v", h = Kp(d, u)), !h) return !1;
            if (!n.current && "changedTouches" in e && (l || c) && (n.current = s), !s) return !0;
            var p = n.current || s;
            return function(e, t, r, n) {
                var s = function(e, t) {
                        return "h" === e && "rtl" === t ? -1 : 1
                    }(e, window.getComputedStyle(t).direction),
                    i = s * n,
                    o = r.target,
                    a = t.contains(o),
                    l = !1,
                    c = i > 0,
                    u = 0,
                    d = 0;
                do {
                    var h = Yp(e, o),
                        p = h[0],
                        f = h[1] - h[2] - s * p;
                    (p || f) && Gp(e, o) && (u += f, d += p), o = o instanceof ShadowRoot ? o.host : o.parentNode
                } while (!a && o !== document.body || a && (t.contains(o) || t === o));
                return (c && Math.abs(u) < 1 || !c && Math.abs(d) < 1) && (l = !0), l
            }(p, t, e, "h" === p ? l : c)
        }), []),
        c = o.useCallback((function(e) {
            var r = e;
            if (tf.length && tf[tf.length - 1] === i) {
                var n = "deltaY" in r ? Xp(r) : Jp(r),
                    s = t.current.filter((function(e) {
                        return e.name === r.type && (e.target === r.target || r.target === e.shadowParent) && (t = e.delta, s = n, t[0] === s[0] && t[1] === s[1]);
                        var t, s
                    }))[0];
                if (s && s.should) r.cancelable && r.preventDefault();
                else if (!s) {
                    var o = (a.current.shards || []).map(Zp).filter(Boolean).filter((function(e) {
                        return e.contains(r.target)
                    }));
                    (o.length > 0 ? l(r, o[0]) : !a.current.noIsolation) && r.cancelable && r.preventDefault()
                }
            }
        }), []),
        u = o.useCallback((function(e, r, n, s) {
            var i = {
                name: e,
                delta: r,
                target: n,
                should: s,
                shadowParent: rf(n)
            };
            t.current.push(i), setTimeout((function() {
                t.current = t.current.filter((function(e) {
                    return e !== i
                }))
            }), 1)
        }), []),
        d = o.useCallback((function(e) {
            r.current = Jp(e), n.current = void 0
        }), []),
        h = o.useCallback((function(t) {
            u(t.type, Xp(t), t.target, l(t, e.lockRef.current))
        }), []),
        p = o.useCallback((function(t) {
            u(t.type, Jp(t), t.target, l(t, e.lockRef.current))
        }), []);
    o.useEffect((function() {
        return tf.push(i), e.setCallbacks({
                onScrollCapture: h,
                onWheelCapture: h,
                onTouchMoveCapture: p
            }), document.addEventListener("wheel", c, Hp), document.addEventListener("touchmove", c, Hp), document.addEventListener("touchstart", d, Hp),
            function() {
                tf = tf.filter((function(e) {
                    return e !== i
                })), document.removeEventListener("wheel", c, Hp), document.removeEventListener("touchmove", c, Hp), document.removeEventListener("touchstart", d, Hp)
            }
    }), []);
    var f = e.removeScrollBar,
        m = e.inert;
    return o.createElement(o.Fragment, null, m ? o.createElement(i, {
        styles: Qp(s)
    }) : null, f ? o.createElement(Bp, {
        gapMode: e.gapMode
    }) : null)
}, Cp.useMedium(sf), Pp);
var sf, of = o.forwardRef((function(e, t) {
    return o.createElement(Ap, bp({}, e, {
        ref: t,
        sideCar: nf
    }))
})); of .classNames = Ap.classNames;
var af = new WeakMap,
    lf = new WeakMap,
    cf = {},
    uf = 0,
    df = function(e) {
        return e && (e.host || df(e.parentNode))
    },
    hf = function(e, t, r, n) {
        var s = function(e, t) {
            return t.map((function(t) {
                if (e.contains(t)) return t;
                var r = df(t);
                return r && e.contains(r) ? r : (console.error("aria-hidden", t, "in not contained inside", e, ". Doing nothing"), null)
            })).filter((function(e) {
                return Boolean(e)
            }))
        }(t, Array.isArray(e) ? e : [e]);
        cf[r] || (cf[r] = new WeakMap);
        var i = cf[r],
            o = [],
            a = new Set,
            l = new Set(s),
            c = function(e) {
                e && !a.has(e) && (a.add(e), c(e.parentNode))
            };
        s.forEach(c);
        var u = function(e) {
            e && !l.has(e) && Array.prototype.forEach.call(e.children, (function(e) {
                if (a.has(e)) u(e);
                else try {
                    var t = e.getAttribute(n),
                        s = null !== t && "false" !== t,
                        l = (af.get(e) || 0) + 1,
                        c = (i.get(e) || 0) + 1;
                    af.set(e, l), i.set(e, c), o.push(e), 1 === l && s && lf.set(e, !0), 1 === c && e.setAttribute(r, "true"), s || e.setAttribute(n, "true")
                } catch (d) {
                    console.error("aria-hidden: cannot operate on ", e, d)
                }
            }))
        };
        return u(t), a.clear(), uf++,
            function() {
                o.forEach((function(e) {
                    var t = af.get(e) - 1,
                        s = i.get(e) - 1;
                    af.set(e, t), i.set(e, s), t || (lf.has(e) || e.removeAttribute(n), lf.delete(e)), s || e.removeAttribute(r)
                })), --uf || (af = new WeakMap, af = new WeakMap, lf = new WeakMap, cf = {})
            }
    },
    pf = function(e, t, r) {
        void 0 === r && (r = "data-aria-hidden");
        var n = Array.from(Array.isArray(e) ? e : [e]),
            s = function(e) {
                return "undefined" == typeof document ? null : (Array.isArray(e) ? e[0] : e).ownerDocument.body
            }(e);
        return s ? (n.push.apply(n, Array.from(s.querySelectorAll("[aria-live]"))), hf(n, s, r, "aria-hidden")) : function() {
            return null
        }
    },
    ff = "Dialog",
    [mf, gf] = Uh(ff),
    [yf, vf] = mf(ff),
    bf = e => {
        const {
            __scopeDialog: t,
            children: r,
            open: n,
            defaultOpen: s,
            onOpenChange: i,
            modal: a = !0
        } = e, l = o.useRef(null), c = o.useRef(null), [u = !1, d] = Wh({
            prop: n,
            defaultProp: s,
            onChange: i
        });
        return T.jsx(yf, {
            scope: t,
            triggerRef: l,
            contentRef: c,
            contentId: Bh(),
            titleId: Bh(),
            descriptionId: Bh(),
            open: u,
            onOpenChange: d,
            onOpenToggle: o.useCallback((() => d((e => !e))), [d]),
            modal: a,
            children: r
        })
    };
bf.displayName = ff;
var xf = "DialogTrigger",
    wf = o.forwardRef(((e, t) => {
        const {
            __scopeDialog: r,
            ...n
        } = e, s = vf(xf, r), i = ed(t, s.triggerRef);
        return T.jsx(Hh.button, {
            type: "button",
            "aria-haspopup": "dialog",
            "aria-expanded": s.open,
            "aria-controls": s.contentId,
            "data-state": Ff(s.open),
            ...n,
            ref: i,
            onClick: Mh(e.onClick, s.onOpenToggle)
        })
    }));
wf.displayName = xf;
var kf = "DialogPortal",
    [jf, Sf] = mf(kf, {
        forceMount: void 0
    }),
    Tf = e => {
        const {
            __scopeDialog: t,
            forceMount: r,
            children: n,
            container: s
        } = e, i = vf(kf, t);
        return T.jsx(jf, {
            scope: t,
            forceMount: r,
            children: o.Children.map(n, (e => T.jsx(mp, {
                present: r || i.open,
                children: T.jsx(fp, {
                    asChild: !0,
                    container: s,
                    children: e
                })
            })))
        })
    };
Tf.displayName = kf;
var _f = "DialogOverlay",
    Ef = o.forwardRef(((e, t) => {
        const r = Sf(_f, e.__scopeDialog),
            {
                forceMount: n = r.forceMount,
                ...s
            } = e,
            i = vf(_f, e.__scopeDialog);
        return i.modal ? T.jsx(mp, {
            present: n || i.open,
            children: T.jsx(Pf, { ...s,
                ref: t
            })
        }) : null
    }));
Ef.displayName = _f;
var Pf = o.forwardRef(((e, t) => {
        const {
            __scopeDialog: r,
            ...n
        } = e, s = vf(_f, r);
        return T.jsx( of , {
            as: td,
            allowPinchZoom: !0,
            shards: [s.contentRef],
            children: T.jsx(Hh.div, {
                "data-state": Ff(s.open),
                ...n,
                ref: t,
                style: {
                    pointerEvents: "auto",
                    ...n.style
                }
            })
        })
    })),
    Cf = "DialogContent",
    Of = o.forwardRef(((e, t) => {
        const r = Sf(Cf, e.__scopeDialog),
            {
                forceMount: n = r.forceMount,
                ...s
            } = e,
            i = vf(Cf, e.__scopeDialog);
        return T.jsx(mp, {
            present: n || i.open,
            children: i.modal ? T.jsx(Af, { ...s,
                ref: t
            }) : T.jsx(Nf, { ...s,
                ref: t
            })
        })
    }));
Of.displayName = Cf;
var Af = o.forwardRef(((e, t) => {
        const r = vf(Cf, e.__scopeDialog),
            n = o.useRef(null),
            s = ed(t, r.contentRef, n);
        return o.useEffect((() => {
            const e = n.current;
            if (e) return pf(e)
        }), []), T.jsx(Rf, { ...e,
            ref: s,
            trapFocus: r.open,
            disableOutsidePointerEvents: !0,
            onCloseAutoFocus: Mh(e.onCloseAutoFocus, (e => {
                var t;
                e.preventDefault(), null == (t = r.triggerRef.current) || t.focus()
            })),
            onPointerDownOutside: Mh(e.onPointerDownOutside, (e => {
                const t = e.detail.originalEvent,
                    r = 0 === t.button && !0 === t.ctrlKey;
                (2 === t.button || r) && e.preventDefault()
            })),
            onFocusOutside: Mh(e.onFocusOutside, (e => e.preventDefault()))
        })
    })),
    Nf = o.forwardRef(((e, t) => {
        const r = vf(Cf, e.__scopeDialog),
            n = o.useRef(!1),
            s = o.useRef(!1);
        return T.jsx(Rf, { ...e,
            ref: t,
            trapFocus: !1,
            disableOutsidePointerEvents: !1,
            onCloseAutoFocus: t => {
                var i, o;
                null == (i = e.onCloseAutoFocus) || i.call(e, t), t.defaultPrevented || (n.current || null == (o = r.triggerRef.current) || o.focus(), t.preventDefault()), n.current = !1, s.current = !1
            },
            onInteractOutside: t => {
                var i, o;
                null == (i = e.onInteractOutside) || i.call(e, t), t.defaultPrevented || (n.current = !0, "pointerdown" === t.detail.originalEvent.type && (s.current = !0));
                const a = t.target;
                (null == (o = r.triggerRef.current) ? void 0 : o.contains(a)) && t.preventDefault(), "focusin" === t.detail.originalEvent.type && s.current && t.preventDefault()
            }
        })
    })),
    Rf = o.forwardRef(((e, t) => {
        const {
            __scopeDialog: r,
            trapFocus: n,
            onOpenAutoFocus: s,
            onCloseAutoFocus: i,
            ...a
        } = e, l = vf(Cf, r), c = o.useRef(null), u = ed(t, c);
        return o.useEffect((() => {
            const e = document.querySelectorAll("[data-radix-focus-guard]");
            return document.body.insertAdjacentElement("afterbegin", e[0] ? ? vp()), document.body.insertAdjacentElement("beforeend", e[1] ? ? vp()), yp++, () => {
                1 === yp && document.querySelectorAll("[data-radix-focus-guard]").forEach((e => e.remove())), yp--
            }
        }), []), T.jsxs(T.Fragment, {
            children: [T.jsx(ap, {
                asChild: !0,
                loop: !0,
                trapped: n,
                onMountAutoFocus: s,
                onUnmountAutoFocus: i,
                children: T.jsx(Zh, {
                    role: "dialog",
                    id: l.contentId,
                    "aria-describedby": l.descriptionId,
                    "aria-labelledby": l.titleId,
                    "data-state": Ff(l.open),
                    ...a,
                    ref: u,
                    onDismiss: () => l.onOpenChange(!1)
                })
            }), T.jsxs(T.Fragment, {
                children: [T.jsx(Wf, {
                    titleId: l.titleId
                }), T.jsx(Hf, {
                    contentRef: c,
                    descriptionId: l.descriptionId
                })]
            })]
        })
    })),
    If = "DialogTitle",
    Lf = o.forwardRef(((e, t) => {
        const {
            __scopeDialog: r,
            ...n
        } = e, s = vf(If, r);
        return T.jsx(Hh.h2, {
            id: s.titleId,
            ...n,
            ref: t
        })
    }));
Lf.displayName = If;
var Mf = "DialogDescription",
    Uf = o.forwardRef(((e, t) => {
        const {
            __scopeDialog: r,
            ...n
        } = e, s = vf(Mf, r);
        return T.jsx(Hh.p, {
            id: s.descriptionId,
            ...n,
            ref: t
        })
    }));
Uf.displayName = Mf;
var Df = "DialogClose",
    $f = o.forwardRef(((e, t) => {
        const {
            __scopeDialog: r,
            ...n
        } = e, s = vf(Df, r);
        return T.jsx(Hh.button, {
            type: "button",
            ...n,
            ref: t,
            onClick: Mh(e.onClick, (() => s.onOpenChange(!1)))
        })
    }));

function Ff(e) {
    return e ? "open" : "closed"
}
$f.displayName = Df;
var Vf = "DialogTitleWarning",
    [Bf, zf] = function(e, t) {
        const r = o.createContext(t);

        function n(e) {
            const {
                children: t,
                ...n
            } = e, s = o.useMemo((() => n), Object.values(n));
            return T.jsx(r.Provider, {
                value: s,
                children: t
            })
        }
        return n.displayName = e + "Provider", [n, function(n) {
            const s = o.useContext(r);
            if (s) return s;
            if (void 0 !== t) return t;
            throw new Error(`\`${n}\` must be used within \`${e}\``)
        }]
    }(Vf, {
        contentName: Cf,
        titleName: If,
        docsSlug: "dialog"
    }),
    Wf = ({
        titleId: e
    }) => {
        const t = zf(Vf),
            r = `\`${t.contentName}\` requires a \`${t.titleName}\` for the component to be accessible for screen reader users.\n\nIf you want to hide the \`${t.titleName}\`, you can wrap it with our VisuallyHidden component.\n\nFor more information, see https://radix-ui.com/primitives/docs/components/${t.docsSlug}`;
        return o.useEffect((() => {
            if (e) {
                document.getElementById(e) || console.error(r)
            }
        }), [r, e]), null
    },
    Hf = ({
        contentRef: e,
        descriptionId: t
    }) => {
        const r = `Warning: Missing \`Description\` or \`aria-describedby={undefined}\` for {${zf("DialogDescriptionWarning").contentName}}.`;
        return o.useEffect((() => {
            var n;
            const s = null == (n = e.current) ? void 0 : n.getAttribute("aria-describedby");
            if (t && s) {
                document.getElementById(t) || console.warn(r)
            }
        }), [r, e, t]), null
    },
    qf = bf,
    Kf = wf,
    Gf = Tf,
    Yf = Ef,
    Jf = Of,
    Xf = Lf,
    Zf = Uf,
    Qf = $f;
var em = ["color"],
    tm = o.forwardRef((function(e, t) {
        var r = e.color,
            n = void 0 === r ? "currentColor" : r,
            s = function(e, t) {
                if (null == e) return {};
                var r, n, s = {},
                    i = Object.keys(e);
                for (n = 0; n < i.length; n++) r = i[n], t.indexOf(r) >= 0 || (s[r] = e[r]);
                return s
            }(e, em);
        return o.createElement("svg", Object.assign({
            width: "15",
            height: "15",
            viewBox: "0 0 15 15",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        }, s, {
            ref: t
        }), o.createElement("path", {
            d: "M11.7816 4.03157C12.0062 3.80702 12.0062 3.44295 11.7816 3.2184C11.5571 2.99385 11.193 2.99385 10.9685 3.2184L7.50005 6.68682L4.03164 3.2184C3.80708 2.99385 3.44301 2.99385 3.21846 3.2184C2.99391 3.44295 2.99391 3.80702 3.21846 4.03157L6.68688 7.49999L3.21846 10.9684C2.99391 11.193 2.99391 11.557 3.21846 11.7816C3.44301 12.0061 3.80708 12.0061 4.03164 11.7816L7.50005 8.31316L10.9685 11.7816C11.193 12.0061 11.5571 12.0061 11.7816 11.7816C12.0062 11.557 12.0062 11.193 11.7816 10.9684L8.31322 7.49999L11.7816 4.03157Z",
            fill: n,
            fillRule: "evenodd",
            clipRule: "evenodd"
        }))
    }));
const rm = qf,
    nm = Kf,
    sm = Gf,
    im = o.forwardRef((({
        className: e,
        ...t
    }, r) => T.jsx(Yf, {
        ref: r,
        className: nh("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", e),
        ...t
    })));
im.displayName = Yf.displayName;
const om = o.forwardRef((({
    className: e,
    children: t,
    ...r
}, n) => T.jsxs(sm, {
    children: [T.jsx(im, {}), T.jsxs(Jf, {
        ref: n,
        className: nh("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg", e),
        ...r,
        children: [t, T.jsxs(Qf, {
            className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
            children: [T.jsx(tm, {
                className: "h-4 w-4"
            }), T.jsx("span", {
                className: "sr-only",
                children: "Close"
            })]
        })]
    })]
})));
om.displayName = Jf.displayName;
const am = ({
    className: e,
    ...t
}) => T.jsx("div", {
    className: nh("flex flex-col space-y-1.5 text-center sm:text-left", e),
    ...t
});
am.displayName = "DialogHeader";
const lm = o.forwardRef((({
    className: e,
    ...t
}, r) => T.jsx(Xf, {
    ref: r,
    className: nh("text-lg font-semibold leading-none tracking-tight", e),
    ...t
})));
lm.displayName = Xf.displayName;
const cm = o.forwardRef((({
    className: e,
    ...t
}, r) => T.jsx(Zf, {
    ref: r,
    className: nh("text-sm text-muted-foreground", e),
    ...t
})));
cm.displayName = Zf.displayName;
var um = Object.freeze({
    InvalidProxyUrlErrorMessage: "The proxyUrl passed to Clerk is invalid. The expected value for proxyUrl is an absolute URL or a relative path with a leading '/'. (key={{url}})",
    InvalidPublishableKeyErrorMessage: "The publishableKey passed to Clerk is invalid. You can get your Publishable key at https://dashboard.clerk.com/last-active?path=api-keys. (key={{key}})",
    MissingPublishableKeyErrorMessage: "Missing publishableKey. You can get your key at https://dashboard.clerk.com/last-active?path=api-keys.",
    MissingSecretKeyErrorMessage: "Missing secretKey. You can get your key at https://dashboard.clerk.com/last-active?path=api-keys.",
    MissingClerkProvider: "{{source}} can only be used within the <ClerkProvider /> component. Learn more: https://clerk.com/docs/components/clerk-provider"
});

function dm({
    packageName: e,
    customMessages: t
}) {
    let r = e;
    const n = { ...um,
        ...t
    };

    function s(e, t) {
        if (!t) return `${r}: ${e}`;
        let n = e;
        const s = e.matchAll(/{{([a-zA-Z0-9-_]+)}}/g);
        for (const r of s) {
            const e = (t[r[1]] || "").toString();
            n = n.replace(`{{${r[1]}}}`, e)
        }
        return `${r}: ${n}`
    }
    return {
        setPackageName({
            packageName: e
        }) {
            return "string" == typeof e && (r = e), this
        },
        setMessages({
            customMessages: e
        }) {
            return Object.assign(n, e || {}), this
        },
        throwInvalidPublishableKeyError(e) {
            throw new Error(s(n.InvalidPublishableKeyErrorMessage, e))
        },
        throwInvalidProxyUrl(e) {
            throw new Error(s(n.InvalidProxyUrlErrorMessage, e))
        },
        throwMissingPublishableKeyError() {
            throw new Error(s(n.MissingPublishableKeyErrorMessage))
        },
        throwMissingSecretKeyError() {
            throw new Error(s(n.MissingSecretKeyErrorMessage))
        },
        throwMissingClerkProviderError(e) {
            throw new Error(s(n.MissingClerkProvider, e))
        },
        throw (e) {
            throw new Error(s(e))
        }
    }
}
var hm = Object.defineProperty,
    pm = Object.getOwnPropertyDescriptor,
    fm = Object.getOwnPropertyNames,
    mm = Object.prototype.hasOwnProperty,
    gm = e => "undefined" != typeof atob && "function" == typeof atob ? atob(e) : "undefined" != typeof global && global.Buffer ? new global.Buffer(e, "base64").toString() : e,
    ym = [".lcl.dev", ".stg.dev", ".lclstage.dev", ".stgstage.dev", ".dev.lclclerk.com", ".stg.lclclerk.com", ".accounts.lclclerk.com", "accountsstage.dev", "accounts.dev"],
    vm = "pk_live_";

function bm(e, t = {}) {
    if (!(e = e || "") || !xm(e)) {
        if (t.fatal && !e) throw new Error("Publishable key is missing. Ensure that your publishable key is correctly configured. Double-check your environment configuration for your keys, or access them here: https://dashboard.clerk.com/last-active?path=api-keys");
        if (t.fatal && !xm(e)) throw new Error("Publishable key not valid.");
        return null
    }
    const r = e.startsWith(vm) ? "production" : "development";
    let n = gm(e.split("_")[2]);
    return n = n.slice(0, -1), t.proxyUrl ? n = t.proxyUrl : "development" !== r && t.domain && (n = `clerk.${t.domain}`), {
        instanceType: r,
        frontendApi: n
    }
}

function xm(e = "") {
    try {
        const t = e.startsWith(vm) || e.startsWith("pk_test_"),
            r = gm(e.split("_")[2] || "").endsWith("$");
        return t && r
    } catch {
        return !1
    }
}
var wm, km, jm = {
        exports: {}
    },
    Sm = {};
var Tm = (km || (km = 1, jm.exports = function() {
    if (wm) return Sm;
    wm = 1;
    var e = s(),
        t = "function" == typeof Object.is ? Object.is : function(e, t) {
            return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
        },
        r = e.useState,
        n = e.useEffect,
        i = e.useLayoutEffect,
        o = e.useDebugValue;

    function a(e) {
        var r = e.getSnapshot;
        e = e.value;
        try {
            var n = r();
            return !t(e, n)
        } catch (s) {
            return !0
        }
    }
    var l = "undefined" == typeof window || void 0 === window.document || void 0 === window.document.createElement ? function(e, t) {
        return t()
    } : function(e, t) {
        var s = t(),
            l = r({
                inst: {
                    value: s,
                    getSnapshot: t
                }
            }),
            c = l[0].inst,
            u = l[1];
        return i((function() {
            c.value = s, c.getSnapshot = t, a(c) && u({
                inst: c
            })
        }), [e, s, t]), n((function() {
            return a(c) && u({
                inst: c
            }), e((function() {
                a(c) && u({
                    inst: c
                })
            }))
        }), [e]), o(s), s
    };
    return Sm.useSyncExternalStore = void 0 !== e.useSyncExternalStore ? e.useSyncExternalStore : l, Sm
}()), jm.exports);
var _m = Object.prototype.hasOwnProperty;
const Em = new WeakMap,
    Pm = () => {},
    Cm = Pm(),
    Om = Object,
    Am = e => e === Cm,
    Nm = e => "function" == typeof e,
    Rm = (e, t) => ({ ...e,
        ...t
    }),
    Im = e => Nm(e.then),
    Lm = {},
    Mm = {},
    Um = "undefined",
    Dm = typeof window != Um,
    $m = typeof document != Um,
    Fm = Dm && "Deno" in window,
    Vm = (e, t) => {
        const r = Em.get(e);
        return [() => !Am(t) && e.get(t) || Lm, n => {
            if (!Am(t)) {
                const s = e.get(t);
                t in Mm || (Mm[t] = s), r[5](t, Rm(s, n), s || Lm)
            }
        }, r[6], () => !Am(t) && t in Mm ? Mm[t] : !Am(t) && e.get(t) || Lm]
    };
let Bm = !0;
const [zm, Wm] = Dm && window.addEventListener ? [window.addEventListener.bind(window), window.removeEventListener.bind(window)] : [Pm, Pm], Hm = {
    isOnline: () => Bm,
    isVisible: () => {
        const e = $m && document.visibilityState;
        return Am(e) || "hidden" !== e
    }
}, qm = {
    initFocus: e => ($m && document.addEventListener("visibilitychange", e), zm("focus", e), () => {
        $m && document.removeEventListener("visibilitychange", e), Wm("focus", e)
    }),
    initReconnect: e => {
        const t = () => {
                Bm = !0, e()
            },
            r = () => {
                Bm = !1
            };
        return zm("online", t), zm("offline", r), () => {
            Wm("online", t), Wm("offline", r)
        }
    }
}, Km = !p.useId, Gm = !Dm || Fm, Ym = e => Dm && typeof window.requestAnimationFrame != Um ? window.requestAnimationFrame(e) : setTimeout(e, 1), Jm = Gm ? o.useEffect : o.useLayoutEffect, Xm = "undefined" != typeof navigator && navigator.connection, Zm = !Gm && Xm && (["slow-2g", "2g"].includes(Xm.effectiveType) || Xm.saveData), Qm = new WeakMap, eg = (e, t) => Om.prototype.toString.call(e) === `[object ${t}]`;
let tg = 0;
const rg = e => {
        const t = typeof e,
            r = eg(e, "Date"),
            n = eg(e, "RegExp"),
            s = eg(e, "Object");
        let i, o;
        if (Om(e) !== e || r || n) i = r ? e.toJSON() : "symbol" == t ? e.toString() : "string" == t ? JSON.stringify(e) : "" + e;
        else {
            if (i = Qm.get(e), i) return i;
            if (i = ++tg + "~", Qm.set(e, i), Array.isArray(e)) {
                for (i = "@", o = 0; o < e.length; o++) i += rg(e[o]) + ",";
                Qm.set(e, i)
            }
            if (s) {
                i = "#";
                const t = Om.keys(e).sort();
                for (; !Am(o = t.pop());) Am(e[o]) || (i += o + ":" + rg(e[o]) + ",");
                Qm.set(e, i)
            }
        }
        return i
    },
    ng = e => {
        if (Nm(e)) try {
            e = e()
        } catch (Iw) {
            e = ""
        }
        const t = e;
        return [e = "string" == typeof e ? e : (Array.isArray(e) ? e.length : e) ? rg(e) : "", t]
    };
let sg = 0;
const ig = () => ++sg;
async function og(...e) {
    const [t, r, n, s] = e, i = Rm({
        populateCache: !0,
        throwOnError: !0
    }, "boolean" == typeof s ? {
        revalidate: s
    } : s || {});
    let o = i.populateCache;
    const a = i.rollbackOnError;
    let l = i.optimisticData;
    const c = i.throwOnError;
    if (Nm(r)) {
        const e = r,
            n = [],
            s = t.keys();
        for (const r of s) !/^\$(inf|sub)\$/.test(r) && e(t.get(r)._k) && n.push(r);
        return Promise.all(n.map(u))
    }
    return u(r);
    async function u(r) {
        const [s] = ng(r);
        if (!s) return;
        const [u, d] = Vm(t, s), [h, p, f, m] = Em.get(t), g = () => {
            const e = h[s];
            return (Nm(i.revalidate) ? i.revalidate(u().data, r) : !1 !== i.revalidate) && (delete f[s], delete m[s], e && e[0]) ? e[0](2).then((() => u().data)) : u().data
        };
        if (e.length < 3) return g();
        let y, v = n;
        const b = ig();
        p[s] = [b, 0];
        const x = !Am(l),
            w = u(),
            k = w.data,
            j = w._c,
            S = Am(j) ? k : j;
        if (x && (l = Nm(l) ? l(S, k) : l, d({
                data: l,
                _c: S
            })), Nm(v)) try {
            v = v(S)
        } catch (Iw) {
            y = Iw
        }
        if (v && Im(v)) {
            if (v = await v.catch((e => {
                    y = e
                })), b !== p[s][0]) {
                if (y) throw y;
                return v
            }
            y && x && (e => "function" == typeof a ? a(e) : !1 !== a)(y) && (o = !0, d({
                data: S,
                _c: Cm
            }))
        }
        if (o && !y)
            if (Nm(o)) {
                const e = o(v, S);
                d({
                    data: e,
                    error: Cm,
                    _c: Cm
                })
            } else d({
                data: v,
                error: Cm,
                _c: Cm
            });
        if (p[s][1] = ig(), Promise.resolve(g()).then((() => {
                d({
                    _c: Cm
                })
            })), !y) return v;
        if (c) throw y
    }
}
const ag = (e, t) => {
        for (const r in e) e[r][0] && e[r][0](t)
    },
    lg = (e, t) => {
        if (!Em.has(e)) {
            const r = Rm(qm, t),
                n = Object.create(null),
                s = og.bind(Cm, e);
            let i = Pm;
            const o = Object.create(null),
                a = (e, t) => {
                    const r = o[e] || [];
                    return o[e] = r, r.push(t), () => r.splice(r.indexOf(t), 1)
                },
                l = (t, r, n) => {
                    e.set(t, r);
                    const s = o[t];
                    if (s)
                        for (const e of s) e(r, n)
                },
                c = () => {
                    if (!Em.has(e) && (Em.set(e, [n, Object.create(null), Object.create(null), Object.create(null), s, l, a]), !Gm)) {
                        const t = r.initFocus(setTimeout.bind(Cm, ag.bind(Cm, n, 0))),
                            s = r.initReconnect(setTimeout.bind(Cm, ag.bind(Cm, n, 1)));
                        i = () => {
                            t && t(), s && s(), Em.delete(e)
                        }
                    }
                };
            return c(), [e, s, c, i]
        }
        return [e, Em.get(e)[4]]
    },
    cg = function e(t, r) {
        var n, s;
        if (t === r) return !0;
        if (t && r && (n = t.constructor) === r.constructor) {
            if (n === Date) return t.getTime() === r.getTime();
            if (n === RegExp) return t.toString() === r.toString();
            if (n === Array) {
                if ((s = t.length) === r.length)
                    for (; s-- && e(t[s], r[s]););
                return -1 === s
            }
            if (!n || "object" == typeof t) {
                for (n in s = 0, t) {
                    if (_m.call(t, n) && ++s && !_m.call(r, n)) return !1;
                    if (!(n in r) || !e(t[n], r[n])) return !1
                }
                return Object.keys(r).length === s
            }
        }
        return t != t && r != r
    },
    [ug, dg] = lg(new Map),
    hg = Rm({
        onLoadingSlow: Pm,
        onSuccess: Pm,
        onError: Pm,
        onErrorRetry: (e, t, r, n, s) => {
            const i = r.errorRetryCount,
                o = s.retryCount,
                a = ~~((Math.random() + .5) * (1 << (o < 8 ? o : 8))) * r.errorRetryInterval;
            !Am(i) && o > i || setTimeout(n, a, s)
        },
        onDiscarded: Pm,
        revalidateOnFocus: !0,
        revalidateOnReconnect: !0,
        revalidateIfStale: !0,
        shouldRetryOnError: !0,
        errorRetryInterval: Zm ? 1e4 : 5e3,
        focusThrottleInterval: 5e3,
        dedupingInterval: 2e3,
        loadingTimeout: Zm ? 5e3 : 3e3,
        compare: cg,
        isPaused: () => !1,
        cache: ug,
        mutate: dg,
        fallback: {}
    }, Hm),
    pg = (e, t) => {
        const r = Rm(e, t);
        if (t) {
            const {
                use: n,
                fallback: s
            } = e, {
                use: i,
                fallback: o
            } = t;
            n && i && (r.use = n.concat(i)), s && o && (r.fallback = Rm(s, o))
        }
        return r
    },
    fg = o.createContext({}),
    mg = "$inf$",
    gg = Dm && window.__SWR_DEVTOOLS_USE__,
    yg = gg ? window.__SWR_DEVTOOLS_USE__ : [],
    vg = e => Nm(e[1]) ? [e[0], e[1], e[2] || {}] : [e[0], null, (null === e[1] ? e[2] : e[1]) || {}],
    bg = () => Rm(hg, o.useContext(fg)),
    xg = yg.concat((e => (t, r, n) => e(t, r && ((...e) => {
        const [n] = ng(t), [, , , s] = Em.get(ug);
        if (n.startsWith(mg)) return r(...e);
        const i = s[n];
        return Am(i) ? r(...e) : (delete s[n], i)
    }), n)));
gg && (window.__SWR_DEVTOOLS_REACT__ = p);
const wg = () => {},
    kg = wg(),
    jg = Object,
    Sg = e => e === kg,
    Tg = new WeakMap,
    _g = (e, t) => jg.prototype.toString.call(e) === `[object ${t}]`;
let Eg = 0;
const Pg = e => {
        const t = typeof e,
            r = _g(e, "Date"),
            n = _g(e, "RegExp"),
            s = _g(e, "Object");
        let i, o;
        if (jg(e) !== e || r || n) i = r ? e.toJSON() : "symbol" == t ? e.toString() : "string" == t ? JSON.stringify(e) : "" + e;
        else {
            if (i = Tg.get(e), i) return i;
            if (i = ++Eg + "~", Tg.set(e, i), Array.isArray(e)) {
                for (i = "@", o = 0; o < e.length; o++) i += Pg(e[o]) + ",";
                Tg.set(e, i)
            }
            if (s) {
                i = "#";
                const t = jg.keys(e).sort();
                for (; !Sg(o = t.pop());) Sg(e[o]) || (i += o + ":" + Pg(e[o]) + ",");
                Tg.set(e, i)
            }
        }
        return i
    },
    Cg = p.use || (e => {
        switch (e.status) {
            case "pending":
                throw e;
            case "fulfilled":
                return e.value;
            case "rejected":
                throw e.reason;
            default:
                throw e.status = "pending", e.then((t => {
                    e.status = "fulfilled", e.value = t
                }), (t => {
                    e.status = "rejected", e.reason = t
                })), e
        }
    }),
    Og = {
        dedupe: !0
    },
    Ag = Om.defineProperty((e => {
        const {
            value: t
        } = e, r = o.useContext(fg), n = Nm(t), s = o.useMemo((() => n ? t(r) : t), [n, r, t]), i = o.useMemo((() => n ? s : pg(r, s)), [n, r, s]), a = s && s.provider, l = o.useRef(Cm);
        a && !l.current && (l.current = lg(a(i.cache || ug), s));
        const c = l.current;
        return c && (i.cache = c[0], i.mutate = c[1]), Jm((() => {
            if (c) return c[2] && c[2](), c[3]
        }), []), o.createElement(fg.Provider, Rm(e, {
            value: i
        }))
    }), "defaultValue", {
        value: hg
    }),
    Ng = (Rg = (e, t, r) => {
        const {
            cache: n,
            compare: s,
            suspense: i,
            fallbackData: a,
            revalidateOnMount: l,
            revalidateIfStale: c,
            refreshInterval: u,
            refreshWhenHidden: d,
            refreshWhenOffline: h,
            keepPreviousData: p
        } = r, [f, m, g, y] = Em.get(n), [v, b] = ng(e), x = o.useRef(!1), w = o.useRef(!1), k = o.useRef(v), j = o.useRef(t), S = o.useRef(r), T = () => S.current, _ = () => T().isVisible() && T().isOnline(), [E, P, C, O] = Vm(n, v), A = o.useRef({}).current, N = Am(a) ? Am(r.fallback) ? Cm : r.fallback[v] : a, R = (e, t) => {
            for (const r in A) {
                const n = r;
                if ("data" === n) {
                    if (!s(e[n], t[n])) {
                        if (!Am(e[n])) return !1;
                        if (!s(B, t[n])) return !1
                    }
                } else if (t[n] !== e[n]) return !1
            }
            return !0
        }, I = o.useMemo((() => {
            const e = !!v && !!t && (Am(l) ? !T().isPaused() && !i && !1 !== c : l),
                r = t => {
                    const r = Rm(t);
                    return delete r._k, e ? {
                        isValidating: !0,
                        isLoading: !0,
                        ...r
                    } : r
                },
                n = E(),
                s = O(),
                o = r(n),
                a = n === s ? o : r(s);
            let u = o;
            return [() => {
                const e = r(E());
                return R(e, u) ? (u.data = e.data, u.isLoading = e.isLoading, u.isValidating = e.isValidating, u.error = e.error, u) : (u = e, e)
            }, () => a]
        }), [n, v]), L = Tm.useSyncExternalStore(o.useCallback((e => C(v, ((t, r) => {
            R(r, t) || e()
        }))), [n, v]), I[0], I[1]), M = !x.current, U = f[v] && f[v].length > 0, D = L.data, $ = Am(D) ? N && Im(N) ? Cg(N) : N : D, F = L.error, V = o.useRef($), B = p ? Am(D) ? Am(V.current) ? $ : V.current : D : $, z = !(U && !Am(F)) && (M && !Am(l) ? l : !T().isPaused() && (i ? !Am($) && c : Am($) || c)), W = !!(v && t && M && z), H = Am(L.isValidating) ? W : L.isValidating, q = Am(L.isLoading) ? W : L.isLoading, K = o.useCallback((async e => {
            const t = j.current;
            if (!v || !t || w.current || T().isPaused()) return !1;
            let n, i, o = !0;
            const a = e || {},
                l = !g[v] || !a.dedupe,
                c = () => Km ? !w.current && v === k.current && x.current : v === k.current,
                u = {
                    isValidating: !1,
                    isLoading: !1
                },
                d = () => {
                    P(u)
                },
                h = () => {
                    const e = g[v];
                    e && e[1] === i && delete g[v]
                },
                p = {
                    isValidating: !0
                };
            Am(E().data) && (p.isLoading = !0);
            try {
                if (l && (P(p), r.loadingTimeout && Am(E().data) && setTimeout((() => {
                        o && c() && T().onLoadingSlow(v, r)
                    }), r.loadingTimeout), g[v] = [t(b), ig()]), [n, i] = g[v], n = await n, l && setTimeout(h, r.dedupingInterval), !g[v] || g[v][1] !== i) return l && c() && T().onDiscarded(v), !1;
                u.error = Cm;
                const e = m[v];
                if (!Am(e) && (i <= e[0] || i <= e[1] || 0 === e[1])) return d(), l && c() && T().onDiscarded(v), !1;
                const a = E().data;
                u.data = s(a, n) ? a : n, l && c() && T().onSuccess(n, v, r)
            } catch (Iw) {
                h();
                const t = T(),
                    {
                        shouldRetryOnError: r
                    } = t;
                t.isPaused() || (u.error = Iw, l && c() && (t.onError(Iw, v, t), (!0 === r || Nm(r) && r(Iw)) && (T().revalidateOnFocus && T().revalidateOnReconnect && !_() || t.onErrorRetry(Iw, v, t, (e => {
                    const t = f[v];
                    t && t[0] && t[0](3, e)
                }), {
                    retryCount: (a.retryCount || 0) + 1,
                    dedupe: !0
                }))))
            }
            return o = !1, d(), !0
        }), [v, n]), G = o.useCallback(((...e) => og(n, k.current, ...e)), []);
        if (Jm((() => {
                j.current = t, S.current = r, Am(D) || (V.current = D)
            })), Jm((() => {
                if (!v) return;
                const e = K.bind(Cm, Og);
                let t = 0;
                if (T().revalidateOnFocus) {
                    const e = Date.now();
                    t = e + T().focusThrottleInterval
                }
                const r = ((e, t, r) => {
                    const n = t[e] || (t[e] = []);
                    return n.push(r), () => {
                        const e = n.indexOf(r);
                        e >= 0 && (n[e] = n[n.length - 1], n.pop())
                    }
                })(v, f, ((r, n = {}) => {
                    if (0 == r) {
                        const r = Date.now();
                        T().revalidateOnFocus && r > t && _() && (t = r + T().focusThrottleInterval, e())
                    } else if (1 == r) T().revalidateOnReconnect && _() && e();
                    else {
                        if (2 == r) return K();
                        if (3 == r) return K(n)
                    }
                }));
                return w.current = !1, k.current = v, x.current = !0, P({
                    _k: b
                }), z && (Am($) || Gm ? e() : Ym(e)), () => {
                    w.current = !0, r()
                }
            }), [v]), Jm((() => {
                let e;

                function t() {
                    const t = Nm(u) ? u(E().data) : u;
                    t && -1 !== e && (e = setTimeout(r, t))
                }

                function r() {
                    E().error || !d && !T().isVisible() || !h && !T().isOnline() ? t() : K(Og).then(t)
                }
                return t(), () => {
                    e && (clearTimeout(e), e = -1)
                }
            }), [u, d, h, v]), o.useDebugValue(B), i && Am($) && v) {
            if (!Km && Gm) throw new Error("Fallback data is required when using Suspense in SSR.");
            j.current = t, S.current = r, w.current = !1;
            const e = y[v];
            if (!Am(e)) {
                const t = G(e);
                Cg(t)
            }
            if (!Am(F)) throw F; {
                const e = K(Og);
                Am(B) || (e.status = "fulfilled", e.value = !0), Cg(e)
            }
        }
        return {
            mutate: G,
            get data() {
                return A.data = !0, B
            },
            get error() {
                return A.error = !0, F
            },
            get isValidating() {
                return A.isValidating = !0, H
            },
            get isLoading() {
                return A.isLoading = !0, q
            }
        }
    }, function(...e) {
        const t = bg(),
            [r, n, s] = vg(e),
            i = pg(t, s);
        let o = Rg;
        const {
            use: a
        } = i, l = (a || []).concat(xg);
        for (let c = l.length; c--;) o = l[c](o);
        return o(r, n || i.fetcher || null, i)
    });
var Rg;
const Ig = Object.freeze(Object.defineProperty({
        __proto__: null,
        SWRConfig: Ag,
        default: Ng,
        mutate: dg,
        preload: (e, t) => {
            const [r, n] = ng(e), [, , , s] = Em.get(ug);
            if (s[r]) return s[r];
            const i = t(n);
            return s[r] = i, i
        },
        unstable_serialize: e => (e => {
            if ("function" == typeof e) try {
                e = e()
            } catch (Iw) {
                e = ""
            }
            const t = e;
            return [e = "string" == typeof e ? e : (Array.isArray(e) ? e.length : e) ? Pg(e) : "", t]
        })(e)[0],
        useSWRConfig: bg
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Lg = () => {},
    Mg = Lg(),
    Ug = Object,
    Dg = e => e === Mg,
    $g = new WeakMap,
    Fg = (e, t) => Ug.prototype.toString.call(e) === `[object ${t}]`;
let Vg = 0;
const Bg = e => {
        const t = typeof e,
            r = Fg(e, "Date"),
            n = Fg(e, "RegExp"),
            s = Fg(e, "Object");
        let i, o;
        if (Ug(e) !== e || r || n) i = r ? e.toJSON() : "symbol" == t ? e.toString() : "string" == t ? JSON.stringify(e) : "" + e;
        else {
            if (i = $g.get(e), i) return i;
            if (i = ++Vg + "~", $g.set(e, i), Array.isArray(e)) {
                for (i = "@", o = 0; o < e.length; o++) i += Bg(e[o]) + ",";
                $g.set(e, i)
            }
            if (s) {
                i = "#";
                const t = Ug.keys(e).sort();
                for (; !Dg(o = t.pop());) Dg(e[o]) || (i += o + ":" + Bg(e[o]) + ",");
                $g.set(e, i)
            }
        }
        return i
    },
    zg = e => (e => {
        if ("function" == typeof e) try {
            e = e()
        } catch (Iw) {
            e = ""
        }
        const t = e;
        return [e = "string" == typeof e ? e : (Array.isArray(e) ? e.length : e) ? Bg(e) : "", t]
    })(e ? e(0, null) : null)[0],
    Wg = Promise.resolve(),
    Hg = (qg = Ng, Kg = e => (t, r, n) => {
        const s = o.useRef(!1),
            {
                cache: i,
                initialSize: a = 1,
                revalidateAll: l = !1,
                persistSize: c = !1,
                revalidateFirstPage: u = !0,
                revalidateOnMount: d = !1,
                parallel: h = !1
            } = n,
            [, , , p] = Em.get(ug);
        let f;
        try {
            f = zg(t), f && (f = mg + f)
        } catch (Iw) {}
        const [m, g, y] = Vm(i, f), v = o.useCallback((() => Am(m()._l) ? a : m()._l), [i, f, a]);
        Tm.useSyncExternalStore(o.useCallback((e => f ? y(f, (() => {
            e()
        })) : () => {}), [i, f]), v, v);
        const b = o.useCallback((() => {
                const e = m()._l;
                return Am(e) ? a : e
            }), [f, a]),
            x = o.useRef(b());
        Jm((() => {
            s.current ? f && g({
                _l: c ? x.current : b()
            }) : s.current = !0
        }), [f, i]);
        const w = d && !s.current,
            k = e(f, (async e => {
                const s = m()._i,
                    o = m()._r;
                g({
                    _r: Cm
                });
                const a = [],
                    c = b(),
                    [d] = Vm(i, e),
                    f = d().data,
                    y = [];
                let v = null;
                for (let m = 0; m < c; ++m) {
                    const [e, c] = ng(t(m, h ? null : v));
                    if (!e) break;
                    const [d, g] = Vm(i, e);
                    let b = d().data;
                    const x = l || s || Am(b) || u && !m && !Am(f) || w || f && !Am(f[m]) && !n.compare(f[m], b);
                    if (r && ("function" == typeof o ? o(b, c) : x)) {
                        const t = async () => {
                            if (e in p) {
                                const t = p[e];
                                delete p[e], b = await t
                            } else b = await r(c);
                            g({
                                data: b,
                                _k: c
                            }), a[m] = b
                        };
                        h ? y.push(t) : await t()
                    } else a[m] = b;
                    h || (v = b)
                }
                return h && await Promise.all(y.map((e => e()))), g({
                    _i: Cm
                }), a
            }), n),
            j = o.useCallback((function(e, t) {
                const r = "boolean" == typeof t ? {
                        revalidate: t
                    } : t || {},
                    n = !1 !== r.revalidate;
                return f ? (n && (Am(e) ? g({
                    _i: !0,
                    _r: r.revalidate
                }) : g({
                    _i: !1,
                    _r: r.revalidate
                })), arguments.length ? k.mutate(e, { ...r,
                    revalidate: n
                }) : k.mutate()) : Wg
            }), [f, i]),
            S = o.useCallback((e => {
                if (!f) return Wg;
                const [, r] = Vm(i, f);
                let n;
                if (Nm(e) ? n = e(b()) : "number" == typeof e && (n = e), "number" != typeof n) return Wg;
                r({
                    _l: n
                }), x.current = n;
                const s = [],
                    [o] = Vm(i, f);
                let a = null;
                for (let l = 0; l < n; ++l) {
                    const [e] = ng(t(l, a)), [r] = Vm(i, e), n = e ? r().data : Cm;
                    if (Am(n)) return j(o().data);
                    s.push(n), a = n
                }
                return j(s)
            }), [f, i, j, b]);
        return {
            size: b(),
            setSize: S,
            mutate: j,
            get data() {
                return k.data
            },
            get error() {
                return k.error
            },
            get isValidating() {
                return k.isValidating
            },
            get isLoading() {
                return k.isLoading
            }
        }
    }, (...e) => {
        const [t, r, n] = vg(e), s = (n.use || []).concat(Kg);
        return qg(t, r, { ...n,
            use: s
        })
    });
var qg, Kg, Gg = Object.prototype.hasOwnProperty;

function Yg(e, t, r) {
    for (r of e.keys())
        if (Jg(r, t)) return r
}

function Jg(e, t) {
    var r, n, s;
    if (e === t) return !0;
    if (e && t && (r = e.constructor) === t.constructor) {
        if (r === Date) return e.getTime() === t.getTime();
        if (r === RegExp) return e.toString() === t.toString();
        if (r === Array) {
            if ((n = e.length) === t.length)
                for (; n-- && Jg(e[n], t[n]););
            return -1 === n
        }
        if (r === Set) {
            if (e.size !== t.size) return !1;
            for (n of e) {
                if ((s = n) && "object" == typeof s && !(s = Yg(t, s))) return !1;
                if (!t.has(s)) return !1
            }
            return !0
        }
        if (r === Map) {
            if (e.size !== t.size) return !1;
            for (n of e) {
                if ((s = n[0]) && "object" == typeof s && !(s = Yg(t, s))) return !1;
                if (!Jg(n[1], t.get(s))) return !1
            }
            return !0
        }
        if (r === ArrayBuffer) e = new Uint8Array(e), t = new Uint8Array(t);
        else if (r === DataView) {
            if ((n = e.byteLength) === t.byteLength)
                for (; n-- && e.getInt8(n) === t.getInt8(n););
            return -1 === n
        }
        if (ArrayBuffer.isView(e)) {
            if ((n = e.byteLength) === t.byteLength)
                for (; n-- && e[n] === t[n];);
            return -1 === n
        }
        if (!r || "object" == typeof e) {
            for (r in n = 0, e) {
                if (Gg.call(e, r) && ++n && !Gg.call(t, r)) return !1;
                if (!(r in t) || !Jg(e[r], t[r])) return !1
            }
            return Object.keys(t).length === n
        }
    }
    return e != e && t != t
}

function Xg(e, t) {
    if (!e) throw "string" == typeof t ? new Error(t) : new Error(`${t.displayName} not found`)
}
var Zg = (e, t) => {
        const {
            assertCtxFn: r = Xg
        } = {}, n = p.createContext(void 0);
        n.displayName = e;
        return [n, () => {
            const t = p.useContext(n);
            return r(t, `${e} not found`), t.value
        }, () => {
            const e = p.useContext(n);
            return e ? e.value : {}
        }]
    },
    Qg = {};
((e, t) => {
    for (var r in t) hm(e, r, {
        get: t[r],
        enumerable: !0
    })
})(Qg, {
    useSWR: () => Ng,
    useSWRInfinite: () => Hg
}), ((e, t, r, n) => {
    if (t && "object" == typeof t || "function" == typeof t)
        for (let s of fm(t)) mm.call(e, s) || s === r || hm(e, s, {
            get: () => t[s],
            enumerable: !(n = pm(t, s)) || n.enumerable
        })
})(Qg, Ig, "default");
var [ey, ty] = Zg("ClerkInstanceContext"), [ry, ny] = Zg("UserContext"), [sy, iy] = Zg("ClientContext"), [oy, ay] = Zg("SessionContext");
p.createContext({});
var [ly, cy] = Zg("OrganizationContext"), uy = ({
    children: e,
    organization: t,
    swrConfig: r
}) => p.createElement(Qg.SWRConfig, {
    value: r
}, p.createElement(ly.Provider, {
    value: {
        value: {
            organization: t
        }
    }
}, e));
"undefined" != typeof window ? p.useLayoutEffect : p.useEffect;
var dy = Jg,
    hy = new Set,
    py = (e, t, r) => {
        const n = (() => {
                try {
                    return !1
                } catch {}
                return !1
            })() || (() => {
                try {
                    return !0
                } catch {}
                return !1
            })(),
            s = e;
        hy.has(s) || n || (hy.add(s), console.warn(`Clerk - DEPRECATION WARNING: "${e}" is deprecated and will be removed in the next major release.\n${t}`))
    },
    fy = dm({
        packageName: "@clerk/clerk-react"
    });
var [my, gy] = Zg("AuthContext"), yy = ey, vy = ty, by = "Unsupported usage of isSatellite, domain or proxyUrl. The usage of isSatellite, domain or proxyUrl as function is not supported in non-browser environments.", xy = e => {
    ! function(e) {
        if (!p.useContext(ey)) {
            if ("function" == typeof e) return void e();
            throw new Error(`${e} can only be used within the <ClerkProvider /> component.\n\nPossible fixes:\n1. Ensure that the <ClerkProvider /> is correctly wrapping your application where this component is used.\n2. Check for multiple versions of the \`@clerk/shared\` package in your project. Use a tool like \`npm ls @clerk/shared\` to identify multiple versions, and update your dependencies to only rely on one.\n\nLearn more: https://clerk.com/docs/components/clerk-provider`.trim())
        }
    }((() => {
        fy.throwMissingClerkProviderError({
            source: e
        })
    }))
}, wy = (e, t) => {
    const r = ("string" == typeof t ? t : null == t ? void 0 : t.component) || e.displayName || e.name || "Component";
    e.displayName = r;
    const n = "string" == typeof t ? void 0 : t,
        s = t => {
            xy(r || "withClerk");
            const s = vy();
            return s.loaded || (null == n ? void 0 : n.renderWhileLoading) ? p.createElement(e, { ...t,
                component: r,
                clerk: s
            }) : null
        };
    return s.displayName = `withClerk(${r})`, s
}, ky = ({
    children: e
}) => {
    xy("SignedIn");
    const {
        userId: t
    } = gy();
    return t ? e : null
}, jy = ({
    children: e
}) => {
    xy("SignedOut");
    const {
        userId: t
    } = gy();
    return null === t ? e : null
};
wy((({
    clerk: e,
    ...t
}) => {
    const {
        client: r,
        session: n
    } = e, s = r.signedInSessions ? r.signedInSessions.length > 0 : r.activeSessions && r.activeSessions.length > 0;
    return p.useEffect((() => {
        null === n && s ? e.redirectToAfterSignOut() : e.redirectToSignIn(t)
    }), []), null
}), "RedirectToSignIn"), wy((({
    clerk: e,
    ...t
}) => (p.useEffect((() => {
    e.redirectToSignUp(t)
}), []), null)), "RedirectToSignUp"), wy((({
    clerk: e
}) => (p.useEffect((() => {
    py("RedirectToUserProfile", "Use the `redirectToUserProfile()` method instead."), e.redirectToUserProfile()
}), []), null)), "RedirectToUserProfile"), wy((({
    clerk: e
}) => (p.useEffect((() => {
    py("RedirectToOrganizationProfile", "Use the `redirectToOrganizationProfile()` method instead."), e.redirectToOrganizationProfile()
}), []), null)), "RedirectToOrganizationProfile"), wy((({
    clerk: e
}) => (p.useEffect((() => {
    py("RedirectToCreateOrganization", "Use the `redirectToCreateOrganization()` method instead."), e.redirectToCreateOrganization()
}), []), null)), "RedirectToCreateOrganization"), wy((({
    clerk: e,
    ...t
}) => (p.useEffect((() => {
    e.handleRedirectCallback(t)
}), []), null)), "AuthenticateWithRedirectCallback");
var Sy = e => {
        throw TypeError(e)
    },
    Ty = (e, t, r) => t.has(e) || Sy("Cannot " + r),
    _y = (e, t, r) => (Ty(e, t, "read from private field"), r ? r.call(e) : t.get(e)),
    Ey = (e, t, r) => t.has(e) ? Sy("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, r),
    Py = (e, t, r, n) => (Ty(e, t, "write to private field"), t.set(e, r), r),
    Cy = (e, t, r) => (Ty(e, t, "access private method"), r);
var Oy = e => {
        var t;
        return null == (t = e.trim().replace(/^v/, "").match(/-(.+?)(\.|$)/)) ? void 0 : t[1]
    },
    Ay = e => e.trim().replace(/^v/, "").split(".")[0];

function Ny(e) {
    return e.startsWith("/")
}
var Ry = {
        initialDelay: 125,
        maxDelayBetweenRetries: 0,
        factor: 2,
        shouldRetry: (e, t) => t < 5,
        retryImmediately: !0,
        jitter: !0
    },
    Iy = async e => new Promise((t => setTimeout(t, e))),
    Ly = (e, t) => t ? e * (1 + Math.random()) : e,
    My = e => {
        let t = 0;
        return async () => {
            await Iy((() => {
                const r = e.initialDelay,
                    n = e.factor;
                let s = r * Math.pow(n, t);
                return s = Ly(s, e.jitter), Math.min(e.maxDelayBetweenRetries || s, s)
            })()), t++
        }
    };
async function Uy(e = "", t) {
    const {
        async: r,
        defer: n,
        beforeLoad: s,
        crossOrigin: i,
        nonce: o
    } = t || {};
    return (async (e, t = {}) => {
        let r = 0;
        const {
            shouldRetry: n,
            initialDelay: s,
            maxDelayBetweenRetries: i,
            factor: o,
            retryImmediately: a,
            jitter: l
        } = { ...Ry,
            ...t
        }, c = My({
            initialDelay: s,
            maxDelayBetweenRetries: i,
            factor: o,
            jitter: l
        });
        for (;;) try {
            return await e()
        } catch (u) {
            if (r++, !n(u, r)) throw u;
            a && 1 === r ? await Iy(Ly(100, l)) : await c()
        }
    })((() => new Promise(((t, a) => {
        e || a(new Error("loadScript cannot be called without a src")), document && document.body || a("loadScript cannot be called when document does not exist");
        const l = document.createElement("script");
        i && l.setAttribute("crossorigin", i), l.async = r || !1, l.defer = n || !1, l.addEventListener("load", (() => {
            l.remove(), t(l)
        })), l.addEventListener("error", (() => {
            l.remove(), a()
        })), l.src = e, l.nonce = o, null == s || s(l), document.body.appendChild(l)
    }))), {
        shouldRetry: (e, t) => t <= 5
    })
}
var Dy = "Clerk: Failed to load Clerk",
    {
        isDevOrStagingUrl: $y
    } = function() {
        const e = new Map;
        return {
            isDevOrStagingUrl: t => {
                if (!t) return !1;
                const r = "string" == typeof t ? t : t.hostname;
                let n = e.get(r);
                return void 0 === n && (n = ym.some((e => r.endsWith(e))), e.set(r, n)), n
            }
        }
    }(),
    Fy = dm({
        packageName: "@clerk/shared"
    });
var Vy = e => {
        var t, r;
        const {
            clerkJSUrl: n,
            clerkJSVariant: s,
            clerkJSVersion: i,
            proxyUrl: o,
            domain: a,
            publishableKey: l
        } = e;
        if (n) return n;
        let c = "";
        var u, d;
        c = o && (!(d = o) || function(e) {
            return /^http(s)?:\/\//.test(e || "")
        }(d) || Ny(d)) ? (u = o, u ? Ny(u) ? new URL(u, window.location.origin).toString() : u : "").replace(/http(s)?:\/\//, "") : a && !$y((null == (t = bm(l)) ? void 0 : t.frontendApi) || "") ? function(e) {
            if (!e) return "";
            let t;
            if (e.match(/^(clerk\.)+\w*$/)) t = /(clerk\.)*(?=clerk\.)/;
            else {
                if (e.match(/\.clerk.accounts/)) return e;
                t = /^(clerk\.)*/gi
            }
            return `clerk.${e.replace(t,"")}`
        }(a) : (null == (r = bm(l)) ? void 0 : r.frontendApi) || "";
        const h = s ? `${s.replace(/\.+$/,"")}.` : "",
            p = ((e, t = "5.58.1") => {
                if (e) return e;
                const r = Oy(t);
                return r ? "snapshot" === r ? "5.58.1" : r : Ay(t)
            })(i);
        return `https://${c}/npm/@clerk/clerk-js@${p}/dist/clerk.${h}browser.js`
    },
    By = e => t => {
        const r = (e => {
            const t = {};
            return e.publishableKey && (t["data-clerk-publishable-key"] = e.publishableKey), e.proxyUrl && (t["data-clerk-proxy-url"] = e.proxyUrl), e.domain && (t["data-clerk-domain"] = e.domain), e.nonce && (t.nonce = e.nonce), t
        })(e);
        for (const e in r) t.setAttribute(e, r[e])
    },
    zy = e => {
        (() => {
            try {
                return !1
            } catch {}
            return !1
        })() && console.error(`Clerk: ${e}`)
    };

function Wy(e, t, r) {
    return "function" == typeof e ? e(t) : void 0 !== e ? e : void 0 !== r ? r : void 0
}
var Hy = (e, ...t) => {
        const r = { ...e
        };
        for (const n of t) delete r[n];
        return r
    },
    qy = e => {
        const t = e.userId,
            r = e.user,
            n = e.sessionId,
            s = e.sessionStatus;
        return {
            userId: t,
            user: r,
            sessionId: n,
            session: e.session,
            sessionStatus: s,
            organization: e.organization,
            orgId: e.orgId,
            orgRole: e.orgRole,
            orgPermissions: e.orgPermissions,
            orgSlug: e.orgSlug,
            actor: e.actor,
            factorVerificationAge: e.factorVerificationAge
        }
    },
    Ky = e => {
        var t, r;
        const n = e.user ? e.user.id : e.user,
            s = e.user,
            i = e.session ? e.session.id : e.session,
            o = e.session,
            a = null == (t = e.session) ? void 0 : t.status,
            l = e.session ? e.session.factorVerificationAge : null,
            c = null == o ? void 0 : o.actor,
            u = e.organization,
            d = e.organization ? e.organization.id : e.organization,
            h = null == u ? void 0 : u.slug,
            p = u ? null == (r = null == s ? void 0 : s.organizationMemberships) ? void 0 : r.find((e => e.organization.id === d)) : u,
            f = p ? p.permissions : p,
            m = p ? p.role : p;
        return {
            userId: n,
            user: s,
            sessionId: i,
            session: o,
            sessionStatus: a,
            organization: u,
            orgId: d,
            orgRole: m,
            orgSlug: h,
            orgPermissions: f,
            actor: c,
            factorVerificationAge: l
        }
    };

function Gy() {
    return "undefined" != typeof window
}
"undefined" == typeof window || window.global || (window.global = "undefined" == typeof global ? window : global);
var Yy = e => t => {
        try {
            return p.Children.only(e)
        } catch {
            return fy.throw((e => `You've passed multiple children components to <${e}/>. You can only pass a single child component or text.`)(t))
        }
    },
    Jy = (e, t) => (e || (e = t), "string" == typeof e && (e = p.createElement("button", null, e)), e),
    Xy = e => (...t) => {
        if (e && "function" == typeof e) return e(...t)
    };
var Zy = new Map;
var Qy = e => {
        const t = Array(e.length).fill(null),
            [r, n] = o.useState(t);
        return e.map(((e, t) => ({
            id: e.id,
            mount: e => n((r => r.map(((r, n) => n === t ? e : r)))),
            unmount: () => n((e => e.map(((e, r) => r === t ? null : e)))),
            portal: () => p.createElement(p.Fragment, null, r[t] ? d.createPortal(e.component, r[t]) : null)
        })))
    },
    ev = (e, t) => !!e && p.isValidElement(e) && (null == e ? void 0 : e.type) === t,
    tv = (e, t) => sv({
        children: e,
        reorderItemsLabels: ["account", "security"],
        LinkComponent: bv,
        PageComponent: vv,
        MenuItemsComponent: jv,
        componentName: "UserProfile"
    }, t),
    rv = (e, t) => sv({
        children: e,
        reorderItemsLabels: ["general", "members"],
        LinkComponent: Pv,
        PageComponent: Ev,
        componentName: "OrganizationProfile"
    }, t),
    nv = e => {
        const t = [],
            r = [Pv, Ev, jv, vv, bv];
        return p.Children.forEach(e, (e => {
            r.some((t => ev(e, t))) || t.push(e)
        })), t
    },
    sv = (e, t) => {
        const {
            children: r,
            LinkComponent: n,
            PageComponent: s,
            MenuItemsComponent: i,
            reorderItemsLabels: o,
            componentName: a
        } = e, {
            allowForAnyChildren: l = !1
        } = t || {}, c = [];
        p.Children.forEach(r, (e => {
            if (!ev(e, s) && !ev(e, n) && !ev(e, i)) return void(e && !l && zy((e => `<${e} /> can only accept <${e}.Page /> and <${e}.Link /> as its children. Any other provided component will be ignored.`)(a)));
            const {
                props: t
            } = e, {
                children: r,
                label: u,
                url: d,
                labelIcon: h
            } = t;
            if (ev(e, s))
                if (iv(t, o)) c.push({
                    label: u
                });
                else {
                    if (!ov(t)) return void zy((e => `Missing props. <${e}.Page /> component requires the following props: url, label, labelIcon, alongside with children to be rendered inside the page.`)(a));
                    c.push({
                        label: u,
                        labelIcon: h,
                        children: r,
                        url: d
                    })
                }
            if (ev(e, n)) {
                if (!av(t)) return void zy((e => `Missing props. <${e}.Link /> component requires the following props: url, label and labelIcon.`)(a));
                c.push({
                    label: u,
                    labelIcon: h,
                    url: d
                })
            }
        }));
        const u = [],
            d = [],
            h = [];
        c.forEach(((e, t) => {
            if (ov(e)) return u.push({
                component: e.children,
                id: t
            }), void d.push({
                component: e.labelIcon,
                id: t
            });
            av(e) && h.push({
                component: e.labelIcon,
                id: t
            })
        }));
        const f = Qy(u),
            m = Qy(d),
            g = Qy(h),
            y = [],
            v = [];
        return c.forEach(((e, t) => {
            if (iv(e, o)) y.push({
                label: e.label
            });
            else {
                if (ov(e)) {
                    const {
                        portal: r,
                        mount: n,
                        unmount: s
                    } = f.find((e => e.id === t)), {
                        portal: i,
                        mount: o,
                        unmount: a
                    } = m.find((e => e.id === t));
                    return y.push({
                        label: e.label,
                        url: e.url,
                        mount: n,
                        unmount: s,
                        mountIcon: o,
                        unmountIcon: a
                    }), v.push(r), void v.push(i)
                }
                if (av(e)) {
                    const {
                        portal: r,
                        mount: n,
                        unmount: s
                    } = g.find((e => e.id === t));
                    return y.push({
                        label: e.label,
                        url: e.url,
                        mountIcon: n,
                        unmountIcon: s
                    }), void v.push(r)
                }
            }
        })), {
            customPages: y,
            customPagesPortals: v
        }
    },
    iv = (e, t) => {
        const {
            children: r,
            label: n,
            url: s,
            labelIcon: i
        } = e;
        return !r && !s && !i && t.some((e => e === n))
    },
    ov = e => {
        const {
            children: t,
            label: r,
            url: n,
            labelIcon: s
        } = e;
        return !!(t && n && s && r)
    },
    av = e => {
        const {
            children: t,
            label: r,
            url: n,
            labelIcon: s
        } = e;
        return !(t || !n || !s || !r)
    },
    lv = ({
        children: e,
        MenuItemsComponent: t,
        MenuActionComponent: r,
        MenuLinkComponent: n,
        UserProfileLinkComponent: s,
        UserProfilePageComponent: i,
        reorderItemsLabels: o
    }) => {
        const a = [],
            l = [],
            c = [];
        p.Children.forEach(e, (e => {
            if (!ev(e, t) && !ev(e, s) && !ev(e, i)) return void(e && zy("<UserButton /> can only accept <UserButton.UserProfilePage />, <UserButton.UserProfileLink /> and <UserButton.MenuItems /> as its children. Any other provided component will be ignored."));
            if (ev(e, s) || ev(e, i)) return;
            const {
                props: l
            } = e;
            p.Children.forEach(l.children, (e => {
                if (!ev(e, r) && !ev(e, n)) return void(e && zy("<UserButton.MenuItems /> component can only accept <UserButton.Action /> and <UserButton.Link /> as its children. Any other provided component will be ignored."));
                const {
                    props: t
                } = e, {
                    label: s,
                    labelIcon: i,
                    href: l,
                    onClick: c,
                    open: u
                } = t;
                if (ev(e, r))
                    if (cv(t, o)) a.push({
                        label: s
                    });
                    else {
                        if (!uv(t)) return void zy("Missing props. <UserButton.Action /> component requires the following props: label."); {
                            const e = {
                                label: s,
                                labelIcon: i
                            };
                            if (void 0 !== c) a.push({ ...e,
                                onClick: c
                            });
                            else {
                                if (void 0 === u) return void zy("Custom menu item must have either onClick or open property");
                                a.push({ ...e,
                                    open: u.startsWith("/") ? u : `/${u}`
                                })
                            }
                        }
                    }
                if (ev(e, n)) {
                    if (!dv(t)) return void zy("Missing props. <UserButton.Link /> component requires the following props: href, label and labelIcon.");
                    a.push({
                        label: s,
                        labelIcon: i,
                        href: l
                    })
                }
            }))
        }));
        const u = [],
            d = [];
        a.forEach(((e, t) => {
            uv(e) && u.push({
                component: e.labelIcon,
                id: t
            }), dv(e) && d.push({
                component: e.labelIcon,
                id: t
            })
        }));
        const h = Qy(u),
            f = Qy(d);
        return a.forEach(((e, t) => {
            if (cv(e, o) && l.push({
                    label: e.label
                }), uv(e)) {
                const {
                    portal: r,
                    mount: n,
                    unmount: s
                } = h.find((e => e.id === t)), i = {
                    label: e.label,
                    mountIcon: n,
                    unmountIcon: s
                };
                "onClick" in e ? i.onClick = e.onClick : "open" in e && (i.open = e.open), l.push(i), c.push(r)
            }
            if (dv(e)) {
                const {
                    portal: r,
                    mount: n,
                    unmount: s
                } = f.find((e => e.id === t));
                l.push({
                    label: e.label,
                    href: e.href,
                    mountIcon: n,
                    unmountIcon: s
                }), c.push(r)
            }
        })), {
            customMenuItems: l,
            customMenuItemsPortals: c
        }
    },
    cv = (e, t) => {
        const {
            children: r,
            label: n,
            onClick: s,
            labelIcon: i
        } = e;
        return !r && !s && !i && t.some((e => e === n))
    },
    uv = e => {
        const {
            label: t,
            labelIcon: r,
            onClick: n,
            open: s
        } = e;
        return !(!r || !t || "function" != typeof n && "string" != typeof s)
    },
    dv = e => {
        const {
            label: t,
            href: r,
            labelIcon: n
        } = e;
        return !!r && !!n && !!t
    };

function hv(e) {
    const t = o.useRef(),
        [r, n] = o.useState("rendering");
    return o.useEffect((() => {
        if (!e) throw new Error("Clerk: no component name provided, unable to detect mount.");
        "undefined" == typeof window || t.current || (t.current = function(e) {
            const {
                root: t = (null == document ? void 0 : document.body),
                selector: r,
                timeout: n = 0
            } = e;
            return new Promise(((e, s) => {
                if (!t) return void s(new Error("No root element provided"));
                let i = t;
                if (r && (i = null == t ? void 0 : t.querySelector(r)), (null == i ? void 0 : i.childElementCount) && i.childElementCount > 0) return void e();
                const o = new MutationObserver((n => {
                    for (const s of n)
                        if ("childList" === s.type && (!i && r && (i = null == t ? void 0 : t.querySelector(r)), (null == i ? void 0 : i.childElementCount) && i.childElementCount > 0)) return o.disconnect(), void e()
                }));
                o.observe(t, {
                    childList: !0,
                    subtree: !0
                }), n > 0 && setTimeout((() => {
                    o.disconnect(), s(new Error("Timeout waiting for element children"))
                }), n)
            }))
        }({
            selector: `[data-clerk-component="${e}"]`
        }).then((() => {
            n("rendered")
        })).catch((() => {
            n("error")
        })))
    }), [e]), r
}
var pv = e => "mount" in e,
    fv = e => "open" in e,
    mv = e => null == e ? void 0 : e.map((({
        mountIcon: e,
        unmountIcon: t,
        ...r
    }) => r)),
    gv = class extends p.PureComponent {
        constructor() {
            super(...arguments), this.rootRef = p.createRef()
        }
        componentDidUpdate(e) {
            var t, r, n, s;
            if (!pv(e) || !pv(this.props)) return;
            const i = Hy(e.props, "customPages", "customMenuItems", "children"),
                o = Hy(this.props.props, "customPages", "customMenuItems", "children"),
                a = (null == (t = i.customPages) ? void 0 : t.length) !== (null == (r = o.customPages) ? void 0 : r.length),
                l = (null == (n = i.customMenuItems) ? void 0 : n.length) !== (null == (s = o.customMenuItems) ? void 0 : s.length),
                c = mv(e.props.customMenuItems),
                u = mv(this.props.props.customMenuItems);
            dy(i, o) && dy(c, u) && !a && !l || this.rootRef.current && this.props.updateProps({
                node: this.rootRef.current,
                props: this.props.props
            })
        }
        componentDidMount() {
            this.rootRef.current && (pv(this.props) && this.props.mount(this.rootRef.current, this.props.props), fv(this.props) && this.props.open(this.props.props))
        }
        componentWillUnmount() {
            this.rootRef.current && (pv(this.props) && this.props.unmount(this.rootRef.current), fv(this.props) && this.props.close())
        }
        render() {
            const {
                hideRootHtmlElement: e = !1
            } = this.props, t = {
                ref: this.rootRef,
                ...this.props.rootProps,
                ...this.props.component && {
                    "data-clerk-component": this.props.component
                }
            };
            return p.createElement(p.Fragment, null, !e && p.createElement("div", { ...t
            }), this.props.children)
        }
    },
    yv = e => {
        var t, r;
        return p.createElement(p.Fragment, null, null == (t = null == e ? void 0 : e.customPagesPortals) ? void 0 : t.map(((e, t) => o.createElement(e, {
            key: t
        }))), null == (r = null == e ? void 0 : e.customMenuItemsPortals) ? void 0 : r.map(((e, t) => o.createElement(e, {
            key: t
        }))))
    };

function vv({
    children: e
}) {
    return zy("<UserProfile.Page /> component needs to be a direct child of `<UserProfile />` or `<UserButton />`."), p.createElement(p.Fragment, null, e)
}

function bv({
    children: e
}) {
    return zy("<UserProfile.Link /> component needs to be a direct child of `<UserProfile />` or `<UserButton />`."), p.createElement(p.Fragment, null, e)
}
wy((({
    clerk: e,
    component: t,
    fallback: r,
    ...n
}) => {
    const s = "rendering" === hv(t) || !e.loaded,
        i = { ...s && r && {
                style: {
                    display: "none"
                }
            }
        };
    return p.createElement(p.Fragment, null, s && r, e.loaded && p.createElement(gv, {
        component: t,
        mount: e.mountSignIn,
        unmount: e.unmountSignIn,
        updateProps: e.__unstable__updateProps,
        props: n,
        rootProps: i
    }))
}), {
    component: "SignIn",
    renderWhileLoading: !0
}), wy((({
    clerk: e,
    component: t,
    fallback: r,
    ...n
}) => {
    const s = "rendering" === hv(t) || !e.loaded,
        i = { ...s && r && {
                style: {
                    display: "none"
                }
            }
        };
    return p.createElement(p.Fragment, null, s && r, e.loaded && p.createElement(gv, {
        component: t,
        mount: e.mountSignUp,
        unmount: e.unmountSignUp,
        updateProps: e.__unstable__updateProps,
        props: n,
        rootProps: i
    }))
}), {
    component: "SignUp",
    renderWhileLoading: !0
});
var xv = wy((({
    clerk: e,
    component: t,
    fallback: r,
    ...n
}) => {
    const s = "rendering" === hv(t) || !e.loaded,
        i = { ...s && r && {
                style: {
                    display: "none"
                }
            }
        },
        {
            customPages: o,
            customPagesPortals: a
        } = tv(n.children);
    return p.createElement(p.Fragment, null, s && r, p.createElement(gv, {
        component: t,
        mount: e.mountUserProfile,
        unmount: e.unmountUserProfile,
        updateProps: e.__unstable__updateProps,
        props: { ...n,
            customPages: o
        },
        rootProps: i
    }, p.createElement(yv, {
        customPagesPortals: a
    })))
}), {
    component: "UserProfile",
    renderWhileLoading: !0
});
Object.assign(xv, {
    Page: vv,
    Link: bv
});
var wv = o.createContext({
        mount: () => {},
        unmount: () => {},
        updateProps: () => {}
    }),
    kv = wy((({
        clerk: e,
        component: t,
        fallback: r,
        ...n
    }) => {
        const s = "rendering" === hv(t) || !e.loaded,
            i = { ...s && r && {
                    style: {
                        display: "none"
                    }
                }
            },
            {
                customPages: o,
                customPagesPortals: a
            } = tv(n.children, {
                allowForAnyChildren: !!n.__experimental_asProvider
            }),
            l = Object.assign(n.userProfileProps || {}, {
                customPages: o
            }),
            {
                customMenuItems: c,
                customMenuItemsPortals: u
            } = (d = n.children, lv({
                children: d,
                reorderItemsLabels: ["manageAccount", "signOut"],
                MenuItemsComponent: jv,
                MenuActionComponent: Sv,
                MenuLinkComponent: Tv,
                UserProfileLinkComponent: bv,
                UserProfilePageComponent: vv
            }));
        var d;
        const h = nv(n.children),
            f = {
                mount: e.mountUserButton,
                unmount: e.unmountUserButton,
                updateProps: e.__unstable__updateProps,
                props: { ...n,
                    userProfileProps: l,
                    customMenuItems: c
                }
            },
            m = {
                customPagesPortals: a,
                customMenuItemsPortals: u
            };
        return p.createElement(wv.Provider, {
            value: f
        }, s && r, e.loaded && p.createElement(gv, {
            component: t,
            ...f,
            hideRootHtmlElement: !!n.__experimental_asProvider,
            rootProps: i
        }, n.__experimental_asProvider ? h : null, p.createElement(yv, { ...m
        })))
    }), {
        component: "UserButton",
        renderWhileLoading: !0
    });

function jv({
    children: e
}) {
    return zy("<UserButton.MenuItems /> component needs to be a direct child of `<UserButton />`."), p.createElement(p.Fragment, null, e)
}

function Sv({
    children: e
}) {
    return zy("<UserButton.Action /> component needs to be a direct child of `<UserButton.MenuItems />`."), p.createElement(p.Fragment, null, e)
}

function Tv({
    children: e
}) {
    return zy("<UserButton.Link /> component needs to be a direct child of `<UserButton.MenuItems />`."), p.createElement(p.Fragment, null, e)
}
var _v = Object.assign(kv, {
    UserProfilePage: vv,
    UserProfileLink: bv,
    MenuItems: jv,
    Action: Sv,
    Link: Tv,
    __experimental_Outlet: function(e) {
        const t = o.useContext(wv),
            r = { ...t,
                props: { ...t.props,
                    ...e
                }
            };
        return p.createElement(gv, { ...r
        })
    }
});

function Ev({
    children: e
}) {
    return zy("<OrganizationProfile.Page /> component needs to be a direct child of `<OrganizationProfile />` or `<OrganizationSwitcher />`."), p.createElement(p.Fragment, null, e)
}

function Pv({
    children: e
}) {
    return zy("<OrganizationProfile.Link /> component needs to be a direct child of `<OrganizationProfile />` or `<OrganizationSwitcher />`."), p.createElement(p.Fragment, null, e)
}
var Cv = wy((({
    clerk: e,
    component: t,
    fallback: r,
    ...n
}) => {
    const s = "rendering" === hv(t) || !e.loaded,
        i = { ...s && r && {
                style: {
                    display: "none"
                }
            }
        },
        {
            customPages: o,
            customPagesPortals: a
        } = rv(n.children);
    return p.createElement(p.Fragment, null, s && r, e.loaded && p.createElement(gv, {
        component: t,
        mount: e.mountOrganizationProfile,
        unmount: e.unmountOrganizationProfile,
        updateProps: e.__unstable__updateProps,
        props: { ...n,
            customPages: o
        },
        rootProps: i
    }, p.createElement(yv, {
        customPagesPortals: a
    })))
}), {
    component: "OrganizationProfile",
    renderWhileLoading: !0
});
Object.assign(Cv, {
    Page: Ev,
    Link: Pv
}), wy((({
    clerk: e,
    component: t,
    fallback: r,
    ...n
}) => {
    const s = "rendering" === hv(t) || !e.loaded,
        i = { ...s && r && {
                style: {
                    display: "none"
                }
            }
        };
    return p.createElement(p.Fragment, null, s && r, e.loaded && p.createElement(gv, {
        component: t,
        mount: e.mountCreateOrganization,
        unmount: e.unmountCreateOrganization,
        updateProps: e.__unstable__updateProps,
        props: n,
        rootProps: i
    }))
}), {
    component: "CreateOrganization",
    renderWhileLoading: !0
});
var Ov = o.createContext({
        mount: () => {},
        unmount: () => {},
        updateProps: () => {}
    }),
    Av = wy((({
        clerk: e,
        component: t,
        fallback: r,
        ...n
    }) => {
        const s = "rendering" === hv(t) || !e.loaded,
            i = { ...s && r && {
                    style: {
                        display: "none"
                    }
                }
            },
            {
                customPages: o,
                customPagesPortals: a
            } = rv(n.children, {
                allowForAnyChildren: !!n.__experimental_asProvider
            }),
            l = Object.assign(n.organizationProfileProps || {}, {
                customPages: o
            }),
            c = nv(n.children),
            u = {
                mount: e.mountOrganizationSwitcher,
                unmount: e.unmountOrganizationSwitcher,
                updateProps: e.__unstable__updateProps,
                props: { ...n,
                    organizationProfileProps: l
                },
                rootProps: i,
                component: t
            };
        return e.__experimental_prefetchOrganizationSwitcher(), p.createElement(Ov.Provider, {
            value: u
        }, p.createElement(p.Fragment, null, s && r, e.loaded && p.createElement(gv, { ...u,
            hideRootHtmlElement: !!n.__experimental_asProvider
        }, n.__experimental_asProvider ? c : null, p.createElement(yv, {
            customPagesPortals: a
        }))))
    }), {
        component: "OrganizationSwitcher",
        renderWhileLoading: !0
    });
Object.assign(Av, {
    OrganizationProfilePage: Ev,
    OrganizationProfileLink: Pv,
    __experimental_Outlet: function(e) {
        const t = o.useContext(Ov),
            r = { ...t,
                props: { ...t.props,
                    ...e
                }
            };
        return p.createElement(gv, { ...r
        })
    }
}), wy((({
    clerk: e,
    component: t,
    fallback: r,
    ...n
}) => {
    const s = "rendering" === hv(t) || !e.loaded,
        i = { ...s && r && {
                style: {
                    display: "none"
                }
            }
        };
    return p.createElement(p.Fragment, null, s && r, e.loaded && p.createElement(gv, {
        component: t,
        mount: e.mountOrganizationList,
        unmount: e.unmountOrganizationList,
        updateProps: e.__unstable__updateProps,
        props: n,
        rootProps: i
    }))
}), {
    component: "OrganizationList",
    renderWhileLoading: !0
}), wy((({
    clerk: e,
    component: t,
    fallback: r,
    ...n
}) => {
    const s = "rendering" === hv(t) || !e.loaded,
        i = { ...s && r && {
                style: {
                    display: "none"
                }
            }
        };
    return p.createElement(p.Fragment, null, s && r, e.loaded && p.createElement(gv, {
        component: t,
        open: e.openGoogleOneTap,
        close: e.closeGoogleOneTap,
        updateProps: e.__unstable__updateProps,
        props: n,
        rootProps: i
    }))
}), {
    component: "GoogleOneTap",
    renderWhileLoading: !0
}), wy((({
    clerk: e,
    component: t,
    fallback: r,
    ...n
}) => {
    const s = "rendering" === hv(t) || !e.loaded,
        i = { ...s && r && {
                style: {
                    display: "none"
                }
            }
        };
    return p.createElement(p.Fragment, null, s && r, e.loaded && p.createElement(gv, {
        component: t,
        mount: e.mountWaitlist,
        unmount: e.unmountWaitlist,
        updateProps: e.__unstable__updateProps,
        props: n,
        rootProps: i
    }))
}), {
    component: "Waitlist",
    renderWhileLoading: !0
});
var Nv = wy((({
    clerk: e,
    children: t,
    ...r
}) => {
    const {
        signUpFallbackRedirectUrl: n,
        forceRedirectUrl: s,
        fallbackRedirectUrl: i,
        signUpForceRedirectUrl: o,
        mode: a,
        initialValues: l,
        withSignUp: c,
        oauthFlow: u,
        ...d
    } = r;
    t = Jy(t, "Sign in");
    const h = Yy(t)("SignInButton"),
        f = { ...d,
            onClick: async t => (h && "object" == typeof h && "props" in h && await Xy(h.props.onClick)(t), (() => {
                const t = {
                    forceRedirectUrl: s,
                    fallbackRedirectUrl: i,
                    signUpFallbackRedirectUrl: n,
                    signUpForceRedirectUrl: o,
                    initialValues: l,
                    withSignUp: c,
                    oauthFlow: u
                };
                return "modal" === a ? e.openSignIn({ ...t,
                    appearance: r.appearance
                }) : e.redirectToSignIn({ ...t,
                    signInFallbackRedirectUrl: i,
                    signInForceRedirectUrl: s
                })
            })())
        };
    return p.cloneElement(h, f)
}), {
    component: "SignInButton",
    renderWhileLoading: !0
});
wy((({
    clerk: e,
    children: t,
    ...r
}) => {
    const {
        fallbackRedirectUrl: n,
        forceRedirectUrl: s,
        signInFallbackRedirectUrl: i,
        signInForceRedirectUrl: o,
        mode: a,
        unsafeMetadata: l,
        initialValues: c,
        oauthFlow: u,
        ...d
    } = r;
    t = Jy(t, "Sign up");
    const h = Yy(t)("SignUpButton"),
        f = { ...d,
            onClick: async t => (h && "object" == typeof h && "props" in h && await Xy(h.props.onClick)(t), (() => {
                const t = {
                    fallbackRedirectUrl: n,
                    forceRedirectUrl: s,
                    signInFallbackRedirectUrl: i,
                    signInForceRedirectUrl: o,
                    unsafeMetadata: l,
                    initialValues: c,
                    oauthFlow: u
                };
                return "modal" === a ? e.openSignUp({ ...t,
                    appearance: r.appearance
                }) : e.redirectToSignUp({ ...t,
                    signUpFallbackRedirectUrl: n,
                    signUpForceRedirectUrl: s
                })
            })())
        };
    return p.cloneElement(h, f)
}), {
    component: "SignUpButton",
    renderWhileLoading: !0
}), wy((({
    clerk: e,
    children: t,
    ...r
}) => {
    const {
        redirectUrl: n = "/",
        signOutOptions: s,
        ...i
    } = r;
    t = Jy(t, "Sign out");
    const o = Yy(t)("SignOutButton"),
        a = { ...i,
            onClick: async t => (await Xy(o.props.onClick)(t), e.signOut({
                redirectUrl: n,
                ...s
            }))
        };
    return p.cloneElement(o, a)
}), {
    component: "SignOutButton",
    renderWhileLoading: !0
}), wy((({
    clerk: e,
    children: t,
    ...r
}) => {
    const {
        redirectUrl: n,
        ...s
    } = r;
    t = Jy(t, "Sign in with Metamask");
    const i = Yy(t)("SignInWithMetamaskButton"),
        o = { ...s,
            onClick: async t => (await Xy(i.props.onClick)(t), (async () => {
                !async function() {
                    await e.authenticateWithMetamask({
                        redirectUrl: n || void 0
                    })
                }()
            })())
        };
    return p.cloneElement(i, o)
}), {
    component: "SignInWithMetamask",
    renderWhileLoading: !0
}), void 0 === globalThis.__BUILD_DISABLE_RHC__ && (globalThis.__BUILD_DISABLE_RHC__ = !1);
var Rv, Iv, Lv, Mv, Uv, Dv, $v, Fv = {
        name: "@clerk/clerk-react",
        version: "5.25.5",
        environment: "production"
    },
    Vv = class e {
        constructor(e) {
            Ey(this, Dv), this.clerkjs = null, this.preopenOneTap = null, this.preopenUserVerification = null, this.preopenSignIn = null, this.preopenSignUp = null, this.preopenUserProfile = null, this.preopenOrganizationProfile = null, this.preopenCreateOrganization = null, this.preOpenWaitlist = null, this.premountSignInNodes = new Map, this.premountSignUpNodes = new Map, this.premountUserProfileNodes = new Map, this.premountUserButtonNodes = new Map, this.premountOrganizationProfileNodes = new Map, this.premountCreateOrganizationNodes = new Map, this.premountOrganizationSwitcherNodes = new Map, this.premountOrganizationListNodes = new Map, this.premountMethodCalls = new Map, this.premountWaitlistNodes = new Map, this.premountPricingTableNodes = new Map, this.premountAddListenerCalls = new Map, this.loadedListeners = [], Ey(this, Rv, !1), Ey(this, Iv), Ey(this, Lv), Ey(this, Mv), this.buildSignInUrl = e => {
                const t = () => {
                    var t;
                    return (null == (t = this.clerkjs) ? void 0 : t.buildSignInUrl(e)) || ""
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("buildSignInUrl", t)
            }, this.buildSignUpUrl = e => {
                const t = () => {
                    var t;
                    return (null == (t = this.clerkjs) ? void 0 : t.buildSignUpUrl(e)) || ""
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("buildSignUpUrl", t)
            }, this.buildAfterSignInUrl = (...e) => {
                const t = () => {
                    var t;
                    return (null == (t = this.clerkjs) ? void 0 : t.buildAfterSignInUrl(...e)) || ""
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("buildAfterSignInUrl", t)
            }, this.buildAfterSignUpUrl = (...e) => {
                const t = () => {
                    var t;
                    return (null == (t = this.clerkjs) ? void 0 : t.buildAfterSignUpUrl(...e)) || ""
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("buildAfterSignUpUrl", t)
            }, this.buildAfterSignOutUrl = () => {
                const e = () => {
                    var e;
                    return (null == (e = this.clerkjs) ? void 0 : e.buildAfterSignOutUrl()) || ""
                };
                if (this.clerkjs && _y(this, Rv)) return e();
                this.premountMethodCalls.set("buildAfterSignOutUrl", e)
            }, this.buildAfterMultiSessionSingleSignOutUrl = () => {
                const e = () => {
                    var e;
                    return (null == (e = this.clerkjs) ? void 0 : e.buildAfterMultiSessionSingleSignOutUrl()) || ""
                };
                if (this.clerkjs && _y(this, Rv)) return e();
                this.premountMethodCalls.set("buildAfterMultiSessionSingleSignOutUrl", e)
            }, this.buildUserProfileUrl = () => {
                const e = () => {
                    var e;
                    return (null == (e = this.clerkjs) ? void 0 : e.buildUserProfileUrl()) || ""
                };
                if (this.clerkjs && _y(this, Rv)) return e();
                this.premountMethodCalls.set("buildUserProfileUrl", e)
            }, this.buildCreateOrganizationUrl = () => {
                const e = () => {
                    var e;
                    return (null == (e = this.clerkjs) ? void 0 : e.buildCreateOrganizationUrl()) || ""
                };
                if (this.clerkjs && _y(this, Rv)) return e();
                this.premountMethodCalls.set("buildCreateOrganizationUrl", e)
            }, this.buildOrganizationProfileUrl = () => {
                const e = () => {
                    var e;
                    return (null == (e = this.clerkjs) ? void 0 : e.buildOrganizationProfileUrl()) || ""
                };
                if (this.clerkjs && _y(this, Rv)) return e();
                this.premountMethodCalls.set("buildOrganizationProfileUrl", e)
            }, this.buildWaitlistUrl = () => {
                const e = () => {
                    var e;
                    return (null == (e = this.clerkjs) ? void 0 : e.buildWaitlistUrl()) || ""
                };
                if (this.clerkjs && _y(this, Rv)) return e();
                this.premountMethodCalls.set("buildWaitlistUrl", e)
            }, this.buildUrlWithAuth = e => {
                const t = () => {
                    var t;
                    return (null == (t = this.clerkjs) ? void 0 : t.buildUrlWithAuth(e)) || ""
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("buildUrlWithAuth", t)
            }, this.handleUnauthenticated = async () => {
                const e = () => {
                    var e;
                    return null == (e = this.clerkjs) ? void 0 : e.handleUnauthenticated()
                };
                this.clerkjs && _y(this, Rv) ? e() : this.premountMethodCalls.set("handleUnauthenticated", e)
            }, this.addOnLoaded = e => {
                this.loadedListeners.push(e), this.loaded && this.emitLoaded()
            }, this.emitLoaded = () => {
                this.loadedListeners.forEach((e => e())), this.loadedListeners = []
            }, this.hydrateClerkJS = e => {
                if (!e) throw new Error("Failed to hydrate latest Clerk JS");
                return this.clerkjs = e, this.premountMethodCalls.forEach((e => e())), this.premountAddListenerCalls.forEach(((t, r) => {
                    t.nativeUnsubscribe = e.addListener(r)
                })), null !== this.preopenSignIn && e.openSignIn(this.preopenSignIn), null !== this.preopenSignUp && e.openSignUp(this.preopenSignUp), null !== this.preopenUserProfile && e.openUserProfile(this.preopenUserProfile), null !== this.preopenUserVerification && e.__internal_openReverification(this.preopenUserVerification), null !== this.preopenOneTap && e.openGoogleOneTap(this.preopenOneTap), null !== this.preopenOrganizationProfile && e.openOrganizationProfile(this.preopenOrganizationProfile), null !== this.preopenCreateOrganization && e.openCreateOrganization(this.preopenCreateOrganization), null !== this.preOpenWaitlist && e.openWaitlist(this.preOpenWaitlist), this.premountSignInNodes.forEach(((t, r) => {
                    e.mountSignIn(r, t)
                })), this.premountSignUpNodes.forEach(((t, r) => {
                    e.mountSignUp(r, t)
                })), this.premountUserProfileNodes.forEach(((t, r) => {
                    e.mountUserProfile(r, t)
                })), this.premountUserButtonNodes.forEach(((t, r) => {
                    e.mountUserButton(r, t)
                })), this.premountOrganizationListNodes.forEach(((t, r) => {
                    e.mountOrganizationList(r, t)
                })), this.premountWaitlistNodes.forEach(((t, r) => {
                    e.mountWaitlist(r, t)
                })), this.premountPricingTableNodes.forEach(((t, r) => {
                    e.__experimental_mountPricingTable(r, t)
                })), Py(this, Rv, !0), this.emitLoaded(), this.clerkjs
            }, this.__unstable__updateProps = async e => {
                const t = await Cy(this, Dv, $v).call(this);
                if (t && "__unstable__updateProps" in t) return t.__unstable__updateProps(e)
            }, this.__experimental_nextTask = async e => this.clerkjs ? this.clerkjs.__experimental_nextTask(e) : Promise.reject(), this.setActive = e => this.clerkjs ? this.clerkjs.setActive(e) : Promise.reject(), this.openSignIn = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.openSignIn(e) : this.preopenSignIn = e
            }, this.closeSignIn = () => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.closeSignIn() : this.preopenSignIn = null
            }, this.__internal_openReverification = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.__internal_openReverification(e) : this.preopenUserVerification = e
            }, this.__internal_closeReverification = () => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.__internal_closeReverification() : this.preopenUserVerification = null
            }, this.openGoogleOneTap = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.openGoogleOneTap(e) : this.preopenOneTap = e
            }, this.closeGoogleOneTap = () => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.closeGoogleOneTap() : this.preopenOneTap = null
            }, this.openUserProfile = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.openUserProfile(e) : this.preopenUserProfile = e
            }, this.closeUserProfile = () => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.closeUserProfile() : this.preopenUserProfile = null
            }, this.openOrganizationProfile = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.openOrganizationProfile(e) : this.preopenOrganizationProfile = e
            }, this.closeOrganizationProfile = () => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.closeOrganizationProfile() : this.preopenOrganizationProfile = null
            }, this.openCreateOrganization = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.openCreateOrganization(e) : this.preopenCreateOrganization = e
            }, this.closeCreateOrganization = () => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.closeCreateOrganization() : this.preopenCreateOrganization = null
            }, this.openWaitlist = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.openWaitlist(e) : this.preOpenWaitlist = e
            }, this.closeWaitlist = () => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.closeWaitlist() : this.preOpenWaitlist = null
            }, this.openSignUp = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.openSignUp(e) : this.preopenSignUp = e
            }, this.closeSignUp = () => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.closeSignUp() : this.preopenSignUp = null
            }, this.mountSignIn = (e, t) => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.mountSignIn(e, t) : this.premountSignInNodes.set(e, t)
            }, this.unmountSignIn = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.unmountSignIn(e) : this.premountSignInNodes.delete(e)
            }, this.__experimental_mountPricingTable = (e, t) => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.__experimental_mountPricingTable(e, t) : this.premountPricingTableNodes.set(e, t)
            }, this.__experimental_unmountPricingTable = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.__experimental_unmountPricingTable(e) : this.premountPricingTableNodes.delete(e)
            }, this.mountSignUp = (e, t) => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.mountSignUp(e, t) : this.premountSignUpNodes.set(e, t)
            }, this.unmountSignUp = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.unmountSignUp(e) : this.premountSignUpNodes.delete(e)
            }, this.mountUserProfile = (e, t) => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.mountUserProfile(e, t) : this.premountUserProfileNodes.set(e, t)
            }, this.unmountUserProfile = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.unmountUserProfile(e) : this.premountUserProfileNodes.delete(e)
            }, this.mountOrganizationProfile = (e, t) => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.mountOrganizationProfile(e, t) : this.premountOrganizationProfileNodes.set(e, t)
            }, this.unmountOrganizationProfile = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.unmountOrganizationProfile(e) : this.premountOrganizationProfileNodes.delete(e)
            }, this.mountCreateOrganization = (e, t) => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.mountCreateOrganization(e, t) : this.premountCreateOrganizationNodes.set(e, t)
            }, this.unmountCreateOrganization = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.unmountCreateOrganization(e) : this.premountCreateOrganizationNodes.delete(e)
            }, this.mountOrganizationSwitcher = (e, t) => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.mountOrganizationSwitcher(e, t) : this.premountOrganizationSwitcherNodes.set(e, t)
            }, this.unmountOrganizationSwitcher = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.unmountOrganizationSwitcher(e) : this.premountOrganizationSwitcherNodes.delete(e)
            }, this.__experimental_prefetchOrganizationSwitcher = () => {
                const e = () => {
                    var e;
                    return null == (e = this.clerkjs) ? void 0 : e.__experimental_prefetchOrganizationSwitcher()
                };
                this.clerkjs && _y(this, Rv) ? e() : this.premountMethodCalls.set("__experimental_prefetchOrganizationSwitcher", e)
            }, this.mountOrganizationList = (e, t) => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.mountOrganizationList(e, t) : this.premountOrganizationListNodes.set(e, t)
            }, this.unmountOrganizationList = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.unmountOrganizationList(e) : this.premountOrganizationListNodes.delete(e)
            }, this.mountUserButton = (e, t) => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.mountUserButton(e, t) : this.premountUserButtonNodes.set(e, t)
            }, this.unmountUserButton = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.unmountUserButton(e) : this.premountUserButtonNodes.delete(e)
            }, this.mountWaitlist = (e, t) => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.mountWaitlist(e, t) : this.premountWaitlistNodes.set(e, t)
            }, this.unmountWaitlist = e => {
                this.clerkjs && _y(this, Rv) ? this.clerkjs.unmountWaitlist(e) : this.premountWaitlistNodes.delete(e)
            }, this.addListener = e => {
                if (this.clerkjs) return this.clerkjs.addListener(e); {
                    const t = () => {
                        var t;
                        const r = this.premountAddListenerCalls.get(e);
                        r && (null == (t = r.nativeUnsubscribe) || t.call(r), this.premountAddListenerCalls.delete(e))
                    };
                    return this.premountAddListenerCalls.set(e, {
                        unsubscribe: t,
                        nativeUnsubscribe: void 0
                    }), t
                }
            }, this.navigate = e => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.navigate(e)
                };
                this.clerkjs && _y(this, Rv) ? t() : this.premountMethodCalls.set("navigate", t)
            }, this.redirectWithAuth = async (...e) => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.redirectWithAuth(...e)
                };
                return this.clerkjs && _y(this, Rv) ? t() : void this.premountMethodCalls.set("redirectWithAuth", t)
            }, this.redirectToSignIn = async e => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.redirectToSignIn(e)
                };
                return this.clerkjs && _y(this, Rv) ? t() : void this.premountMethodCalls.set("redirectToSignIn", t)
            }, this.redirectToSignUp = async e => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.redirectToSignUp(e)
                };
                return this.clerkjs && _y(this, Rv) ? t() : void this.premountMethodCalls.set("redirectToSignUp", t)
            }, this.redirectToUserProfile = async () => {
                const e = () => {
                    var e;
                    return null == (e = this.clerkjs) ? void 0 : e.redirectToUserProfile()
                };
                return this.clerkjs && _y(this, Rv) ? e() : void this.premountMethodCalls.set("redirectToUserProfile", e)
            }, this.redirectToAfterSignUp = () => {
                const e = () => {
                    var e;
                    return null == (e = this.clerkjs) ? void 0 : e.redirectToAfterSignUp()
                };
                if (this.clerkjs && _y(this, Rv)) return e();
                this.premountMethodCalls.set("redirectToAfterSignUp", e)
            }, this.redirectToAfterSignIn = () => {
                const e = () => {
                    var e;
                    return null == (e = this.clerkjs) ? void 0 : e.redirectToAfterSignIn()
                };
                this.clerkjs && _y(this, Rv) ? e() : this.premountMethodCalls.set("redirectToAfterSignIn", e)
            }, this.redirectToAfterSignOut = () => {
                const e = () => {
                    var e;
                    return null == (e = this.clerkjs) ? void 0 : e.redirectToAfterSignOut()
                };
                this.clerkjs && _y(this, Rv) ? e() : this.premountMethodCalls.set("redirectToAfterSignOut", e)
            }, this.redirectToOrganizationProfile = async () => {
                const e = () => {
                    var e;
                    return null == (e = this.clerkjs) ? void 0 : e.redirectToOrganizationProfile()
                };
                return this.clerkjs && _y(this, Rv) ? e() : void this.premountMethodCalls.set("redirectToOrganizationProfile", e)
            }, this.redirectToCreateOrganization = async () => {
                const e = () => {
                    var e;
                    return null == (e = this.clerkjs) ? void 0 : e.redirectToCreateOrganization()
                };
                return this.clerkjs && _y(this, Rv) ? e() : void this.premountMethodCalls.set("redirectToCreateOrganization", e)
            }, this.redirectToWaitlist = async () => {
                const e = () => {
                    var e;
                    return null == (e = this.clerkjs) ? void 0 : e.redirectToWaitlist()
                };
                return this.clerkjs && _y(this, Rv) ? e() : void this.premountMethodCalls.set("redirectToWaitlist", e)
            }, this.handleRedirectCallback = async e => {
                var t;
                const r = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.handleRedirectCallback(e)
                };
                this.clerkjs && _y(this, Rv) ? null == (t = r()) || t.catch((() => {})) : this.premountMethodCalls.set("handleRedirectCallback", r)
            }, this.handleGoogleOneTapCallback = async (e, t) => {
                var r;
                const n = () => {
                    var r;
                    return null == (r = this.clerkjs) ? void 0 : r.handleGoogleOneTapCallback(e, t)
                };
                this.clerkjs && _y(this, Rv) ? null == (r = n()) || r.catch((() => {})) : this.premountMethodCalls.set("handleGoogleOneTapCallback", n)
            }, this.handleEmailLinkVerification = async e => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.handleEmailLinkVerification(e)
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("handleEmailLinkVerification", t)
            }, this.authenticateWithMetamask = async e => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.authenticateWithMetamask(e)
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("authenticateWithMetamask", t)
            }, this.authenticateWithCoinbaseWallet = async e => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.authenticateWithCoinbaseWallet(e)
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("authenticateWithCoinbaseWallet", t)
            }, this.authenticateWithOKXWallet = async e => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.authenticateWithOKXWallet(e)
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("authenticateWithOKXWallet", t)
            }, this.authenticateWithWeb3 = async e => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.authenticateWithWeb3(e)
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("authenticateWithWeb3", t)
            }, this.authenticateWithGoogleOneTap = async e => (await Cy(this, Dv, $v).call(this)).authenticateWithGoogleOneTap(e), this.createOrganization = async e => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.createOrganization(e)
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("createOrganization", t)
            }, this.getOrganization = async e => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.getOrganization(e)
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("getOrganization", t)
            }, this.joinWaitlist = async e => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.joinWaitlist(e)
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("joinWaitlist", t)
            }, this.signOut = async (...e) => {
                const t = () => {
                    var t;
                    return null == (t = this.clerkjs) ? void 0 : t.signOut(...e)
                };
                if (this.clerkjs && _y(this, Rv)) return t();
                this.premountMethodCalls.set("signOut", t)
            };
            const {
                Clerk: t = null,
                publishableKey: r
            } = e || {};
            Py(this, Mv, r), Py(this, Lv, null == e ? void 0 : e.proxyUrl), Py(this, Iv, null == e ? void 0 : e.domain), this.options = e, this.Clerk = t, this.mode = Gy() ? "browser" : "server", this.options.sdkMetadata || (this.options.sdkMetadata = Fv), _y(this, Mv) && this.loadClerkJS()
        }
        get publishableKey() {
            return _y(this, Mv)
        }
        get loaded() {
            return _y(this, Rv)
        }
        static getOrCreateInstance(t) {
            return (!Gy() || !_y(this, Uv) || t.Clerk && _y(this, Uv).Clerk !== t.Clerk || _y(this, Uv).publishableKey !== t.publishableKey) && Py(this, Uv, new e(t)), _y(this, Uv)
        }
        static clearInstance() {
            Py(this, Uv, null)
        }
        get domain() {
            return "undefined" != typeof window && window.location ? Wy(_y(this, Iv), new URL(window.location.href), "") : "function" == typeof _y(this, Iv) ? fy.throw(by) : _y(this, Iv) || ""
        }
        get proxyUrl() {
            return "undefined" != typeof window && window.location ? Wy(_y(this, Lv), new URL(window.location.href), "") : "function" == typeof _y(this, Lv) ? fy.throw(by) : _y(this, Lv) || ""
        }
        __internal_getOption(e) {
            var t;
            return null == (t = this.clerkjs) ? void 0 : t.__internal_getOption(e)
        }
        get sdkMetadata() {
            var e;
            return (null == (e = this.clerkjs) ? void 0 : e.sdkMetadata) || this.options.sdkMetadata || void 0
        }
        get instanceType() {
            var e;
            return null == (e = this.clerkjs) ? void 0 : e.instanceType
        }
        get frontendApi() {
            var e;
            return (null == (e = this.clerkjs) ? void 0 : e.frontendApi) || ""
        }
        get isStandardBrowser() {
            var e;
            return (null == (e = this.clerkjs) ? void 0 : e.isStandardBrowser) || this.options.standardBrowser || !1
        }
        get isSatellite() {
            return "undefined" != typeof window && window.location ? Wy(this.options.isSatellite, new URL(window.location.href), !1) : "function" == typeof this.options.isSatellite && fy.throw(by)
        }
        async loadClerkJS() {
            var e;
            if ("browser" === this.mode && !_y(this, Rv)) {
                "undefined" != typeof window && (window.__clerk_publishable_key = _y(this, Mv), window.__clerk_proxy_url = this.proxyUrl, window.__clerk_domain = this.domain);
                try {
                    if (this.Clerk) {
                        let e;
                        "function" == typeof this.Clerk ? (e = new this.Clerk(_y(this, Mv), {
                            proxyUrl: this.proxyUrl,
                            domain: this.domain
                        }), await e.load(this.options)) : (e = this.Clerk, e.loaded || await e.load(this.options)), global.Clerk = e
                    } else if (!__BUILD_DISABLE_RHC__) {
                        if (global.Clerk || await (async e => {
                                const t = document.querySelector("script[data-clerk-js-script]");
                                return t ? new Promise(((e, r) => {
                                    t.addEventListener("load", (() => {
                                        e(t)
                                    })), t.addEventListener("error", (() => {
                                        r(Dy)
                                    }))
                                })) : (null == e ? void 0 : e.publishableKey) ? Uy(Vy(e), {
                                    async: !0,
                                    crossOrigin: "anonymous",
                                    nonce: e.nonce,
                                    beforeLoad: By(e)
                                }).catch((() => {
                                    throw new Error(Dy)
                                })) : void Fy.throwMissingPublishableKeyError()
                            })({ ...this.options,
                                publishableKey: _y(this, Mv),
                                proxyUrl: this.proxyUrl,
                                domain: this.domain,
                                nonce: this.options.nonce
                            }), !global.Clerk) throw new Error("Failed to download latest ClerkJS. Contact support@clerk.com.");
                        await global.Clerk.load(this.options)
                    }
                    return (null == (e = global.Clerk) ? void 0 : e.loaded) ? this.hydrateClerkJS(global.Clerk) : void 0
                } catch (Iw) {
                    const t = Iw;
                    return void console.error(t.stack || t.message || t)
                }
            }
        }
        get version() {
            var e;
            return null == (e = this.clerkjs) ? void 0 : e.version
        }
        get client() {
            return this.clerkjs ? this.clerkjs.client : void 0
        }
        get session() {
            return this.clerkjs ? this.clerkjs.session : void 0
        }
        get user() {
            return this.clerkjs ? this.clerkjs.user : void 0
        }
        get organization() {
            return this.clerkjs ? this.clerkjs.organization : void 0
        }
        get telemetry() {
            return this.clerkjs ? this.clerkjs.telemetry : void 0
        }
        get __unstable__environment() {
            return this.clerkjs ? this.clerkjs.__unstable__environment : void 0
        }
        get isSignedIn() {
            return !!this.clerkjs && this.clerkjs.isSignedIn
        }
        get __experimental_commerce() {
            var e;
            return null == (e = this.clerkjs) ? void 0 : e.__experimental_commerce
        }
        __unstable__setEnvironment(...e) {
            this.clerkjs && "__unstable__setEnvironment" in this.clerkjs && this.clerkjs.__unstable__setEnvironment(e)
        }
    };
Rv = new WeakMap, Iv = new WeakMap, Lv = new WeakMap, Mv = new WeakMap, Uv = new WeakMap, Dv = new WeakSet, $v = function() {
    return new Promise((e => {
        this.addOnLoaded((() => e(this.clerkjs)))
    }))
}, Ey(Vv, Uv);
var Bv = Vv;

function zv(e) {
    const {
        isomorphicClerkOptions: t,
        initialState: r,
        children: n
    } = e, {
        isomorphicClerk: s,
        loaded: i
    } = Wv(t), [o, a] = p.useState({
        client: s.client,
        session: s.session,
        user: s.user,
        organization: s.organization
    });
    p.useEffect((() => s.addListener((e => a({ ...e
    })))), []);
    const l = ((e, t, r) => !e && r ? qy(r) : Ky(t))(i, o, r),
        c = p.useMemo((() => ({
            value: s
        })), [i]),
        u = p.useMemo((() => ({
            value: o.client
        })), [o.client]),
        {
            sessionId: d,
            sessionStatus: h,
            session: f,
            userId: m,
            user: g,
            orgId: y,
            actor: v,
            organization: b,
            orgRole: x,
            orgSlug: w,
            orgPermissions: k,
            factorVerificationAge: j
        } = l,
        S = p.useMemo((() => ({
            value: {
                sessionId: d,
                sessionStatus: h,
                userId: m,
                actor: v,
                orgId: y,
                orgRole: x,
                orgSlug: w,
                orgPermissions: k,
                factorVerificationAge: j
            }
        })), [d, h, m, v, y, x, w, j]),
        T = p.useMemo((() => ({
            value: f
        })), [d, f]),
        _ = p.useMemo((() => ({
            value: g
        })), [m, g]),
        E = p.useMemo((() => ({
            value: {
                organization: b
            }
        })), [y, b]);
    return p.createElement(yy.Provider, {
        value: c
    }, p.createElement(sy.Provider, {
        value: u
    }, p.createElement(oy.Provider, {
        value: T
    }, p.createElement(uy, { ...E.value
    }, p.createElement(my.Provider, {
        value: S
    }, p.createElement(ry.Provider, {
        value: _
    }, n))))))
}
var Wv = e => {
    const [t, r] = p.useState(!1), n = p.useMemo((() => Bv.getOrCreateInstance(e)), []);
    return p.useEffect((() => {
        n.__unstable__updateProps({
            appearance: e.appearance
        })
    }), [e.appearance]), p.useEffect((() => {
        n.__unstable__updateProps({
            options: e
        })
    }), [e.localization]), p.useEffect((() => {
        n.addOnLoaded((() => r(!0)))
    }), []), p.useEffect((() => () => {
        Bv.clearInstance(), r(!1)
    }), []), {
        isomorphicClerk: n,
        loaded: t
    }
};
var Hv, qv = function(e, t, r) {
    const n = e.displayName || e.name || t || "Component",
        s = n => (function(e, t, r = 1) {
            p.useEffect((() => {
                const n = Zy.get(e) || 0;
                return n == r ? fy.throw(t) : (Zy.set(e, n + 1), () => {
                    Zy.set(e, (Zy.get(e) || 1) - 1)
                })
            }), [])
        }(t, r), p.createElement(e, { ...n
        }));
    return s.displayName = `withMaxAllowedInstancesGuard(${n})`, s
}((function(e) {
    const {
        initialState: t,
        children: r,
        __internal_bypassMissingPublishableKey: n,
        ...s
    } = e, {
        publishableKey: i = "",
        Clerk: o
    } = s;
    return o || n || (i ? i && !xm(i) && fy.throwInvalidPublishableKeyError({
        key: i
    }) : fy.throwMissingPublishableKeyError()), p.createElement(zv, {
        initialState: t,
        isomorphicClerkOptions: s
    }, r)
}), "ClerkProvider", "You've added multiple <ClerkProvider> components in your React component tree. Wrap your components in a single <ClerkProvider>.");
qv.displayName = "ClerkProvider",
    function(e) {
        fy.setMessages(e).setPackageName(e)
    }({
        packageName: "@clerk/clerk-react"
    }), Hv = "@clerk/clerk-react", Fy.setPackageName({
        packageName: Hv
    });
const Kv = ({
        onClose: e,
        isAuth: t,
        onSignIn: r,
        onSignOut: n
    }) => {
        const [s, i] = o.useState(null), a = e => {
            i(s === e ? null : e)
        };
        return T.jsx(Pa.div, {
            className: "fixed inset-0 z-40 bg-white pt-20 px-4 overflow-y-auto md:hidden",
            variants: {
                closed: {
                    opacity: 0,
                    y: -20
                },
                open: {
                    opacity: 1,
                    y: 0,
                    transition: {
                        duration: .3
                    }
                }
            },
            initial: "closed",
            animate: "open",
            exit: "closed",
            children: T.jsxs("nav", {
                className: "flex flex-col space-y-4 py-6",
                children: [T.jsxs("div", {
                    className: "border-b pb-4",
                    children: [T.jsxs("div", {
                        className: "flex items-center justify-between py-2",
                        onClick: () => a("work-mobile"),
                        children: [T.jsx("span", {
                            className: "text-lg font-medium",
                            children: "Our Work"
                        }), T.jsx(ph, {
                            className: "h-5 w-5 transition-transform " + ("work-mobile" === s ? "rotate-180" : "")
                        })]
                    }), T.jsx(z, {
                        children: "work-mobile" === s && T.jsx(Pa.div, {
                            initial: {
                                height: 0,
                                opacity: 0
                            },
                            animate: {
                                height: "auto",
                                opacity: 1
                            },
                            exit: {
                                height: 0,
                                opacity: 0
                            },
                            transition: {
                                duration: .3
                            },
                            className: "overflow-hidden",
                            children: T.jsxs("div", {
                                className: "py-2 pl-4 space-y-2",
                                children: [T.jsx(c, {
                                    to: "/work/research-development",
                                    className: "block py-2 text-gray-700 hover:text-black",
                                    onClick: e,
                                    children: "Research & Development"
                                }), T.jsx(c, {
                                    to: "/work/billionaire-fund",
                                    className: "block py-2 text-gray-700 hover:text-black",
                                    onClick: e,
                                    children: "Billionaire Fund"
                                }), T.jsx(c, {
                                    to: "/work/education-stem",
                                    className: "block py-2 text-gray-700 hover:text-black",
                                    onClick: e,
                                    children: "Education & STEM"
                                })]
                            })
                        })
                    })]
                }), T.jsxs("div", {
                    className: "border-b pb-4",
                    children: [T.jsxs("div", {
                        className: "flex items-center justify-between py-2",
                        onClick: () => a("about-mobile"),
                        children: [T.jsx("span", {
                            className: "text-lg font-medium",
                            children: "About"
                        }), T.jsx(ph, {
                            className: "h-5 w-5 transition-transform " + ("about-mobile" === s ? "rotate-180" : "")
                        })]
                    }), T.jsx(z, {
                        children: "about-mobile" === s && T.jsx(Pa.div, {
                            initial: {
                                height: 0,
                                opacity: 0
                            },
                            animate: {
                                height: "auto",
                                opacity: 1
                            },
                            exit: {
                                height: 0,
                                opacity: 0
                            },
                            transition: {
                                duration: .3
                            },
                            className: "overflow-hidden",
                            children: T.jsxs("div", {
                                className: "py-2 pl-4 space-y-2",
                                children: [T.jsx(c, {
                                    to: "/about/vision-mission",
                                    className: "block py-2 text-gray-700 hover:text-black",
                                    onClick: e,
                                    children: "Vision & Mission"
                                }), T.jsx(c, {
                                    to: "/about/governance",
                                    className: "block py-2 text-gray-700 hover:text-black",
                                    onClick: e,
                                    children: "Governance, Leadership & Transparency"
                                }), T.jsx(c, {
                                    to: "/about/timeline",
                                    className: "block py-2 text-gray-700 hover:text-black",
                                    onClick: e,
                                    children: "History & Timeline"
                                })]
                            })
                        })
                    })]
                }), T.jsx(c, {
                    to: "/news",
                    className: "block py-2 text-lg font-medium border-b pb-4",
                    onClick: e,
                    children: "News"
                }), T.jsx(c, {
                    to: "/contact",
                    className: "block py-2 text-lg font-medium border-b pb-4",
                    onClick: e,
                    children: "Contact"
                }), T.jsxs("div", {
                    className: "pt-4 mt-4 border-t flex flex-col space-y-4",
                    children: [T.jsx("div", {
                        className: "flex items-center justify-center",
                        children: T.jsx(ky, {
                            children: T.jsxs("div", {
                                className: "flex flex-col items-center gap-2",
                                children: [T.jsx(_v, {
                                    afterSignOutUrl: "/",
                                    appearance: {
                                        elements: {
                                            userButtonAvatarBox: "h-14 w-14",
                                            userButtonBox: "w-full flex justify-center"
                                        }
                                    }
                                }), T.jsx("span", {
                                    className: "text-sm text-gray-600",
                                    children: "Manage account"
                                })]
                            })
                        })
                    }), T.jsx(jy, {
                        children: T.jsx(Nv, {
                            mode: "modal",
                            children: T.jsxs("button", {
                                className: "signin-button w-full justify-center py-2",
                                children: [T.jsx(Eh, {
                                    className: "h-4 w-4 mr-2"
                                }), "Sign in to your account"]
                            })
                        })
                    }), T.jsx(ky, {
                        children: T.jsxs("div", {
                            className: "flex flex-col space-y-3 pt-2 border-t border-gray-100",
                            children: [T.jsxs(c, {
                                to: "/profile",
                                onClick: e,
                                className: "flex items-center px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-md",
                                children: [T.jsx(gh, {
                                    className: "h-5 w-5 mr-2"
                                }), T.jsx("span", {
                                    children: "Profile"
                                })]
                            }), T.jsxs(c, {
                                to: "/dashboard",
                                onClick: e,
                                className: "flex items-center px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-md",
                                children: [T.jsx(jh, {
                                    className: "h-5 w-5 mr-2"
                                }), T.jsx("span", {
                                    children: "Dashboard"
                                })]
                            })]
                        })
                    }), T.jsx(c, {
                        to: "/get-involved/donate",
                        onClick: e,
                        children: T.jsx("button", {
                            className: "donate-button-mobile",
                            children: "Donate"
                        })
                    }), t && T.jsx(ih, {
                        onClick: n,
                        variant: "outline",
                        className: "w-full justify-center border-gray-300 text-gray-700 hover:bg-gray-50",
                        children: "Sign Out from Other Services"
                    })]
                })]
            })
        })
    },
    Gv = () => {
        const [e, t] = o.useState(!1), [r, n] = o.useState(!1), [s, i] = o.useState(null), {
            user: a,
            signOut: l
        } = Zu(), u = f(), d = m();
        o.useEffect((() => {
            const e = () => {
                t(window.scrollY > 10)
            };
            return window.addEventListener("scroll", e), () => window.removeEventListener("scroll", e)
        }), []), o.useEffect((() => {
            n(!1), i(null)
        }), [u.pathname]);
        const h = e => {
                i(s === e ? null : e)
            },
            p = () => {
                i(null)
            },
            g = {
                hidden: {
                    opacity: 0,
                    y: -20
                },
                visible: {
                    opacity: 1,
                    y: 0,
                    transition: {
                        duration: .3
                    }
                }
            };
        return T.jsxs(T.Fragment, {
            children: [T.jsx(Pa.header, {
                className: `fixed top-0 left-0 right-0 z-50 ${e?"bg-white border-b border-gray-200 shadow-sm":"bg-white"} transition-all duration-300`,
                variants: {
                    initial: {
                        y: -100
                    },
                    animate: {
                        y: 0,
                        transition: {
                            type: "spring",
                            stiffness: 100,
                            damping: 20
                        }
                    }
                },
                initial: "initial",
                animate: "animate",
                children: T.jsx("div", {
                    className: "container mx-auto px-4",
                    children: T.jsxs("div", {
                        className: "flex items-center justify-between h-20",
                        children: [T.jsx(c, {
                            to: "/",
                            className: "flex items-center",
                            children: T.jsx(Pa.div, {
                                whileHover: {
                                    scale: 1.05
                                },
                                whileTap: {
                                    scale: .95
                                },
                                className: "text-2xl font-bold text-black",
                                children: "Nynexa Foundation"
                            })
                        }), T.jsxs("nav", {
                            className: "hidden md:flex items-center space-x-1",
                            children: [T.jsxs("div", {
                                className: "relative px-2 py-2 cursor-pointer",
                                onMouseEnter: () => h("work"),
                                onMouseLeave: () => p(),
                                children: [T.jsxs("div", {
                                    className: "flex items-center text-gray-800 hover:text-black transition-colors font-medium",
                                    children: [T.jsx("span", {
                                        children: "Our Work"
                                    }), T.jsx(ph, {
                                        className: "ml-1 h-4 w-4 transition-transform " + ("work" === s ? "rotate-180" : "")
                                    })]
                                }), T.jsx(z, {
                                    children: "work" === s && T.jsx(Pa.div, {
                                        className: "absolute left-0 mt-2 w-screen max-w-4xl bg-white shadow-xl border border-gray-200",
                                        style: {
                                            left: "-150px"
                                        },
                                        variants: g,
                                        initial: "hidden",
                                        animate: "visible",
                                        exit: "hidden",
                                        children: T.jsx(Lh, {
                                            type: "work",
                                            onClose: () => i(null)
                                        })
                                    })
                                })]
                            }), T.jsxs("div", {
                                className: "relative px-2 py-2 cursor-pointer",
                                onMouseEnter: () => h("about"),
                                onMouseLeave: () => p(),
                                children: [T.jsxs("div", {
                                    className: "flex items-center text-gray-800 hover:text-black transition-colors font-medium",
                                    children: [T.jsx("span", {
                                        children: "About"
                                    }), T.jsx(ph, {
                                        className: "ml-1 h-4 w-4 transition-transform " + ("about" === s ? "rotate-180" : "")
                                    })]
                                }), T.jsx(z, {
                                    children: "about" === s && T.jsx(Pa.div, {
                                        className: "absolute left-0 mt-2 w-screen max-w-4xl bg-white shadow-xl border border-gray-200",
                                        style: {
                                            left: "-300px"
                                        },
                                        variants: g,
                                        initial: "hidden",
                                        animate: "visible",
                                        exit: "hidden",
                                        children: T.jsx(Lh, {
                                            type: "about",
                                            onClose: () => i(null)
                                        })
                                    })
                                })]
                            }), T.jsx(c, {
                                to: "/news",
                                className: "px-2 py-2 text-gray-800 hover:text-black transition-colors font-medium",
                                children: "News"
                            }), T.jsx(c, {
                                to: "/contact",
                                className: "px-2 py-2 text-gray-800 hover:text-black transition-colors font-medium",
                                children: "Contact"
                            })]
                        }), T.jsxs("div", {
                            className: "flex items-center space-x-2",
                            children: [T.jsxs(rm, {
                                children: [T.jsx(nm, {
                                    asChild: !0,
                                    children: T.jsx(ih, {
                                        variant: "ghost",
                                        size: "icon",
                                        className: "text-gray-600 hover:text-black hover:bg-gray-100",
                                        "aria-label": "Search",
                                        children: T.jsx(Oh, {
                                            className: "h-5 w-5"
                                        })
                                    })
                                }), T.jsxs(om, {
                                    className: "sm:max-w-[425px]",
                                    children: [T.jsxs(am, {
                                        children: [T.jsx(lm, {
                                            children: "Search our website"
                                        }), T.jsx(cm, {
                                            children: "Find information about our programs, initiatives, and more."
                                        })]
                                    }), T.jsx("div", {
                                        className: "grid gap-4 py-4",
                                        children: T.jsxs("div", {
                                            className: "relative",
                                            children: [T.jsx(Oh, {
                                                className: "absolute left-2 top-3 h-4 w-4 text-gray-500"
                                            }), T.jsx("input", {
                                                className: "flex h-10 w-full rounded-md border border-input bg-background px-9 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",
                                                placeholder: "Search..."
                                            })]
                                        })
                                    })]
                                })]
                            }), T.jsxs("div", {
                                className: "hidden md:flex items-center",
                                children: [T.jsx(ky, {
                                    children: T.jsx(_v, {
                                        afterSignOutUrl: "/",
                                        appearance: {
                                            elements: {
                                                userButtonAvatarBox: "h-10 w-10",
                                                userButtonBox: "h-10 w-10",
                                                userButtonOuterIdentifier: "hidden",
                                                userButtonTrigger: "ring-offset-background ring-black focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                                            }
                                        }
                                    })
                                }), T.jsx(jy, {
                                    children: T.jsx(Nv, {
                                        mode: "modal",
                                        children: T.jsxs("button", {
                                            className: "signin-button mr-2",
                                            children: [T.jsx(Eh, {
                                                className: "h-4 w-4 mr-1"
                                            }), "Sign in"]
                                        })
                                    })
                                })]
                            }), T.jsx("div", {
                                className: "hidden md:block",
                                children: T.jsx(c, {
                                    to: "/get-involved/donate",
                                    children: T.jsx("button", {
                                        className: "donate-button",
                                        children: "Donate"
                                    })
                                })
                            })]
                        }), T.jsx("div", {
                            className: "md:hidden flex items-center",
                            children: T.jsx(ih, {
                                variant: "ghost",
                                size: "icon",
                                onClick: () => {
                                    n(!r)
                                },
                                "aria-label": "Toggle menu",
                                className: "text-black hover:bg-gray-100",
                                children: r ? T.jsx(Rh, {
                                    className: "h-6 w-6"
                                }) : T.jsx(Ch, {
                                    className: "h-6 w-6"
                                })
                            })
                        })]
                    })
                })
            }), T.jsx(z, {
                children: r && T.jsx(Kv, {
                    onClose: () => n(!1),
                    isAuth: !!a,
                    onSignIn: () => d("/auth/login"),
                    onSignOut: async () => {
                        await l(), d("/")
                    }
                })
            }), T.jsx("div", {
                className: "h-20"
            })]
        })
    },
    Yv = o.forwardRef((({
        className: e,
        type: t,
        ...r
    }, n) => T.jsx("input", {
        type: t,
        className: nh("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", e),
        ref: n,
        ...r
    })));
Yv.displayName = "Input";
const Jv = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
    Xv = /^https?:\/\/([^\/]+)[^\?]+\??(.+)$/,
    Zv = async e => {
        if (!(e => Jv.test(String(e).toLowerCase()))(e)) return {
            success: !1,
            message: "Please provide a valid email address"
        };
        try {
            const [t, r] = (e => {
                const [, t, r] = e.replace("&amp;", "&").match(Xv) ? ? [null, null, null];
                return [t, new URLSearchParams(r)]
            })("https://nynexafoundation.us21.list-manage.com/subscribe/post?u=1487cc549a49109c00fe60a80&id=93cd7be172");
            if (!t || !r) throw new Error("Invalid Mailchimp URL configuration");
            r.set("MERGE0", e), r.set("b_1487cc549a49109c00fe60a80_93cd7be172", "");
            await fetch(`https://${t}/subscribe/post`, {
                method: "POST",
                mode: "no-cors",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
                },
                body: r.toString()
            });
            return {
                success: !0,
                message: "Thank you for subscribing to our newsletter!"
            }
        } catch (t) {
            return console.error("Mailchimp subscription error:", t), {
                success: !1,
                message: "There was a problem subscribing you to the newsletter. Please try again."
            }
        }
    },
    Qv = () => {
        const [e, t] = o.useState(""), [r, n] = o.useState(!1), [s, i] = o.useState(!1), {
            toast: a
        } = Yu(), l = {
            hidden: {
                opacity: 0,
                y: 50
            },
            visible: {
                opacity: 1,
                y: 0,
                transition: {
                    duration: .6,
                    staggerChildren: .1
                }
            }
        }, u = {
            hidden: {
                opacity: 0,
                y: 20
            },
            visible: {
                opacity: 1,
                y: 0,
                transition: {
                    duration: .5
                }
            }
        }, d = {
            hover: {
                scale: 1.2,
                rotate: 5,
                transition: {
                    duration: .2
                }
            }
        };
        return T.jsx("footer", {
            className: "bg-gray-900 text-white pt-16 pb-8",
            children: T.jsxs("div", {
                className: "container mx-auto px-4",
                children: [T.jsxs(Pa.div, {
                    initial: "hidden",
                    whileInView: "visible",
                    viewport: {
                        once: !0
                    },
                    variants: l,
                    className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12",
                    children: [T.jsxs(Pa.div, {
                        variants: u,
                        className: "space-y-4",
                        children: [T.jsx("h3", {
                            className: "text-lg font-semibold",
                            children: "About Nynexa"
                        }), T.jsx("p", {
                            className: "text-gray-400",
                            children: "The Nynexa Foundation is dedicated to advancing humanity through groundbreaking research, education, and strategic philanthropy."
                        }), T.jsxs("div", {
                            className: "flex space-x-4",
                            children: [T.jsx(Pa.a, {
                                href: "https://facebook.com",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                variants: d,
                                whileHover: "hover",
                                className: "text-gray-400 hover:text-white transition-colors",
                                children: T.jsx(vh, {
                                    size: 20
                                })
                            }), T.jsx(Pa.a, {
                                href: "https://twitter.com",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                variants: d,
                                whileHover: "hover",
                                className: "text-gray-400 hover:text-white transition-colors",
                                children: T.jsx(Nh, {
                                    size: 20
                                })
                            }), T.jsx(Pa.a, {
                                href: "https://linkedin.com",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                variants: d,
                                whileHover: "hover",
                                className: "text-gray-400 hover:text-white transition-colors",
                                children: T.jsx(Th, {
                                    size: 20
                                })
                            }), T.jsx(Pa.a, {
                                href: "https://instagram.com",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                variants: d,
                                whileHover: "hover",
                                className: "text-gray-400 hover:text-white transition-colors",
                                children: T.jsx(wh, {
                                    size: 20
                                })
                            }), T.jsx(Pa.a, {
                                href: "https://youtube.com",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                variants: d,
                                whileHover: "hover",
                                className: "text-gray-400 hover:text-white transition-colors",
                                children: T.jsx(Ih, {
                                    size: 20
                                })
                            })]
                        })]
                    }), T.jsxs(Pa.div, {
                        variants: u,
                        className: "space-y-4",
                        children: [T.jsx("h3", {
                            className: "text-lg font-semibold",
                            children: "Quick Links"
                        }), T.jsxs("ul", {
                            className: "space-y-2",
                            children: [T.jsx("li", {
                                children: T.jsx(c, {
                                    to: "/about",
                                    className: "text-gray-400 hover:text-white transition-colors",
                                    children: "About Us"
                                })
                            }), T.jsx("li", {
                                children: T.jsx(c, {
                                    to: "/work/research-development",
                                    className: "text-gray-400 hover:text-white transition-colors",
                                    children: "Research & Development"
                                })
                            }), T.jsx("li", {
                                children: T.jsx(c, {
                                    to: "/work/billionaire-fund",
                                    className: "text-gray-400 hover:text-white transition-colors",
                                    children: "Billionaire Fund"
                                })
                            }), T.jsx("li", {
                                children: T.jsx(c, {
                                    to: "/work/education-stem",
                                    className: "text-gray-400 hover:text-white transition-colors",
                                    children: "Education & STEM"
                                })
                            }), T.jsx("li", {
                                children: T.jsx(c, {
                                    to: "/news",
                                    className: "text-gray-400 hover:text-white transition-colors",
                                    children: "News & Updates"
                                })
                            })]
                        })]
                    }), T.jsxs(Pa.div, {
                        variants: u,
                        className: "space-y-4",
                        children: [T.jsx("h3", {
                            className: "text-lg font-semibold",
                            children: "Get Involved"
                        }), T.jsxs("ul", {
                            className: "space-y-2",
                            children: [T.jsx("li", {
                                children: T.jsx(c, {
                                    to: "/get-involved/donate",
                                    className: "text-gray-400 hover:text-white transition-colors",
                                    children: "Make a Donation"
                                })
                            }), T.jsx("li", {
                                children: T.jsx(c, {
                                    to: "/get-involved/partners",
                                    className: "text-gray-400 hover:text-white transition-colors",
                                    children: "Partnerships"
                                })
                            }), T.jsx("li", {
                                children: T.jsx(c, {
                                    to: "/get-involved/donate",
                                    className: "text-gray-400 hover:text-white transition-colors",
                                    children: "Volunteer"
                                })
                            }), T.jsx("li", {
                                children: T.jsx(c, {
                                    to: "/get-involved/careers",
                                    className: "text-gray-400 hover:text-white transition-colors",
                                    children: "Careers"
                                })
                            }), T.jsx("li", {
                                children: T.jsx(c, {
                                    to: "/contact",
                                    className: "text-gray-400 hover:text-white transition-colors",
                                    children: "Contact Us"
                                })
                            })]
                        })]
                    }), T.jsxs(Pa.div, {
                        variants: u,
                        className: "space-y-4",
                        children: [T.jsx("h3", {
                            className: "text-lg font-semibold",
                            children: "Newsletter"
                        }), T.jsx("p", {
                            className: "text-gray-400",
                            children: "Subscribe to our newsletter for the latest updates on our work and impact."
                        }), s ? T.jsxs("div", {
                            className: "flex items-center space-x-2 text-white p-4 bg-gray-800 rounded-lg",
                            children: [T.jsx(mh, {
                                className: "h-5 w-5 text-green-500"
                            }), T.jsx("p", {
                                className: "text-sm",
                                children: "Thank you for subscribing!"
                            })]
                        }) : T.jsxs("form", {
                            onSubmit: async r => {
                                if (r.preventDefault(), e) {
                                    n(!0);
                                    try {
                                        const r = await Zv(e);
                                        if (!r.success) throw new Error(r.message);
                                        i(!0), a({
                                            title: "Subscription successful!",
                                            description: r.message
                                        }), t("")
                                    } catch (s) {
                                        a({
                                            title: "Subscription failed",
                                            description: s.message || "There was an error subscribing to the newsletter.",
                                            variant: "destructive"
                                        })
                                    } finally {
                                        n(!1)
                                    }
                                }
                            },
                            className: "space-y-2",
                            children: [T.jsxs("div", {
                                className: "flex",
                                children: [T.jsxs("div", {
                                    className: "relative flex-grow",
                                    children: [T.jsx(Ph, {
                                        className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                                    }), T.jsx(Yv, {
                                        type: "email",
                                        placeholder: "Your email address",
                                        className: "pl-10 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500 w-full",
                                        value: e,
                                        onChange: e => t(e.target.value),
                                        required: !0
                                    }), T.jsx("input", {
                                        type: "text",
                                        tabIndex: -1,
                                        name: "b_1487cc549a49109c00fe60a80_93cd7be172",
                                        style: {
                                            position: "absolute",
                                            left: "-5000px"
                                        },
                                        "aria-hidden": "true"
                                    })]
                                }), T.jsx(ih, {
                                    type: "submit",
                                    className: "ml-2 bg-black hover:bg-black-800",
                                    disabled: r,
                                    children: r ? T.jsx(_h, {
                                        className: "h-4 w-4 animate-spin"
                                    }) : "Subscribe"
                                })]
                            }), T.jsxs("p", {
                                className: "text-xs text-gray-500",
                                children: ["By subscribing, you agree to our", " ", T.jsx(c, {
                                    to: "/privacy-policy",
                                    className: "text-black hover:text-black-600",
                                    children: "Privacy Policy"
                                }), "."]
                            })]
                        })]
                    })]
                }), T.jsxs(Pa.div, {
                    initial: "hidden",
                    whileInView: "visible",
                    viewport: {
                        once: !0
                    },
                    variants: l,
                    className: "border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center",
                    children: [T.jsxs("p", {
                        className: "text-gray-400 text-sm mb-4 md:mb-0",
                        children: ["© ", (new Date).getFullYear(), " Nynexa Foundation. All rights reserved."]
                    }), T.jsxs("div", {
                        className: "flex space-x-4 text-sm text-gray-400",
                        children: [T.jsx(c, {
                            to: "/privacy-policy",
                            className: "hover:text-white transition-colors",
                            children: "Privacy Policy"
                        }), T.jsx("span", {
                            className: "text-gray-600",
                            children: "|"
                        }), T.jsx(c, {
                            to: "/terms-of-use",
                            className: "hover:text-white transition-colors",
                            children: "Terms of Use"
                        }), T.jsx("span", {
                            className: "text-gray-600",
                            children: "|"
                        }), T.jsx(c, {
                            to: "/cookie-policy",
                            className: "hover:text-white transition-colors",
                            children: "Cookie Policy"
                        })]
                    })]
                })]
            })
        })
    };
var eb = o.forwardRef(((e, t) => T.jsx(Hh.span, { ...e,
    ref: t,
    style: {
        position: "absolute",
        border: 0,
        width: 1,
        height: 1,
        padding: 0,
        margin: -1,
        overflow: "hidden",
        clip: "rect(0, 0, 0, 0)",
        whiteSpace: "nowrap",
        wordWrap: "normal",
        ...e.style
    }
})));
eb.displayName = "VisuallyHidden";
var tb = "ToastProvider",
    [rb, nb, sb] = function(e) {
        const t = e + "CollectionProvider",
            [r, n] = Uh(t),
            [s, i] = r(t, {
                collectionRef: {
                    current: null
                },
                itemMap: new Map
            }),
            o = e => {
                const {
                    scope: t,
                    children: r
                } = e, n = p.useRef(null), i = p.useRef(new Map).current;
                return T.jsx(s, {
                    scope: t,
                    itemMap: i,
                    collectionRef: n,
                    children: r
                })
            };
        o.displayName = t;
        const a = e + "CollectionSlot",
            l = p.forwardRef(((e, t) => {
                const {
                    scope: r,
                    children: n
                } = e, s = ed(t, i(a, r).collectionRef);
                return T.jsx(td, {
                    ref: s,
                    children: n
                })
            }));
        l.displayName = a;
        const c = e + "CollectionItemSlot",
            u = "data-radix-collection-item",
            d = p.forwardRef(((e, t) => {
                const {
                    scope: r,
                    children: n,
                    ...s
                } = e, o = p.useRef(null), a = ed(t, o), l = i(c, r);
                return p.useEffect((() => (l.itemMap.set(o, {
                    ref: o,
                    ...s
                }), () => {
                    l.itemMap.delete(o)
                }))), T.jsx(td, {
                    [u]: "",
                    ref: a,
                    children: n
                })
            }));
        return d.displayName = c, [{
            Provider: o,
            Slot: l,
            ItemSlot: d
        }, function(t) {
            const r = i(e + "CollectionConsumer", t);
            return p.useCallback((() => {
                const e = r.collectionRef.current;
                if (!e) return [];
                const t = Array.from(e.querySelectorAll(`[${u}]`));
                return Array.from(r.itemMap.values()).sort(((e, r) => t.indexOf(e.ref.current) - t.indexOf(r.ref.current)))
            }), [r.collectionRef, r.itemMap])
        }, n]
    }("Toast"),
    [ib, ob] = Uh("Toast", [sb]),
    [ab, lb] = ib(tb),
    cb = e => {
        const {
            __scopeToast: t,
            label: r = "Notification",
            duration: n = 5e3,
            swipeDirection: s = "right",
            swipeThreshold: i = 50,
            children: a
        } = e, [l, c] = o.useState(null), [u, d] = o.useState(0), h = o.useRef(!1), p = o.useRef(!1);
        return r.trim() || console.error(`Invalid prop \`label\` supplied to \`${tb}\`. Expected non-empty \`string\`.`), T.jsx(rb.Provider, {
            scope: t,
            children: T.jsx(ab, {
                scope: t,
                label: r,
                duration: n,
                swipeDirection: s,
                swipeThreshold: i,
                toastCount: u,
                viewport: l,
                onViewportChange: c,
                onToastAdd: o.useCallback((() => d((e => e + 1))), []),
                onToastRemove: o.useCallback((() => d((e => e - 1))), []),
                isFocusedToastEscapeKeyDownRef: h,
                isClosePausedRef: p,
                children: a
            })
        })
    };
cb.displayName = tb;
var ub = "ToastViewport",
    db = ["F8"],
    hb = "toast.viewportPause",
    pb = "toast.viewportResume",
    fb = o.forwardRef(((e, t) => {
        const {
            __scopeToast: r,
            hotkey: n = db,
            label: s = "Notifications ({hotkey})",
            ...i
        } = e, a = lb(ub, r), l = nb(r), c = o.useRef(null), u = o.useRef(null), d = o.useRef(null), h = o.useRef(null), p = ed(t, h, a.onViewportChange), f = n.join("+").replace(/Key/g, "").replace(/Digit/g, ""), m = a.toastCount > 0;
        o.useEffect((() => {
            const e = e => {
                var t;
                n.every((t => e[t] || e.code === t)) && (null == (t = h.current) || t.focus())
            };
            return document.addEventListener("keydown", e), () => document.removeEventListener("keydown", e)
        }), [n]), o.useEffect((() => {
            const e = c.current,
                t = h.current;
            if (m && e && t) {
                const r = () => {
                        if (!a.isClosePausedRef.current) {
                            const e = new CustomEvent(hb);
                            t.dispatchEvent(e), a.isClosePausedRef.current = !0
                        }
                    },
                    n = () => {
                        if (a.isClosePausedRef.current) {
                            const e = new CustomEvent(pb);
                            t.dispatchEvent(e), a.isClosePausedRef.current = !1
                        }
                    },
                    s = t => {
                        !e.contains(t.relatedTarget) && n()
                    },
                    i = () => {
                        e.contains(document.activeElement) || n()
                    };
                return e.addEventListener("focusin", r), e.addEventListener("focusout", s), e.addEventListener("pointermove", r), e.addEventListener("pointerleave", i), window.addEventListener("blur", r), window.addEventListener("focus", n), () => {
                    e.removeEventListener("focusin", r), e.removeEventListener("focusout", s), e.removeEventListener("pointermove", r), e.removeEventListener("pointerleave", i), window.removeEventListener("blur", r), window.removeEventListener("focus", n)
                }
            }
        }), [m, a.isClosePausedRef]);
        const g = o.useCallback((({
            tabbingDirection: e
        }) => {
            const t = l().map((t => {
                const r = t.ref.current,
                    n = [r, ...Rb(r)];
                return "forwards" === e ? n : n.reverse()
            }));
            return ("forwards" === e ? t.reverse() : t).flat()
        }), [l]);
        return o.useEffect((() => {
            const e = h.current;
            if (e) {
                const t = t => {
                    var r, n, s;
                    const i = t.altKey || t.ctrlKey || t.metaKey;
                    if ("Tab" === t.key && !i) {
                        const i = document.activeElement,
                            o = t.shiftKey;
                        if (t.target === e && o) return void(null == (r = u.current) || r.focus());
                        const a = g({
                                tabbingDirection: o ? "backwards" : "forwards"
                            }),
                            l = a.findIndex((e => e === i));
                        Ib(a.slice(l + 1)) ? t.preventDefault() : o ? null == (n = u.current) || n.focus() : null == (s = d.current) || s.focus()
                    }
                };
                return e.addEventListener("keydown", t), () => e.removeEventListener("keydown", t)
            }
        }), [l, g]), T.jsxs(np, {
            ref: c,
            role: "region",
            "aria-label": s.replace("{hotkey}", f),
            tabIndex: -1,
            style: {
                pointerEvents: m ? void 0 : "none"
            },
            children: [m && T.jsx(gb, {
                ref: u,
                onFocusFromOutsideViewport: () => {
                    Ib(g({
                        tabbingDirection: "forwards"
                    }))
                }
            }), T.jsx(rb.Slot, {
                scope: r,
                children: T.jsx(Hh.ol, {
                    tabIndex: -1,
                    ...i,
                    ref: p
                })
            }), m && T.jsx(gb, {
                ref: d,
                onFocusFromOutsideViewport: () => {
                    Ib(g({
                        tabbingDirection: "backwards"
                    }))
                }
            })]
        })
    }));
fb.displayName = ub;
var mb = "ToastFocusProxy",
    gb = o.forwardRef(((e, t) => {
        const {
            __scopeToast: r,
            onFocusFromOutsideViewport: n,
            ...s
        } = e, i = lb(mb, r);
        return T.jsx(eb, {
            "aria-hidden": !0,
            tabIndex: 0,
            ...s,
            ref: t,
            style: {
                position: "fixed"
            },
            onFocus: e => {
                var t;
                const r = e.relatedTarget;
                !(null == (t = i.viewport) ? void 0 : t.contains(r)) && n()
            }
        })
    }));
gb.displayName = mb;
var yb = "Toast",
    vb = o.forwardRef(((e, t) => {
        const {
            forceMount: r,
            open: n,
            defaultOpen: s,
            onOpenChange: i,
            ...o
        } = e, [a = !0, l] = Wh({
            prop: n,
            defaultProp: s,
            onChange: i
        });
        return T.jsx(mp, {
            present: r || a,
            children: T.jsx(wb, {
                open: a,
                ...o,
                ref: t,
                onClose: () => l(!1),
                onPause: zh(e.onPause),
                onResume: zh(e.onResume),
                onSwipeStart: Mh(e.onSwipeStart, (e => {
                    e.currentTarget.setAttribute("data-swipe", "start")
                })),
                onSwipeMove: Mh(e.onSwipeMove, (e => {
                    const {
                        x: t,
                        y: r
                    } = e.detail.delta;
                    e.currentTarget.setAttribute("data-swipe", "move"), e.currentTarget.style.setProperty("--radix-toast-swipe-move-x", `${t}px`), e.currentTarget.style.setProperty("--radix-toast-swipe-move-y", `${r}px`)
                })),
                onSwipeCancel: Mh(e.onSwipeCancel, (e => {
                    e.currentTarget.setAttribute("data-swipe", "cancel"), e.currentTarget.style.removeProperty("--radix-toast-swipe-move-x"), e.currentTarget.style.removeProperty("--radix-toast-swipe-move-y"), e.currentTarget.style.removeProperty("--radix-toast-swipe-end-x"), e.currentTarget.style.removeProperty("--radix-toast-swipe-end-y")
                })),
                onSwipeEnd: Mh(e.onSwipeEnd, (e => {
                    const {
                        x: t,
                        y: r
                    } = e.detail.delta;
                    e.currentTarget.setAttribute("data-swipe", "end"), e.currentTarget.style.removeProperty("--radix-toast-swipe-move-x"), e.currentTarget.style.removeProperty("--radix-toast-swipe-move-y"), e.currentTarget.style.setProperty("--radix-toast-swipe-end-x", `${t}px`), e.currentTarget.style.setProperty("--radix-toast-swipe-end-y", `${r}px`), l(!1)
                }))
            })
        })
    }));
vb.displayName = yb;
var [bb, xb] = ib(yb, {
    onClose() {}
}), wb = o.forwardRef(((e, t) => {
    const {
        __scopeToast: r,
        type: n = "foreground",
        duration: s,
        open: i,
        onClose: a,
        onEscapeKeyDown: l,
        onPause: c,
        onResume: u,
        onSwipeStart: h,
        onSwipeMove: p,
        onSwipeCancel: f,
        onSwipeEnd: m,
        ...g
    } = e, y = lb(yb, r), [v, b] = o.useState(null), x = ed(t, (e => b(e))), w = o.useRef(null), k = o.useRef(null), j = s || y.duration, S = o.useRef(0), _ = o.useRef(j), E = o.useRef(0), {
        onToastAdd: P,
        onToastRemove: C
    } = y, O = zh((() => {
        var e;
        (null == v ? void 0 : v.contains(document.activeElement)) && (null == (e = y.viewport) || e.focus()), a()
    })), A = o.useCallback((e => {
        e && e !== 1 / 0 && (window.clearTimeout(E.current), S.current = (new Date).getTime(), E.current = window.setTimeout(O, e))
    }), [O]);
    o.useEffect((() => {
        const e = y.viewport;
        if (e) {
            const t = () => {
                    A(_.current), null == u || u()
                },
                r = () => {
                    const e = (new Date).getTime() - S.current;
                    _.current = _.current - e, window.clearTimeout(E.current), null == c || c()
                };
            return e.addEventListener(hb, r), e.addEventListener(pb, t), () => {
                e.removeEventListener(hb, r), e.removeEventListener(pb, t)
            }
        }
    }), [y.viewport, j, c, u, A]), o.useEffect((() => {
        i && !y.isClosePausedRef.current && A(j)
    }), [i, j, y.isClosePausedRef, A]), o.useEffect((() => (P(), () => C())), [P, C]);
    const N = o.useMemo((() => v ? Ob(v) : null), [v]);
    return y.viewport ? T.jsxs(T.Fragment, {
        children: [N && T.jsx(kb, {
            __scopeToast: r,
            role: "status",
            "aria-live": "foreground" === n ? "assertive" : "polite",
            "aria-atomic": !0,
            children: N
        }), T.jsx(bb, {
            scope: r,
            onClose: O,
            children: d.createPortal(T.jsx(rb.ItemSlot, {
                scope: r,
                children: T.jsx(rp, {
                    asChild: !0,
                    onEscapeKeyDown: Mh(l, (() => {
                        y.isFocusedToastEscapeKeyDownRef.current || O(), y.isFocusedToastEscapeKeyDownRef.current = !1
                    })),
                    children: T.jsx(Hh.li, {
                        role: "status",
                        "aria-live": "off",
                        "aria-atomic": !0,
                        tabIndex: 0,
                        "data-state": i ? "open" : "closed",
                        "data-swipe-direction": y.swipeDirection,
                        ...g,
                        ref: x,
                        style: {
                            userSelect: "none",
                            touchAction: "none",
                            ...e.style
                        },
                        onKeyDown: Mh(e.onKeyDown, (e => {
                            "Escape" === e.key && (null == l || l(e.nativeEvent), e.nativeEvent.defaultPrevented || (y.isFocusedToastEscapeKeyDownRef.current = !0, O()))
                        })),
                        onPointerDown: Mh(e.onPointerDown, (e => {
                            0 === e.button && (w.current = {
                                x: e.clientX,
                                y: e.clientY
                            })
                        })),
                        onPointerMove: Mh(e.onPointerMove, (e => {
                            if (!w.current) return;
                            const t = e.clientX - w.current.x,
                                r = e.clientY - w.current.y,
                                n = Boolean(k.current),
                                s = ["left", "right"].includes(y.swipeDirection),
                                i = ["left", "up"].includes(y.swipeDirection) ? Math.min : Math.max,
                                o = s ? i(0, t) : 0,
                                a = s ? 0 : i(0, r),
                                l = "touch" === e.pointerType ? 10 : 2,
                                c = {
                                    x: o,
                                    y: a
                                },
                                u = {
                                    originalEvent: e,
                                    delta: c
                                };
                            n ? (k.current = c, Ab("toast.swipeMove", p, u, {
                                discrete: !1
                            })) : Nb(c, y.swipeDirection, l) ? (k.current = c, Ab("toast.swipeStart", h, u, {
                                discrete: !1
                            }), e.target.setPointerCapture(e.pointerId)) : (Math.abs(t) > l || Math.abs(r) > l) && (w.current = null)
                        })),
                        onPointerUp: Mh(e.onPointerUp, (e => {
                            const t = k.current,
                                r = e.target;
                            if (r.hasPointerCapture(e.pointerId) && r.releasePointerCapture(e.pointerId), k.current = null, w.current = null, t) {
                                const r = e.currentTarget,
                                    n = {
                                        originalEvent: e,
                                        delta: t
                                    };
                                Nb(t, y.swipeDirection, y.swipeThreshold) ? Ab("toast.swipeEnd", m, n, {
                                    discrete: !0
                                }) : Ab("toast.swipeCancel", f, n, {
                                    discrete: !0
                                }), r.addEventListener("click", (e => e.preventDefault()), {
                                    once: !0
                                })
                            }
                        }))
                    })
                })
            }), y.viewport)
        })]
    }) : null
})), kb = e => {
    const {
        __scopeToast: t,
        children: r,
        ...n
    } = e, s = lb(yb, t), [i, a] = o.useState(!1), [l, c] = o.useState(!1);
    return function(e = () => {}) {
        const t = zh(e);
        $h((() => {
            let e = 0,
                r = 0;
            return e = window.requestAnimationFrame((() => r = window.requestAnimationFrame(t))), () => {
                window.cancelAnimationFrame(e), window.cancelAnimationFrame(r)
            }
        }), [t])
    }((() => a(!0))), o.useEffect((() => {
        const e = window.setTimeout((() => c(!0)), 1e3);
        return () => window.clearTimeout(e)
    }), []), l ? null : T.jsx(fp, {
        asChild: !0,
        children: T.jsx(eb, { ...n,
            children: i && T.jsxs(T.Fragment, {
                children: [s.label, " ", r]
            })
        })
    })
}, jb = o.forwardRef(((e, t) => {
    const {
        __scopeToast: r,
        ...n
    } = e;
    return T.jsx(Hh.div, { ...n,
        ref: t
    })
}));
jb.displayName = "ToastTitle";
var Sb = o.forwardRef(((e, t) => {
    const {
        __scopeToast: r,
        ...n
    } = e;
    return T.jsx(Hh.div, { ...n,
        ref: t
    })
}));
Sb.displayName = "ToastDescription";
var Tb = "ToastAction",
    _b = o.forwardRef(((e, t) => {
        const {
            altText: r,
            ...n
        } = e;
        return r.trim() ? T.jsx(Cb, {
            altText: r,
            asChild: !0,
            children: T.jsx(Pb, { ...n,
                ref: t
            })
        }) : (console.error(`Invalid prop \`altText\` supplied to \`${Tb}\`. Expected non-empty \`string\`.`), null)
    }));
_b.displayName = Tb;
var Eb = "ToastClose",
    Pb = o.forwardRef(((e, t) => {
        const {
            __scopeToast: r,
            ...n
        } = e, s = xb(Eb, r);
        return T.jsx(Cb, {
            asChild: !0,
            children: T.jsx(Hh.button, {
                type: "button",
                ...n,
                ref: t,
                onClick: Mh(e.onClick, s.onClose)
            })
        })
    }));
Pb.displayName = Eb;
var Cb = o.forwardRef(((e, t) => {
    const {
        __scopeToast: r,
        altText: n,
        ...s
    } = e;
    return T.jsx(Hh.div, {
        "data-radix-toast-announce-exclude": "",
        "data-radix-toast-announce-alt": n || void 0,
        ...s,
        ref: t
    })
}));

function Ob(e) {
    const t = [];
    return Array.from(e.childNodes).forEach((e => {
        if (e.nodeType === e.TEXT_NODE && e.textContent && t.push(e.textContent), function(e) {
                return e.nodeType === e.ELEMENT_NODE
            }(e)) {
            const r = e.ariaHidden || e.hidden || "none" === e.style.display,
                n = "" === e.dataset.radixToastAnnounceExclude;
            if (!r)
                if (n) {
                    const r = e.dataset.radixToastAnnounceAlt;
                    r && t.push(r)
                } else t.push(...Ob(e))
        }
    })), t
}

function Ab(e, t, r, {
    discrete: n
}) {
    const s = r.originalEvent.currentTarget,
        i = new CustomEvent(e, {
            bubbles: !0,
            cancelable: !0,
            detail: r
        });
    t && s.addEventListener(e, t, {
        once: !0
    }), n ? qh(s, i) : s.dispatchEvent(i)
}
var Nb = (e, t, r = 0) => {
    const n = Math.abs(e.x),
        s = Math.abs(e.y),
        i = n > s;
    return "left" === t || "right" === t ? i && n > r : !i && s > r
};

function Rb(e) {
    const t = [],
        r = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
            acceptNode: e => {
                const t = "INPUT" === e.tagName && "hidden" === e.type;
                return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
            }
        });
    for (; r.nextNode();) t.push(r.currentNode);
    return t
}

function Ib(e) {
    const t = document.activeElement;
    return e.some((e => e === t || (e.focus(), document.activeElement !== t)))
}
var Lb = fb,
    Mb = vb,
    Ub = jb,
    Db = Sb,
    $b = _b,
    Fb = Pb;
const Vb = cb,
    Bb = o.forwardRef((({
        className: e,
        ...t
    }, r) => T.jsx(Lb, {
        ref: r,
        className: nh("fixed top-0 z-[100] flex max-h-screen w-full flex-col-reverse p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]", e),
        ...t
    })));
Bb.displayName = Lb.displayName;
const zb = cd("group pointer-events-auto relative flex w-full items-center justify-between space-x-2 overflow-hidden rounded-md border p-4 pr-6 shadow-lg transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-top-full data-[state=open]:sm:slide-in-from-bottom-full", {
        variants: {
            variant: {
                default: "border bg-background text-foreground",
                destructive: "destructive group border-destructive bg-destructive text-destructive-foreground"
            }
        },
        defaultVariants: {
            variant: "default"
        }
    }),
    Wb = o.forwardRef((({
        className: e,
        variant: t,
        ...r
    }, n) => T.jsx(Mb, {
        ref: n,
        className: nh(zb({
            variant: t
        }), e),
        ...r
    })));
Wb.displayName = Mb.displayName;
o.forwardRef((({
    className: e,
    ...t
}, r) => T.jsx($b, {
    ref: r,
    className: nh("inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium transition-colors hover:bg-secondary focus:outline-none focus:ring-1 focus:ring-ring disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-muted/40 group-[.destructive]:hover:border-destructive/30 group-[.destructive]:hover:bg-destructive group-[.destructive]:hover:text-destructive-foreground group-[.destructive]:focus:ring-destructive", e),
    ...t
}))).displayName = $b.displayName;
const Hb = o.forwardRef((({
    className: e,
    ...t
}, r) => T.jsx(Fb, {
    ref: r,
    className: nh("absolute right-1 top-1 rounded-md p-1 text-foreground/50 opacity-0 transition-opacity hover:text-foreground focus:opacity-100 focus:outline-none focus:ring-1 group-hover:opacity-100 group-[.destructive]:text-red-300 group-[.destructive]:hover:text-red-50 group-[.destructive]:focus:ring-red-400 group-[.destructive]:focus:ring-offset-red-600", e),
    "toast-close": "",
    ...t,
    children: T.jsx(tm, {
        className: "h-4 w-4"
    })
})));
Hb.displayName = Fb.displayName;
const qb = o.forwardRef((({
    className: e,
    ...t
}, r) => T.jsx(Ub, {
    ref: r,
    className: nh("text-sm font-semibold [&+div]:text-xs", e),
    ...t
})));
qb.displayName = Ub.displayName;
const Kb = o.forwardRef((({
    className: e,
    ...t
}, r) => T.jsx(Db, {
    ref: r,
    className: nh("text-sm opacity-90", e),
    ...t
})));

function Gb() {
    const {
        toasts: e
    } = Yu();
    return T.jsxs(Vb, {
        children: [e.map((function({
            id: e,
            title: t,
            description: r,
            action: n,
            ...s
        }) {
            return T.jsxs(Wb, { ...s,
                children: [T.jsxs("div", {
                    className: "grid gap-1",
                    children: [t && T.jsx(qb, {
                        children: t
                    }), r && T.jsx(Kb, {
                        children: r
                    })]
                }), n, T.jsx(Hb, {})]
            }, e)
        })), T.jsx(Bb, {})]
    })
}
Kb.displayName = Db.displayName;
class Yb extends o.Component {
    constructor() {
        super(...arguments), n(this, "state", {
            hasError: !1,
            error: null,
            errorInfo: null
        }), n(this, "handleReload", (() => {
            window.location.reload()
        })), n(this, "handleGoHome", (() => {
            window.location.href = "/"
        }))
    }
    static getDerivedStateFromError(e) {
        return {
            hasError: !0,
            error: e,
            errorInfo: null
        }
    }
    componentDidCatch(e, t) {
        this.setState({
            errorInfo: t
        }), console.error("Uncaught error:", e, t)
    }
    render() {
        return this.state.hasError ? this.props.fallback ? this.props.fallback : T.jsx("div", {
            className: "min-h-screen flex items-center justify-center bg-gray-50 px-4",
            children: T.jsxs("div", {
                className: "max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center",
                children: [T.jsx("div", {
                    className: "flex justify-center mb-6",
                    children: T.jsx("div", {
                        className: "bg-red-100 p-3 rounded-full",
                        children: T.jsx(Ah, {
                            className: "h-12 w-12 text-red-600"
                        })
                    })
                }), T.jsx("h1", {
                    className: "text-2xl font-bold text-gray-900 mb-4",
                    children: "Something went wrong"
                }), T.jsx("p", {
                    className: "text-gray-600 mb-6",
                    children: "We're sorry, but an unexpected error has occurred. Our team has been notified and is working to fix the issue."
                }), T.jsxs("div", {
                    className: "flex flex-col sm:flex-row gap-4 justify-center",
                    children: [T.jsx(ih, {
                        onClick: this.handleReload,
                        className: "bg-black hover:bg-black-800",
                        children: "Reload Page"
                    }), T.jsx(ih, {
                        onClick: this.handleGoHome,
                        variant: "outline",
                        className: "border-black text-black hover:bg-black-50",
                        children: "Go to Homepage"
                    })]
                }), !1]
            })
        }) : this.props.children
    }
}
const Jb = () => {
        if ("undefined" == typeof navigator) return !1;
        const e = navigator.userAgent.toLowerCase();
        return e.includes("samsung") || e.includes("android") && e.includes("sm-") || e.includes("android") && e.includes("galaxy")
    },
    Xb = () => {
        if (!Jb()) return !1;
        if ("undefined" != typeof document) {
            document.body.classList.add("is-samsung-device");
            document.querySelectorAll("section, main > div, [data-motion], [data-animate]").forEach((e => {
                e.style.display = "block", e.style.visibility = "visible", e.style.opacity = "1";
                const t = document.createElement("div");
                t.className = "force-render", t.setAttribute("aria-hidden", "true"), t.innerHTML = "\x3c!-- Force Samsung layout recalculation --\x3e", e.appendChild(t), e.offsetHeight, e.style.contentVisibility = "visible", e.classList.add("force-content-visibility")
            }));
            const e = document.querySelector("main");
            if (e) {
                const t = document.createElement("div");
                t.className = "samsung-render-fix start", t.setAttribute("aria-hidden", "true"), t.style.height = "1px", t.style.width = "100%", t.style.display = "block";
                const r = document.createElement("div");
                r.className = "samsung-render-fix end", r.setAttribute("aria-hidden", "true"), r.style.height = "1px", r.style.width = "100%", r.style.display = "block", e.insertBefore(t, e.firstChild), e.appendChild(r)
            }
            return !0
        }
        return !1
    },
    Zb = () => {
        if ("undefined" == typeof window) return;
        const e = () => {
            Jb() && (console.log("Samsung device detected, applying fixes"), Xb(), setTimeout((() => {
                Xb()
            }), 500))
        };
        if (window.addEventListener("load", e), void 0 !== window.history) {
            const t = window.history.pushState;
            window.history.pushState = function() {
                t.apply(this, arguments), setTimeout(e, 100)
            }, window.addEventListener("popstate", (() => {
                setTimeout(e, 100)
            }))
        }
        e()
    };
var Qb = {};

function ex() {
    return "undefined" != typeof window
}

function tx() {
    try {} catch (e) {}
    return "production"
}

function rx() {
    return "development" === ((ex() ? window.vam : tx()) || "production")
}

function nx(e = {
    debug: !0
}) {
    var t;
    if (!ex()) return;
    ! function(e = "auto") {
        window.vam = "auto" !== e ? e : tx()
    }(e.mode), window.va || (window.va = function(...e) {
        (window.vaq = window.vaq || []).push(e)
    }), e.beforeSend && (null == (t = window.va) || t.call(window, "beforeSend", e.beforeSend));
    const r = function(e) {
        return e.scriptSrc ? e.scriptSrc : rx() ? "https://va.vercel-scripts.com/v1/script.debug.js" : e.basePath ? `${e.basePath}/insights/script.js` : "/_vercel/insights/script.js"
    }(e);
    if (document.head.querySelector(`script[src*="${r}"]`)) return;
    const n = document.createElement("script");
    n.src = r, n.defer = !0, n.dataset.sdkn = "@vercel/analytics" + (e.framework ? `/${e.framework}` : ""), n.dataset.sdkv = "1.5.0", e.disableAutoTrack && (n.dataset.disableAutoTrack = "1"), e.endpoint ? n.dataset.endpoint = e.endpoint : e.basePath && (n.dataset.endpoint = `${e.basePath}/insights`), e.dsn && (n.dataset.dsn = e.dsn), n.onerror = () => {
        const e = rx() ? "Please check if any ad blockers are enabled and try again." : "Be sure to enable Web Analytics for your project and deploy again. See https://vercel.com/docs/analytics/quickstart for more information.";
        console.log(`[Vercel Web Analytics] Failed to load script from ${r}. ${e}`)
    }, rx() && !1 === e.debug && (n.dataset.debug = "false"), document.head.appendChild(n)
}

function sx() {
    if ("undefined" != typeof process) return Qb.REACT_APP_VERCEL_OBSERVABILITY_BASEPATH
}

function ix(e) {
    return o.useEffect((() => {
        var t;
        e.beforeSend && (null == (t = window.va) || t.call(window, "beforeSend", e.beforeSend))
    }), [e.beforeSend]), o.useEffect((() => {
        nx({
            framework: e.framework || "react",
            basePath: e.basePath ? ? sx(),
            ...void 0 !== e.route && {
                disableAutoTrack: !0
            },
            ...e
        })
    }), []), o.useEffect((() => {
        e.route && e.path && function({
            route: e,
            path: t
        }) {
            var r;
            null == (r = window.va) || r.call(window, "pageview", {
                route: e,
                path: t
            })
        }({
            route: e.route,
            path: e.path
        })
    }), [e.route, e.path]), null
}
var ox = {};

function ax(e = {}) {
    var t;
    if ("undefined" == typeof window || null === e.route) return null;
    window.si || (window.si = function(...e) {
        (window.siq = window.siq || []).push(e)
    });
    const r = function(e) {
        return e.scriptSrc ? e.scriptSrc : e.dsn ? "https://va.vercel-scripts.com/v1/speed-insights/script.js" : e.basePath ? `${e.basePath}/speed-insights/script.js` : "/_vercel/speed-insights/script.js"
    }(e);
    if (document.head.querySelector(`script[src*="${r}"]`)) return null;
    e.beforeSend && (null == (t = window.si) || t.call(window, "beforeSend", e.beforeSend));
    const n = document.createElement("script");
    return n.src = r, n.defer = !0, n.dataset.sdkn = "@vercel/speed-insights" + (e.framework ? `/${e.framework}` : ""), n.dataset.sdkv = "1.2.0", e.sampleRate && (n.dataset.sampleRate = e.sampleRate.toString()), e.route && (n.dataset.route = e.route), e.endpoint ? n.dataset.endpoint = e.endpoint : e.basePath && (n.dataset.endpoint = `${e.basePath}/speed-insights/vitals`), e.dsn && (n.dataset.dsn = e.dsn), n.onerror = () => {
        console.log(`[Vercel Speed Insights] Failed to load script from ${r}. Please check if any content blockers are enabled and try again.`)
    }, document.head.appendChild(n), {
        setRoute: e => {
            n.dataset.route = e ? ? void 0
        }
    }
}

function lx() {
    if ("undefined" != typeof process) return ox.REACT_APP_VERCEL_OBSERVABILITY_BASEPATH
}

function cx(e) {
    o.useEffect((() => {
        var t;
        e.beforeSend && (null == (t = window.si) || t.call(window, "beforeSend", e.beforeSend))
    }), [e.beforeSend]);
    const t = o.useRef(null);
    return o.useEffect((() => {
        if (t.current) e.route && t.current(e.route);
        else {
            const r = ax({
                framework: e.framework ? ? "react",
                basePath: e.basePath ? ? lx(),
                ...e
            });
            r && (t.current = r.setRoute)
        }
    }), [e.route]), null
}
const ux = ({
        children: e,
        hideHeader: t = !1,
        hideFooter: r = !1
    }) => (o.useEffect((() => {
        if (Jb()) {
            console.log("Samsung device detected in MainLayout, applying fixes"), Xb();
            const e = [100, 300, 800, 1500].map((e => setTimeout(Xb, e)));
            return () => {
                e.forEach(clearTimeout)
            }
        }
    }), []), T.jsx(Yb, {
        children: T.jsxs("div", {
            className: "flex flex-col min-h-screen bg-white",
            children: [!t && T.jsx(Gv, {}), T.jsx(o.Suspense, {
                fallback: T.jsx(Ca, {
                    size: "md",
                    text: "Loading content..."
                }),
                children: T.jsx(z, {
                    mode: "wait",
                    children: T.jsxs(Pa.main, {
                        className: "flex-grow mobile-compatible-content",
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: 1
                        },
                        exit: {
                            opacity: 0
                        },
                        transition: {
                            duration: .3
                        },
                        style: {
                            willChange: "transform",
                            isolation: "isolate",
                            contain: "paint layout"
                        },
                        "data-mobile-fix": "true",
                        children: [T.jsx("div", {
                            className: "force-render",
                            "aria-hidden": "true",
                            style: {
                                display: "none"
                            }
                        }), e, T.jsx("div", {
                            className: "force-render",
                            "aria-hidden": "true",
                            style: {
                                display: "none"
                            }
                        })]
                    })
                })
            }), !r && T.jsx(Qv, {}), T.jsx(Gb, {}), T.jsx(ix, {}), T.jsx(cx, {}), T.jsx("div", {
                className: "hidden",
                "aria-hidden": "true",
                id: "samsung-fix-container",
                children: T.jsx("div", {
                    className: "force-render force-content-visibility"
                })
            })]
        })
    })),
    dx = ({
        title: e,
        subtitle: t,
        backgroundImage: r,
        alignment: n = "center",
        size: s = "medium",
        overlay: i = !0,
        textColor: o = "light",
        children: a
    }) => {
        const l = () => "light" === o ? "text-white" : "text-gray-900",
            c = {
                hidden: {
                    opacity: 0,
                    y: 20
                },
                visible: {
                    opacity: 1,
                    y: 0,
                    transition: {
                        duration: .6
                    }
                }
            };
        return T.jsxs("div", {
            className: `relative ${(()=>{switch(s){case"small":return"h-64";case"large":return"h-[500px]";default:return"h-96"}})()} overflow-hidden bg-black-900 flex items-center`,
            children: [r && T.jsxs("div", {
                className: "absolute inset-0 w-full h-full",
                children: [T.jsx(Pa.div, {
                    initial: {
                        scale: 1.1
                    },
                    animate: {
                        scale: 1
                    },
                    transition: {
                        duration: 1.5
                    },
                    className: "w-full h-full",
                    children: T.jsx("img", {
                        src: r,
                        alt: e,
                        className: "w-full h-full object-cover"
                    })
                }), i && T.jsx("div", {
                    className: "absolute inset-0 bg-gradient-to-r from-black-900/80 to-black-700/70"
                })]
            }), T.jsxs(Pa.div, {
                className: `container mx-auto px-4 relative z-10 flex flex-col ${(()=>{switch(n){case"left":return"text-left items-start";case"right":return"text-right items-end";default:return"text-center items-center"}})()} justify-center`,
                variants: {
                    hidden: {
                        opacity: 0
                    },
                    visible: {
                        opacity: 1,
                        transition: {
                            duration: .6,
                            staggerChildren: .2
                        }
                    }
                },
                initial: "hidden",
                animate: "visible",
                children: [T.jsx(Pa.h1, {
                    className: `text-4xl md:text-5xl lg:text-6xl font-bold mb-4 ${l()}`,
                    variants: c,
                    children: e
                }), t && T.jsx(Pa.p, {
                    className: `text-lg md:text-xl max-w-3xl ${l()} opacity-90`,
                    variants: c,
                    children: t
                }), a && T.jsx(Pa.div, {
                    className: "mt-6",
                    variants: c,
                    children: a
                })]
            })]
        })
    },
    hx = ({
        overrides: e = {},
        homeLabel: t = "Home",
        className: r = ""
    }) => {
        const n = f().pathname.split("/").filter((e => e)),
            s = t => e[t] ? e[t] : t.split("-").map((e => e.charAt(0).toUpperCase() + e.slice(1))).join(" ");
        return T.jsx("nav", {
            className: `flex items-center text-sm text-gray-500 py-4 ${r}`,
            "aria-label": "Breadcrumb",
            children: T.jsxs("ol", {
                className: "flex items-center flex-wrap",
                children: [T.jsx("li", {
                    className: "flex items-center",
                    children: T.jsxs(c, {
                        to: "/",
                        className: "flex items-center hover:text-black transition-colors",
                        children: [T.jsx(xh, {
                            className: "h-4 w-4 mr-1"
                        }), T.jsx("span", {
                            children: t
                        })]
                    })
                }), n.map(((e, t) => {
                    const r = `/${n.slice(0,t+1).join("/")}`,
                        i = t === n.length - 1;
                    return T.jsxs("li", {
                        className: "flex items-center",
                        children: [T.jsx(fh, {
                            className: "h-4 w-4 mx-2 text-gray-400"
                        }), i ? T.jsx("span", {
                            className: "font-medium text-gray-900",
                            children: s(e)
                        }) : T.jsx(c, {
                            to: r,
                            className: "hover:text-black transition-colors",
                            children: s(e)
                        })]
                    }, e)
                }))]
            })
        })
    };
var px, fx;
const mx = l(function() {
    if (fx) return px;
    fx = 1;
    var e = "undefined" != typeof Element,
        t = "function" == typeof Map,
        r = "function" == typeof Set,
        n = "function" == typeof ArrayBuffer && !!ArrayBuffer.isView;

    function s(i, o) {
        if (i === o) return !0;
        if (i && o && "object" == typeof i && "object" == typeof o) {
            if (i.constructor !== o.constructor) return !1;
            var a, l, c, u;
            if (Array.isArray(i)) {
                if ((a = i.length) != o.length) return !1;
                for (l = a; 0 != l--;)
                    if (!s(i[l], o[l])) return !1;
                return !0
            }
            if (t && i instanceof Map && o instanceof Map) {
                if (i.size !== o.size) return !1;
                for (u = i.entries(); !(l = u.next()).done;)
                    if (!o.has(l.value[0])) return !1;
                for (u = i.entries(); !(l = u.next()).done;)
                    if (!s(l.value[1], o.get(l.value[0]))) return !1;
                return !0
            }
            if (r && i instanceof Set && o instanceof Set) {
                if (i.size !== o.size) return !1;
                for (u = i.entries(); !(l = u.next()).done;)
                    if (!o.has(l.value[0])) return !1;
                return !0
            }
            if (n && ArrayBuffer.isView(i) && ArrayBuffer.isView(o)) {
                if ((a = i.length) != o.length) return !1;
                for (l = a; 0 != l--;)
                    if (i[l] !== o[l]) return !1;
                return !0
            }
            if (i.constructor === RegExp) return i.source === o.source && i.flags === o.flags;
            if (i.valueOf !== Object.prototype.valueOf && "function" == typeof i.valueOf && "function" == typeof o.valueOf) return i.valueOf() === o.valueOf();
            if (i.toString !== Object.prototype.toString && "function" == typeof i.toString && "function" == typeof o.toString) return i.toString() === o.toString();
            if ((a = (c = Object.keys(i)).length) !== Object.keys(o).length) return !1;
            for (l = a; 0 != l--;)
                if (!Object.prototype.hasOwnProperty.call(o, c[l])) return !1;
            if (e && i instanceof Element) return !1;
            for (l = a; 0 != l--;)
                if (("_owner" !== c[l] && "__v" !== c[l] && "__o" !== c[l] || !i.$$typeof) && !s(i[c[l]], o[c[l]])) return !1;
            return !0
        }
        return i != i && o != o
    }
    return px = function(e, t) {
        try {
            return s(e, t)
        } catch (r) {
            if ((r.message || "").match(/stack|recursion/i)) return console.warn("react-fast-compare cannot handle circular refs"), !1;
            throw r
        }
    }
}());
var gx, yx;
const vx = l(yx ? gx : (yx = 1, gx = function(e, t, r, n, s, i, o, a) {
    if (!e) {
        var l;
        if (void 0 === t) l = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
        else {
            var c = [r, n, s, i, o, a],
                u = 0;
            (l = new Error(t.replace(/%s/g, (function() {
                return c[u++]
            })))).name = "Invariant Violation"
        }
        throw l.framesToPop = 1, l
    }
}));
var bx, xx;
const wx = l(xx ? bx : (xx = 1, bx = function(e, t, r, n) {
    var s = r ? r.call(n, e, t) : void 0;
    if (void 0 !== s) return !!s;
    if (e === t) return !0;
    if ("object" != typeof e || !e || "object" != typeof t || !t) return !1;
    var i = Object.keys(e),
        o = Object.keys(t);
    if (i.length !== o.length) return !1;
    for (var a = Object.prototype.hasOwnProperty.bind(t), l = 0; l < i.length; l++) {
        var c = i[l];
        if (!a(c)) return !1;
        var u = e[c],
            d = t[c];
        if (!1 === (s = r ? r.call(n, u, d, c) : void 0) || void 0 === s && u !== d) return !1
    }
    return !0
}));
var kx = (e => (e.BASE = "base", e.BODY = "body", e.HEAD = "head", e.HTML = "html", e.LINK = "link", e.META = "meta", e.NOSCRIPT = "noscript", e.SCRIPT = "script", e.STYLE = "style", e.TITLE = "title", e.FRAGMENT = "Symbol(react.fragment)", e))(kx || {}),
    jx = {
        rel: ["amphtml", "canonical", "alternate"]
    },
    Sx = {
        type: ["application/ld+json"]
    },
    Tx = {
        charset: "",
        name: ["generator", "robots", "description"],
        property: ["og:type", "og:title", "og:url", "og:image", "og:image:alt", "og:description", "twitter:url", "twitter:title", "twitter:description", "twitter:image", "twitter:image:alt", "twitter:card", "twitter:site"]
    },
    _x = Object.values(kx),
    Ex = {
        accesskey: "accessKey",
        charset: "charSet",
        class: "className",
        contenteditable: "contentEditable",
        contextmenu: "contextMenu",
        "http-equiv": "httpEquiv",
        itemprop: "itemProp",
        tabindex: "tabIndex"
    },
    Px = Object.entries(Ex).reduce(((e, [t, r]) => (e[r] = t, e)), {}),
    Cx = "data-rh",
    Ox = "defaultTitle",
    Ax = "defer",
    Nx = "encodeSpecialCharacters",
    Rx = "onChangeClientState",
    Ix = "titleTemplate",
    Lx = "prioritizeSeoTags",
    Mx = (e, t) => {
        for (let r = e.length - 1; r >= 0; r -= 1) {
            const n = e[r];
            if (Object.prototype.hasOwnProperty.call(n, t)) return n[t]
        }
        return null
    },
    Ux = e => {
        let t = Mx(e, "title");
        const r = Mx(e, Ix);
        if (Array.isArray(t) && (t = t.join("")), r && t) return r.replace(/%s/g, (() => t));
        const n = Mx(e, Ox);
        return t || n || void 0
    },
    Dx = e => Mx(e, Rx) || (() => {}),
    $x = (e, t) => t.filter((t => void 0 !== t[e])).map((t => t[e])).reduce(((e, t) => ({ ...e,
        ...t
    })), {}),
    Fx = (e, t) => t.filter((e => void 0 !== e.base)).map((e => e.base)).reverse().reduce(((t, r) => {
        if (!t.length) {
            const n = Object.keys(r);
            for (let s = 0; s < n.length; s += 1) {
                const i = n[s].toLowerCase();
                if (-1 !== e.indexOf(i) && r[i]) return t.concat(r)
            }
        }
        return t
    }), []),
    Vx = (e, t, r) => {
        const n = {};
        return r.filter((t => {
            return !!Array.isArray(t[e]) || (void 0 !== t[e] && (r = `Helmet: ${e} should be of type "Array". Instead found type "${typeof t[e]}"`, console && "function" == typeof console.warn && console.warn(r)), !1);
            var r
        })).map((t => t[e])).reverse().reduce(((e, r) => {
            const s = {};
            r.filter((e => {
                let r;
                const i = Object.keys(e);
                for (let n = 0; n < i.length; n += 1) {
                    const s = i[n],
                        o = s.toLowerCase(); - 1 === t.indexOf(o) || "rel" === r && "canonical" === e[r].toLowerCase() || "rel" === o && "stylesheet" === e[o].toLowerCase() || (r = o), -1 === t.indexOf(s) || "innerHTML" !== s && "cssText" !== s && "itemprop" !== s || (r = s)
                }
                if (!r || !e[r]) return !1;
                const o = e[r].toLowerCase();
                return n[r] || (n[r] = {}), s[r] || (s[r] = {}), !n[r][o] && (s[r][o] = !0, !0)
            })).reverse().forEach((t => e.push(t)));
            const i = Object.keys(s);
            for (let t = 0; t < i.length; t += 1) {
                const e = i[t],
                    r = { ...n[e],
                        ...s[e]
                    };
                n[e] = r
            }
            return e
        }), []).reverse()
    },
    Bx = (e, t) => {
        if (Array.isArray(e) && e.length)
            for (let r = 0; r < e.length; r += 1) {
                if (e[r][t]) return !0
            }
        return !1
    },
    zx = e => Array.isArray(e) ? e.join("") : e,
    Wx = (e, t) => Array.isArray(e) ? e.reduce(((e, r) => (((e, t) => {
        const r = Object.keys(e);
        for (let n = 0; n < r.length; n += 1)
            if (t[r[n]] && t[r[n]].includes(e[r[n]])) return !0;
        return !1
    })(r, t) ? e.priority.push(r) : e.default.push(r), e)), {
        priority: [],
        default: []
    }) : {
        default: e,
        priority: []
    },
    Hx = (e, t) => ({ ...e,
        [t]: void 0
    }),
    qx = ["noscript", "script", "style"],
    Kx = (e, t = !0) => !1 === t ? String(e) : String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;"),
    Gx = e => Object.keys(e).reduce(((t, r) => {
        const n = void 0 !== e[r] ? `${r}="${e[r]}"` : `${r}`;
        return t ? `${t} ${n}` : n
    }), ""),
    Yx = (e, t = {}) => Object.keys(e).reduce(((t, r) => (t[Ex[r] || r] = e[r], t)), t),
    Jx = (e, t) => t.map(((t, r) => {
        const n = {
            key: r,
            [Cx]: !0
        };
        return Object.keys(t).forEach((e => {
            const r = Ex[e] || e;
            if ("innerHTML" === r || "cssText" === r) {
                const e = t.innerHTML || t.cssText;
                n.dangerouslySetInnerHTML = {
                    __html: e
                }
            } else n[r] = t[e]
        })), p.createElement(e, n)
    })),
    Xx = (e, t, r = !0) => {
        switch (e) {
            case "title":
                return {
                    toComponent: () => ((e, t, r) => {
                        const n = Yx(r, {
                            key: t,
                            [Cx]: !0
                        });
                        return [p.createElement("title", n, t)]
                    })(0, t.title, t.titleAttributes),
                    toString: () => ((e, t, r, n) => {
                        const s = Gx(r),
                            i = zx(t);
                        return s ? `<${e} ${Cx}="true" ${s}>${Kx(i,n)}</${e}>` : `<${e} ${Cx}="true">${Kx(i,n)}</${e}>`
                    })(e, t.title, t.titleAttributes, r)
                };
            case "bodyAttributes":
            case "htmlAttributes":
                return {
                    toComponent: () => Yx(t),
                    toString: () => Gx(t)
                };
            default:
                return {
                    toComponent: () => Jx(e, t),
                    toString: () => ((e, t, r = !0) => t.reduce(((t, n) => {
                        const s = n,
                            i = Object.keys(s).filter((e => !("innerHTML" === e || "cssText" === e))).reduce(((e, t) => {
                                const n = void 0 === s[t] ? t : `${t}="${Kx(s[t],r)}"`;
                                return e ? `${e} ${n}` : n
                            }), ""),
                            o = s.innerHTML || s.cssText || "",
                            a = -1 === qx.indexOf(e);
                        return `${t}<${e} ${Cx}="true" ${i}${a?"/>":`>${o}</${e}>`}`
                    }), ""))(e, t, r)
                }
        }
    },
    Zx = e => {
        const {
            baseTag: t,
            bodyAttributes: r,
            encode: n = !0,
            htmlAttributes: s,
            noscriptTags: i,
            styleTags: o,
            title: a = "",
            titleAttributes: l,
            prioritizeSeoTags: c
        } = e;
        let {
            linkTags: u,
            metaTags: d,
            scriptTags: h
        } = e, p = {
            toComponent: () => {},
            toString: () => ""
        };
        return c && ({
            priorityMethods: p,
            linkTags: u,
            metaTags: d,
            scriptTags: h
        } = (({
            metaTags: e,
            linkTags: t,
            scriptTags: r,
            encode: n
        }) => {
            const s = Wx(e, Tx),
                i = Wx(t, jx),
                o = Wx(r, Sx);
            return {
                priorityMethods: {
                    toComponent: () => [...Jx("meta", s.priority), ...Jx("link", i.priority), ...Jx("script", o.priority)],
                    toString: () => `${Xx("meta",s.priority,n)} ${Xx("link",i.priority,n)} ${Xx("script",o.priority,n)}`
                },
                metaTags: s.default,
                linkTags: i.default,
                scriptTags: o.default
            }
        })(e)), {
            priority: p,
            base: Xx("base", t, n),
            bodyAttributes: Xx("bodyAttributes", r, n),
            htmlAttributes: Xx("htmlAttributes", s, n),
            link: Xx("link", u, n),
            meta: Xx("meta", d, n),
            noscript: Xx("noscript", i, n),
            script: Xx("script", h, n),
            style: Xx("style", o, n),
            title: Xx("title", {
                title: a,
                titleAttributes: l
            }, n)
        }
    },
    Qx = [],
    ew = !("undefined" == typeof window || !window.document || !window.document.createElement),
    tw = class {
        constructor(e, t) {
            n(this, "instances", []), n(this, "canUseDOM", ew), n(this, "context"), n(this, "value", {
                setHelmet: e => {
                    this.context.helmet = e
                },
                helmetInstances: {
                    get: () => this.canUseDOM ? Qx : this.instances,
                    add: e => {
                        (this.canUseDOM ? Qx : this.instances).push(e)
                    },
                    remove: e => {
                        const t = (this.canUseDOM ? Qx : this.instances).indexOf(e);
                        (this.canUseDOM ? Qx : this.instances).splice(t, 1)
                    }
                }
            }), this.context = e, this.canUseDOM = t || !1, t || (e.helmet = Zx({
                baseTag: [],
                bodyAttributes: {},
                htmlAttributes: {},
                linkTags: [],
                metaTags: [],
                noscriptTags: [],
                scriptTags: [],
                styleTags: [],
                title: "",
                titleAttributes: {}
            }))
        }
    },
    rw = p.createContext({}),
    nw = (e = class extends o.Component {
        constructor(t) {
            super(t), n(this, "helmetData"), this.helmetData = new tw(this.props.context || {}, e.canUseDOM)
        }
        render() {
            return p.createElement(rw.Provider, {
                value: this.helmetData.value
            }, this.props.children)
        }
    }, n(e, "canUseDOM", ew), e),
    sw = (e, t) => {
        const r = document.head || document.querySelector("head"),
            n = r.querySelectorAll(`${e}[${Cx}]`),
            s = [].slice.call(n),
            i = [];
        let o;
        return t && t.length && t.forEach((t => {
            const r = document.createElement(e);
            for (const e in t)
                if (Object.prototype.hasOwnProperty.call(t, e))
                    if ("innerHTML" === e) r.innerHTML = t.innerHTML;
                    else if ("cssText" === e) r.styleSheet ? r.styleSheet.cssText = t.cssText : r.appendChild(document.createTextNode(t.cssText));
            else {
                const n = e,
                    s = void 0 === t[n] ? "" : t[n];
                r.setAttribute(e, s)
            }
            r.setAttribute(Cx, "true"), s.some(((e, t) => (o = t, r.isEqualNode(e)))) ? s.splice(o, 1) : i.push(r)
        })), s.forEach((e => {
            var t;
            return null == (t = e.parentNode) ? void 0 : t.removeChild(e)
        })), i.forEach((e => r.appendChild(e))), {
            oldTags: s,
            newTags: i
        }
    },
    iw = (e, t) => {
        const r = document.getElementsByTagName(e)[0];
        if (!r) return;
        const n = r.getAttribute(Cx),
            s = n ? n.split(",") : [],
            i = [...s],
            o = Object.keys(t);
        for (const a of o) {
            const e = t[a] || "";
            r.getAttribute(a) !== e && r.setAttribute(a, e), -1 === s.indexOf(a) && s.push(a);
            const n = i.indexOf(a); - 1 !== n && i.splice(n, 1)
        }
        for (let a = i.length - 1; a >= 0; a -= 1) r.removeAttribute(i[a]);
        s.length === i.length ? r.removeAttribute(Cx) : r.getAttribute(Cx) !== o.join(",") && r.setAttribute(Cx, o.join(","))
    },
    ow = (e, t) => {
        const {
            baseTag: r,
            bodyAttributes: n,
            htmlAttributes: s,
            linkTags: i,
            metaTags: o,
            noscriptTags: a,
            onChangeClientState: l,
            scriptTags: c,
            styleTags: u,
            title: d,
            titleAttributes: h
        } = e;
        iw("body", n), iw("html", s), ((e, t) => {
            void 0 !== e && document.title !== e && (document.title = zx(e)), iw("title", t)
        })(d, h);
        const p = {
                baseTag: sw("base", r),
                linkTags: sw("link", i),
                metaTags: sw("meta", o),
                noscriptTags: sw("noscript", a),
                scriptTags: sw("script", c),
                styleTags: sw("style", u)
            },
            f = {},
            m = {};
        Object.keys(p).forEach((e => {
            const {
                newTags: t,
                oldTags: r
            } = p[e];
            t.length && (f[e] = t), r.length && (m[e] = p[e].oldTags)
        })), t && t(), l(e, f, m)
    },
    aw = null,
    lw = e => {
        aw && cancelAnimationFrame(aw), e.defer ? aw = requestAnimationFrame((() => {
            ow(e, (() => {
                aw = null
            }))
        })) : (ow(e), aw = null)
    },
    cw = class extends o.Component {
        constructor() {
            super(...arguments), n(this, "rendered", !1)
        }
        shouldComponentUpdate(e) {
            return !wx(e, this.props)
        }
        componentDidUpdate() {
            this.emitChange()
        }
        componentWillUnmount() {
            const {
                helmetInstances: e
            } = this.props.context;
            e.remove(this), this.emitChange()
        }
        emitChange() {
            const {
                helmetInstances: e,
                setHelmet: t
            } = this.props.context;
            let r = null;
            const n = (s = e.get().map((e => {
                const t = { ...e.props
                };
                return delete t.context, t
            })), {
                baseTag: Fx(["href"], s),
                bodyAttributes: $x("bodyAttributes", s),
                defer: Mx(s, Ax),
                encode: Mx(s, Nx),
                htmlAttributes: $x("htmlAttributes", s),
                linkTags: Vx("link", ["rel", "href"], s),
                metaTags: Vx("meta", ["name", "charset", "http-equiv", "property", "itemprop"], s),
                noscriptTags: Vx("noscript", ["innerHTML"], s),
                onChangeClientState: Dx(s),
                scriptTags: Vx("script", ["src", "innerHTML"], s),
                styleTags: Vx("style", ["cssText"], s),
                title: Ux(s),
                titleAttributes: $x("titleAttributes", s),
                prioritizeSeoTags: Bx(s, Lx)
            });
            var s;
            nw.canUseDOM ? lw(n) : Zx && (r = Zx(n)), t(r)
        }
        init() {
            if (this.rendered) return;
            this.rendered = !0;
            const {
                helmetInstances: e
            } = this.props.context;
            e.add(this), this.emitChange()
        }
        render() {
            return this.init(), null
        }
    },
    uw = (t = class extends o.Component {
        shouldComponentUpdate(e) {
            return !mx(Hx(this.props, "helmetData"), Hx(e, "helmetData"))
        }
        mapNestedChildrenToProps(e, t) {
            if (!t) return null;
            switch (e.type) {
                case "script":
                case "noscript":
                    return {
                        innerHTML: t
                    };
                case "style":
                    return {
                        cssText: t
                    };
                default:
                    throw new Error(`<${e.type} /> elements are self-closing and can not contain children. Refer to our API for more information.`)
            }
        }
        flattenArrayTypeChildren(e, t, r, n) {
            return { ...t,
                [e.type]: [...t[e.type] || [], { ...r,
                    ...this.mapNestedChildrenToProps(e, n)
                }]
            }
        }
        mapObjectTypeChildren(e, t, r, n) {
            switch (e.type) {
                case "title":
                    return { ...t,
                        [e.type]: n,
                        titleAttributes: { ...r
                        }
                    };
                case "body":
                    return { ...t,
                        bodyAttributes: { ...r
                        }
                    };
                case "html":
                    return { ...t,
                        htmlAttributes: { ...r
                        }
                    };
                default:
                    return { ...t,
                        [e.type]: { ...r
                        }
                    }
            }
        }
        mapArrayTypeChildrenToProps(e, t) {
            let r = { ...t
            };
            return Object.keys(e).forEach((t => {
                r = { ...r,
                    [t]: e[t]
                }
            })), r
        }
        warnOnInvalidChildren(e, t) {
            return vx(_x.some((t => e.type === t)), "function" == typeof e.type ? "You may be attempting to nest <Helmet> components within each other, which is not allowed. Refer to our API for more information." : `Only elements types ${_x.join(", ")} are allowed. Helmet does not support rendering <${e.type}> elements. Refer to our API for more information.`), vx(!t || "string" == typeof t || Array.isArray(t) && !t.some((e => "string" != typeof e)), `Helmet expects a string as a child of <${e.type}>. Did you forget to wrap your children in braces? ( <${e.type}>{\`\`}</${e.type}> ) Refer to our API for more information.`), !0
        }
        mapChildrenToProps(e, t) {
            let r = {};
            return p.Children.forEach(e, (e => {
                if (!e || !e.props) return;
                const {
                    children: n,
                    ...s
                } = e.props, i = Object.keys(s).reduce(((e, t) => (e[Px[t] || t] = s[t], e)), {});
                let {
                    type: o
                } = e;
                switch ("symbol" == typeof o ? o = o.toString() : this.warnOnInvalidChildren(e, n), o) {
                    case "Symbol(react.fragment)":
                        t = this.mapChildrenToProps(n, t);
                        break;
                    case "link":
                    case "meta":
                    case "noscript":
                    case "script":
                    case "style":
                        r = this.flattenArrayTypeChildren(e, r, i, n);
                        break;
                    default:
                        t = this.mapObjectTypeChildren(e, t, i, n)
                }
            })), this.mapArrayTypeChildrenToProps(r, t)
        }
        render() {
            const {
                children: e,
                ...t
            } = this.props;
            let r = { ...t
                },
                {
                    helmetData: n
                } = t;
            if (e && (r = this.mapChildrenToProps(e, r)), n && !(n instanceof tw)) {
                n = new tw(n.context, !0), delete r.helmetData
            }
            return n ? p.createElement(cw, { ...r,
                context: n.value
            }) : p.createElement(rw.Consumer, null, (e => p.createElement(cw, { ...r,
                context: e
            })))
        }
    }, n(t, "defaultProps", {
        defer: !0,
        encodeSpecialCharacters: !0,
        prioritizeSeoTags: !1
    }), t);
const dw = ({
        title: e,
        description: t,
        keywords: r,
        image: n,
        url: s,
        type: i = "website",
        noindex: o = !1
    }) => {
        const a = "Nynexa Foundation",
            l = e ? `${e} | ${a}` : a,
            c = t || "The Nynexa Foundation is dedicated to advancing humanity through groundbreaking research, strategic investments, and educational initiatives.",
            u = n || "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&q=80",
            d = s || "https://nynexafoundation.org";
        return T.jsxs(uw, {
            children: [T.jsx("title", {
                children: l
            }), T.jsx("meta", {
                name: "description",
                content: c
            }), r && T.jsx("meta", {
                name: "keywords",
                content: r
            }), o && T.jsx("meta", {
                name: "robots",
                content: "noindex, nofollow"
            }), T.jsx("meta", {
                property: "og:type",
                content: i
            }), T.jsx("meta", {
                property: "og:url",
                content: d
            }), T.jsx("meta", {
                property: "og:title",
                content: l
            }), T.jsx("meta", {
                property: "og:description",
                content: c
            }), T.jsx("meta", {
                property: "og:image",
                content: u
            }), T.jsx("meta", {
                property: "twitter:card",
                content: "summary_large_image"
            }), T.jsx("meta", {
                property: "twitter:url",
                content: d
            }), T.jsx("meta", {
                property: "twitter:title",
                content: l
            }), T.jsx("meta", {
                property: "twitter:description",
                content: c
            }), T.jsx("meta", {
                property: "twitter:image",
                content: u
            }), T.jsx("link", {
                rel: "canonical",
                href: d
            })]
        })
    },
    hw = () => T.jsxs(ux, {
        children: [T.jsx(dw, {
            title: "Privacy Policy",
            description: "Learn about the Nynexa Foundation's privacy practices, how we collect, use, and protect your personal information.",
            keywords: "Nynexa Foundation privacy policy, data protection, GDPR compliance, personal information, privacy practices"
        }), T.jsx(dx, {
            title: "Privacy Policy",
            subtitle: "Our commitment to protecting your privacy",
            backgroundImage: "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=1920&q=80"
        }), T.jsxs("div", {
            className: "container mx-auto px-4 py-12",
            children: [T.jsx(hx, {
                overrides: {
                    "privacy-policy": "Privacy Policy"
                }
            }), T.jsx("div", {
                className: "max-w-4xl mx-auto",
                children: T.jsxs(Pa.div, {
                    initial: {
                        opacity: 0,
                        y: 20
                    },
                    whileInView: {
                        opacity: 1,
                        y: 0
                    },
                    viewport: {
                        once: !0
                    },
                    transition: {
                        duration: .5
                    },
                    className: "space-y-8 prose prose-lg max-w-none",
                    children: [T.jsxs("p", {
                        className: "text-lg text-gray-600",
                        children: ["Last Updated: ", (new Date).toLocaleDateString("en-US", {
                            month: "long",
                            day: "numeric",
                            year: "numeric"
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Introduction"
                        }), T.jsxs("p", {
                            children: ['The Nynexa Foundation ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website at ', " ", T.jsx("a", {
                                href: "https://nynexafoundation.org",
                                className: "text-black font-medium underline",
                                children: "nynexafoundation.org"
                            }), " ", '(the "Site") or engage with our services.']
                        }), T.jsx("p", {
                            children: 'We reserve the right to make changes to this Privacy Policy at any time and for any reason. We will alert you about any changes by updating the "Last Updated" date of this Privacy Policy. You are encouraged to periodically review this Privacy Policy to stay informed of updates.'
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Information We Collect"
                        }), T.jsx("h3", {
                            className: "text-xl font-semibold text-gray-900 mt-6",
                            children: "Personal Information"
                        }), T.jsx("p", {
                            children: "We may collect personal information that you voluntarily provide to us when you:"
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsx("li", {
                                children: "Register for an account"
                            }), T.jsx("li", {
                                children: "Sign up for our newsletter"
                            }), T.jsx("li", {
                                children: "Make a donation"
                            }), T.jsx("li", {
                                children: "Fill out a contact form"
                            }), T.jsx("li", {
                                children: "Apply for programs or funding"
                            }), T.jsx("li", {
                                children: "Participate in surveys or research"
                            })]
                        }), T.jsx("p", {
                            children: "The personal information we may collect includes:"
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsx("li", {
                                children: "Name"
                            }), T.jsx("li", {
                                children: "Email address"
                            }), T.jsx("li", {
                                children: "Mailing address"
                            }), T.jsx("li", {
                                children: "Phone number"
                            }), T.jsx("li", {
                                children: "Demographic information"
                            }), T.jsx("li", {
                                children: "Payment information (for donations)"
                            }), T.jsx("li", {
                                children: "Professional background (for applications)"
                            }), T.jsx("li", {
                                children: "Educational information (for applications)"
                            })]
                        }), T.jsx("h3", {
                            className: "text-xl font-semibold text-gray-900 mt-6",
                            children: "Automatically Collected Information"
                        }), T.jsx("p", {
                            children: "When you access our Site, we may automatically collect certain information about your device, including:"
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsx("li", {
                                children: "IP address"
                            }), T.jsx("li", {
                                children: "Browser type"
                            }), T.jsx("li", {
                                children: "Operating system"
                            }), T.jsx("li", {
                                children: "Device information"
                            }), T.jsx("li", {
                                children: "Pages visited"
                            }), T.jsx("li", {
                                children: "Time and date of visits"
                            }), T.jsx("li", {
                                children: "Referring website"
                            }), T.jsx("li", {
                                children: "Other statistics"
                            })]
                        }), T.jsxs("p", {
                            children: ["This information is collected using cookies, web beacons, and other tracking technologies. For more information about our use of cookies, please see our ", " ", T.jsx(c, {
                                to: "/cookie-policy",
                                className: "text-black font-medium underline",
                                children: "Cookie Policy"
                            }), "."]
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "How We Use Your Information"
                        }), T.jsx("p", {
                            children: "We may use the information we collect for various purposes, including:"
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsx("li", {
                                children: "Providing, maintaining, and improving our Site and services"
                            }), T.jsx("li", {
                                children: "Processing donations and sending receipts"
                            }), T.jsx("li", {
                                children: "Sending newsletters and updates about our work"
                            }), T.jsx("li", {
                                children: "Responding to inquiries and providing support"
                            }), T.jsx("li", {
                                children: "Evaluating applications for programs and funding"
                            }), T.jsx("li", {
                                children: "Conducting research and analysis to better understand our audience"
                            }), T.jsx("li", {
                                children: "Complying with legal obligations"
                            }), T.jsx("li", {
                                children: "Preventing fraudulent activity"
                            }), T.jsx("li", {
                                children: "Protecting our rights and the rights of others"
                            })]
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Disclosure of Your Information"
                        }), T.jsx("p", {
                            children: "We may share your information with third parties in certain situations, including:"
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsx("li", {
                                children: "With service providers who perform services on our behalf"
                            }), T.jsx("li", {
                                children: "With partner organizations for collaborative programs (with your consent)"
                            }), T.jsx("li", {
                                children: "When required by law or to protect our rights"
                            }), T.jsx("li", {
                                children: "In connection with a merger, acquisition, or sale of assets"
                            }), T.jsx("li", {
                                children: "With your consent or at your direction"
                            })]
                        }), T.jsx("p", {
                            children: "We do not sell, rent, or trade your personal information to third parties for marketing purposes."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Your Privacy Rights"
                        }), T.jsx("p", {
                            children: "Depending on your location, you may have certain rights regarding your personal information, including:"
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsx("li", {
                                children: "The right to access personal information we hold about you"
                            }), T.jsx("li", {
                                children: "The right to request correction of inaccurate information"
                            }), T.jsx("li", {
                                children: "The right to request deletion of your information"
                            }), T.jsx("li", {
                                children: "The right to restrict or object to processing"
                            }), T.jsx("li", {
                                children: "The right to data portability"
                            }), T.jsx("li", {
                                children: "The right to withdraw consent"
                            })]
                        }), T.jsx("p", {
                            children: 'To exercise these rights, please contact us using the information provided in the "Contact Us" section below.'
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Data Security"
                        }), T.jsx("p", {
                            children: "We implement appropriate technical and organizational measures to protect your personal information from unauthorized access, disclosure, alteration, or destruction. However, no data transmission over the Internet or storage system can be guaranteed to be 100% secure. If you have reason to believe that your interaction with us is no longer secure, please immediately notify us using the contact information provided below."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Third-Party Websites"
                        }), T.jsx("p", {
                            children: "Our Site may contain links to third-party websites that are not owned or controlled by us. We have no control over, and assume no responsibility for, the content, privacy policies, or practices of any third-party websites or services. We encourage you to be aware when you leave our Site and to read the privacy policies of each website you visit."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Children's Privacy"
                        }), T.jsx("p", {
                            children: "Our Site is not intended for children under the age of 16. We do not knowingly collect personal information from children under 16. If you are a parent or guardian and believe that your child has provided us with personal information, please contact us, and we will take steps to delete such information."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "International Data Transfers"
                        }), T.jsx("p", {
                            children: "Your information may be transferred to, and maintained on, computers located outside of your state, province, country, or other governmental jurisdiction where the data protection laws may differ from those in your jurisdiction. If you are located outside the United States and choose to provide information to us, please note that we transfer the information to the United States and process it there."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Contact Us"
                        }), T.jsx("p", {
                            children: "If you have any questions or concerns about this Privacy Policy or our privacy practices, please contact us at:"
                        }), T.jsxs("div", {
                            className: "mt-2",
                            children: [T.jsx("p", {
                                children: "Nynexa Foundation"
                            }), T.jsx("p", {
                                children: "123 Innovation Way"
                            }), T.jsx("p", {
                                children: "New York, NY 10001"
                            }), T.jsx("p", {
                                children: "United States"
                            }), T.jsx("p", {
                                children: T.jsx("a", {
                                    href: "mailto:privacy@nynexafoundation.org",
                                    className: "text-black font-medium underline",
                                    children: "privacy@nynexafoundation.org"
                                })
                            })]
                        })]
                    })]
                })
            })]
        })]
    }),
    pw = () => T.jsxs(ux, {
        children: [T.jsx(dw, {
            title: "Terms of Use",
            description: "Review the Nynexa Foundation's Terms of Use, which govern your access to and use of our website and services.",
            keywords: "Nynexa Foundation terms, terms of use, terms and conditions, user agreement, legal terms"
        }), T.jsx(dx, {
            title: "Terms of Use",
            subtitle: "Guidelines for using our website and services",
            backgroundImage: "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=1920&q=80"
        }), T.jsxs("div", {
            className: "container mx-auto px-4 py-12",
            children: [T.jsx(hx, {
                overrides: {
                    "terms-of-use": "Terms of Use"
                }
            }), T.jsx("div", {
                className: "max-w-4xl mx-auto",
                children: T.jsxs(Pa.div, {
                    initial: {
                        opacity: 0,
                        y: 20
                    },
                    whileInView: {
                        opacity: 1,
                        y: 0
                    },
                    viewport: {
                        once: !0
                    },
                    transition: {
                        duration: .5
                    },
                    className: "space-y-8 prose prose-lg max-w-none",
                    children: [T.jsxs("p", {
                        className: "text-lg text-gray-600",
                        children: ["Last Updated: ", (new Date).toLocaleDateString("en-US", {
                            month: "long",
                            day: "numeric",
                            year: "numeric"
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "1. Acceptance of Terms"
                        }), T.jsxs("p", {
                            children: ["Welcome to the Nynexa Foundation website. By accessing and using our website at", " ", T.jsx("a", {
                                href: "https://nynexafoundation.org",
                                className: "text-black font-medium underline",
                                children: "nynexafoundation.org"
                            }), " ", '(the "Site"), you accept and agree to be bound by these Terms of Use. If you do not agree to these Terms of Use, please do not use our Site.']
                        }), T.jsx("p", {
                            children: "We reserve the right to change these Terms of Use at any time without prior notice. Your continued use of the Site following the posting of changes to these Terms of Use will be considered your acceptance of those changes."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "2. Intellectual Property Rights"
                        }), T.jsx("p", {
                            children: "The Site and its entire content, features, and functionality (including but not limited to all information, text, images, videos, and the design, selection, and arrangement thereof) are owned by the Nynexa Foundation, its licensors, or other providers of such material, and are protected by United States and international copyright, trademark, patent, trade secret, and other intellectual property or proprietary rights laws."
                        }), T.jsx("p", {
                            children: "These Terms of Use permit you to use the Site for your personal, non-commercial use only. You may not reproduce, distribute, modify, create derivative works of, publicly display, publicly perform, republish, download, store, or transmit any of the material on our Site, except as follows:"
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsx("li", {
                                children: "Your computer may temporarily store copies of such materials in RAM incidental to your accessing and viewing those materials."
                            }), T.jsx("li", {
                                children: "You may store files that are automatically cached by your web browser for display enhancement purposes."
                            }), T.jsx("li", {
                                children: "You may print or download one copy of a reasonable number of pages of the Site for your own personal, non-commercial use and not for further reproduction, publication, or distribution."
                            }), T.jsx("li", {
                                children: "If we provide social media features with certain content, you may take such actions as are enabled by such features."
                            })]
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "3. Prohibited Uses"
                        }), T.jsx("p", {
                            children: "You may use the Site only for lawful purposes and in accordance with these Terms of Use. You agree not to use the Site:"
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsx("li", {
                                children: "In any way that violates any applicable federal, state, local, or international law or regulation."
                            }), T.jsx("li", {
                                children: "For the purpose of exploiting, harming, or attempting to exploit or harm minors in any way."
                            }), T.jsx("li", {
                                children: "To send, knowingly receive, upload, download, use, or re-use any material that does not comply with the standards set out in these Terms of Use."
                            }), T.jsx("li", {
                                children: 'To transmit, or procure the sending of, any advertising or promotional material, including any "junk mail," "chain letter," "spam," or any other similar solicitation.'
                            }), T.jsx("li", {
                                children: "To impersonate or attempt to impersonate the Nynexa Foundation, a Nynexa Foundation employee, another user, or any other person or entity."
                            }), T.jsx("li", {
                                children: "To engage in any other conduct that restricts or inhibits anyone's use or enjoyment of the Site, or which may harm the Nynexa Foundation or users of the Site or expose them to liability."
                            })]
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "4. User Contributions"
                        }), T.jsx("p", {
                            children: 'The Site may contain message boards, chat rooms, personal profiles, forums, bulletin boards, and other interactive features (collectively, "Interactive Services") that allow users to post, submit, publish, display, or transmit to other users or other persons (hereinafter, "post") content or materials (collectively, "User Contributions") on or through the Site.'
                        }), T.jsx("p", {
                            children: "All User Contributions must comply with the Content Standards set out in these Terms of Use. Any User Contribution you post to the Site will be considered non-confidential and non-proprietary. By providing any User Contribution on the Site, you grant us and our affiliates and service providers, and each of their respective licensees, successors, and assigns the right to use, reproduce, modify, perform, display, distribute, and otherwise disclose to third parties any such material."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "5. Content Standards"
                        }), T.jsx("p", {
                            children: "These content standards apply to any and all User Contributions and use of Interactive Services. User Contributions must in their entirety comply with all applicable federal, state, local, and international laws and regulations."
                        }), T.jsx("p", {
                            children: "Without limiting the foregoing, User Contributions must not:"
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsx("li", {
                                children: "Contain any material that is defamatory, obscene, indecent, abusive, offensive, harassing, violent, hateful, inflammatory, or otherwise objectionable."
                            }), T.jsx("li", {
                                children: "Promote sexually explicit or pornographic material, violence, or discrimination based on race, sex, religion, nationality, disability, sexual orientation, or age."
                            }), T.jsx("li", {
                                children: "Infringe any patent, trademark, trade secret, copyright, or other intellectual property or other rights of any other person."
                            }), T.jsx("li", {
                                children: "Violate the legal rights (including the rights of publicity and privacy) of others or contain any material that could give rise to any civil or criminal liability under applicable laws or regulations."
                            }), T.jsx("li", {
                                children: "Be likely to deceive any person."
                            }), T.jsx("li", {
                                children: "Promote any illegal activity, or advocate, promote, or assist any unlawful act."
                            }), T.jsx("li", {
                                children: "Impersonate any person, or misrepresent your identity or affiliation with any person or organization."
                            }), T.jsx("li", {
                                children: "Involve commercial activities or sales, such as contests, sweepstakes, and other sales promotions, barter, or advertising."
                            }), T.jsx("li", {
                                children: "Give the impression that they emanate from or are endorsed by us or any other person or entity, if this is not the case."
                            })]
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "6. Reliance on Information Posted"
                        }), T.jsx("p", {
                            children: "The information presented on or through the Site is made available solely for general information purposes. We do not warrant the accuracy, completeness, or usefulness of this information. Any reliance you place on such information is strictly at your own risk. We disclaim all liability and responsibility arising from any reliance placed on such materials by you or any other visitor to the Site, or by anyone who may be informed of any of its contents."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "7. Links to Other Websites"
                        }), T.jsx("p", {
                            children: "The Site may contain links to other websites that are not operated by us. If you click on a third-party link, you will be directed to that third party's site. We strongly advise you to review the Privacy Policy and terms of service of every site you visit."
                        }), T.jsx("p", {
                            children: "We have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services. We do not warrant or make any representations regarding the use or the results of the use of the materials on any linked sites in terms of their correctness, accuracy, reliability, or otherwise."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "8. Disclaimer of Warranties"
                        }), T.jsx("p", {
                            children: "You understand that we cannot and do not guarantee or warrant that files available for downloading from the internet or the Site will be free of viruses or other destructive code. You are responsible for implementing sufficient procedures and checkpoints to satisfy your particular requirements for anti-virus protection and accuracy of data input and output, and for maintaining a means external to our site for any reconstruction of any lost data."
                        }), T.jsx("p", {
                            children: "TO THE FULLEST EXTENT PROVIDED BY LAW, WE WILL NOT BE LIABLE FOR ANY LOSS OR DAMAGE CAUSED BY A DISTRIBUTED DENIAL-OF-SERVICE ATTACK, VIRUSES, OR OTHER TECHNOLOGICALLY HARMFUL MATERIAL THAT MAY INFECT YOUR COMPUTER EQUIPMENT, COMPUTER PROGRAMS, DATA, OR OTHER PROPRIETARY MATERIAL DUE TO YOUR USE OF THE SITE OR ANY SERVICES OR ITEMS OBTAINED THROUGH THE SITE OR TO YOUR DOWNLOADING OF ANY MATERIAL POSTED ON IT, OR ON ANY WEBSITE LINKED TO IT."
                        }), T.jsx("p", {
                            children: 'YOUR USE OF THE SITE, ITS CONTENT, AND ANY SERVICES OR ITEMS OBTAINED THROUGH THE SITE IS AT YOUR OWN RISK. THE SITE, ITS CONTENT, AND ANY SERVICES OR ITEMS OBTAINED THROUGH THE SITE ARE PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS, WITHOUT ANY WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED.'
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "9. Limitation of Liability"
                        }), T.jsx("p", {
                            children: "TO THE FULLEST EXTENT PROVIDED BY LAW, IN NO EVENT WILL THE NYNEXA FOUNDATION, ITS AFFILIATES, OR THEIR LICENSORS, SERVICE PROVIDERS, EMPLOYEES, AGENTS, OFFICERS, OR DIRECTORS BE LIABLE FOR DAMAGES OF ANY KIND, UNDER ANY LEGAL THEORY, ARISING OUT OF OR IN CONNECTION WITH YOUR USE, OR INABILITY TO USE, THE SITE, ANY WEBSITES LINKED TO IT, ANY CONTENT ON THE SITE OR SUCH OTHER WEBSITES, INCLUDING ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "10. Indemnification"
                        }), T.jsx("p", {
                            children: "You agree to defend, indemnify, and hold harmless the Nynexa Foundation, its affiliates, licensors, and service providers, and its and their respective officers, directors, employees, contractors, agents, licensors, suppliers, successors, and assigns from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses, or fees (including reasonable attorneys' fees) arising out of or relating to your violation of these Terms of Use or your use of the Site."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "11. Governing Law"
                        }), T.jsx("p", {
                            children: "These Terms of Use and any dispute or claim arising out of, or related to, them, their subject matter, or their formation shall be governed by and construed in accordance with the laws of the State of New York, without giving effect to any choice or conflict of law provisions."
                        }), T.jsx("p", {
                            children: "Any legal suit, action, or proceeding arising out of, or related to, these Terms of Use or the Site shall be instituted exclusively in the federal courts of the United States or the courts of the State of New York. You waive any and all objections to the exercise of jurisdiction over you by such courts and to venue in such courts."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "12. Severability"
                        }), T.jsx("p", {
                            children: "If any provision of these Terms of Use is held by a court or other tribunal of competent jurisdiction to be invalid, illegal, or unenforceable for any reason, such provision shall be eliminated or limited to the minimum extent such that the remaining provisions of the Terms of Use will continue in full force and effect."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "13. Contact Information"
                        }), T.jsx("p", {
                            children: "If you have any questions or concerns about these Terms of Use, please contact us at:"
                        }), T.jsxs("div", {
                            className: "mt-2",
                            children: [T.jsx("p", {
                                children: "Nynexa Foundation"
                            }), T.jsx("p", {
                                children: "123 Innovation Way"
                            }), T.jsx("p", {
                                children: "New York, NY 10001"
                            }), T.jsx("p", {
                                children: "United States"
                            }), T.jsx("p", {
                                children: T.jsx("a", {
                                    href: "mailto:legal@nynexafoundation.org",
                                    className: "text-black font-medium underline",
                                    children: "legal@nynexafoundation.org"
                                })
                            })]
                        })]
                    })]
                })
            })]
        })]
    }),
    fw = () => T.jsxs(ux, {
        children: [T.jsx(dw, {
            title: "Cookie Policy",
            description: "Learn about how the Nynexa Foundation uses cookies and similar technologies on our website.",
            keywords: "Nynexa Foundation cookie policy, cookies, tracking technologies, web beacons, privacy"
        }), T.jsx(dx, {
            title: "Cookie Policy",
            subtitle: "How we use cookies and similar technologies",
            backgroundImage: "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=1920&q=80"
        }), T.jsxs("div", {
            className: "container mx-auto px-4 py-12",
            children: [T.jsx(hx, {
                overrides: {
                    "cookie-policy": "Cookie Policy"
                }
            }), T.jsx("div", {
                className: "max-w-4xl mx-auto",
                children: T.jsxs(Pa.div, {
                    initial: {
                        opacity: 0,
                        y: 20
                    },
                    whileInView: {
                        opacity: 1,
                        y: 0
                    },
                    viewport: {
                        once: !0
                    },
                    transition: {
                        duration: .5
                    },
                    className: "space-y-8 prose prose-lg max-w-none",
                    children: [T.jsxs("p", {
                        className: "text-lg text-gray-600",
                        children: ["Last Updated: ", (new Date).toLocaleDateString("en-US", {
                            month: "long",
                            day: "numeric",
                            year: "numeric"
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Introduction"
                        }), T.jsxs("p", {
                            children: ['The Nynexa Foundation ("we," "our," or "us") uses cookies and similar technologies on our website at ', " ", T.jsx("a", {
                                href: "https://nynexafoundation.org",
                                className: "text-black font-medium underline",
                                children: "nynexafoundation.org"
                            }), " ", '(the "Site"). This Cookie Policy explains how we use cookies, what types of cookies we use, and how you can control them.']
                        }), T.jsx("p", {
                            children: "By using our Site, you consent to the use of cookies in accordance with this Cookie Policy. If you do not accept the use of cookies, please disable them as explained below, or refrain from using our Site."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "What Are Cookies?"
                        }), T.jsx("p", {
                            children: "Cookies are small text files that are stored on your device (computer, tablet, or mobile) when you visit websites. They are widely used to make websites work more efficiently, provide a better user experience, and provide information to the owners of the site."
                        }), T.jsx("p", {
                            children: 'Cookies can be "persistent" or "session" cookies. Persistent cookies remain on your device when you go offline, while session cookies are deleted as soon as you close your web browser.'
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Types of Cookies We Use"
                        }), T.jsx("p", {
                            children: "We use the following types of cookies on our Site:"
                        }), T.jsx("h3", {
                            className: "text-xl font-semibold text-gray-900 mt-6",
                            children: "1. Essential Cookies"
                        }), T.jsx("p", {
                            children: "These cookies are necessary for the operation of our Site. They enable core functionality such as security, network management, accessibility, and basic user preferences. You may disable these by changing your browser settings, but this may affect how the Site functions."
                        }), T.jsxs("table", {
                            className: "min-w-full bg-white border border-gray-200 mb-6",
                            children: [T.jsx("thead", {
                                children: T.jsxs("tr", {
                                    children: [T.jsx("th", {
                                        className: "py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700",
                                        children: "Cookie Name"
                                    }), T.jsx("th", {
                                        className: "py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700",
                                        children: "Purpose"
                                    }), T.jsx("th", {
                                        className: "py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700",
                                        children: "Duration"
                                    })]
                                })
                            }), T.jsxs("tbody", {
                                children: [T.jsxs("tr", {
                                    children: [T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "XSRF-TOKEN"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "Used for security purposes to prevent cross-site request forgery"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "Session"
                                    })]
                                }), T.jsxs("tr", {
                                    className: "bg-gray-50",
                                    children: [T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "session"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "Maintains user session information"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "Session"
                                    })]
                                })]
                            })]
                        }), T.jsx("h3", {
                            className: "text-xl font-semibold text-gray-900 mt-6",
                            children: "2. Performance and Analytics Cookies"
                        }), T.jsx("p", {
                            children: "These cookies collect information about how visitors use our Site, such as which pages they visit most often and if they receive error messages. The information collected is aggregated and anonymous. We use this data to improve our Site's performance."
                        }), T.jsxs("table", {
                            className: "min-w-full bg-white border border-gray-200 mb-6",
                            children: [T.jsx("thead", {
                                children: T.jsxs("tr", {
                                    children: [T.jsx("th", {
                                        className: "py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700",
                                        children: "Cookie Name"
                                    }), T.jsx("th", {
                                        className: "py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700",
                                        children: "Purpose"
                                    }), T.jsx("th", {
                                        className: "py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700",
                                        children: "Duration"
                                    })]
                                })
                            }), T.jsxs("tbody", {
                                children: [T.jsxs("tr", {
                                    children: [T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "_ga"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "Used by Google Analytics to distinguish users"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "2 years"
                                    })]
                                }), T.jsxs("tr", {
                                    className: "bg-gray-50",
                                    children: [T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "_gid"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "Used by Google Analytics to distinguish users"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "24 hours"
                                    })]
                                }), T.jsxs("tr", {
                                    children: [T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "_gat"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "Used by Google Analytics to throttle request rate"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "1 minute"
                                    })]
                                })]
                            })]
                        }), T.jsx("h3", {
                            className: "text-xl font-semibold text-gray-900 mt-6",
                            children: "3. Functionality Cookies"
                        }), T.jsx("p", {
                            children: "These cookies allow our Site to remember choices you make (such as your username, language preference, or region) and provide enhanced, personalized features. They may be set by us or by third-party providers whose services we have added to our pages."
                        }), T.jsxs("table", {
                            className: "min-w-full bg-white border border-gray-200 mb-6",
                            children: [T.jsx("thead", {
                                children: T.jsxs("tr", {
                                    children: [T.jsx("th", {
                                        className: "py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700",
                                        children: "Cookie Name"
                                    }), T.jsx("th", {
                                        className: "py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700",
                                        children: "Purpose"
                                    }), T.jsx("th", {
                                        className: "py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700",
                                        children: "Duration"
                                    })]
                                })
                            }), T.jsxs("tbody", {
                                children: [T.jsxs("tr", {
                                    children: [T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "preferredTheme"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "Remembers your preferred theme (light/dark)"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "1 year"
                                    })]
                                }), T.jsxs("tr", {
                                    className: "bg-gray-50",
                                    children: [T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "language"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "Remembers your language preference"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "1 year"
                                    })]
                                })]
                            })]
                        }), T.jsx("h3", {
                            className: "text-xl font-semibold text-gray-900 mt-6",
                            children: "4. Targeting/Advertising Cookies"
                        }), T.jsx("p", {
                            children: "These cookies record your visits to our Site, the pages you have visited, and the links you have followed. We use this information to make our Site and the advertising displayed on it more relevant to your interests. We may also share this information with third parties for this purpose."
                        }), T.jsxs("table", {
                            className: "min-w-full bg-white border border-gray-200 mb-6",
                            children: [T.jsx("thead", {
                                children: T.jsxs("tr", {
                                    children: [T.jsx("th", {
                                        className: "py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700",
                                        children: "Cookie Name"
                                    }), T.jsx("th", {
                                        className: "py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700",
                                        children: "Purpose"
                                    }), T.jsx("th", {
                                        className: "py-2 px-4 border-b border-gray-200 bg-gray-50 text-left text-sm font-semibold text-gray-700",
                                        children: "Duration"
                                    })]
                                })
                            }), T.jsxs("tbody", {
                                children: [T.jsxs("tr", {
                                    children: [T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "_fbp"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "Used by Facebook to deliver advertisements"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "3 months"
                                    })]
                                }), T.jsxs("tr", {
                                    className: "bg-gray-50",
                                    children: [T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "_ttp"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "Used for marketing attribution"
                                    }), T.jsx("td", {
                                        className: "py-2 px-4 border-b border-gray-200 text-sm",
                                        children: "1 year"
                                    })]
                                })]
                            })]
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Third-Party Cookies"
                        }), T.jsx("p", {
                            children: "In addition to our own cookies, we may also use various third-party cookies to report usage statistics of the Site, deliver advertisements, and so on. These cookies may include:"
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsx("li", {
                                children: "Google Analytics cookies for analyzing site traffic and user behavior"
                            }), T.jsx("li", {
                                children: "Social media cookies from platforms like Facebook, Twitter, and LinkedIn to enable sharing functionality"
                            }), T.jsx("li", {
                                children: "Advertising cookies from our marketing partners"
                            }), T.jsx("li", {
                                children: "Payment processor cookies for donation processing"
                            })]
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Other Tracking Technologies"
                        }), T.jsx("p", {
                            children: "In addition to cookies, we may use other similar technologies on our Site, such as:"
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsxs("li", {
                                children: [T.jsx("strong", {
                                    children: "Web Beacons:"
                                }), " Small transparent graphic images that are used to track user behavior and engagement"]
                            }), T.jsxs("li", {
                                children: [T.jsx("strong", {
                                    children: "Pixels:"
                                }), " Tiny code snippets in our emails that allow us to know if an email has been opened"]
                            }), T.jsxs("li", {
                                children: [T.jsx("strong", {
                                    children: "Local Storage:"
                                }), " Similar to cookies but can store larger amounts of data"]
                            })]
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Managing Cookies"
                        }), T.jsx("p", {
                            children: 'Most web browsers allow you to control cookies through their settings. You can typically find these settings in the "Options," "Preferences," or "Settings" menu of your browser. You can also:'
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsx("li", {
                                children: "Delete cookies from your device"
                            }), T.jsx("li", {
                                children: "Block cookies by activating the setting on your browser that allows you to refuse all or some cookies"
                            }), T.jsx("li", {
                                children: "Set your browser to notify you when you receive a cookie"
                            })]
                        }), T.jsx("p", {
                            className: "mt-4",
                            children: "Please note that if you choose to block or delete cookies, you may not be able to access certain areas or features of our Site, and some services may not function properly."
                        }), T.jsx("h3", {
                            className: "text-xl font-semibold text-gray-900 mt-6",
                            children: "How to Manage Cookies in Different Browsers"
                        }), T.jsxs("ul", {
                            className: "list-disc pl-6 space-y-2",
                            children: [T.jsxs("li", {
                                children: [T.jsx("strong", {
                                    children: "Google Chrome:"
                                }), " Settings > Privacy and security > Cookies and other site data"]
                            }), T.jsxs("li", {
                                children: [T.jsx("strong", {
                                    children: "Mozilla Firefox:"
                                }), " Options > Privacy & Security > Cookies and Site Data"]
                            }), T.jsxs("li", {
                                children: [T.jsx("strong", {
                                    children: "Safari:"
                                }), " Preferences > Privacy > Cookies and website data"]
                            }), T.jsxs("li", {
                                children: [T.jsx("strong", {
                                    children: "Microsoft Edge:"
                                }), " Settings > Cookies and site permissions > Cookies and site data"]
                            })]
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Do Not Track Signals"
                        }), T.jsx("p", {
                            children: 'Some browsers have a "Do Not Track" feature that lets you tell websites that you do not want to have your online activities tracked. We currently do not respond to "Do Not Track" signals because there is not yet a common understanding of how to interpret these signals across the industry. However, you can disable cookies as described above.'
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "Updates to This Cookie Policy"
                        }), T.jsx("p", {
                            children: "We may update this Cookie Policy from time to time to reflect changes in technology, law, or our data practices. Any changes will become effective when we post the revised Cookie Policy on our Site. Your continued use of our Site following these changes means that you accept the revised Cookie Policy."
                        })]
                    }), T.jsxs("section", {
                        children: [T.jsx("h2", {
                            className: "text-2xl font-bold text-gray-900",
                            children: "More Information"
                        }), T.jsxs("p", {
                            children: ["For more information about how we protect your personal information, please review our ", " ", T.jsx(c, {
                                to: "/privacy-policy",
                                className: "text-black font-medium underline",
                                children: "Privacy Policy"
                            }), "."]
                        }), T.jsx("p", {
                            children: "If you have any questions or concerns about our use of cookies, please contact us at:"
                        }), T.jsxs("div", {
                            className: "mt-2",
                            children: [T.jsx("p", {
                                children: "Nynexa Foundation"
                            }), T.jsx("p", {
                                children: "123 Innovation Way"
                            }), T.jsx("p", {
                                children: "New York, NY 10001"
                            }), T.jsx("p", {
                                children: "United States"
                            }), T.jsx("p", {
                                children: T.jsx("a", {
                                    href: "mailto:privacy@nynexafoundation.org",
                                    className: "text-black font-medium underline",
                                    children: "privacy@nynexafoundation.org"
                                })
                            })]
                        })]
                    })]
                })
            })]
        })]
    }),
    mw = o.lazy((() => C((() =>
        import ("./HomePage-r3k_KD5L.js")), __vite__mapDeps([2, 1, 3, 4, 5, 6, 7, 8, 9])))),
    gw = o.lazy((() => C((() =>
        import ("./NewsPage-DW-E3f0q.js")), __vite__mapDeps([10, 1, 8, 4, 9, 11])))),
    yw = o.lazy((() => C((() =>
        import ("./ContactPage-Br1cbQZq.js")), __vite__mapDeps([12, 1, 13])))),
    vw = o.lazy((() => C((() =>
        import ("./NotFound-C03kZNmN.js")), __vite__mapDeps([14, 1])))),
    bw = o.lazy((() => C((() =>
        import ("./GovernanceLeadershipPage-8XYRwW08.js")), __vite__mapDeps([15, 1, 4, 16, 6, 17, 18, 5])))),
    xw = o.lazy((() => C((() =>
        import ("./VisionMissionPage-CeCR5xjZ.js")), __vite__mapDeps([19, 1])))),
    ww = o.lazy((() => C((() =>
        import ("./StoriesPage-CONwsZ32.js")), __vite__mapDeps([20, 1, 11, 13, 9])))),
    kw = o.lazy((() => C((() =>
        import ("./ReportsPage-ZPyHQw6c.js")), __vite__mapDeps([21, 1, 18])))),
    jw = o.lazy((() => C((() =>
        import ("./DonatePage-pkAiZeYW.js")), __vite__mapDeps([22, 1])))),
    Sw = o.lazy((() => C((() =>
        import ("./PartnersPage-fqi53bUE.js")), __vite__mapDeps([23, 3, 1])))),
    Tw = o.lazy((() => C((() =>
        import ("./CareersPage-KuRYqTpt.js")), __vite__mapDeps([24, 1, 11, 13])))),
    _w = o.lazy((() => C((() =>
        import ("./ResearchDevelopmentPage-BXWeFgbV.js")), __vite__mapDeps([25, 26, 7, 27, 28, 16, 6, 17, 1])))),
    Ew = o.lazy((() => C((() =>
        import ("./EducationStemPage-DaNNpYpM.js")), __vite__mapDeps([29, 26, 28, 6, 1])))),
    Pw = o.lazy((() => C((() =>
        import ("./BillionaireFundPage-BqFKLyDf.js")), __vite__mapDeps([30, 6, 16, 28, 27, 1]))));

function Cw() {
    return T.jsx(o.Suspense, {
        fallback: T.jsx(Ca, {
            fullScreen: !0,
            size: "lg",
            text: "Loading Nynexa Foundation..."
        }),
        children: T.jsx(T.Fragment, {
            children: T.jsxs(g, {
                children: [T.jsx(y, {
                    path: "/",
                    element: T.jsx(mw, {})
                }), T.jsx(y, {
                    path: "/about",
                    element: T.jsx(v, {
                        to: "/about/governance-leadership",
                        replace: !0
                    })
                }), T.jsx(y, {
                    path: "/about/governance-leadership",
                    element: T.jsx(bw, {})
                }), T.jsx(y, {
                    path: "/about/vision-mission",
                    element: T.jsx(xw, {})
                }), T.jsx(y, {
                    path: "/about/leadership",
                    element: T.jsx(v, {
                        to: "/about/governance-leadership",
                        replace: !0
                    })
                }), T.jsx(y, {
                    path: "/about/governance",
                    element: T.jsx(v, {
                        to: "/about/governance-leadership",
                        replace: !0
                    })
                }), T.jsx(y, {
                    path: "/about/partners",
                    element: T.jsx(v, {
                        to: "/get-involved/partners",
                        replace: !0
                    })
                }), T.jsx(y, {
                    path: "/about/careers",
                    element: T.jsx(v, {
                        to: "/get-involved/careers",
                        replace: !0
                    })
                }), T.jsx(y, {
                    path: "/about/approach",
                    element: T.jsx(v, {
                        to: "/about/vision-mission",
                        replace: !0
                    })
                }), T.jsx(y, {
                    path: "/impact",
                    element: T.jsx(v, {
                        to: "/impact/stories",
                        replace: !0
                    })
                }), T.jsx(y, {
                    path: "/impact/stories",
                    element: T.jsx(ww, {})
                }), T.jsx(y, {
                    path: "/impact/reports",
                    element: T.jsx(kw, {})
                }), T.jsx(y, {
                    path: "/get-involved",
                    element: T.jsx(v, {
                        to: "/get-involved/donate",
                        replace: !0
                    })
                }), T.jsx(y, {
                    path: "/get-involved/donate",
                    element: T.jsx(jw, {})
                }), T.jsx(y, {
                    path: "/get-involved/partners",
                    element: T.jsx(Sw, {})
                }), T.jsx(y, {
                    path: "/get-involved/careers",
                    element: T.jsx(Tw, {})
                }), T.jsx(y, {
                    path: "/work/research-development",
                    element: T.jsx(_w, {})
                }), T.jsx(y, {
                    path: "/work/education-stem",
                    element: T.jsx(Ew, {})
                }), T.jsx(y, {
                    path: "/work/billionaire-fund",
                    element: T.jsx(Pw, {})
                }), T.jsx(y, {
                    path: "/news",
                    element: T.jsx(gw, {})
                }), T.jsx(y, {
                    path: "/contact",
                    element: T.jsx(yw, {})
                }), T.jsx(y, {
                    path: "/privacy-policy",
                    element: T.jsx(hw, {})
                }), T.jsx(y, {
                    path: "/terms-of-use",
                    element: T.jsx(pw, {})
                }), T.jsx(y, {
                    path: "/cookie-policy",
                    element: T.jsx(fw, {})
                }), T.jsx(y, {
                    path: "*",
                    element: T.jsx(vw, {})
                })]
            })
        })
    })
}
const Ow = () => {
        if ("undefined" != typeof window)
            if (Jb()) {
                console.log("Navigation detected on Samsung device, ensuring content visibility");
                [0, 100, 300, 800, 1500].forEach((e => {
                    setTimeout((() => {
                        Xb();
                        document.querySelectorAll("section, main > div, article").forEach((e => {
                            e instanceof HTMLElement && (e.style.visibility = "visible", e.style.display = "block", e.style.opacity = "1")
                        }));
                        document.querySelectorAll("[data-motion], [data-animate]").forEach((e => {
                            e instanceof HTMLElement && (e.style.visibility = "visible", e.style.display = "block", e.style.opacity = "1")
                        }))
                    }), e)
                }))
            } else setTimeout((() => {}), 300)
    },
    Aw = () => {
        if ("undefined" == typeof window) return;
        const e = window.history.pushState;
        window.history.pushState = function() {
            e.apply(this, arguments), Ow()
        };
        const t = window.history.replaceState;
        window.history.replaceState = function() {
            t.apply(this, arguments), Ow()
        }, window.addEventListener("popstate", Ow), window.addEventListener("hashchange", Ow), window.addEventListener("load", (() => {
            Ow()
        })), "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", Ow) : Ow()
    };
window.React = p, "undefined" == typeof window && (p.useLayoutEffect = p.useEffect), "undefined" != typeof window && setTimeout((() => {
    Zb(), Aw()
}), 100);
const Nw = document.getElementById("root");
if (!Nw) throw new Error("Root element not found");
window.React = p || p;
try {
    E.createRoot(Nw).render(T.jsx(p.StrictMode, {
        children: T.jsx(qv, {
            publishableKey: "pk_test_cG9ldGljLW1hbnRpcy0zMS5jbGVyay5hY2NvdW50cy5kZXYk",
            appearance: {
                variables: {
                    colorPrimary: "black",
                    borderRadius: "0.375rem"
                },
                elements: {
                    formButtonPrimary: "bg-black hover:bg-black-800 text-white py-2 px-4 rounded-md",
                    card: "bg-white shadow-xl border border-gray-200 rounded-lg",
                    logoBox: "hidden",
                    logoImage: "hidden",
                    header: "text-xl text-center font-bold mb-4",
                    socialButtonsBlockButton: "border border-gray-300 bg-white hover:bg-gray-50 text-black",
                    formFieldLabel: "text-gray-700",
                    formFieldInput: "bg-white border border-gray-300 rounded-md focus:ring-2 focus:ring-black focus:border-transparent",
                    dividerLine: "bg-gray-200",
                    dividerText: "text-gray-500 mx-3",
                    footerActionLink: "text-black hover:text-gray-600 underline",
                    identityPreviewEditButtonIcon: "text-black",
                    alert: "rounded-lg"
                }
            },
            localization: {
                signIn: {
                    phoneCode: {
                        title: "Sign in to Nynexa Foundation"
                    },
                    start: {
                        title: "Sign in to Nynexa Foundation",
                        subtitle: "to continue to our platform"
                    }
                }
            },
            afterSignInUrl: "/",
            afterSignUpUrl: "/",
            children: T.jsx(nw, {
                children: T.jsx(b, {
                    children: T.jsx(Xu, {
                        children: T.jsx(Cw, {})
                    })
                })
            })
        })
    })), "undefined" != typeof window && setTimeout((() => {
        Zb(), Aw()
    }), 500)
} catch (Lw) {
    console.error("React render error:", Lw), Nw && (Nw.innerHTML = `\n      <div style="padding: 20px; font-family: system-ui, sans-serif;">\n        <h1>Something went wrong</h1>\n        <p>Please try refreshing the page or contact support if the issue persists.</p>\n        <pre>${Lw instanceof Error?Lw.message:String(Lw)}</pre>\n      </div>\n    `)
}
document.addEventListener("DOMContentLoaded", (function() {
    function e() {
        const e = document.querySelectorAll(".signin-button");
        console.log("SignIn buttons found:", e.length), e.forEach((e => {
            const t = e.closest(".flex.items-center");
            if (t) {
                const e = window.getComputedStyle(t);
                if (console.log("SignIn button parent display:", e.display), window.innerWidth >= 768) {
                    t.style.display = "flex";
                    let e = t.parentElement;
                    for (; e;) e.classList.contains("hidden") && (e.classList.remove("hidden"), e.classList.add("flex"), console.log("Fixed hidden ancestor:", e)), e.classList.contains("md:hidden") && (e.classList.remove("md:hidden"), e.classList.add("md:flex"), console.log("Fixed md:hidden ancestor:", e)), e = e.parentElement
                }
            }
        }))
    }
    e(), window.addEventListener("resize", e)
}));
export {
    uh as A, ih as B, mh as C, bh as G, Yv as I, Sh as L, Ph as M, dx as P, dw as S, Nh as T, Hs as a, B as b, ch as c, nh as d, kh as e, Yu as f, _h as g, Zv as h, ux as i, T as j, hx as k, Oh as l, Pa as m, hh as n, Ca as o, Th as p, Hh as q, cd as r, jr as s, td as t, A as u, Zu as v, Fu as w, yh as x, dh as y
};
//# sourceMappingURL=index-AQVjGcvK.js.map