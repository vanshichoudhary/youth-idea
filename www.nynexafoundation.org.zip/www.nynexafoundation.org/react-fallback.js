// This script is a last-resort fallback for React initialization
(function() {
    // Wait a bit for normal initialization to happen
    setTimeout(function() {
        const root = document.getElementById('root');
        // Only run if the root is empty (suggesting React failed to render)
        if (root && (!root.hasChildNodes() || (root.children.length === 1 && root.children[0].tagName === 'NOSCRIPT'))) {
            console.log('Fallback script activating - React may have failed to initialize');

            // Try to load React dynamically as a last resort
            const script = document.createElement('script');
            script.src = 'https://unpkg.com/react@18/umd/react.production.min.js';
            script.onload = function() {
                const domScript = document.createElement('script');
                domScript.src = 'https://unpkg.com/react-dom@18/umd/react-dom.production.min.js';
                domScript.onload = function() {
                    console.log('React loaded via fallback, attempting to render basic content');
                    root.innerHTML = `
            <div style="padding: 20px; font-family: system-ui, sans-serif;">
              <h1>Nynexa Foundation</h1>
              <p>We're experiencing technical difficulties. Please try refreshing the page.</p>
              <button onclick="window.location.reload()">Refresh Page</button>
            </div>
          `;
                };
                document.head.appendChild(domScript);
            };
            document.head.appendChild(script);
        }
    }, 5000); // Wait 5 seconds for normal initialization before trying fallback
})();