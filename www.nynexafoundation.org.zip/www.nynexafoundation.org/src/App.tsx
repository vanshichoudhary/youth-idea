import { Suspense, lazy } from "react";
import { useRoutes, Routes, Route, Navigate } from "react-router-dom";
import LoadingSpinner from "./components/shared/LoadingSpinner";
import PrivacyPolicyPage from "./pages/PrivacyPolicyPage";
import TermsOfUsePage from "./pages/TermsOfUsePage";
import CookiePolicyPage from "./pages/CookiePolicyPage";

// Lazy load all pages for better performance
const HomePage = lazy(() => import("./pages/HomePage"));
const NewsPage = lazy(() => import("./pages/NewsPage"));
const ContactPage = lazy(() => import("./pages/ContactPage"));
const NotFound = lazy(() => import("./components/shared/NotFound"));

// Lazy load about pages - only import existing pages
const GovernanceLeadershipPage = lazy(() => import("./pages/about/GovernanceLeadershipPage"));
const VisionMissionPage = lazy(() => import("./pages/about/VisionMissionPage"));

// Impact pages
const StoriesPage = lazy(() => import("./pages/impact/StoriesPage"));
const ReportsPage = lazy(() => import("./pages/impact/ReportsPage"));

// Get Involved pages
const DonatePage = lazy(() => import("./pages/get-involved/DonatePage"));
const PartnersPage = lazy(() => import("./pages/get-involved/PartnersPage"));
const CareersPage = lazy(() => import("./pages/get-involved/CareersPage"));

// Work section pages
const ResearchDevelopmentPage = lazy(() => import("./pages/work/ResearchDevelopmentPage"));
const EducationStemPage = lazy(() => import("./pages/work/EducationStemPage"));
const BillionaireFundPage = lazy(() => import("./pages/work/BillionaireFundPage"));

function App() {
  return (
    <Suspense
      fallback={
        <LoadingSpinner 
          fullScreen 
          size="lg" 
          text="Loading Nynexa Foundation..." 
        />
      }
    >
      <>
        <Routes>
          {/* Main routes */}
          <Route path="/" element={<HomePage />} />

          {/* About section */}
          <Route
            path="/about"
            element={<Navigate to="/about/governance-leadership" replace />}
          />
          <Route path="/about/governance-leadership" element={<GovernanceLeadershipPage />} />
          <Route path="/about/vision-mission" element={<VisionMissionPage />} />

          {/* Redirects for old URLs */}
          <Route path="/about/leadership" element={<Navigate to="/about/governance-leadership" replace />} />
          <Route path="/about/governance" element={<Navigate to="/about/governance-leadership" replace />} />
          <Route path="/about/partners" element={<Navigate to="/get-involved/partners" replace />} />
          <Route path="/about/careers" element={<Navigate to="/get-involved/careers" replace />} />
          <Route path="/about/approach" element={<Navigate to="/about/vision-mission" replace />} />

          {/* Impact section */}
          <Route
            path="/impact"
            element={<Navigate to="/impact/stories" replace />}
          />
          <Route path="/impact/stories" element={<StoriesPage />} />
          <Route path="/impact/reports" element={<ReportsPage />} />

          {/* Get Involved section */}
          <Route
            path="/get-involved"
            element={<Navigate to="/get-involved/donate" replace />}
          />
          <Route path="/get-involved/donate" element={<DonatePage />} />
          <Route path="/get-involved/partners" element={<PartnersPage />} />
          <Route path="/get-involved/careers" element={<CareersPage />} />

          {/* Work section */}
          <Route path="/work/research-development" element={<ResearchDevelopmentPage />} />
          <Route path="/work/education-stem" element={<EducationStemPage />} />
          <Route path="/work/billionaire-fund" element={<BillionaireFundPage />} />

          {/* News */}
          <Route path="/news" element={<NewsPage />} />

          {/* Contact */}
          <Route path="/contact" element={<ContactPage />} />

          {/* Footer Policy Pages */}
          <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
          <Route path="/terms-of-use" element={<TermsOfUsePage />} />
          <Route path="/cookie-policy" element={<CookiePolicyPage />} />

          {/* 404 page */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </>
    </Suspense>
  );
}

export default App;
