import React from "react";
import { motion } from "framer-motion";
import { ArrowRight, Calendar } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface NewsCardProps {
  title?: string;
  date?: string;
  excerpt?: string;
  imageUrl?: string;
  category?: string;
  link?: string;
  className?: string;
}

const NewsCard = ({
  title = "Nynexa Foundation Launches New STEM Education Initiative",
  date = "June 15, 2023",
  excerpt = "The Nynexa Foundation has announced a groundbreaking new program aimed at advancing STEM education across underserved communities worldwide.",
  imageUrl = "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80",
  category = "Education",
  link = "#",
  className,
}: NewsCardProps) => {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
      className={cn("h-full", className)}
    >
      <Card className="overflow-hidden h-full flex flex-col bg-white">
        <div className="relative h-48 overflow-hidden">
          <img
            src={imageUrl}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
          />
          <div className="absolute top-4 left-4 bg-purple-700 text-white text-xs font-semibold py-1 px-2 rounded">
            {category}
          </div>
        </div>

        <CardHeader>
          <div className="flex items-center text-sm text-gray-500 mb-2">
            <Calendar className="h-4 w-4 mr-1" />
            <span>{date}</span>
          </div>
          <CardTitle className="text-xl font-bold text-gray-800 line-clamp-2 hover:text-purple-700 transition-colors">
            {title}
          </CardTitle>
        </CardHeader>

        <CardContent className="flex-grow">
          <CardDescription className="text-gray-600 line-clamp-3">
            {excerpt}
          </CardDescription>
        </CardContent>

        <CardFooter className="pt-2">
          <a
            href={link}
            className="inline-flex items-center text-purple-700 font-medium hover:text-purple-900 transition-colors"
          >
            Read more
            <ArrowRight className="ml-2 h-4 w-4" />
          </a>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default NewsCard;
