import React from "react";
import { motion } from "framer-motion";
import { ArrowRight, Lightbulb, Landmark, GraduationCap } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { cn } from "@/lib/utils";

export interface PillarCardProps {
  title: string;
  description: string;
  icon?: "research" | "fund" | "education" | string;
  imageUrl?: string;
  linkUrl?: string;
  linkText?: string;
  className?: string;
}

const PillarCard = ({
  title = "Innovative R&D",
  description = "Pioneering research and development in longevity, artificial super intelligence, and sustainable technologies.",
  icon = "research",
  imageUrl,
  linkUrl = "#",
  linkText = "Learn More",
  className,
}: PillarCardProps) => {
  const getIcon = () => {
    switch (icon) {
      case "research":
        return <Lightbulb className="h-10 w-10 text-purple-600" />;
      case "fund":
        return <Landmark className="h-10 w-10 text-purple-600" />;
      case "education":
        return <GraduationCap className="h-10 w-10 text-purple-600" />;
      default:
        return <Lightbulb className="h-10 w-10 text-purple-600" />;
    }
  };

  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
      className={cn("h-full", className)}
    >
      <Card className="h-full flex flex-col overflow-hidden border-purple-100 bg-white">
        {imageUrl && (
          <div className="relative h-48 w-full overflow-hidden">
            <img
              src={imageUrl}
              alt={title}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          </div>
        )}
        <CardHeader className="pb-0">
          <div className="mb-4">{getIcon()}</div>
          <CardTitle className="text-2xl font-bold text-purple-900">
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-grow">
          <CardDescription className="text-base text-gray-600">
            {description}
          </CardDescription>
        </CardContent>
        <CardFooter>
          <a
            href={linkUrl}
            className="group inline-flex items-center text-purple-700 hover:text-purple-900 font-medium"
          >
            {linkText}
            <ArrowRight className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </a>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default PillarCard;
