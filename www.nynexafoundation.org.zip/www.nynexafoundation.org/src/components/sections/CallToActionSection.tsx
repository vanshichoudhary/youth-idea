import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, Handshake, ExternalLink, HeartHandshake } from "lucide-react";
import { motion } from "framer-motion";

interface CallToActionSectionProps {
  title?: string;
  description?: string;
  actions?: Array<{
    label: string;
    href: string;
    icon?: React.ReactNode;
    variant?: "default" | "secondary" | "outline";
  }>;
  backgroundColor?: string;
}

const CallToActionSection = ({
  title = "Join Our Mission",
  description = "Together, we can drive innovation and create positive change for generations to come.",
  actions = [
    {
      label: "Make a Donation",
      href: "/get-involved/donate",
      icon: <HeartHandshake className="mr-2 h-4 w-4" />,
      variant: "default",
    },
    {
      label: "Become a Partner",
      href: "/get-involved/partners",
      icon: <Handshake className="mr-2 h-4 w-4" />,
      variant: "outline",
    },
    {
      label: "Explore Initiatives", 
      href: "/work",
      icon: <ExternalLink className="mr-2 h-4 w-4" />,
      variant: "outline",
    },
  ],
  backgroundColor = "bg-black-900",
}: CallToActionSectionProps) => {
  return (
    <section
      className={`${backgroundColor} text-white py-16 px-4 md:py-20 md:px-8 lg:px-16 w-full`}
    >
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center"
        >
          <div>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="text-3xl md:text-4xl font-bold mb-4"
            >
              {title}
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-lg md:text-xl text-gray-300 mb-6 max-w-2xl"
            >
              {description}
            </motion.p>
          </div>

          <div className="flex flex-col sm:flex-row flex-wrap gap-4 justify-start lg:justify-end">
            {actions.map((action, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.1 + index * 0.1 }}
                className="mission-button-container"
              >
                <a 
                  href={action.href} 
                  className={`
                    inline-flex items-center px-6 py-3 rounded-lg font-medium shadow-lg transition-all duration-200
                    ${action.variant === "default" ? "bg-white text-black hover:bg-gray-200" : ""}
                    ${action.variant === "secondary" ? "bg-black-600 text-white hover:bg-black-500" : ""}
                    ${action.variant === "outline" ? "border-2 border-white text-white bg-transparent hover:bg-white hover:text-black" : ""}
                  `}
                >
                  {action.icon}
                  {action.label}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CallToActionSection;
