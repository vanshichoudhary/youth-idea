import React from "react";
import { motion, useAnimation } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { useEffect } from "react";

const IntroductionSection = () => {
  const controls = useAnimation();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  useEffect(() => {
    if (inView) {
      controls.start("visible");
    }
  }, [controls, inView]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  };

  return (
    <section className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          animate={controls}
          initial="hidden"
          variants={containerVariants}
          className="max-w-5xl mx-auto"
        >
          <motion.h2
            variants={itemVariants}
            className="text-4xl md:text-5xl font-bold text-black-800 mb-12 leading-tight max-w-3xl"
          >
            Shaping the Future of Humanity
          </motion.h2>

          <motion.p
            variants={itemVariants}
            className="text-xl md:text-2xl text-gray-700 mb-16 leading-relaxed max-w-3xl"
          >
            The Nynexa Foundation was established with a singular vision: to
            accelerate human progress through strategic investments in science,
            technology, and education.
          </motion.p>

          <motion.div
            variants={itemVariants}
            className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20"
          >
            <div className="bg-white rounded-xl p-8 shadow-md border border-gray-200 transition-transform duration-300 hover:-translate-y-2">
              <div className="bg-black-100 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <span className="text-xl font-bold text-black-800">01</span>
              </div>
              <h3 className="text-2xl font-bold text-black-800 mb-4">
                Identify
              </h3>
              <p className="text-gray-700">
                We identify critical global challenges where innovation can
                drive transformative change and create strategic opportunities for impact.
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-md border border-gray-200 transition-transform duration-300 hover:-translate-y-2">
              <div className="bg-black-100 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <span className="text-xl font-bold text-black-800">02</span>
              </div>
              <h3 className="text-2xl font-bold text-black-800 mb-4">
                Invest
              </h3>
              <p className="text-gray-700">
                We strategically invest resources in research, education,
                and collaborative initiatives to accelerate meaningful solutions.
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-md border border-gray-200 transition-transform duration-300 hover:-translate-y-2">
              <div className="bg-black-100 w-16 h-16 rounded-full flex items-center justify-center mb-6">
                <span className="text-xl font-bold text-black-800">03</span>
              </div>
              <h3 className="text-2xl font-bold text-black-800 mb-4">
                Impact
              </h3>
              <p className="text-gray-700">
                We measure and amplify our impact through scaling
                successful solutions globally and fostering sustainable change.
              </p>
            </div>
          </motion.div>

          <motion.div
            variants={itemVariants}
            className="mt-24 bg-black-900 text-white p-10 rounded-xl"
          >
            <blockquote className="text-3xl md:text-4xl font-light leading-tight max-w-4xl">
              "Our mission is to be the catalyst that transforms human potential
              into reality."
              <footer className="mt-8 text-base font-normal text-gray-300">
                — Rajnish Mani Tiwari, Founder of the Nynexa Foundation
              </footer>
            </blockquote>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default IntroductionSection;
