import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, ExternalLink } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const VideoHeroSection = () => {
  const [isVideoOpen, setIsVideoOpen] = useState(false);

  const textVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <section className="relative h-screen max-h-[800px] overflow-hidden">
      <div className="absolute inset-0 w-full h-full bg-[#000000]">
        {/* Dark abstract science video background */}
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover opacity-30 mix-blend-screen"
        >
          <source
            src="https://www.fordfoundation.org/wp-content/uploads/2025/01/website_cover_video_update_2025_final-_720.mp4"
            type="video/mp4"
          />
          Your browser does not support the video tag.
        </video>

        <div className="absolute inset-0 z-30 flex items-center">
          <div className="container mx-auto px-6 md:px-8">
            <motion.div
              className="max-w-3xl ml-0 text-left" 
              variants={textVariants}
              initial="hidden"
              animate="visible"
            >
              <motion.h1
                className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 md:mb-6 leading-tight drop-shadow-lg"
                variants={itemVariants}
              >
                Advancing Humanity Through Innovation
              </motion.h1>
              <motion.p
                className="text-lg md:text-xl text-white mb-6 md:mb-8 max-w-2xl drop-shadow-lg"
                variants={itemVariants}
              >
                We're on a mission to solve humanity's greatest challenges
                through groundbreaking research, strategic investments, and
                educational initiatives.
              </motion.p>
              <motion.div
                className="flex flex-col sm:flex-row items-start space-y-4 sm:space-y-0 sm:space-x-4"
                variants={itemVariants}
              >
                <Link to="/work/research-development">
                  <a className="hero-button hero-button-primary">
                    Explore Our Work
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </a>
                </Link>
                <Link to="/about">
                  <a className="hero-button hero-button-outline">
                    <ExternalLink className="mr-2 h-4 w-4" /> Learn About Us
                  </a>
                </Link>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
      
      {/* Mobile compatibility div to ensure content renders on Samsung devices */}
      <div className="block md:hidden">
        <div className="opacity-0 h-0 overflow-hidden">
          {/* Force browser to calculate layout for these elements */}
          <div className="flex flex-col">
            <h1>Nynexa Foundation</h1>
            <p>Ensuring mobile compatibility</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VideoHeroSection;
