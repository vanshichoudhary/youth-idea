import React from "react";
import { Link, useLocation } from "react-router-dom";
import { ChevronRight, Home } from "lucide-react";

interface BreadcrumbsProps {
  overrides?: Record<string, string>;
  homeLabel?: string;
  className?: string;
}

const Breadcrumbs: React.FC<BreadcrumbsProps> = ({
  overrides = {},
  homeLabel = "Home",
  className = "",
}) => {
  const location = useLocation();
  const pathnames = location.pathname.split("/").filter((x) => x);

  // Format a path segment for display
  const formatPathname = (pathname: string): string => {
    // Check if there's an override for this pathname
    if (overrides[pathname]) {
      return overrides[pathname];
    }

    // Otherwise, format it by replacing hyphens with spaces and capitalizing each word
    return pathname
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  return (
    <nav
      className={`flex items-center text-sm text-gray-500 py-4 ${className}`}
      aria-label="Breadcrumb"
    >
      <ol className="flex items-center flex-wrap">
        <li className="flex items-center">
          <Link
            to="/"
            className="flex items-center hover:text-black transition-colors"
          >
            <Home className="h-4 w-4 mr-1" />
            <span>{homeLabel}</span>
          </Link>
        </li>

        {pathnames.map((pathname, index) => {
          // Build the path up to this point
          const routeTo = `/${pathnames.slice(0, index + 1).join("/")}`;
          const isLast = index === pathnames.length - 1;

          return (
            <li key={pathname} className="flex items-center">
              <ChevronRight className="h-4 w-4 mx-2 text-gray-400" />
              {isLast ? (
                <span className="font-medium text-gray-900">
                  {formatPathname(pathname)}
                </span>
              ) : (
                <Link
                  to={routeTo}
                  className="hover:text-black transition-colors"
                >
                  {formatPathname(pathname)}
                </Link>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
};

export default Breadcrumbs;
