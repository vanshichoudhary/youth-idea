import React from "react";
import { motion } from "framer-motion";

interface LoadingSpinnerProps {
  size?: "sm" | "md" | "lg";
  color?: "default" | "primary" | "secondary";
  text?: string;
  fullScreen?: boolean;
}

const LoadingSpinner = ({
  size = "md",
  color = "default",
  text,
  fullScreen = false,
}: LoadingSpinnerProps) => {
  // Size mappings
  const sizeMap = {
    sm: {
      container: "h-8 w-8",
      dot: "h-1.5 w-1.5",
    },
    md: {
      container: "h-12 w-12",
      dot: "h-2 w-2",
    },
    lg: {
      container: "h-16 w-16",
      dot: "h-3 w-3",
    },
  };

  // Color mappings
  const colorMap = {
    default: "bg-black",
    primary: "bg-black-800",
    secondary: "bg-gray-600",
  };

  // Container variants based on fullScreen prop
  const containerClass = fullScreen
    ? "fixed inset-0 flex items-center justify-center bg-white/80 backdrop-blur-sm z-50"
    : "flex items-center justify-center";

  const textClass = fullScreen
    ? "mt-6 text-lg font-medium text-black"
    : "mt-3 text-sm font-medium text-black";

  // Animation variants
  const containerVariants = {
    animate: {
      transition: {
        staggerChildren: 0.12,
      },
    },
  };

  const dotVariants = {
    initial: {
      y: 0,
      opacity: 0.2,
    },
    animate: {
      y: [0, -10, 0],
      opacity: [0.2, 1, 0.2],
      transition: {
        repeat: Infinity,
        duration: 1,
      },
    },
  };

  return (
    <div className={containerClass}>
      <div className="flex flex-col items-center justify-center">
        <motion.div
          className={`relative ${sizeMap[size].container}`}
          variants={containerVariants}
          initial="initial"
          animate="animate"
        >
          {[...Array(4)].map((_, i) => (
            <motion.span
              key={i}
              className={`absolute ${sizeMap[size].dot} ${colorMap[color]} rounded-full`}
              style={{
                left: "50%",
                top: "50%",
                transform: `rotate(${i * 90}deg) translateX(${parseInt(sizeMap[size].container.split(" ")[1].split("-")[1]) / 2 - 2}px)`,
                transformOrigin: "0 0",
              }}
              variants={dotVariants}
            />
          ))}
        </motion.div>
        {text && <p className={textClass}>{text}</p>}
      </div>
    </div>
  );
};

export default LoadingSpinner; 