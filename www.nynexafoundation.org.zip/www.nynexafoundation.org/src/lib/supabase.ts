import { createClient } from "@supabase/supabase-js";
import { Database } from "@/types/supabase";

// Use environment variables with fallback values for development
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://example.supabase.co";
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "mock-key-for-development";

// Warning only shown in development
if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
  console.warn("Using mock Supabase configuration. Auth functionality will be limited.");
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);
