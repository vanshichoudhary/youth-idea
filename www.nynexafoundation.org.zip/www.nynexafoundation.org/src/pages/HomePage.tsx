import React, { useEffect } from "react";
import { motion, useAnimation } from "framer-motion";
import { useInView } from "react-intersection-observer";
import MainLayout from "@/components/layout/MainLayout";
import VideoHeroSection from "@/components/sections/VideoHeroSection";
import IntroductionSection from "@/components/sections/IntroductionSection";
import CorePillarsSection from "@/components/sections/CorePillarsSection";
import ImpactHighlightsSection from "@/components/sections/ImpactHighlightsSection";
import NewsFeedSection from "@/components/sections/NewsFeedSection";
import CallToActionSection from "@/components/sections/CallToActionSection";
import SEO from "@/components/shared/SEO";

const HomePage = () => {
  const controls = useAnimation();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  useEffect(() => {
    if (inView) {
      controls.start("visible");
    }
  }, [controls, inView]);

  return (
    <MainLayout>
      <SEO
        title="Advancing Humanity Through Innovation"
        description="The Nynexa Foundation is dedicated to advancing humanity through groundbreaking research, strategic investments, and educational initiatives."
        keywords="innovation, research, education, philanthropy, technology, science, STEM"
      />

      <VideoHeroSection />

      <motion.div
        ref={ref}
        animate={controls}
        initial="hidden"
        variants={{
          visible: {
            opacity: 1,
            y: 0,
            transition: {
              duration: 0.5,
              staggerChildren: 0.3,
            },
          },
          hidden: { opacity: 0, y: 50 },
        }}
      >
        <IntroductionSection />
        <CorePillarsSection />
        <ImpactHighlightsSection />
        <NewsFeedSection />
        <CallToActionSection />
      </motion.div>
    </MainLayout>
  );
};

export default HomePage;
