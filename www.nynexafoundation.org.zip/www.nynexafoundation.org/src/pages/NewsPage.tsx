import React, { useState } from "react";
import { motion } from "framer-motion";
import MainLayout from "@/components/layout/MainLayout";
import PageHeader from "@/components/shared/PageHeader";
import Breadcrumbs from "@/components/shared/Breadcrumbs";
import SEO from "@/components/shared/SEO";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import NewsCard from "@/components/cards/NewsCard";
import { Search, Filter, Calendar } from "lucide-react";

interface NewsItem {
  id: string;
  title: string;
  date: string;
  excerpt: string;
  imageUrl: string;
  category: string;
  link: string;
}

const NewsPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const newsItems: NewsItem[] = [
    {
      id: "1",
      title: "Nynexa Foundation Launches New Research Initiative",
      date: "April 15, 2023",
      excerpt:
        "The Nynexa Foundation announces a groundbreaking research initiative focused on sustainable technologies and their global implementation.",
      imageUrl:
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800&q=80",
      category: "Research & Development",
      link: "/news/research-initiative",
    },
    {
      id: "2",
      title: "Annual Billionaire Summit Addresses Global Challenges",
      date: "March 28, 2023",
      excerpt:
        "Leading philanthropists and innovators gathered at the exclusive Nynexa Billionaire Summit to discuss collaborative approaches to solving humanity's most pressing issues.",
      imageUrl:
        "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&q=80",
      category: "Billionaire Fund",
      link: "/news/billionaire-summit",
    },
    {
      id: "3",
      title: "Nynexa Academy Opens Applications for Fall Semester",
      date: "March 10, 2023",
      excerpt:
        "The prestigious Nynexa Academy is now accepting applications for its innovative STEM programs designed to nurture the next generation of visionary leaders.",
      imageUrl:
        "https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=800&q=80",
      category: "Education & STEM",
      link: "/news/academy-applications",
    },
    {
      id: "4",
      title: "Breakthrough in Longevity Research Funded by Nynexa",
      date: "February 22, 2023",
      excerpt:
        "Scientists supported by the Nynexa Foundation have identified a key cellular pathway that could significantly extend human healthspan.",
      imageUrl:
        "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=800&q=80",
      category: "Research & Development",
      link: "/news/longevity-breakthrough",
    },
    {
      id: "5",
      title: "Nynexa Foundation Partners with Global Universities",
      date: "February 15, 2023",
      excerpt:
        "New academic partnerships will accelerate research and create opportunities for talented students worldwide.",
      imageUrl:
        "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800&q=80",
      category: "Partnerships",
      link: "/news/university-partnerships",
    },
    {
      id: "6",
      title: "AI for Climate Solutions Initiative Launches",
      date: "January 30, 2023",
      excerpt:
        "The Nynexa Foundation announces a new program leveraging artificial intelligence to address climate change challenges.",
      imageUrl:
        "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80",
      category: "Research & Development",
      link: "/news/ai-climate-initiative",
    },
    {
      id: "7",
      title: "Nynexa Foundation Releases Annual Impact Report",
      date: "January 15, 2023",
      excerpt:
        "The report highlights significant progress across all three pillars of the Foundation's work during the past year.",
      imageUrl:
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80",
      category: "Foundation Updates",
      link: "/news/annual-report-2022",
    },
    {
      id: "8",
      title: "Global STEM Education Initiative Reaches 100,000 Students",
      date: "December 12, 2022",
      excerpt:
        "The Nynexa Foundation's flagship education program has now impacted students across 25 countries.",
      imageUrl:
        "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800&q=80",
      category: "Education & STEM",
      link: "/news/stem-initiative-milestone",
    },
    {
      id: "9",
      title: "Nynexa Foundation Welcomes New Board Members",
      date: "November 28, 2022",
      excerpt:
        "Three distinguished leaders in science, technology, and philanthropy join the Foundation's Board of Directors.",
      imageUrl:
        "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=800&q=80",
      category: "Foundation Updates",
      link: "/news/new-board-members",
    },
  ];

  const categories = [
    "All",
    ...new Set(newsItems.map((item) => item.category)),
  ];

  const filteredNews = newsItems.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory =
      selectedCategory === "All" || item.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  return (
    <MainLayout>
      <SEO
        title="News & Insights"
        description="Stay informed about the latest news, events, and insights from the Nynexa Foundation."
        keywords="Nynexa Foundation news, updates, press releases, events, insights, announcements"
      />

      <PageHeader
        title="News & Insights"
        subtitle="Stay informed about our latest initiatives, breakthroughs, and events"
        backgroundImage="https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=1920&q=80"
      />

      <div className="container mx-auto px-4 py-12">
        <Breadcrumbs
          overrides={{
            news: "News & Insights",
          }}
        />

        <div className="max-w-7xl mx-auto">
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex flex-col md:flex-row gap-4 mb-8">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Search news..."
                  className="pl-10 py-6 border-gray-300"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <div className="relative">
                <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <select
                  className="pl-10 py-2 pr-8 border border-gray-300 rounded-md bg-white h-12 w-full md:w-64 appearance-none focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                >
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                  <svg
                    className="w-5 h-5 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M19 9l-7 7-7-7"
                    ></path>
                  </svg>
                </div>
              </div>
            </div>

            {filteredNews.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                {filteredNews.map((news, index) => (
                  <motion.div
                    key={news.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <NewsCard
                      title={news.title}
                      date={news.date}
                      excerpt={news.excerpt}
                      imageUrl={news.imageUrl}
                      category={news.category}
                      link={news.link}
                    />
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <p className="text-gray-600 mb-4">
                  No news articles matching your criteria.
                </p>
                <Button
                  variant="outline"
                  className="border-purple-700 text-purple-700 hover:bg-purple-50"
                  onClick={() => {
                    setSearchTerm("");
                    setSelectedCategory("All");
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            )}

            <div className="flex justify-center">
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  className="border-gray-300 text-gray-600"
                  disabled
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  className="border-purple-700 bg-purple-700 text-white hover:bg-purple-800"
                >
                  1
                </Button>
                <Button
                  variant="outline"
                  className="border-gray-300 text-gray-600 hover:border-purple-700 hover:text-purple-700"
                >
                  2
                </Button>
                <Button
                  variant="outline"
                  className="border-gray-300 text-gray-600 hover:border-purple-700 hover:text-purple-700"
                >
                  3
                </Button>
                <Button
                  variant="outline"
                  className="border-gray-300 text-gray-600 hover:border-purple-700 hover:text-purple-700"
                >
                  Next
                </Button>
              </div>
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mt-16"
          >
            <h2 className="text-2xl font-bold text-purple-900 mb-6">
              Upcoming Events
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
                <div className="flex items-center text-purple-700 mb-3">
                  <Calendar className="h-5 w-5 mr-2" />
                  <span className="text-sm font-medium">May 15-17, 2023</span>
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">
                  Nynexa Global Innovation Summit
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  New York, NY & Virtual
                </p>
                <p className="text-gray-600 mb-4">
                  Join leaders from science, technology, business, and policy to
                  explore solutions to humanity's greatest challenges.
                </p>
                <Button
                  variant="outline"
                  className="w-full border-purple-700 text-purple-700 hover:bg-purple-50"
                  asChild
                >
                  <a href="/events/innovation-summit">Learn More</a>
                </Button>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
                <div className="flex items-center text-purple-700 mb-3">
                  <Calendar className="h-5 w-5 mr-2" />
                  <span className="text-sm font-medium">June 8, 2023</span>
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">
                  AI Safety Symposium
                </h3>
                <p className="text-gray-600 text-sm mb-4">Virtual Event</p>
                <p className="text-gray-600 mb-4">
                  A virtual symposium exploring the latest research and
                  approaches to ensuring beneficial and safe artificial
                  intelligence.
                </p>
                <Button
                  variant="outline"
                  className="w-full border-purple-700 text-purple-700 hover:bg-purple-50"
                  asChild
                >
                  <a href="/events/ai-safety-symposium">Learn More</a>
                </Button>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
                <div className="flex items-center text-purple-700 mb-3">
                  <Calendar className="h-5 w-5 mr-2" />
                  <span className="text-sm font-medium">July 22-24, 2023</span>
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">
                  STEM Education Conference
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  Singapore & Virtual
                </p>
                <p className="text-gray-600 mb-4">
                  Educators, researchers, and innovators gather to share best
                  practices in STEM education for the 21st century.
                </p>
                <Button
                  variant="outline"
                  className="w-full border-purple-700 text-purple-700 hover:bg-purple-50"
                  asChild
                >
                  <a href="/events/stem-education-conference">Learn More</a>
                </Button>
              </div>
            </div>
          </motion.section>
        </div>
      </div>
    </MainLayout>
  );
};

export default NewsPage;
