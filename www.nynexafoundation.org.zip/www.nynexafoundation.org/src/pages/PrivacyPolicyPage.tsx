import React from "react";
import { motion } from "framer-motion";
import MainLayout from "@/components/layout/MainLayout";
import PageHeader from "@/components/shared/PageHeader";
import Breadcrumbs from "@/components/shared/Breadcrumbs";
import SEO from "@/components/shared/SEO";
import { Link } from "react-router-dom";

const PrivacyPolicyPage = () => {
  return (
    <MainLayout>
      <SEO
        title="Privacy Policy"
        description="Learn about the Nynexa Foundation's privacy practices, how we collect, use, and protect your personal information."
        keywords="Nynexa Foundation privacy policy, data protection, GDPR compliance, personal information, privacy practices"
      />

      <PageHeader
        title="Privacy Policy"
        subtitle="Our commitment to protecting your privacy"
        backgroundImage="https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=1920&q=80"
      />

      <div className="container mx-auto px-4 py-12">
        <Breadcrumbs
          overrides={{
            "privacy-policy": "Privacy Policy",
          }}
        />

        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="space-y-8 prose prose-lg max-w-none"
          >
            <p className="text-lg text-gray-600">
              Last Updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
            </p>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Introduction</h2>
              <p>
                The Nynexa Foundation ("we," "our," or "us") is committed to protecting your privacy. 
                This Privacy Policy explains how we collect, use, disclose, and safeguard your information 
                when you visit our website at {" "}
                <a href="https://nynexafoundation.org" className="text-black font-medium underline">
                  nynexafoundation.org
                </a>{" "}
                (the "Site") or engage with our services.
              </p>
              <p>
                We reserve the right to make changes to this Privacy Policy at any time and for any reason. 
                We will alert you about any changes by updating the "Last Updated" date of this Privacy Policy. 
                You are encouraged to periodically review this Privacy Policy to stay informed of updates.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Information We Collect</h2>
              
              <h3 className="text-xl font-semibold text-gray-900 mt-6">Personal Information</h3>
              <p>
                We may collect personal information that you voluntarily provide to us when you:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Register for an account</li>
                <li>Sign up for our newsletter</li>
                <li>Make a donation</li>
                <li>Fill out a contact form</li>
                <li>Apply for programs or funding</li>
                <li>Participate in surveys or research</li>
              </ul>
              <p>
                The personal information we may collect includes:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Name</li>
                <li>Email address</li>
                <li>Mailing address</li>
                <li>Phone number</li>
                <li>Demographic information</li>
                <li>Payment information (for donations)</li>
                <li>Professional background (for applications)</li>
                <li>Educational information (for applications)</li>
              </ul>

              <h3 className="text-xl font-semibold text-gray-900 mt-6">Automatically Collected Information</h3>
              <p>
                When you access our Site, we may automatically collect certain information about your device, including:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>IP address</li>
                <li>Browser type</li>
                <li>Operating system</li>
                <li>Device information</li>
                <li>Pages visited</li>
                <li>Time and date of visits</li>
                <li>Referring website</li>
                <li>Other statistics</li>
              </ul>
              <p>
                This information is collected using cookies, web beacons, and other tracking technologies. 
                For more information about our use of cookies, please see our {" "}
                <Link to="/cookie-policy" className="text-black font-medium underline">
                  Cookie Policy
                </Link>.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">How We Use Your Information</h2>
              <p>
                We may use the information we collect for various purposes, including:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Providing, maintaining, and improving our Site and services</li>
                <li>Processing donations and sending receipts</li>
                <li>Sending newsletters and updates about our work</li>
                <li>Responding to inquiries and providing support</li>
                <li>Evaluating applications for programs and funding</li>
                <li>Conducting research and analysis to better understand our audience</li>
                <li>Complying with legal obligations</li>
                <li>Preventing fraudulent activity</li>
                <li>Protecting our rights and the rights of others</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Disclosure of Your Information</h2>
              <p>
                We may share your information with third parties in certain situations, including:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>With service providers who perform services on our behalf</li>
                <li>With partner organizations for collaborative programs (with your consent)</li>
                <li>When required by law or to protect our rights</li>
                <li>In connection with a merger, acquisition, or sale of assets</li>
                <li>With your consent or at your direction</li>
              </ul>
              <p>
                We do not sell, rent, or trade your personal information to third parties for marketing purposes.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Your Privacy Rights</h2>
              <p>
                Depending on your location, you may have certain rights regarding your personal information, including:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>The right to access personal information we hold about you</li>
                <li>The right to request correction of inaccurate information</li>
                <li>The right to request deletion of your information</li>
                <li>The right to restrict or object to processing</li>
                <li>The right to data portability</li>
                <li>The right to withdraw consent</li>
              </ul>
              <p>
                To exercise these rights, please contact us using the information provided in the "Contact Us" section below.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Data Security</h2>
              <p>
                We implement appropriate technical and organizational measures to protect your personal information 
                from unauthorized access, disclosure, alteration, or destruction. However, no data transmission over 
                the Internet or storage system can be guaranteed to be 100% secure. If you have reason to believe 
                that your interaction with us is no longer secure, please immediately notify us using the contact 
                information provided below.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Third-Party Websites</h2>
              <p>
                Our Site may contain links to third-party websites that are not owned or controlled by us. 
                We have no control over, and assume no responsibility for, the content, privacy policies, 
                or practices of any third-party websites or services. We encourage you to be aware when you 
                leave our Site and to read the privacy policies of each website you visit.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Children's Privacy</h2>
              <p>
                Our Site is not intended for children under the age of 16. We do not knowingly collect personal 
                information from children under 16. If you are a parent or guardian and believe that your child 
                has provided us with personal information, please contact us, and we will take steps to delete 
                such information.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">International Data Transfers</h2>
              <p>
                Your information may be transferred to, and maintained on, computers located outside of your state, 
                province, country, or other governmental jurisdiction where the data protection laws may differ 
                from those in your jurisdiction. If you are located outside the United States and choose to provide 
                information to us, please note that we transfer the information to the United States and process it there.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">Contact Us</h2>
              <p>
                If you have any questions or concerns about this Privacy Policy or our privacy practices, 
                please contact us at:
              </p>
              <div className="mt-2">
                <p>Nynexa Foundation</p>
                <p>123 Innovation Way</p>
                <p>New York, NY 10001</p>
                <p>United States</p>
                <p>
                  <a href="mailto:privacy@nynexafoundation.org" className="text-black font-medium underline">
                    privacy@nynexafoundation.org
                  </a>
                </p>
              </div>
            </section>
          </motion.div>
        </div>
      </div>
    </MainLayout>
  );
};

export default PrivacyPolicyPage; 