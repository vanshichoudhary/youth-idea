import React from "react";
import { motion } from "framer-motion";
import MainLayout from "@/components/layout/MainLayout";
import PageHeader from "@/components/shared/PageHeader";
import Breadcrumbs from "@/components/shared/Breadcrumbs";
import SEO from "@/components/shared/SEO";
import { Link } from "react-router-dom";

const TermsOfUsePage = () => {
  return (
    <MainLayout>
      <SEO
        title="Terms of Use"
        description="Review the Nynexa Foundation's Terms of Use, which govern your access to and use of our website and services."
        keywords="Nynexa Foundation terms, terms of use, terms and conditions, user agreement, legal terms"
      />

      <PageHeader
        title="Terms of Use"
        subtitle="Guidelines for using our website and services"
        backgroundImage="https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?w=1920&q=80"
      />

      <div className="container mx-auto px-4 py-12">
        <Breadcrumbs
          overrides={{
            "terms-of-use": "Terms of Use",
          }}
        />

        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="space-y-8 prose prose-lg max-w-none"
          >
            <p className="text-lg text-gray-600">
              Last Updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
            </p>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">1. Acceptance of Terms</h2>
              <p>
                Welcome to the Nynexa Foundation website. By accessing and using our website at{" "}
                <a href="https://nynexafoundation.org" className="text-black font-medium underline">
                  nynexafoundation.org
                </a>{" "}
                (the "Site"), you accept and agree to be bound by these Terms of Use. If you do not agree to these 
                Terms of Use, please do not use our Site.
              </p>
              <p>
                We reserve the right to change these Terms of Use at any time without prior notice. Your continued 
                use of the Site following the posting of changes to these Terms of Use will be considered your 
                acceptance of those changes.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">2. Intellectual Property Rights</h2>
              <p>
                The Site and its entire content, features, and functionality (including but not limited to all 
                information, text, images, videos, and the design, selection, and arrangement thereof) are owned 
                by the Nynexa Foundation, its licensors, or other providers of such material, and are protected 
                by United States and international copyright, trademark, patent, trade secret, and other 
                intellectual property or proprietary rights laws.
              </p>
              <p>
                These Terms of Use permit you to use the Site for your personal, non-commercial use only. You may 
                not reproduce, distribute, modify, create derivative works of, publicly display, publicly perform, 
                republish, download, store, or transmit any of the material on our Site, except as follows:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Your computer may temporarily store copies of such materials in RAM incidental to your accessing and viewing those materials.</li>
                <li>You may store files that are automatically cached by your web browser for display enhancement purposes.</li>
                <li>You may print or download one copy of a reasonable number of pages of the Site for your own personal, non-commercial use and not for further reproduction, publication, or distribution.</li>
                <li>If we provide social media features with certain content, you may take such actions as are enabled by such features.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">3. Prohibited Uses</h2>
              <p>
                You may use the Site only for lawful purposes and in accordance with these Terms of Use. You agree not to use the Site:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>In any way that violates any applicable federal, state, local, or international law or regulation.</li>
                <li>For the purpose of exploiting, harming, or attempting to exploit or harm minors in any way.</li>
                <li>To send, knowingly receive, upload, download, use, or re-use any material that does not comply with the standards set out in these Terms of Use.</li>
                <li>To transmit, or procure the sending of, any advertising or promotional material, including any "junk mail," "chain letter," "spam," or any other similar solicitation.</li>
                <li>To impersonate or attempt to impersonate the Nynexa Foundation, a Nynexa Foundation employee, another user, or any other person or entity.</li>
                <li>To engage in any other conduct that restricts or inhibits anyone's use or enjoyment of the Site, or which may harm the Nynexa Foundation or users of the Site or expose them to liability.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">4. User Contributions</h2>
              <p>
                The Site may contain message boards, chat rooms, personal profiles, forums, bulletin boards, and other 
                interactive features (collectively, "Interactive Services") that allow users to post, submit, publish, 
                display, or transmit to other users or other persons (hereinafter, "post") content or materials 
                (collectively, "User Contributions") on or through the Site.
              </p>
              <p>
                All User Contributions must comply with the Content Standards set out in these Terms of Use. Any User 
                Contribution you post to the Site will be considered non-confidential and non-proprietary. By providing 
                any User Contribution on the Site, you grant us and our affiliates and service providers, and each of 
                their respective licensees, successors, and assigns the right to use, reproduce, modify, perform, display, 
                distribute, and otherwise disclose to third parties any such material.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">5. Content Standards</h2>
              <p>
                These content standards apply to any and all User Contributions and use of Interactive Services. User 
                Contributions must in their entirety comply with all applicable federal, state, local, and international 
                laws and regulations.
              </p>
              <p>
                Without limiting the foregoing, User Contributions must not:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Contain any material that is defamatory, obscene, indecent, abusive, offensive, harassing, violent, hateful, inflammatory, or otherwise objectionable.</li>
                <li>Promote sexually explicit or pornographic material, violence, or discrimination based on race, sex, religion, nationality, disability, sexual orientation, or age.</li>
                <li>Infringe any patent, trademark, trade secret, copyright, or other intellectual property or other rights of any other person.</li>
                <li>Violate the legal rights (including the rights of publicity and privacy) of others or contain any material that could give rise to any civil or criminal liability under applicable laws or regulations.</li>
                <li>Be likely to deceive any person.</li>
                <li>Promote any illegal activity, or advocate, promote, or assist any unlawful act.</li>
                <li>Impersonate any person, or misrepresent your identity or affiliation with any person or organization.</li>
                <li>Involve commercial activities or sales, such as contests, sweepstakes, and other sales promotions, barter, or advertising.</li>
                <li>Give the impression that they emanate from or are endorsed by us or any other person or entity, if this is not the case.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">6. Reliance on Information Posted</h2>
              <p>
                The information presented on or through the Site is made available solely for general information purposes. 
                We do not warrant the accuracy, completeness, or usefulness of this information. Any reliance you place on 
                such information is strictly at your own risk. We disclaim all liability and responsibility arising from 
                any reliance placed on such materials by you or any other visitor to the Site, or by anyone who may be 
                informed of any of its contents.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">7. Links to Other Websites</h2>
              <p>
                The Site may contain links to other websites that are not operated by us. If you click on a third-party link, 
                you will be directed to that third party's site. We strongly advise you to review the Privacy Policy and 
                terms of service of every site you visit.
              </p>
              <p>
                We have no control over and assume no responsibility for the content, privacy policies, or practices of any 
                third-party sites or services. We do not warrant or make any representations regarding the use or the 
                results of the use of the materials on any linked sites in terms of their correctness, accuracy, 
                reliability, or otherwise.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">8. Disclaimer of Warranties</h2>
              <p>
                You understand that we cannot and do not guarantee or warrant that files available for downloading from the 
                internet or the Site will be free of viruses or other destructive code. You are responsible for implementing 
                sufficient procedures and checkpoints to satisfy your particular requirements for anti-virus protection and 
                accuracy of data input and output, and for maintaining a means external to our site for any reconstruction 
                of any lost data.
              </p>
              <p>
                TO THE FULLEST EXTENT PROVIDED BY LAW, WE WILL NOT BE LIABLE FOR ANY LOSS OR DAMAGE CAUSED BY A DISTRIBUTED 
                DENIAL-OF-SERVICE ATTACK, VIRUSES, OR OTHER TECHNOLOGICALLY HARMFUL MATERIAL THAT MAY INFECT YOUR COMPUTER 
                EQUIPMENT, COMPUTER PROGRAMS, DATA, OR OTHER PROPRIETARY MATERIAL DUE TO YOUR USE OF THE SITE OR ANY 
                SERVICES OR ITEMS OBTAINED THROUGH THE SITE OR TO YOUR DOWNLOADING OF ANY MATERIAL POSTED ON IT, OR ON 
                ANY WEBSITE LINKED TO IT.
              </p>
              <p>
                YOUR USE OF THE SITE, ITS CONTENT, AND ANY SERVICES OR ITEMS OBTAINED THROUGH THE SITE IS AT YOUR OWN RISK. 
                THE SITE, ITS CONTENT, AND ANY SERVICES OR ITEMS OBTAINED THROUGH THE SITE ARE PROVIDED ON AN "AS IS" AND 
                "AS AVAILABLE" BASIS, WITHOUT ANY WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">9. Limitation of Liability</h2>
              <p>
                TO THE FULLEST EXTENT PROVIDED BY LAW, IN NO EVENT WILL THE NYNEXA FOUNDATION, ITS AFFILIATES, OR THEIR 
                LICENSORS, SERVICE PROVIDERS, EMPLOYEES, AGENTS, OFFICERS, OR DIRECTORS BE LIABLE FOR DAMAGES OF ANY KIND, 
                UNDER ANY LEGAL THEORY, ARISING OUT OF OR IN CONNECTION WITH YOUR USE, OR INABILITY TO USE, THE SITE, ANY 
                WEBSITES LINKED TO IT, ANY CONTENT ON THE SITE OR SUCH OTHER WEBSITES, INCLUDING ANY DIRECT, INDIRECT, 
                SPECIAL, INCIDENTAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">10. Indemnification</h2>
              <p>
                You agree to defend, indemnify, and hold harmless the Nynexa Foundation, its affiliates, licensors, and 
                service providers, and its and their respective officers, directors, employees, contractors, agents, 
                licensors, suppliers, successors, and assigns from and against any claims, liabilities, damages, judgments, 
                awards, losses, costs, expenses, or fees (including reasonable attorneys' fees) arising out of or relating 
                to your violation of these Terms of Use or your use of the Site.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">11. Governing Law</h2>
              <p>
                These Terms of Use and any dispute or claim arising out of, or related to, them, their subject matter, or 
                their formation shall be governed by and construed in accordance with the laws of the State of New York, 
                without giving effect to any choice or conflict of law provisions.
              </p>
              <p>
                Any legal suit, action, or proceeding arising out of, or related to, these Terms of Use or the Site shall 
                be instituted exclusively in the federal courts of the United States or the courts of the State of New York. 
                You waive any and all objections to the exercise of jurisdiction over you by such courts and to venue in 
                such courts.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">12. Severability</h2>
              <p>
                If any provision of these Terms of Use is held by a court or other tribunal of competent jurisdiction to be 
                invalid, illegal, or unenforceable for any reason, such provision shall be eliminated or limited to the 
                minimum extent such that the remaining provisions of the Terms of Use will continue in full force and effect.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900">13. Contact Information</h2>
              <p>
                If you have any questions or concerns about these Terms of Use, please contact us at:
              </p>
              <div className="mt-2">
                <p>Nynexa Foundation</p>
                <p>123 Innovation Way</p>
                <p>New York, NY 10001</p>
                <p>United States</p>
                <p>
                  <a href="mailto:legal@nynexafoundation.org" className="text-black font-medium underline">
                    legal@nynexafoundation.org
                  </a>
                </p>
              </div>
            </section>
          </motion.div>
        </div>
      </div>
    </MainLayout>
  );
};

export default TermsOfUsePage; 