/**
 * Samsung Mobile Device Detection and Fix
 * 
 * This utility detects Samsung devices and applies specific fixes for the known layout issues
 * on devices like Samsung Note 20 Ultra where content may not display properly.
 */

// Detect if the current device is a Samsung mobile device
export const isSamsungDevice = () => {
    if (typeof navigator === 'undefined') return false;

    const ua = navigator.userAgent.toLowerCase();
    return ua.includes('samsung') ||
        (ua.includes('android') && ua.includes('sm-')) ||
        (ua.includes('android') && ua.includes('galaxy'));
};

// Apply Samsung-specific fixes to ensure content displays correctly
export const applySamsungFixes = () => {
    if (!isSamsungDevice()) return false;

    // Add a class to the body to enable Samsung-specific CSS
    if (typeof document !== 'undefined') {
        document.body.classList.add('is-samsung-device');

        // Force a reflow/rerender of all sections
        const sections = document.querySelectorAll('section, main > div, [data-motion], [data-animate]');

        sections.forEach(section => {
            // Force layout recalculation
            section.style.display = 'block';
            section.style.visibility = 'visible';
            section.style.opacity = '1';

            // Create and append a dummy element to force reflow
            const dummy = document.createElement('div');
            dummy.className = 'force-render';
            dummy.setAttribute('aria-hidden', 'true');
            dummy.innerHTML = '<!-- Force Samsung layout recalculation -->';
            section.appendChild(dummy);

            // Force a layout calculation by accessing offsetHeight
            void section.offsetHeight;

            // Apply content-visibility explicitly
            section.style.contentVisibility = 'visible';
            section.classList.add('force-content-visibility');
        });

        // Create additional invisible elements at the beginning and end of main content
        // to ensure proper rendering in the Samsung browser engine
        const main = document.querySelector('main');
        if (main) {
            const startMarker = document.createElement('div');
            startMarker.className = 'samsung-render-fix start';
            startMarker.setAttribute('aria-hidden', 'true');
            startMarker.style.height = '1px';
            startMarker.style.width = '100%';
            startMarker.style.display = 'block';

            const endMarker = document.createElement('div');
            endMarker.className = 'samsung-render-fix end';
            endMarker.setAttribute('aria-hidden', 'true');
            endMarker.style.height = '1px';
            endMarker.style.width = '100%';
            endMarker.style.display = 'block';

            main.insertBefore(startMarker, main.firstChild);
            main.appendChild(endMarker);
        }

        return true;
    }

    return false;
};

// Initialize the Samsung device detection and apply fixes
export const initMobileFixes = () => {
    // Run on the client side only
    if (typeof window === 'undefined') return;

    // Apply fixes on load and after any navigation
    const applyFixes = () => {
        if (isSamsungDevice()) {
            console.log('Samsung device detected, applying fixes');
            applySamsungFixes();

            // Set a timeout to re-apply fixes after a delay (helps with dynamic content)
            setTimeout(() => {
                applySamsungFixes();
            }, 500);
        }
    };

    // Add event listeners
    window.addEventListener('load', applyFixes);

    // Handle SPA navigation if using React Router or similar
    if (typeof window.history !== 'undefined') {
        const originalPushState = window.history.pushState;
        window.history.pushState = function() {
            originalPushState.apply(this, arguments);
            setTimeout(applyFixes, 100);
        };

        window.addEventListener('popstate', () => {
            setTimeout(applyFixes, 100);
        });
    }

    // Initialize immediately
    applyFixes();
};

export default {
    isSamsungDevice,
    applySamsungFixes,
    initMobileFixes
};