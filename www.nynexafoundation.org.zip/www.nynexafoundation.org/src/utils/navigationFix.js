/**
 * Navigation Fix Utility
 * 
 * This utility ensures smooth page transitions and layout fixes after navigation events,
 * particularly for Samsung devices where content sometimes fails to render correctly.
 */

import {
    isSamsungDevice,
    applySamsungFixes
} from './mobileFix';

// Track if navigation is in progress
let navigationInProgress = false;

// Apply fixes after navigation events (route changes)
export const fixAfterNavigation = () => {
    // Only run on the client side
    if (typeof window === 'undefined') return;

    // Mark navigation as in progress
    navigationInProgress = true;

    // Apply Samsung-specific fixes if needed
    if (isSamsungDevice()) {
        console.log('Navigation detected on Samsung device, ensuring content visibility');

        // Schedule multiple fixes to ensure content loads properly
        const applyFixWithDelay = (delay) => {
            setTimeout(() => {
                applySamsungFixes();

                // Force visibility of all sections
                const sections = document.querySelectorAll('section, main > div, article');
                sections.forEach(section => {
                    if (section instanceof HTMLElement) {
                        section.style.visibility = 'visible';
                        section.style.display = 'block';
                        section.style.opacity = '1';
                    }
                });

                // Find any animation containers and ensure they're visible
                const animationContainers = document.querySelectorAll('[data-motion], [data-animate]');
                animationContainers.forEach(container => {
                    if (container instanceof HTMLElement) {
                        container.style.visibility = 'visible';
                        container.style.display = 'block';
                        container.style.opacity = '1';
                    }
                });

                // Mark navigation as complete after the last fix is applied
                if (delay === 1500) {
                    navigationInProgress = false;
                }
            }, delay);
        };

        // Apply fixes at multiple intervals to catch all content loading stages
        [0, 100, 300, 800, 1500].forEach(applyFixWithDelay);
    } else {
        // For non-Samsung devices, just mark navigation as complete after a short delay
        setTimeout(() => {
            navigationInProgress = false;
        }, 300);
    }
};

// Hook into history API for SPA navigation
export const initNavigationFixes = () => {
    if (typeof window === 'undefined') return;

    // Patch history.pushState and history.replaceState
    const originalPushState = window.history.pushState;
    window.history.pushState = function() {
        originalPushState.apply(this, arguments);
        fixAfterNavigation();
    };

    const originalReplaceState = window.history.replaceState;
    window.history.replaceState = function() {
        originalReplaceState.apply(this, arguments);
        fixAfterNavigation();
    };

    // Listen for popstate events (back/forward navigation)
    window.addEventListener('popstate', fixAfterNavigation);

    // Check for hash changes (anchor navigation)
    window.addEventListener('hashchange', fixAfterNavigation);

    // Apply fixes on initial page load
    window.addEventListener('load', () => {
        fixAfterNavigation();
    });

    // Apply fixes when DOM content is loaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', fixAfterNavigation);
    } else {
        // DOM already loaded, apply immediately
        fixAfterNavigation();
    }
};

// Check if navigation is currently in progress
export const isNavigating = () => navigationInProgress;

export default {
    fixAfterNavigation,
    initNavigationFixes,
    isNavigating
};